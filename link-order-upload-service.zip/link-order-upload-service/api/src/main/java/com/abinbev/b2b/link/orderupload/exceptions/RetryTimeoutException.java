package com.abinbev.b2b.link.orderupload.exceptions;

import com.abinbev.b2b.link.orderupload.utilities.exceptions.GlobalException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.Issue;

public class RetryTimeoutException extends GlobalException {

	private static final long serialVersionUID = 3385547221138232680L;

	public RetryTimeoutException(final Issue issue) {
		super(issue);
	}

	public RetryTimeoutException(final Issue issue, final Exception ex) {
		super(issue, ex);
	}
//  
//  public static RetryTimeoutException retryTimeout() {
//    return new RetryTimeoutException(new Issue(IssueEnum.SERVICE_RETRY_TIMEOUT));
//  }
}
