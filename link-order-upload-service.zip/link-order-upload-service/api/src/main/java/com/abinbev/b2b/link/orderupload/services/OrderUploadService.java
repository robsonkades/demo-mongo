package com.abinbev.b2b.link.orderupload.services;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.abinbev.b2b.link.orderupload.dto.OrderDTO;
import com.abinbev.b2b.link.orderupload.exceptions.RetryTimeoutException;
import com.abinbev.b2b.link.orderupload.orderprocessor.OrderProcessorService;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.GlobalException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrderUploadService {
  
  @Value("${orderProcessor.retryTimeout}")
  private long retryTimeout;
  
  private final OrderProcessorService orderProcessorService;
  
  public OrderDTO upload(OrderDTO orderDTO) {
    OrderDTO orderDTOReturned = this.orderProcessorService.upload(orderDTO);
    
    LocalDateTime atStartOfProcess = LocalDateTime.now();
    
    while (orderDTOReturned.getOrderId() == null) {
      
      // Solução utilizada para a primeira versão com comunicação sincrona.
      // Com o sleep, foi reduzido o número de chamadas ao webpoint, mas que posteriormente será feito via mensageria.
      try {
        Thread.sleep(2000);
      } catch (InterruptedException e) {
        Thread.currentThread().interrupt();
        throw GlobalException.globalException();
      }
      
      log.info("Trying to obtain the order with id " + orderDTOReturned.getOrderIdProcessor() + ".");
      orderDTOReturned = this.orderProcessorService.getOrder(orderDTOReturned.getOrderIdProcessor());
      
      this.validateTimeout(atStartOfProcess);
      
    }
    
    return orderDTOReturned;
  }
  
  private void validateTimeout(LocalDateTime atStartOfProcess) {
    var now = LocalDateTime.now();
    long diff = ChronoUnit.SECONDS.between(atStartOfProcess, now);
    
    if (diff > retryTimeout) {
      throw RetryTimeoutException.retryTimeout();
    }    
  }

}
