package com.abinbev.b2b.link.orderupload.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.springframework.web.multipart.MultipartFile;

@Getter
@Builder
public class OrderDTO {

  @Setter private String orderId;

  @JsonIgnore private String orderIdProcessor;

  @JsonIgnore private UUID accountId;

  @JsonIgnore private Optional<MultipartFile> orderFile;

  private List<ItemDTO> items;

  public void addItem(ItemDTO itemDTO) {
    items.add(itemDTO);
  }
}
