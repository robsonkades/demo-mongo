package com.abinbev.b2b.link.orderupload.interceptors;

import com.abinbev.b2b.link.orderupload.properties.LogProperties;
import com.abinbev.b2b.link.orderupload.utilities.helpers.Constants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.http.server.ServletServerHttpResponse;
import org.springframework.lang.NonNull;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

@Slf4j
@ControllerAdvice
public class CustomResponseBodyAdviceAdapter implements ResponseBodyAdvice<Object> {

  private final LogProperties logProperties;
  private final ObjectMapper objectMapper;

  public CustomResponseBodyAdviceAdapter(
      final LogProperties logProperties, final ObjectMapper objectMapper) {
    this.logProperties = logProperties;
    this.objectMapper = objectMapper;
  }

  @Override
  public boolean supports(
      @NonNull final MethodParameter methodParameter,
      @NonNull final Class<? extends HttpMessageConverter<?>> aClass) {
    return true;
  }

  @Override
  public Object beforeBodyWrite(
      final Object object,
      @NonNull final MethodParameter methodParameter,
      @NonNull final MediaType mediaType,
      @NonNull final Class<? extends HttpMessageConverter<?>> aClass,
      @NonNull final ServerHttpRequest serverHttpRequest,
      @NonNull final ServerHttpResponse serverHttpResponse) {

    if (serverHttpRequest instanceof ServletServerHttpRequest
        && serverHttpResponse instanceof ServletServerHttpResponse
        && shouldLogRequest(serverHttpRequest)) {

      try {

        if (object != null) {
          log.info(String.format("Response body %s", objectMapper.writeValueAsString(object)));
        }
      } catch (final JsonProcessingException e) {
        log.error("Error on parsing response body");
      }
      return object;
    }
    return object;
  }

  private boolean shouldLogRequest(final ServerHttpRequest request) {

    final HttpHeaders headers = request.getHeaders();
    var countryHeader = headers.get(Constants.COUNTRY_HEADER);

    if (countryHeader != null && !countryHeader.isEmpty()) {
      final String countryHeaderEntry = countryHeader.get(0);
      return logProperties.getEnabledTo().contains(countryHeaderEntry);
    }
    return false;
  }
}
