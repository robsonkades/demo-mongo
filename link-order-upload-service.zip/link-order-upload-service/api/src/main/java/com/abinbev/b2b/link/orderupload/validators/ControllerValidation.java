package com.abinbev.b2b.link.orderupload.validators;

import com.abinbev.b2b.link.orderupload.constants.ApiConstants;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.BadRequestException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.IssueEnum;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public interface ControllerValidation {

  static void validateHeaderRequestTraceId(final String headerName, final String value) {
    validateRequiredHeader(IssueEnum.REQUEST_TRACE_ID_NOT_VALID, headerName, value);
  }

  static void validateHeaderCountry(final String headerName, final String value) {

    final List<String> validCountries = Arrays.asList(Locale.getISOCountries());

    validateRequiredHeader(IssueEnum.COUNTRY_NOT_VALID, headerName, value);

    if (!validCountries.contains(value)) {
      throw BadRequestException.invalidParam(
          IssueEnum.COUNTRY_NOT_VALID,
          Collections.singletonList(
              String.format(ApiConstants.NOT_VALID_PARAM_ERROR_MSG, headerName)));
    }
  }

  private static void validateRequiredHeader(
      final IssueEnum issueType, final String headerName, final String value) {

    if (value == null || value.isBlank()) {
      throw BadRequestException.invalidParam(
          issueType,
          Collections.singletonList(
              String.format(ApiConstants.MANDATORY_PARAM_ERROR_MSG, headerName)));
    }
  }
}
