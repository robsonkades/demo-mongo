package com.abinbev.b2b.link.orderupload.constants;

public abstract class ServiceConstants {

  private ServiceConstants() {}

  public static final String NEW_RELIC_TRANSACTION_CATEGORY = "LinkOrderUploadService";

  public static final String SERVICE_UNAVAILABLE = "The server is temporarily unavailable.";
  
}
