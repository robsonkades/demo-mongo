package com.abinbev.b2b.link.orderupload.configs;

import com.abinbev.b2b.link.orderupload.interceptors.ControllerRequestInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;

@Configuration
public class WebMvcConfig extends WebMvcConfigurationSupport {

  private final ControllerRequestInterceptor controllerRequestInterceptor;

  public WebMvcConfig(final ControllerRequestInterceptor controllerRequestInterceptor) {
    this.controllerRequestInterceptor = controllerRequestInterceptor;
  }

  @Override
  protected void addInterceptors(final InterceptorRegistry registry) {
    registry.addInterceptor(controllerRequestInterceptor);
  }
}
