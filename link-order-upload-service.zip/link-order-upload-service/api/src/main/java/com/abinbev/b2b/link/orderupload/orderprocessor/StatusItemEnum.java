package com.abinbev.b2b.link.orderupload.orderprocessor;

public enum StatusItemEnum {
  PENDING("Pendente"), //
  PROCESSED("Processado");

  private final String status;

  StatusItemEnum(String status) {
    this.status = status;
  }

  @Override
  public String toString() {
    return this.status;
  }
}
