package com.abinbev.b2b.link.orderupload.services;

import java.time.OffsetDateTime;
import java.util.Optional;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.abinbev.b2b.link.orderupload.dto.OrderUploadResponse;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderStatus;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderUpload;
import com.abinbev.b2b.link.orderupload.utilities.domain.Provider;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.BadRequestException;
import com.abinbev.b2b.link.orderupload.utilities.helpers.RabbitUtil;
import com.abinbev.b2b.link.orderupload.utilities.interceptors.ContextHolder;
import com.abinbev.b2b.link.orderupload.utilities.messages.OrderMessage;
import com.abinbev.b2b.link.orderupload.utilities.services.SendMessageService;
import com.abinbev.b2b.link.orderupload.validators.ContentTypeValidation;

@Service
public class CreateOrderUploadService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CreateOrderUploadService.class);

	private final SaveOrderService saveOrderService;
	private final SendMessageService sendMessageService;
	private final GetProviderService getProviderService;
	private final ContentTypeValidation contentTypeValidation; 

	@Value("${message.exchanges.orderUpload}")
	protected String orderUploadExchangeName;

	public CreateOrderUploadService(final SaveOrderService saveOrderService,
			final SendMessageService sendMessageService,
			final GetProviderService getProviderService,
			final ContentTypeValidation contentTypeValidation) {
		this.saveOrderService = saveOrderService;
		this.sendMessageService = sendMessageService;
		this.getProviderService = getProviderService;
		this.contentTypeValidation = contentTypeValidation;
	}

	public OrderUploadResponse execute(UUID accountId, Optional<MultipartFile> fileOptional) {

		MultipartFile file = fileOptional.orElseThrow(BadRequestException::fileNotFound);	
		boolean isSupported = contentTypeValidation.isSupportedContentType(file.getContentType());
		
		if (!isSupported) {
			throw BadRequestException.invalidContentType();
		}
		
		var orderUploadProvider = getProviderService.getOrderUpload(Provider.WEDUU.name());
		var orderProcessorId = orderUploadProvider.execute(accountId, file);

		OrderUpload orderUpload = new OrderUpload();
		orderUpload.setAccountId(accountId.toString());
		orderUpload.setOrderId(UUID.randomUUID().toString());
		orderUpload.setProviderOrderId(orderProcessorId);
		orderUpload.setUpdatedAt(OffsetDateTime.now());
		orderUpload.setStatus(OrderStatus.PENDING);
		orderUpload.setProvider(Provider.WEDUU);

		OrderMessage orderMessage = new OrderMessage();
		orderMessage.setOrderId(orderUpload.getOrderId());
		orderMessage.setAccountId(orderUpload.getAccountId());
		orderMessage.setProvider(Provider.WEDUU);

		LOGGER.info("Create order with id {}", orderUpload.getOrderId());

		saveOrderService.execute(orderUpload);

		final String routingKey = RabbitUtil.buildRoutingKey(ContextHolder.getCountry());
		sendMessageService.execute(orderMessage, orderUploadExchangeName, routingKey);

		return new OrderUploadResponse(orderUpload.getOrderId(), orderUpload.getStatus());
	}
}
