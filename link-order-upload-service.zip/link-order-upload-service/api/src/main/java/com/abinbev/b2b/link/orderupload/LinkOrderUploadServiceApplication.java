package com.abinbev.b2b.link.orderupload;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@EnableCaching
@SpringBootApplication(scanBasePackages = "com.abinbev.b2b.link.orderupload")
public class LinkOrderUploadServiceApplication {

  public static void main(String[] args) {
    SpringApplication.run(LinkOrderUploadServiceApplication.class, args);
  }
}
