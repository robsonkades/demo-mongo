package com.abinbev.b2b.link.orderupload.exceptions;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletionException;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import com.abinbev.b2b.link.orderupload.utilities.exceptions.BadRequestException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.GlobalException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.InvalidCountryException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.InvalidJwtException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.Issue;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.IssueEnum;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.ServiceUnavailableException;
import com.abinbev.b2b.link.orderupload.utilities.helpers.Constants;
import com.abinbev.b2b.link.orderupload.utilities.services.TranslationService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

	private String requestTraceId = "RequestTraceId: ";

	@Value("${spring.servlet.multipart.max-file-size}")
	private String maxfileSize;
	
	private final TranslationService translationService;
	
	public GlobalExceptionHandler(final TranslationService translationService) {
		this.translationService = translationService;
	}

	@ExceptionHandler({ InvalidCountryException.class, InvalidJwtException.class })
	@ResponseStatus(value = HttpStatus.FORBIDDEN)
	public Issue handleJwtAndCountryValidationsException(final GlobalException ex, final WebRequest request) {

		log.warn(requestTraceId + request.getHeader(Constants.REQUEST_TRACE_ID_HEADER), ex);

		return ex.getIssue();
	}

	@ExceptionHandler(HttpMessageNotReadableException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	protected Issue handleHttpMessageNotReadableException(final HttpMessageNotReadableException ex, final WebRequest request) {

		log.warn(requestTraceId + request.getHeader(Constants.REQUEST_TRACE_ID_HEADER), ex);

		IssueEnum issueEnum = IssueEnum.UNEXPECTED_ERROR;
		
		String code = issueEnum.getCode();
		String key = issueEnum.getKey();
	
		String message = translationService.execute(key);

		return new Issue(code, message);
	}

	@ExceptionHandler(HttpClientErrorException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	protected Issue handleHttpClientErrorException(final HttpClientErrorException ex, final WebRequest request) {

		log.warn(requestTraceId + request.getHeader(Constants.REQUEST_TRACE_ID_HEADER), ex);
		
		IssueEnum issueEnum = IssueEnum.BAD_REQUEST;
		String code = issueEnum.getCode();

		return new Issue(code, ex.getLocalizedMessage());
	}

	@ExceptionHandler(MethodArgumentNotValidException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	protected Issue handleMethodArgumentNotValid(final MethodArgumentNotValidException ex, final WebRequest request) {

		log.warn(ex.getLocalizedMessage());

		final List<String> errors = new ArrayList<>();

		for (final FieldError error : ex.getBindingResult().getFieldErrors()) {
			errors.add(error.getField() + ": " + error.getDefaultMessage());
		}

		for (final ObjectError error : ex.getBindingResult().getGlobalErrors()) {
			errors.add(error.getObjectName() + ": " + error.getDefaultMessage());
		}
		
		IssueEnum issueEnum = IssueEnum.BAD_REQUEST;
		
		String code = issueEnum.getCode();
		String key = issueEnum.getKey();
	
		String message = translationService.execute(key);

		return new Issue(code, message, errors);
	}

	@ExceptionHandler(MissingRequestHeaderException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public Issue handleMissingRequestHeaderException(final MissingRequestHeaderException ex, final WebRequest request) {

		log.warn(requestTraceId + request.getHeader(Constants.REQUEST_TRACE_ID_HEADER), ex);

		IssueEnum issueEnum = IssueEnum.BAD_REQUEST;
		String code = issueEnum.getCode();

		return new Issue(code, ex.getLocalizedMessage());
	}

	@ExceptionHandler(MissingServletRequestParameterException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public Issue handleMissingServletRequestParameterException(final Exception ex, final WebRequest request) {

		log.warn(requestTraceId + request.getHeader(Constants.REQUEST_TRACE_ID_HEADER), ex);

		IssueEnum issueEnum = IssueEnum.BAD_REQUEST;
		String code = issueEnum.getCode();

		return new Issue(code, ex.getLocalizedMessage());
	}

	@ExceptionHandler(MaxUploadSizeExceededException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public Issue processSizeLimitExceededException(final MaxUploadSizeExceededException ex, final WebRequest request) {

		log.warn(requestTraceId + request.getHeader(Constants.REQUEST_TRACE_ID_HEADER), ex);
		
		IssueEnum issueEnum = IssueEnum.SIZE_LIMIT_EXCEEDED;
		String code = issueEnum.getCode();
		String key = issueEnum.getKey();
		
		String message = translationService.execute(key, maxfileSize);

		return new Issue(code, message);
	}

	@ExceptionHandler(Exception.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	public Issue processExceptions(final Exception ex, final WebRequest request) {

		log.warn(requestTraceId + request.getHeader(Constants.REQUEST_TRACE_ID_HEADER), ex);
		
		IssueEnum issueEnum = IssueEnum.UNEXPECTED_ERROR;
		String code = issueEnum.getCode();
		String key = issueEnum.getKey();
		
		String message = translationService.execute(key);

		return new Issue(code, message);
	}

	@ExceptionHandler(HttpRequestMethodNotSupportedException.class)
	@ResponseStatus(code = HttpStatus.METHOD_NOT_ALLOWED, value = HttpStatus.METHOD_NOT_ALLOWED)
	protected Issue processHttpRequestMethodNotSupportedException(final HttpRequestMethodNotSupportedException ex,
			final WebRequest request) {

		log.warn(requestTraceId + request.getHeader(Constants.REQUEST_TRACE_ID_HEADER), ex.getLocalizedMessage());
		
		IssueEnum issueEnum = IssueEnum.METHOD_NOT_ALLOWED;
		String code = issueEnum.getCode();
		String key = issueEnum.getKey();
		
		String currentMethod = ex.getMethod();
		String supportedMethod = Objects.requireNonNull(ex.getSupportedHttpMethods())
										.stream()
										.map(Enum::name)
										.collect(Collectors.joining(","));
		
		String message = translationService.execute(key, currentMethod, supportedMethod);

		return new Issue(code, message);
	}

	@ExceptionHandler(CompletionException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	protected Issue processCompletionException(final CompletionException ex, final HttpServletRequest request,
			final HttpServletResponse response) {

		if (ex.getCause() instanceof BadRequestException) {
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			return processBadRequestException((BadRequestException) ex.getCause(), request);
		} else {
			
			IssueEnum issueEnum = IssueEnum.UNEXPECTED_ERROR;
			
			String code = issueEnum.getCode();
			String key = issueEnum.getKey();
		
			String message = translationService.execute(key);

			return new Issue(code, message);
		}
	}

	@ExceptionHandler({ ExecutionException.class, InterruptedException.class })
	@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
	protected Issue processExecutionException(final Exception ex, final HttpServletRequest request) {

		log.warn(requestTraceId + request.getHeader(Constants.REQUEST_TRACE_ID_HEADER), ex.getLocalizedMessage());

		IssueEnum issueEnum = IssueEnum.UNEXPECTED_ERROR;
		
		String code = issueEnum.getCode();
		String key = issueEnum.getKey();
	
		String message = translationService.execute(key);

		return new Issue(code, message);
	}

	@ExceptionHandler(BadRequestException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	protected Issue processBadRequestException(final BadRequestException ex, final HttpServletRequest request) {

		this.logWithDetails(ex);

		return ex.getIssue();
	}

	@ExceptionHandler(ServiceUnavailableException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	protected Issue processServiceUnavailableException(final ServiceUnavailableException ex,
			final HttpServletRequest request) {

		this.logWithDetails(ex);

		return ex.getIssue();
	}

	@ExceptionHandler(RetryTimeoutException.class)
	@ResponseStatus(value = HttpStatus.GATEWAY_TIMEOUT)
	protected Issue processRetryTimeoutExceptionException(final RetryTimeoutException ex,
			final HttpServletRequest request) {

		this.logWithDetails(ex);

		return ex.getIssue();
	}

	@ExceptionHandler(BindException.class)
	@ResponseStatus(value = HttpStatus.BAD_REQUEST)
	protected Issue handleRequestParameterNotValid(final BindException ex, final WebRequest request) {

		log.warn(requestTraceId + request.getHeader(Constants.REQUEST_TRACE_ID_HEADER), ex);

		final List<String> errors = new ArrayList<>();

		for (final FieldError error : ex.getBindingResult().getFieldErrors()) {
			errors.add(error.getField() + ": " + error.getDefaultMessage());
		}
		
		IssueEnum issueEnum = IssueEnum.BAD_REQUEST;
		
		String code = issueEnum.getCode();
		String key = issueEnum.getKey();
	
		String message = translationService.execute(key);

		return new Issue(code, message, errors);
	}

	private void logWithDetails(GlobalException e) {
		if (e.getIssue().getDetails() != null && !e.getIssue().getDetails().isEmpty()) {
			log.warn(e.getIssue().getMessage() + " " + String.join(", ", e.getIssue().getDetails()));
		} else {
			log.warn(e.getIssue().getMessage());
		}
	}
}
