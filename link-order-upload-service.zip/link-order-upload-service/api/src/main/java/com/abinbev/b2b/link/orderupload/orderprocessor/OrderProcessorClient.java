package com.abinbev.b2b.link.orderupload.orderprocessor;

import java.io.IOException;
import java.net.ConnectException;
import java.nio.channels.ClosedChannelException;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.abinbev.b2b.link.orderupload.utilities.exceptions.BadRequestException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.GlobalException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.Issue;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.IssueEnum;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.ServiceUnavailableException;
import com.abinbev.b2b.link.orderupload.utilities.services.TranslationService;
import com.google.common.io.Files;

import io.netty.channel.unix.Errors.NativeIoException;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import reactor.core.publisher.Mono;

@Getter
@Component
@RequiredArgsConstructor
class OrderProcessorClient {

  private final WebClient webClient;
  private final AuthCredentialService authCredentialService;
  private final TranslationService translationService;

  public OrderUploaded uploadOrder(UUID accountId, MultipartFile file) {
    return this.webClient.post().uri("/upload")
        .headers(httpHeaders -> httpHeaders.setBearerAuth(this.authCredentialService.getToken().getToken()))
        .body(BodyInserters.fromMultipartData(generateBody(accountId, file))).retrieve()
        .onStatus(HttpStatus::isError, response -> {
          if (HttpStatus.NOT_FOUND.equals(response.statusCode())
              || HttpStatus.SERVICE_UNAVAILABLE.equals(response.statusCode())) {

            IssueEnum issueEnum = IssueEnum.SERVICE_ORDER_PROCESSOR_UNAVAILABLE;
            String key = issueEnum.getKey();
            String code = issueEnum.getCode();

            String message = translationService.execute(key);

            return Mono.error(new ServiceUnavailableException(new Issue(code, message)));
          }
          IssueEnum issueEnum = IssueEnum.FAILED_STATUS_CODE;

          String key = issueEnum.getKey();
          String code = issueEnum.getCode();

          String message = translationService.execute(key, response.statusCode());

          return Mono.error(new GlobalException(new Issue(code, message)));
        }).bodyToMono(OrderUploaded.class).onErrorMap(e -> {

          if (ExceptionUtils.getRootCause(e) instanceof ConnectException
              || ExceptionUtils.getRootCause(e) instanceof ClosedChannelException
              || ExceptionUtils.getRootCause(e) instanceof NativeIoException) {
            IssueEnum issueEnum = IssueEnum.SERVICE_ORDER_PROCESSOR_UNAVAILABLE;
            String key = issueEnum.getKey();
            String code = issueEnum.getCode();

            String message = translationService.execute(key);

            return new ServiceUnavailableException(new Issue(code, message));
          }

          return e;
        }).block();
  }

  public OrderProcessed getOrder(String orderId) {
    return this.webClient.post().uri("/get_order/{orderId}", orderId)
        .headers(httpHeaders -> httpHeaders.setBearerAuth(this.authCredentialService.getToken().getToken())).retrieve()
        .onStatus(HttpStatus::isError, response -> {
          if (HttpStatus.NOT_FOUND.equals(response.statusCode())
              || HttpStatus.SERVICE_UNAVAILABLE.equals(response.statusCode())) {

            IssueEnum issueEnum = IssueEnum.SERVICE_ORDER_PROCESSOR_UNAVAILABLE;
            String key = issueEnum.getKey();
            String code = issueEnum.getCode();

            String message = translationService.execute(key);

            return Mono.error(new ServiceUnavailableException(new Issue(code, message)));
          }
          IssueEnum issueEnum = IssueEnum.FAILED_STATUS_CODE;

          String key = issueEnum.getKey();
          String code = issueEnum.getCode();

          String message = translationService.execute(key, response.statusCode());

          return Mono.error(new GlobalException(new Issue(code, message)));
        }).bodyToMono(OrderProcessed.class).onErrorMap(e -> {

          if (ExceptionUtils.getRootCause(e) instanceof ConnectException
              || ExceptionUtils.getRootCause(e) instanceof ClosedChannelException
              || ExceptionUtils.getRootCause(e) instanceof NativeIoException) {
            IssueEnum issueEnum = IssueEnum.SERVICE_ORDER_PROCESSOR_UNAVAILABLE;
            String key = issueEnum.getKey();
            String code = issueEnum.getCode();

            String message = translationService.execute(key);

            return new ServiceUnavailableException(new Issue(code, message));
          }

          return e;
        }).block();
  }

  private MultiValueMap<String, HttpEntity<?>> generateBody(UUID accountId, MultipartFile file) {

    MultipartBodyBuilder builder = new MultipartBodyBuilder();

    String header = String.format("form-data; name=%s; filename=%s", "file", generateFileName(file));

    try {
      builder.part("id", UUID.randomUUID().toString());
      builder.part("file", new ByteArrayResource(file.getBytes())).header("Content-Disposition", header);
      builder.part("account_id", accountId.toString());
    } catch (IOException ex) {

      IssueEnum issueEnum = IssueEnum.UNEXPECTED_ERROR;

      String key = issueEnum.getKey();
      String code = issueEnum.getCode();

      String message = translationService.execute(key);

      throw new GlobalException(new Issue(code, message), ex);
    }

    return builder.build();
  }

  private String generateFileName(MultipartFile file) {

    String fileName = Optional.of(file.getOriginalFilename()).orElseThrow(() -> {
      IssueEnum issueEnum = IssueEnum.FILE_NAME_NOT_FOUND;
      String key = issueEnum.getKey();
      String code = issueEnum.getCode();
      String message = translationService.execute(key);
      return new BadRequestException(new Issue(code, message));
    });

    String fileExtension = Files.getFileExtension(fileName);

    fileName = fileName.replaceAll("[^a-zA-Z0-9]", "__") // remove any character that isn't number or letter
        .replaceAll("(.)\\1{1,}", "$1") // remove underline repetition
        .replaceAll("_" + fileExtension, "") // remove _extension
        .concat("." + fileExtension); // add file extension

    return fileName;

  }

}