package com.abinbev.b2b.link.orderupload.services;

import java.util.Map;
import java.util.Objects;

import org.springframework.stereotype.Service;

@Service
public class GetProviderService {

	private final Map<String, OrderUploadProviderService> getOrderUploadProviderMap;

	public GetProviderService(final Map<String, OrderUploadProviderService> getOrderUploadProviderMap) {
		this.getOrderUploadProviderMap = getOrderUploadProviderMap;
	}

	public OrderUploadProviderService getOrderUpload(String providerName) {
		var type = String.format("ORDER_UPLOAD_%s", providerName);
		OrderUploadProviderService provider = getOrderUploadProviderMap.get(type);

		if (Objects.isNull(provider)) {
			throw new IllegalArgumentException(String.format("The provider '%s' not supported", providerName));
		}
		return provider;
	}
}
