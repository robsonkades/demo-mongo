package com.abinbev.b2b.link.orderupload.constants;

public class StatusConstants {

  private StatusConstants() {}

  public static final String STATUS_200_GET_OK_MESSAGE = "Successfully retrieved";
  public static final int STATUS_200_GET_OK_CODE = 200;

  public static final String STATUS_204_NO_CONTENT_MESSAGE = "No Content";
  public static final int STATUS_204_NO_CONTENT_CODE = 204;

  public static final String STATUS_400_BAD_REQUEST_MESSAGE = "Resource is invalid";
  public static final int STATUS_400_BAD_REQUEST_CODE = 400;

  public static final String STATUS_401_UNAUTHORIZED_MESSAGE =
      "You are not authorized to view the resource";
  public static final int STATUS_401_UNAUTHORIZED_CODE = 401;

  public static final String STATUS_403_FORBIDDEN_MESSAGE =
      "Accessing the resource you were trying to reach is forbidden";
  public static final int STATUS_403_FORBIDDEN_CODE = 403;

  public static final String STATUS_404_NOT_FOUND_MESSAGE =
      "The resource you were trying to reach is not found";
  public static final int STATUS_404_NOT_FOUND_CODE = 404;

  public static final String STATUS_500_INTERNAL_SERVER_ERROR_MESSAGE = "Internal Server Error";
  public static final int STATUS_500_INTERNAL_SERVER_ERROR_CODE = 500;
}
