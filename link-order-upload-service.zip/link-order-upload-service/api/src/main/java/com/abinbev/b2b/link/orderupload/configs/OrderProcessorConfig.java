package com.abinbev.b2b.link.orderupload.configs;

import java.util.Arrays;
import java.util.List;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class OrderProcessorConfig {

  private WebClient.Builder webClientBuilder = null;

  @Value("${orderProcessor.baseUrl}")
  private String baseUrl;

  public OrderProcessorConfig(WebClient.Builder webClientBuilder) {
    this.webClientBuilder = webClientBuilder;
  }

  @Bean
  public WebClient webClient() {
    return webClientBuilder.baseUrl(this.baseUrl).build();
  }

  @Bean
  public List<String> contentTypesSupported() {

    String[] contentTypes = {
      "application/pdf",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
      "application/vnd.ms-excel",
      "text/csv",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "application/msword"
    };

    return Arrays.asList(contentTypes);
  }
}
