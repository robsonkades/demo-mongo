package com.abinbev.b2b.link.orderupload.orderprocessor;

import java.net.ConnectException;
import java.nio.channels.ClosedChannelException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import com.abinbev.b2b.link.orderupload.utilities.exceptions.GlobalException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.Issue;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.IssueEnum;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.ServiceUnavailableException;
import com.abinbev.b2b.link.orderupload.utilities.services.TranslationService;

import io.netty.channel.unix.Errors.NativeIoException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Slf4j
@Component
@RequiredArgsConstructor
class AuthCredentialService {
  
  private final AuthCredential authCredential;
  private final WebClient webClient;
  private final TranslationService translationService;
  
  @Cacheable("orderprocessor.auth.token")
  public AuthToken getToken() {
      
      log.info("Auth Credential Service | Getting token.");
      
      return this.webClient
                .post()
                .uri("/auth/login")
                .body(Mono.just(authCredential), AuthCredential.class)
                .retrieve()
                .onStatus(HttpStatus::isError, response -> {
                    if (HttpStatus.NOT_FOUND.equals(response.statusCode())
                        || HttpStatus.SERVICE_UNAVAILABLE.equals(response.statusCode())
                        || HttpStatus.BAD_GATEWAY.equals(response.statusCode())) {
                    	
						IssueEnum issueEnum = IssueEnum.SERVICE_ORDER_PROCESSOR_UNAVAILABLE;
						String key = issueEnum.getKey();
						String code = issueEnum.getCode();

						String message = translationService.execute(key);

						return Mono.error(new ServiceUnavailableException(new Issue(code, message)));
                    }
                    
                    IssueEnum issueEnum = IssueEnum.FAILED_STATUS_CODE;
                    
                 	String key = issueEnum.getKey();
                	String code = issueEnum.getCode();
                	
                	String message = translationService.execute(key, response.statusCode());
                    
                   return Mono.error(new GlobalException(new Issue(code, message)));
                })
                .bodyToMono(AuthToken.class)
                .onErrorMap(e -> {
                  
                  if (ExceptionUtils.getRootCause(e) instanceof ConnectException
                      || ExceptionUtils.getRootCause(e) instanceof ClosedChannelException
                      || ExceptionUtils.getRootCause(e) instanceof NativeIoException
                      ) {
                	  
                  	IssueEnum issueEnum = IssueEnum.SERVICE_ORDER_PROCESSOR_UNAVAILABLE;
                  	String key = issueEnum.getKey();
                  	String code = issueEnum.getCode();
                  	
                  	String message = translationService.execute(key);
                  	
                    return new ServiceUnavailableException(new Issue(code, message));
                  }
                  
                  return e;
                })
                .block();
    
    }  
  
}
