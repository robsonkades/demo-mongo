package com.abinbev.b2b.link.orderupload.constants;

public final class SwaggerConstants {

  public static final String API_TAG_NAME = "Notification Center Service API";
  public static final String API_TAG_DESCRIPTION = "ABI B2B Global Notification Center Service.";

  public static final String METADATA_KEY_VERSION = "API_VERSION";
  public static final String METADATA_TITLE = "AB-Inbev B2B Notification Center Service (Delta)";
  public static final String METADATA_DESCRIPTION =
      "\"REST API for AB-Inbev Notification Center Service Microservice\"";
  public static final String METADATA_LICENSE = "Anheuser-Busch InBev © 2021";

  private SwaggerConstants() {}
}
