package com.abinbev.b2b.link.orderupload.services.weduu;

import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.abinbev.b2b.link.orderupload.services.OrderUploadProviderService;
import com.abinbev.b2b.link.orderupload.utilities.clients.weduu.WeduuClient;

@Service("ORDER_UPLOAD_WEDUU")
public class OrderUploadWeduuService implements OrderUploadProviderService {
	
	private final WeduuClient weduuClient;

	public OrderUploadWeduuService(final WeduuClient weduuClient) {
		this.weduuClient = weduuClient;
	}

	@Override
	public String execute(UUID accountId, MultipartFile file) {
		var order = weduuClient.uploadOrder(accountId, file);
		return order.getId();
	}
}
