package com.abinbev.b2b.link.orderupload.interceptors;

import static com.abinbev.b2b.link.orderupload.constants.ServiceConstants.NEW_RELIC_TRANSACTION_CATEGORY;

import java.lang.reflect.Method;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.core.ApplicationPart;
import org.slf4j.MDC;
import org.springframework.lang.NonNull;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.util.ClassUtils;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.AsyncHandlerInterceptor;

import com.abinbev.b2b.link.orderupload.constants.ApiConstants;
import com.abinbev.b2b.link.orderupload.utilities.helpers.Constants;
import com.abinbev.b2b.link.orderupload.utilities.interceptors.ContextHolder;
import com.abinbev.b2b.link.orderupload.validators.ControllerValidation;
import com.newrelic.api.agent.NewRelic;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class ControllerRequestInterceptor implements AsyncHandlerInterceptor {

  @Override
  public boolean preHandle(
      final HttpServletRequest request, final HttpServletResponse response, final Object handler)
      throws Exception {
    
    final RequestTraceValidation annotationIsPresent = getAnnotation(handler);
    
    renameTransaction(handler);
    
    MDC.put(ApiConstants.SERVICE_NAME, ApiConstants.SERVICE_NAME_VALUE);
    
    NewRelic.addCustomParameter(ApiConstants.SERVICE_NAME, ApiConstants.SERVICE_NAME_VALUE);
    
    if (annotationIsPresent != null && annotationIsPresent.requestTraceId()) {
      
      ContextHolder.setRequestTraceId(request.getHeader(Constants.REQUEST_TRACE_ID_HEADER));
      
      ControllerValidation.validateHeaderRequestTraceId(
          Constants.REQUEST_TRACE_ID_HEADER,
          request.getHeader(Constants.REQUEST_TRACE_ID_HEADER));
      
      MDC.put(
          Constants.REQUEST_TRACE_ID_HEADER,
          request.getHeader(Constants.REQUEST_TRACE_ID_HEADER));
      
      ContextHolder.setRequestTraceId(request.getHeader(Constants.REQUEST_TRACE_ID_HEADER));
      
      NewRelic.addCustomParameter(
          Constants.REQUEST_TRACE_ID_HEADER,
          request.getHeader(Constants.REQUEST_TRACE_ID_HEADER));
      
    }
    
    if (annotationIsPresent != null && annotationIsPresent.requestUri()) {
    
      MDC.put(ApiConstants.REQUEST_URI_HEADER, request.getRequestURI());
      
      NewRelic.addCustomParameter(ApiConstants.REQUEST_URI_HEADER, request.getRequestURI());
      
    }
    
    if (annotationIsPresent != null && annotationIsPresent.country()) {
      
      ContextHolder.setCountry(request.getHeader(Constants.COUNTRY_HEADER));
      
      ControllerValidation.validateHeaderCountry(
          Constants.COUNTRY_HEADER, request.getHeader(Constants.COUNTRY_HEADER));
      
      ContextHolder.setCountry(request.getHeader(Constants.COUNTRY_HEADER));
      
      MDC.put(Constants.COUNTRY_HEADER, request.getHeader(Constants.COUNTRY_HEADER));
      
      NewRelic.addCustomParameter(
          Constants.COUNTRY_HEADER, request.getHeader(Constants.COUNTRY_HEADER));
      
    }
    
    if (annotationIsPresent != null && annotationIsPresent.accountId()) {
      
      MDC.put(ApiConstants.ACCOUNT_ID_PARAMETER, request.getParameter(ApiConstants.ACCOUNT_ID_PARAMETER));
      
      NewRelic.addCustomParameter(
          ApiConstants.ACCOUNT_ID_PARAMETER, request.getParameter(ApiConstants.ACCOUNT_ID_PARAMETER));
      
    }
    
    try {
      if (annotationIsPresent != null && annotationIsPresent.file() && request.getPart("file") != null) {

        String fileName = ((ApplicationPart)request.getPart("file")).getSubmittedFileName();

        MDC.put(ApiConstants.FILE_PARAMETER, fileName);

        NewRelic.addCustomParameter(ApiConstants.FILE_PARAMETER, fileName);

      }
    } catch (ServletException e) {
      //criticized after - file not found
    }
    
    if (annotationIsPresent != null && annotationIsPresent.xBeesCaller()) {
      MDC.put(
          ApiConstants.X_BEES_CALLER_HEADER, request.getHeader(ApiConstants.X_BEES_CALLER_HEADER));
      
      NewRelic.addCustomParameter(
          ApiConstants.X_BEES_CALLER_HEADER, request.getHeader(ApiConstants.X_BEES_CALLER_HEADER));
      
    }
    
    if (annotationIsPresent != null && annotationIsPresent.xBeesOrigin()) {
      
      MDC.put(
          ApiConstants.X_BEES_ORIGIN_HEADER, request.getHeader(ApiConstants.X_BEES_ORIGIN_HEADER));
      
      NewRelic.addCustomParameter(
          ApiConstants.X_BEES_ORIGIN_HEADER, request.getHeader(ApiConstants.X_BEES_ORIGIN_HEADER));
      
    }
    
    return true;
  }

  private void renameTransaction(final Object handler) {
    if (handler instanceof HandlerMethod) {
      try {
        NewRelic.setTransactionName(
            NEW_RELIC_TRANSACTION_CATEGORY, ((HandlerMethod) handler).getMethod().getName());
      } catch (final Exception ex) {
        log.warn("Not able to rename transaction from {}", handler.getClass(), ex);
      }
    }
  }

  @Override
  public void afterCompletion(
      @NonNull final HttpServletRequest request,
      @NonNull final HttpServletResponse response,
      @NonNull final Object handler,
      @Nullable final Exception ex) {
    MDC.clear();
  }

  private RequestTraceValidation getAnnotation(final Object object) {
    
    if (object instanceof HandlerMethod) {
      final HandlerMethod handler = (HandlerMethod) object;
      final RequestTraceValidation annotationFromClass = getAnnotationFromClass(handler);
      return annotationFromClass != null ? annotationFromClass : getAnnotationFromMethod(handler);
    }
    
    return null;
  }
  

  private RequestTraceValidation getAnnotationFromClass(final HandlerMethod handler) {
    
    final Class<?> beanClass = ClassUtils.getUserClass(handler.getBean().getClass());
    
    if (beanClass.isAnnotationPresent(RequestTraceValidation.class)) {
      return beanClass.getAnnotation(RequestTraceValidation.class);
    }
    
    return null;
    
  }

  private RequestTraceValidation getAnnotationFromMethod(final HandlerMethod handler) {
    
    final Method beanMethod = handler.getMethod();
    
    if (beanMethod.isAnnotationPresent(RequestTraceValidation.class)) {
      return beanMethod.getAnnotation(RequestTraceValidation.class);
    }
    
    return null;
    
  }
}
