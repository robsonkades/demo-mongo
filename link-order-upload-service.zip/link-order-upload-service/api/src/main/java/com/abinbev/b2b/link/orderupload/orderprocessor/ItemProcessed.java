package com.abinbev.b2b.link.orderupload.orderprocessor;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
class ItemProcessed {

  @JsonProperty("cd_sku_output")
  private String sku;
  
  @JsonProperty("num_pedido")
  private String orderNumber;

  @JsonProperty("qty")
  private int quantity;

  @JsonProperty("status_curator")
  private String status;
}
