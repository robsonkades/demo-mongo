package com.abinbev.b2b.link.orderupload.controllers;

import java.util.Optional;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.abinbev.b2b.link.orderupload.dto.GetOrderResponse;
import com.abinbev.b2b.link.orderupload.dto.OrderUploadResponse;
import com.abinbev.b2b.link.orderupload.interceptors.RequestTraceValidation;
import com.abinbev.b2b.link.orderupload.services.CreateOrderUploadService;
import com.abinbev.b2b.link.orderupload.services.GetOrderService;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.BadRequestException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.Issue;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.IssueEnum;
import com.abinbev.b2b.link.orderupload.utilities.interceptors.ContextHolder;
import com.abinbev.b2b.link.orderupload.utilities.services.TranslationService;
import com.newrelic.api.agent.Trace;

@RestController
@RequestMapping("/orders")
public class OrdersController {

  private static final String WEDUU = "WEDUU";
  private final CreateOrderUploadService createOrderUploadService;
  private final GetOrderService getOrderService;
  private final TranslationService translationService;

  public OrdersController(
		  final CreateOrderUploadService createOrderUploadService,
		  final GetOrderService getOrderService,
		  final TranslationService translationService) {
    this.createOrderUploadService = createOrderUploadService;
    this.getOrderService = getOrderService;
    this.translationService = translationService;
  }

  @Trace
  @RequestTraceValidation
  @PostMapping
  @ResponseStatus(HttpStatus.ACCEPTED)
  public ResponseEntity<OrderUploadResponse> create(
      @RequestParam("account_id") UUID accountId, @RequestParam Optional<MultipartFile> file) {
	  
    OrderUploadResponse response = createOrderUploadService.execute(accountId, file);
    
    return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
  }
  

  @Trace
  @RequestTraceValidation
  @GetMapping("/{account_id}/{order_id}")
  @ResponseStatus(HttpStatus.OK)
  public ResponseEntity<GetOrderResponse> read(@PathVariable("account_id") String accountId, @PathVariable("order_id") String orderId) {

    var orderResponse = getOrderService.execute(orderId, accountId, WEDUU);
   
    if (orderResponse.isEmpty()) {
    	
      IssueEnum issueEnum = IssueEnum.ORDER_NOT_FOUND;
      String key = issueEnum.getKey();
      String code = issueEnum.getCode();
      
      String message = translationService.execute(key, orderId, ContextHolder.getCountry());
     
      throw new BadRequestException(new Issue(code, message));
    }
    
    var order = orderResponse.get();
    
    GetOrderResponse response =  new GetOrderResponse();
    response.setStatus(order.getStatus());
    response.setItems(order.getItems());
    
    return ResponseEntity.status(HttpStatus.OK).body(response);
  }
}
