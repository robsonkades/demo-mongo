package com.abinbev.b2b.link.orderupload.properties;

import java.util.Set;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "logging")
public class LogProperties {

  private Set<String> enabledTo;
  
}
