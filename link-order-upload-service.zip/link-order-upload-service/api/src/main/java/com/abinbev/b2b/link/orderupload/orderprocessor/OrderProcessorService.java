package com.abinbev.b2b.link.orderupload.orderprocessor;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.abinbev.b2b.link.orderupload.dto.ItemDTO;
import com.abinbev.b2b.link.orderupload.dto.OrderDTO;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.BadRequestException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.GlobalException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.Issue;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.IssueEnum;
import com.abinbev.b2b.link.orderupload.utilities.services.TranslationService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrderProcessorService {
  
  private final List<String> contentTypesSupported;
  
  private final OrderProcessorClient orderProcessorClient;
  
  private final TranslationService translationService;
  
  public OrderDTO upload(OrderDTO orderDTO) {
    
    OrderDTO orderDTOReturned = null;
    
    MultipartFile file = orderDTO.getOrderFile().orElseThrow(() -> {
      
      IssueEnum issueEnum = IssueEnum.FILE_NOT_FOUND;
      String key = issueEnum.getKey();
      String code = issueEnum.getCode();

      String message = translationService.execute(key);
      
      return new BadRequestException(new Issue(code, message));
    });
    
    validateContentType(file);
      
    //upload order
    var orderUploaded = uploadOrder(orderDTO.getAccountId(), file);
    
    //retrieve order
    orderDTOReturned = getOrder(orderUploaded.orElseThrow(GlobalException::globalException).getId());
    
    return orderDTOReturned;
    
  } 
  
  private Optional<OrderUploaded> uploadOrder(UUID accountId, MultipartFile file) {
    
    log.info("Order Processor Service | Doing file upload.");
    
     OrderUploaded orderUploaded = this.orderProcessorClient.uploadOrder(accountId, file);
     
     return Optional.of(orderUploaded);
  }  
  
  private void validateContentType(MultipartFile file) {
    
    if (!contentTypesSupported.contains(file.getContentType())) {
      throw BadRequestException.invalidContentType();
    }
    
  }

  public OrderDTO getOrder(String orderId) {
    log.info("Order Processor Service | Verifying if order(" + orderId + ") was processed.");
    
    var orderDTO = OrderDTO.builder()
        .orderIdProcessor(orderId)
        .items(new ArrayList<>())
        .build();
    
    OrderProcessed orderProcessed = this.orderProcessorClient.getOrder(orderId);
    
    if (orderProcessed == null) {
      throw GlobalException.globalException();
    }
    
    if (orderProcessed.isWithError()) {
      throw BadRequestException.invalidFile(Collections.singletonList(orderProcessed.getStatus()));
    }
    
    if (orderProcessed.getItems() != null && !orderProcessed.getItems().isEmpty()) {
      orderDTO.setOrderId(orderProcessed.getItems().get(0).getOrderNumber());
      
      orderProcessed.getItems().stream()
        .filter(item -> item.getStatus().equals(StatusItemEnum.PROCESSED.toString()))
        .forEach(itemProcessed -> orderDTO.addItem(new ItemDTO(itemProcessed.getSku(), itemProcessed.getQuantity())));
    }
    
    return orderDTO;
  }
  
}