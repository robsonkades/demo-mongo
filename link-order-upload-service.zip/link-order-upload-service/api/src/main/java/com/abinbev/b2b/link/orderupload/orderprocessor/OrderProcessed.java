package com.abinbev.b2b.link.orderupload.orderprocessor;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
class OrderProcessed {

  @JsonProperty("order_id")
  private String orderIdProcessor;
  
  private List<ItemProcessed> items;

  @JsonProperty("error")
  private boolean withError = false;

  private String file;

  private String status;

  private String uploaded;
}
