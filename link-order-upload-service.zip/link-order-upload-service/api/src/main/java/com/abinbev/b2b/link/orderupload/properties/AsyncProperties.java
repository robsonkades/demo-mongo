package com.abinbev.b2b.link.orderupload.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "async")
public class AsyncProperties {

  private Integer corePoolSize;
  private Integer maxPoolSize;

  public Integer getCorePoolSize() {
    return corePoolSize;
  }

  public void setCorePoolSize(final Integer corePoolSize) {
    this.corePoolSize = corePoolSize;
  }

  public Integer getMaxPoolSize() {
    return maxPoolSize;
  }

  public void setMaxPoolSize(final Integer maxPoolSize) {
    this.maxPoolSize = maxPoolSize;
  }
}
