package com.abinbev.b2b.link.orderupload.orderprocessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
class AuthToken {

  private String message;
  private String token;
}
