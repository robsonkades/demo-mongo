package com.abinbev.b2b.link.orderupload.validators;

import org.springframework.stereotype.Component;

import com.abinbev.b2b.link.orderupload.properties.FileProperties;

@Component
public class ContentTypeValidation {
	
	private final FileProperties fileProperties;
	
	public ContentTypeValidation(FileProperties fileProperties) {
		this.fileProperties = fileProperties;
	}

	public boolean isSupportedContentType(String contentType) {
		return fileProperties.getContentTypes().stream().anyMatch(type -> type.equals(contentType));
	}
}
