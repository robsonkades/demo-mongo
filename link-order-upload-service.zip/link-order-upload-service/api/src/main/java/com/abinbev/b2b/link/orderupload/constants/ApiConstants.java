package com.abinbev.b2b.link.orderupload.constants;

public final class ApiConstants {

  public static final String SERVICE_NAME = "serviceName";
  
  public static final String SERVICE_NAME_VALUE = "link-order-upload-service";
  
  public static final String REQUEST_TRACE_ID_HEADER = "requestTraceId";
  
  public static final String ACCOUNT_ID_PARAMETER = "account_id";
  
  public static final String FILE_PARAMETER = "file";

  public static final String AUTHORIZATION_HEADER = "Authorization";

  public static final String HEADER_CONTENT_TYPE = "Content-Type";

  public static final String REQUEST_URI_HEADER = "requestUri";

  public static final String X_BEES_CALLER_HEADER = "x-bees-caller";

  public static final String X_BEES_ORIGIN_HEADER = "x-bees-origin";

  public static final String NOT_VALID_PARAM_ERROR_MSG = "%s not valid";

  public static final String MANDATORY_PARAM_ERROR_MSG = "%s is mandatory";

  public static final String VENDOR_ID = "vendorId";

  public static final String COUNTRY_JWT = "country";

  public static final String SUB_JWT = "sub";

  private ApiConstants() {}
}
