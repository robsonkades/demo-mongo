package com.abinbev.b2b.link.orderupload.configs;

import com.abinbev.b2b.link.orderupload.properties.AsyncProperties;
import java.util.concurrent.Executor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
public class AsyncConfig {

  private final AsyncProperties asyncProperties;

  public AsyncConfig(final AsyncProperties asyncProperties) {
    this.asyncProperties = asyncProperties;
  }

  @Primary
  @Bean(name = "taskExecutor")
  public Executor taskExecutor() {
    final ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
    executor.setThreadNamePrefix("Async-");
    executor.setCorePoolSize(asyncProperties.getCorePoolSize());
    executor.setMaxPoolSize(asyncProperties.getMaxPoolSize());
    executor.setTaskDecorator(new ServiceTaskDecorator());
    executor.afterPropertiesSet();
    return executor;
  }
}
