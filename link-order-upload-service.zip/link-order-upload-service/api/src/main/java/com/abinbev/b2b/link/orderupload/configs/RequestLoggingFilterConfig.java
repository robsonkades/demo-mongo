package com.abinbev.b2b.link.orderupload.configs;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.core.ApplicationPart;
import org.slf4j.MDC;
import java.io.IOException;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.lang.NonNull;
import org.springframework.web.filter.AbstractRequestLoggingFilter;
import com.abinbev.b2b.link.orderupload.constants.ApiConstants;
import com.abinbev.b2b.link.orderupload.properties.LogProperties;
import com.abinbev.b2b.link.orderupload.utilities.helpers.Constants;

@Configuration
public class RequestLoggingFilterConfig {

  private final LogProperties loggingProperties;

  public RequestLoggingFilterConfig(final LogProperties logProperties) {
    this.loggingProperties = logProperties;
  }

  @Bean
  public AbstractRequestLoggingFilter logFilter() {

    final AbstractRequestLoggingFilter filter =
        new AbstractRequestLoggingFilter() {

          @Override
          protected void doFilterInternal(
              @NonNull final HttpServletRequest request,
              @NonNull final HttpServletResponse response,
              @NonNull final FilterChain filterChain)
              throws ServletException, IOException {

            if (shouldLogRequest(request)) {
              registerServiceLogData(request);
            }
            
            super.doFilterInternal(request, response, filterChain);
          }

          @Override
          protected void beforeRequest(
              @NonNull final HttpServletRequest request, @NonNull final String message) {
            
            if (shouldLogRequest(request)) {
              logger.info(message.replace("\n", "").replace("\t", ""));
            }
            
          }

          @Override
          protected void afterRequest(
              @NonNull final HttpServletRequest request, @NonNull final String message) {

            if (shouldLogRequest(request)) {
              registerServiceLogData(request);
              logger.info(message.replace("\n", "").replace("\t", ""));
              MDC.clear();
            }
            
          }
        };
        
    filter.setIncludeQueryString(true);
    filter.setIncludePayload(true);
    return filter;
  }

  private boolean shouldLogRequest(final HttpServletRequest request) {
    
    final String country = request.getHeader(Constants.COUNTRY_HEADER);
    
    return loggingProperties.getEnabledTo().contains(country)
        && !request.getRequestURI().startsWith("/actuator");
  }

  public void registerServiceLogData(final HttpServletRequest request) {
    
    MDC.put(ApiConstants.SERVICE_NAME, ApiConstants.SERVICE_NAME_VALUE);    
    
    MDC.put(ApiConstants.HEADER_CONTENT_TYPE, request.getHeader(ApiConstants.HEADER_CONTENT_TYPE));
    
    MDC.put(
        Constants.REQUEST_TRACE_ID_HEADER,
        request.getHeader(Constants.REQUEST_TRACE_ID_HEADER));
    
    MDC.put(
        ApiConstants.REQUEST_URI_HEADER,
        request.getRequestURI());    
    
    MDC.put(Constants.COUNTRY_HEADER, request.getHeader(Constants.COUNTRY_HEADER));
    
    
    MDC.put(ApiConstants.ACCOUNT_ID_PARAMETER, request.getParameter(ApiConstants.ACCOUNT_ID_PARAMETER));
    
    try {
      if (request.getPart("file") != null) {
        String fileName = ((ApplicationPart)request.getPart("file")).getSubmittedFileName();
        MDC.put(ApiConstants.FILE_PARAMETER, fileName);
      }
    } catch (ServletException | IOException | IllegalStateException e) {
      //criticized after - file not found or file size
    }
    
  }
}
