package com.abinbev.b2b.link.orderupload.services;

import java.util.UUID;

import org.springframework.web.multipart.MultipartFile;

public interface OrderUploadProviderService {
	String execute(UUID accountId, MultipartFile file);
}
