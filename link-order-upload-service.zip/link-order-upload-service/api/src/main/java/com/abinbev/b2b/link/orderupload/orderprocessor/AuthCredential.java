package com.abinbev.b2b.link.orderupload.orderprocessor;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component
class AuthCredential {

  @Value("${orderProcessor.auth.email}")
  private String email;

  @Value("${orderProcessor.auth.password}")
  private String password;
}
