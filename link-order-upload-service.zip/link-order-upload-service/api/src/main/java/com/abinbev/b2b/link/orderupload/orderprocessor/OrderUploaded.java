package com.abinbev.b2b.link.orderupload.orderprocessor;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
class OrderUploaded {

  private String id;
  private String file;
  private String flag;
  private String error;
  private String timestamp;
}
