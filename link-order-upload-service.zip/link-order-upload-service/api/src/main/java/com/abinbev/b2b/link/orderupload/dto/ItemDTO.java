package com.abinbev.b2b.link.orderupload.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class ItemDTO {

  private String id;
  private int quantity;
}
