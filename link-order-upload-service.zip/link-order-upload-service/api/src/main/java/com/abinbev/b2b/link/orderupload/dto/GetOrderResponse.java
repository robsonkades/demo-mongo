package com.abinbev.b2b.link.orderupload.dto;

import java.util.List;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderItem;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderStatus;

public class GetOrderResponse {

  private OrderStatus status;
  private List<OrderItem> items;

  public OrderStatus getStatus() {
    return status;
  }

  public void setStatus(OrderStatus status) {
    this.status = status;
  }

  public List<OrderItem> getItems() {
    return items;
  }

  public void setItems(List<OrderItem> items) {
    this.items = items;
  }
}
