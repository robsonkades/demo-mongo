package com.abinbev.b2b.link.orderupload.services;



import static org.assertj.core.api.Assertions.assertThat;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ActiveProfiles;

import com.abinbev.b2b.link.orderupload.BaseSuite;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderItem;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderStatus;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderUpload;
import com.abinbev.b2b.link.orderupload.utilities.domain.Provider;
import com.abinbev.b2b.link.orderupload.utilities.interceptors.ContextHolder;

@SpringBootTest
@ActiveProfiles("test")
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
class GetOrderServiceTests extends BaseSuite {

	@Autowired
	private GetOrderService getOrderService;
	
	@Autowired
	private SaveOrderService saveOrderService;
	
	@Autowired
	private MongoTemplate template;
	
	@BeforeEach
	void each() {
		ContextHolder.setCountry("US");
		ContextHolder.setRequestTraceId(UUID.randomUUID().toString());
		template.dropCollection(OrderUpload.class);
	}

	@Test
	void itShouldBeAbleToGetOrder() {
		// Assemble
		var orderId = UUID.randomUUID().toString();
		var accountId = UUID.randomUUID().toString();
		var providerOrderId = UUID.randomUUID().toString();
		
		
		var sku1 = UUID.randomUUID().toString();
		var sku2 = UUID.randomUUID().toString();
		var sku3 = UUID.randomUUID().toString();
		
		var item1 =	new OrderItem(sku1, 10);
		var item2 =	new OrderItem(sku2, 20);
		var item3 =	new OrderItem(sku3, 30);
		
		var order = new OrderUpload();
		order.setAccountId(accountId);
		order.setOrderId(orderId);
		order.setProvider(Provider.WEDUU);
		order.setProviderOrderId(providerOrderId);
		order.setStatus(OrderStatus.PROCESSED);
		order.setUpdatedAt(OffsetDateTime.now());
		order.setItems(List.of(item1, item2, item3));
		
		saveOrderService.execute(order);
		
		// Actions
		var response = getOrderService.execute(orderId, accountId, Provider.WEDUU.name());
		
		// Assertions
		assertThat(response.get()).isNotNull();
		assertThat(response.get().getAccountId()).isEqualTo(accountId);
		assertThat(response.get().getOrderId()).isEqualTo(orderId);
		assertThat(response.get().getProvider()).isEqualTo(Provider.WEDUU);
		assertThat(response.get().getProviderOrderId()).isEqualTo(providerOrderId);
		assertThat(response.get().getItems())
			.usingElementComparatorOnFields("sku", "quantity")
			.containsExactlyInAnyOrder(item1, item2, item3);
	}
	
	@Test
	void itShouldNotBeAbleToGetOrderIfDeleted() {
		// Assemble
		var orderId = UUID.randomUUID().toString();
		var accountId = UUID.randomUUID().toString();
		var providerOrderId = UUID.randomUUID().toString();
		
		
		var sku1 = UUID.randomUUID().toString();
		var sku2 = UUID.randomUUID().toString();
		var sku3 = UUID.randomUUID().toString();
		
		var item1 =	new OrderItem(sku1, 10);
		var item2 =	new OrderItem(sku2, 20);
		var item3 =	new OrderItem(sku3, 30);
		
		var order = new OrderUpload();
		order.setAccountId(accountId);
		order.setOrderId(orderId);
		order.setProvider(Provider.WEDUU);
		order.setProviderOrderId(providerOrderId);
		order.setStatus(OrderStatus.PROCESSED);
		order.setUpdatedAt(OffsetDateTime.now());
		order.setDeleted(true);
		order.setItems(List.of(item1, item2, item3));
		
		saveOrderService.execute(order);
		
		// Actions
		var response = getOrderService.execute(orderId, accountId, Provider.WEDUU.name());
		
		// Assertions
		assertThat(response).isNotPresent();
	}
}
