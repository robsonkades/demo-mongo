package com.abinbev.b2b.link.orderupload;

import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ActiveProfiles;


@SpringBootTest
@ActiveProfiles("test")
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
class LinkOrderUploadServiceApplicationTests extends BaseSuite {

  @Test
  void contextLoads() {

    String test = "teste";
    Assert.assertFalse(test.isEmpty());
  }
}
