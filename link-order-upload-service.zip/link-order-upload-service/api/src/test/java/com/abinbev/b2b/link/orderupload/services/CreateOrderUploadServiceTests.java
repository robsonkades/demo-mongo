package com.abinbev.b2b.link.orderupload.services;

import static org.mockito.Mockito.times;

import java.util.Optional;
import java.util.UUID;

import org.assertj.core.api.Assertions;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ActiveProfiles;

import com.abinbev.b2b.link.orderupload.BaseSuite;
import com.abinbev.b2b.link.orderupload.services.weduu.OrderUploadWeduuService;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderStatus;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderUpload;
import com.abinbev.b2b.link.orderupload.utilities.domain.Provider;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.BadRequestException;
import com.abinbev.b2b.link.orderupload.utilities.interceptors.ContextHolder;
import com.abinbev.b2b.link.orderupload.utilities.messages.OrderMessage;
import com.abinbev.b2b.link.orderupload.utilities.services.SendMessageService;

@SpringBootTest
@ActiveProfiles("test")
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
class CreateOrderUploadServiceTests extends BaseSuite {

	@MockBean
	private SendMessageService messageService;

	@MockBean
	private OrderUploadWeduuService orderUploadWeduuService;

	@Autowired
	private CreateOrderUploadService createOrderUploadService;

	@Autowired
	private MongoTemplate template;

	@Value("${message.delay}")
	private int delay;

	@Value("${message.exchanges.orderUpload}")
	protected String orderUploadExchangeName;

	@BeforeEach
	void each() {
		ContextHolder.setCountry("US");
		ContextHolder.setRequestTraceId(UUID.randomUUID().toString());
		template.dropCollection(OrderUpload.class);
	}

	@Test
	void itShouldBeAbleToCreateOrderUpload() {
		// Assemble
		var accountId = UUID.randomUUID();
		var file = new MockMultipartFile("user-file", "test.txt", "application/pdf", "test data".getBytes());

		var orderProcessorId = "e77661cc-3d2e-4eea-a7dd-c4a840f28354";
		
		var message = new OrderMessage();
		message.setAccountId(accountId.toString());
		message.setOrderId(orderProcessorId);
		message.setProvider(Provider.WEDUU);

		Mockito.when(orderUploadWeduuService.execute(Mockito.any(), Mockito.any())).thenReturn(orderProcessorId);

		Mockito.doNothing().when(messageService).execute(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
        
		// Actions
		var response = createOrderUploadService.execute(accountId, Optional.of(file));

		// Assertions
		Mockito.verify(orderUploadWeduuService, times(1)).execute(accountId, file);
		
		Assertions.assertThat(response.getStatus()).isEqualTo(OrderStatus.PENDING);
		Assertions.assertThat(response.getOrderId()).isNotBlank();
	}
	
	@Test
	void itShouldNotBeAbleToCreateOrderUploadIfFileNotFound() {
		// Actions
		Assert.assertThrows(BadRequestException.class, () -> createOrderUploadService.execute(UUID.randomUUID(), Optional.empty()));
	}
	
	@Test
	void itShouldNotBeAbleToCreateOrderUploadIfFileNotSupported() {
		// Actions
		
		var file = new MockMultipartFile("user-file", "test.txt", "application/wrong-pdf", "test data".getBytes());

		Assert.assertThrows(BadRequestException.class, () -> createOrderUploadService.execute(UUID.randomUUID(), Optional.of(file)));
	}

}
