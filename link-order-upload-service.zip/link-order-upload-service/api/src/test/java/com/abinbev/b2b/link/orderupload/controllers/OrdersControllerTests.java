package com.abinbev.b2b.link.orderupload.controllers;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.abinbev.b2b.link.orderupload.BaseSuite;
import com.abinbev.b2b.link.orderupload.services.SaveOrderService;
import com.abinbev.b2b.link.orderupload.services.weduu.OrderUploadWeduuService;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderItem;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderStatus;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderUpload;
import com.abinbev.b2b.link.orderupload.utilities.domain.Provider;
import com.abinbev.b2b.link.orderupload.utilities.interceptors.ContextHolder;

@SpringBootTest
@ActiveProfiles("test")
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
@AutoConfigureMockMvc
class OrdersControllerTests extends BaseSuite {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private OrderUploadWeduuService orderUploadWeduuService;

	@Autowired
	private SaveOrderService saveOrderService;
	
	@Autowired
	private MongoTemplate template;
	
	@BeforeEach
	void each() {
		ContextHolder.setCountry("US");
		template.dropCollection(OrderUpload.class);
	}

	@Test
	void itNotShouldBeAbleToUploadFileIfItIsInvalidFile() throws Exception {
		// Assemble
		HttpHeaders headers = new HttpHeaders();
		headers.add("requestTraceId", UUID.randomUUID().toString());
		headers.add("country", "US");

		MockMultipartFile file = new MockMultipartFile("image", "WX20180207-134704@2x.png", "image/png",
				"Hello World".getBytes());

		// Action
		ResultActions response = mockMvc.perform(MockMvcRequestBuilders.multipart("/orders")
				.file("file", file.getBytes()).param("account_id", UUID.randomUUID().toString()).headers(headers));

		// Assert
		response.andExpect(MockMvcResultMatchers.status().isBadRequest())
				.andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.content()
						.json("{\"code\":\"OUS-7\",\"message\":\"Unsupported file type passed to upload.\"}"));
	}

	@Test
	void itNotShouldBeAbleToUploadFileWithoutFile() throws Exception {
		// Assemble
		HttpHeaders headers = new HttpHeaders();
		headers.add("requestTraceId", UUID.randomUUID().toString());
		headers.add("country", "US");

		MockMultipartFile file = new MockMultipartFile("image", "WX20180207-134704@2x.png", "image/png",
				"Hello World".getBytes());

		// Action
		ResultActions response = mockMvc
				.perform(MockMvcRequestBuilders.multipart("/orders").file("file", file.getBytes()).headers(headers));

		// Assert
		response.andExpect(MockMvcResultMatchers.status().isBadRequest())
				.andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.content().json(
						"{\"code\":\"OUS-4\",\"message\":\"Invalid request.\",\"details\":[\"Required request parameter 'account_id' for method parameter type UUID is not present\"]}"));
	}

	@Test
	void itNotShouldBeAbleToUploadFileWithoutAccountId() throws Exception {
		// Assemble
		HttpHeaders headers = new HttpHeaders();
		headers.add("requestTraceId", UUID.randomUUID().toString());
		headers.add("country", "US");

		// Action
		ResultActions response = mockMvc.perform(MockMvcRequestBuilders.multipart("/orders")
				.param("account_id", UUID.randomUUID().toString()).headers(headers));

		// Assert
		response.andExpect(MockMvcResultMatchers.status().isBadRequest())
				.andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.content().json(
						"{\"code\":\"OUS-4\",\"message\":\"Invalid request.\",\"details\":[\"Order file not found.\"]}"));
	}

	@Test
	void itNotShouldBeAbleToUploadFileWithoutCountry() throws Exception {
		// Assemble
		HttpHeaders headers = new HttpHeaders();
		headers.add("requestTraceId", UUID.randomUUID().toString());

		MockMultipartFile file = new MockMultipartFile("image", "WX20180207-134704@2x.png", "application/pdf",
				"Hello World".getBytes());

		// Action
		ResultActions response = mockMvc.perform(MockMvcRequestBuilders.multipart("/orders")
				.file("file", file.getBytes()).param("account_id", UUID.randomUUID().toString()).headers(headers));

		// Assert
		response.andExpect(MockMvcResultMatchers.status().isBadRequest())
				.andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.content().json(
						"{\"code\":\"OUS-3\",\"message\":\"Invalid 'country'\",\"details\":[\"country is mandatory\"]}"));
	}

	@Test
	void itNotShouldBeAbleToUploadFileWithoutRequestId() throws Exception {
		// Assemble
		HttpHeaders headers = new HttpHeaders();
//        headers.add("requestTraceId", UUID.randomUUID().toString());
		headers.add("country", "US");

		MockMultipartFile file = new MockMultipartFile("image", "WX20180207-134704@2x.png", "application/pdf",
				"Hello World".getBytes());

		// Action
		ResultActions response = mockMvc.perform(MockMvcRequestBuilders.multipart("/orders")
				.file("file", file.getBytes()).param("account_id", UUID.randomUUID().toString()).headers(headers));

		// Assert
		response.andExpect(MockMvcResultMatchers.status().isBadRequest())
				.andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.content().json(
						"{\"code\":\"OUS-2\",\"message\":\"Invalid 'requestTraceId'\",\"details\":[\"requestTraceId is mandatory\"]}"));
	}

	@Test
	void itShouldBeAbleToUploadFile() throws Exception {
		// Assemble
		HttpHeaders headers = new HttpHeaders();
		headers.add("requestTraceId", UUID.randomUUID().toString());
		headers.add("country", "US");

		MockMultipartFile file = new MockMultipartFile("file", "file.pdf", "application/pdf", "file".getBytes());

		var orderIdProcessor = UUID.randomUUID().toString();

		Mockito.when(orderUploadWeduuService.execute(Mockito.any(), Mockito.any())).thenReturn(orderIdProcessor);

		// Action
		ResultActions response = mockMvc.perform(
				MockMvcRequestBuilders.multipart("/orders").file(file).contentType(MediaType.MULTIPART_FORM_DATA)
						.param("account_id", UUID.randomUUID().toString()).headers(headers));

		response.andExpect(MockMvcResultMatchers.status().isAccepted())
				.andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.jsonPath("$.orderId").exists())
				.andExpect(MockMvcResultMatchers.jsonPath("$.orderId").isString())
				.andExpect(MockMvcResultMatchers.jsonPath("$.status").exists())
				.andExpect(MockMvcResultMatchers.jsonPath("$.status").isString())
				.andExpect(MockMvcResultMatchers.jsonPath("$.status").value("PENDING"));
	}

	@Test
	void itShouldNotBeAbleToReadOrderIdNonExisting() throws Exception {
		// Assemble
		HttpHeaders headers = new HttpHeaders();
		headers.add("requestTraceId", UUID.randomUUID().toString());
		headers.add("country", "US");

		var accountId = UUID.randomUUID().toString();
		var orderId = UUID.randomUUID().toString();

		// Action
		ResultActions response = mockMvc
				.perform(MockMvcRequestBuilders.get("/orders/" + accountId + "/" + orderId).headers(headers));

		response.andExpect(MockMvcResultMatchers.status().isBadRequest())
				.andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.content().json(
						"{\"code\":\"OUS-4\",\"message\":\"Invalid request.\",\"details\":[\"Order doesn't found with id '"+orderId+"'\"]}"));
	}

	@Test
	void itShouldBeAbleToReadOrder() throws Exception {
		// Assemble
		HttpHeaders headers = new HttpHeaders();
		headers.add("requestTraceId", UUID.randomUUID().toString());
		headers.add("country", "US");

		var accountId = UUID.fromString("2f6ae591-f4cc-4e0e-83a9-bdf6bb1f2e39").toString();
		var orderId = UUID.fromString("dc7d99d0-375f-4cef-9019-580ee7bda44f").toString();
		var providerOrderId = UUID.fromString("5db9af84-3b59-42ca-aa00-2d3212d76009").toString();
			
		var itemSku1 = UUID.fromString("0e9aa2e6-b4f5-4847-b65e-131456235489").toString();
		var itemSku2 = UUID.fromString("3b1773a5-10f0-4331-8dc1-f84f59a641a7").toString();
		var itemSku3 = UUID.fromString("f49c8d82-37aa-4fc2-812c-bf09e2497f5a").toString();
	
		var item1 = new OrderItem(itemSku1, 10);
		var item2 = new OrderItem(itemSku2, 20);
		var item3 = new OrderItem(itemSku3, 30);
		
		var order = new OrderUpload();
		order.setAccountId(accountId);
		order.setOrderId(orderId);
		order.setProvider(Provider.WEDUU);
		order.setStatus(OrderStatus.PROCESSED);
		order.setUpdatedAt(OffsetDateTime.now());
		order.setProviderOrderId(providerOrderId);
		order.setDeleted(false);
		order.setItems(List.of(item1, item2, item3));
		
		saveOrderService.execute(order);

		// Action
		ResultActions response = mockMvc
				.perform(MockMvcRequestBuilders.get("/orders/" + accountId + "/" + orderId).headers(headers));

		response.andExpect(MockMvcResultMatchers.status().isOk())
				.andExpect(MockMvcResultMatchers.content().contentType(MediaType.APPLICATION_JSON))
				.andExpect(MockMvcResultMatchers.content().json("{\"status\":\"PROCESSED\",\"items\":[{\"sku\":\"0e9aa2e6-b4f5-4847-b65e-131456235489\",\"quantity\":10},{\"sku\":\"3b1773a5-10f0-4331-8dc1-f84f59a641a7\",\"quantity\":20},{\"sku\":\"f49c8d82-37aa-4fc2-812c-bf09e2497f5a\",\"quantity\":30}]}"));
	}
}
