package com.abinbev.b2b.link.orderupload.services.weduu;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ActiveProfiles;

import com.abinbev.b2b.link.orderupload.BaseSuite;
import com.abinbev.b2b.link.orderupload.utilities.clients.weduu.OrderUploaded;
import com.abinbev.b2b.link.orderupload.utilities.clients.weduu.WeduuClient;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderUpload;
import com.abinbev.b2b.link.orderupload.utilities.interceptors.ContextHolder;

@SpringBootTest
@ActiveProfiles("test")
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
class OrderUploadWeduuServiceTests extends BaseSuite {

	@Autowired
	private OrderUploadWeduuService orderUploadWeduuService;
	
	@MockBean
	private WeduuClient weduuClient;
	
	@Autowired
	private MongoTemplate template;
	
	@BeforeEach
	void each() {
		ContextHolder.setCountry("US");
		ContextHolder.setRequestTraceId(UUID.randomUUID().toString());
		template.dropCollection(OrderUpload.class);
	}

	@Test
	void itShouldBeAbleToUploadOrderWeduu() {
		// Assemble
		var order = new OrderUploaded();
		order.setId("id");
		
		Mockito.when(weduuClient.uploadOrder(Mockito.any(), Mockito.any())).thenReturn(order);
		
		var file = new MockMultipartFile("user-file", "test.txt", "application/pdf", "test data".getBytes());
		
		// Actions
		var response = orderUploadWeduuService.execute(UUID.randomUUID(), file);
		
		// Assertions
		assertThat(response).isEqualTo(order.getId());
	}
}
