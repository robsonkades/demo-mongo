package com.abinbev.b2b.link.orderupload.services;

import static org.junit.Assert.assertThrows;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.ActiveProfiles;

import com.abinbev.b2b.link.orderupload.BaseSuite;

@SpringBootTest
@ActiveProfiles("test")
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
class GetProviderServiceTests extends BaseSuite {
	
	@Autowired
	private GetProviderService getProviderService;
	
	@Test
	void itShouldBeAbleInjectProvider() {
		var provider = getProviderService.getOrderUpload("WEDUU");
		Assertions.assertNotNull(provider);
	}
	
	@Test
	void itShouldNotBeAbleInjectProviderIfNonExisting() {
	    assertThrows(IllegalArgumentException.class, () -> getProviderService.getOrderUpload("FAKE"));
	}
}
