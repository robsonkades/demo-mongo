package com.abinbev.b2b.link.orderupload.utilities.messages;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.Set;
import javax.validation.ConstraintViolation;

public abstract class AbstractRequest {

  /*
   * Important: it must not be visible for clients, because we do not know the formats sent by them.
   * If we decide to expose this field, we would have to guarantee the entry always UTC, in which
   * case receiving a java.time.OffSetDateTime would be better.
   */
  @JsonIgnore private Long updatedAt;

  @JsonIgnore private boolean hasError;

  @JsonIgnore private Set<ConstraintViolation<AbstractRequest>> constraintViolations;

  public Long getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(final Long updatedAt) {
    this.updatedAt = updatedAt;
  }

  public boolean hasError() {
    return hasError;
  }

  public void setHasError(final boolean hasError) {
    this.hasError = hasError;
  }

  public Set<ConstraintViolation<AbstractRequest>> getConstraintViolations() {
    return constraintViolations;
  }

  public void setConstraintViolations(
      final Set<ConstraintViolation<AbstractRequest>> constraintViolations) {
    this.constraintViolations = constraintViolations;
  }
}
