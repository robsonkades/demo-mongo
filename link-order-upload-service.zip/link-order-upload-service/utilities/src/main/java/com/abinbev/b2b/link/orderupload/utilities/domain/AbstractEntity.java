package com.abinbev.b2b.link.orderupload.utilities.domain;

import com.abinbev.b2b.link.orderupload.utilities.formatter.OffsetDateTimeDeserializer;
import com.abinbev.b2b.link.orderupload.utilities.formatter.OffsetDateTimeSerializer;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import java.time.OffsetDateTime;

public abstract class AbstractEntity {

  @JsonSerialize(using = OffsetDateTimeSerializer.class)
  @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
  protected OffsetDateTime updatedAt;

  @JsonIgnore protected boolean deleted = false;

  protected AbstractEntity() {
    // Default constructor
  }

  public OffsetDateTime getUpdatedAt() {
    return updatedAt;
  }

  public void setUpdatedAt(final OffsetDateTime updatedAt) {
    this.updatedAt = updatedAt;
  }

  public boolean isDeleted() {
    return deleted;
  }

  public void setDeleted(final boolean deleted) {
    this.deleted = deleted;
  }
}
