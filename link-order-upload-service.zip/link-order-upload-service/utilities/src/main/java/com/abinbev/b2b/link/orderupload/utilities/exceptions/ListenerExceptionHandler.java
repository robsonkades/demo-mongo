package com.abinbev.b2b.link.orderupload.utilities.exceptions;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.util.ErrorHandler;

public class ListenerExceptionHandler implements ErrorHandler {

  private static final Logger LOGGER = LoggerFactory.getLogger(ListenerExceptionHandler.class);

  @Override
  public void handleError(final Throwable throwable) {
    LOGGER.error(throwable.getMessage(), throwable);
    throw new AmqpRejectAndDontRequeueException(throwable);
  }
}
