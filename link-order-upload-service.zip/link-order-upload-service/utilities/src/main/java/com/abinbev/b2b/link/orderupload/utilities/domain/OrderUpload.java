package com.abinbev.b2b.link.orderupload.utilities.domain;

import java.util.ArrayList;
import java.util.List;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "#{@dbCollections.findOrderUploadCollectionByCountry()}")
public class OrderUpload extends AbstractEntity {

  @Id private String orderId;

  private String accountId;

  private OrderStatus status = OrderStatus.PENDING;

  private Provider provider;

  private String providerOrderId;
  
  private List<OrderItem> items = new ArrayList<>();

  public String getOrderId() {
    return orderId;
  }

  public void setOrderId(String orderId) {
    this.orderId = orderId;
  }

  public String getAccountId() {
    return accountId;
  }

  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  public OrderStatus getStatus() {
    return status;
  }

  public void setStatus(OrderStatus status) {
    this.status = status;
  }

  public Provider getProvider() {
    return provider;
  }

  public void setProvider(Provider provider) {
    this.provider = provider;
  }

  public String getProviderOrderId() {
    return providerOrderId;
  }

  public void setProviderOrderId(String providerOrderId) {
    this.providerOrderId = providerOrderId;
  }
  
  public List<OrderItem> getItems() {
    return items;
  }
  
  public void setItems(List<OrderItem> items) {
    this.items = items;
  }
}
