package com.abinbev.b2b.link.orderupload.utilities.queues;

import java.util.ArrayList;
import java.util.List;

public class MessageQueues {

  private List<String> orderUploadQueues = new ArrayList<>();

  public List<String> getOrderUploadQueues() {
    return orderUploadQueues;
  }

  public void setOrderUploadQueues(List<String> orderUploadQueues) {
    this.orderUploadQueues = orderUploadQueues;
  }
}
