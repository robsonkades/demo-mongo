package com.abinbev.b2b.link.orderupload.utilities.exceptions;

public class InvalidCountryException extends GlobalException {

	private static final long serialVersionUID = 7036801235167112830L;

	public InvalidCountryException(final Issue issue) {
		super(issue);
	}

	public InvalidCountryException(final Issue issue, final Exception ex) {
		super(issue, ex);
	}
//
//  public static InvalidCountryException invalidCountryJWT(final String country) {
//    return new InvalidCountryException(new Issue(IssueEnum.INVALID_COUNTRY_JWT, country));
//  }
}
