package com.abinbev.b2b.link.orderupload.utilities.helpers;

public abstract class Constants {

  public static final String REQUEST_TRACE_ID_HEADER = "requestTraceId";
  
  public static final String RETRY_HEADER = "retry";
  
  public static final String LOCALE = "locale";
  
  public static final String DELAY_HEADER = "x-delay";

  public static final String COUNTRY_HEADER = "country";

  public static final String VENDOR_ID = "vendorId";

  public static final String PROVIDER = "provider";

  public static final String SERVICE_UNAVAILABLE =
      "The server does not exists or is temporarily down.";

  public static final String SUPPORTED_EXTENSION_FILE =
      "Supported types are: PDF, DOC(X), XLS(X) and CSV.";

  public static final String SERVICE_ORDER_PROCESSOR_UNAVAILABLE =
      "The order processor service does not exists or is temporarily down.";

  public static final String FAILED_STATUS_CODE = "Failed! %s";
  
  public static final String SIZE_LIMIT_EXCEEDED = "File exceeds the configured maximum size of (%s).";

  private Constants() {}
}
