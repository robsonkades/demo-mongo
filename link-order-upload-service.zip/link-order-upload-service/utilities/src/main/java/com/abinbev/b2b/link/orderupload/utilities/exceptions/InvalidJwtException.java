package com.abinbev.b2b.link.orderupload.utilities.exceptions;

public class InvalidJwtException extends GlobalException {

	private static final long serialVersionUID = -5939441266594938067L;

	public InvalidJwtException(final Issue issue) {
		super(issue);
	}

	public InvalidJwtException(final Issue issue, final Exception ex) {
		super(issue, ex);
	}

//  public static InvalidJwtException invalidJWT() {
//    return new InvalidJwtException(new Issue(IssueEnum.INVALID_JWT));
//  }
}
