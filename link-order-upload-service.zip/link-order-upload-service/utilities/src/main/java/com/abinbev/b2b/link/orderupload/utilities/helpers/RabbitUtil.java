package com.abinbev.b2b.link.orderupload.utilities.helpers;

import org.apache.commons.lang3.StringUtils;

public class RabbitUtil {

  private RabbitUtil() {}

  public static String buildQueueName(final String country, final String queueSuffixName) {
    return String.format(RabbitConstant.TEXT_QUEUE_FORMAT, country.toLowerCase(), queueSuffixName);
  }

  public static String buildRoutingKey(final String country) {
    return country.toLowerCase();
  }

  public static String buildRoutingKey(final String country, final String routingKeySuffixName) {

    if (StringUtils.isEmpty(routingKeySuffixName)) {
      return buildRoutingKey(country);
    }
    return String.format(
        RabbitConstant.TEXT_QUEUE_FORMAT, country.toLowerCase(), routingKeySuffixName);
  }

  public static String buildDeadLetterRoutingKey(final String routingKey) {
    return String.format(
        RabbitConstant.TEXT_QUEUE_FORMAT,
        routingKey.toLowerCase(),
        RabbitConstant.DEAD_LETTER_SUFFIX);
  }
}
