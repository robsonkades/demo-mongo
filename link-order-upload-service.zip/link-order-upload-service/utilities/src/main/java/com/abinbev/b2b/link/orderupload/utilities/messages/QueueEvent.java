package com.abinbev.b2b.link.orderupload.utilities.messages;

import com.abinbev.b2b.link.orderupload.utilities.formatter.DateFormatUtil;
import com.abinbev.b2b.link.orderupload.utilities.interceptors.ContextHolder;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonUnwrapped;

public class QueueEvent {

  private Long updatedAt;
  private String country;

  @JsonUnwrapped private Object messageObject;

  public QueueEvent() {
    super();
  }

  public QueueEvent(final AbstractRequest messageObject) {
    this.messageObject = messageObject;
    this.setUpdatedAt(messageObject.getUpdatedAt());
    this.setCountry(ContextHolder.getCountry());
  }

  public QueueEvent(final Object messageObject) {
    this.messageObject = messageObject;
    this.setUpdatedAt(System.currentTimeMillis());
    this.setCountry(ContextHolder.getCountry());
  }

  @JsonIgnore
  public Long getUpdatedAt() {
    return this.updatedAt;
  }

  public String getCountry() {
    return this.country;
  }

  public void setCountry(final String country) {
    this.country = country;
  }

  public void setMessageObject(final Object messageObject) {
    this.messageObject = messageObject;
  }

  @JsonProperty("updatedAt")
  public void setUpdatedAt(final String updatedAt) {
    this.updatedAt = DateFormatUtil.toTimeMilisWithOffset(updatedAt);
  }

  @JsonProperty("updatedAt")
  public String getUpdatedAtAsString() {
    return DateFormatUtil.toStringISOFromMillis(this.updatedAt);
  }

  public void setUpdatedAt(final Long updatedAt) {
    this.updatedAt = updatedAt;
  }
}
