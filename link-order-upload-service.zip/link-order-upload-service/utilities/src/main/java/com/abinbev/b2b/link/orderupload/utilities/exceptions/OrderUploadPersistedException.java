package com.abinbev.b2b.link.orderupload.utilities.exceptions;

public class OrderUploadPersistedException extends GlobalException {

	private static final long serialVersionUID = 5708184274116426936L;

	public OrderUploadPersistedException(final Issue issue) {
		super(issue);
	}

	public OrderUploadPersistedException(final Issue issue, final Exception ex) {
		super(issue, ex);
	}
}
