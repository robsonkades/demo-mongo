package com.abinbev.b2b.link.orderupload.utilities.repositories;

import com.abinbev.b2b.link.orderupload.utilities.domain.OrderUpload;
import java.util.List;
import java.util.Optional;

public interface OrderUploadRepository {

  Optional<OrderUpload> find(
      final String country, final String provider, final String orderId, final String accountId);

  List<OrderUpload> listAll(final String country);

  boolean upsert(final String country, final OrderUpload entity);
}
