package com.abinbev.b2b.link.orderupload.utilities.interceptors;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.support.ListenerExecutionFailedException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.ListenerException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.TraceIdException;
import com.abinbev.b2b.link.orderupload.utilities.helpers.Constants;

public class RequestTraceIdHeaderListener implements MethodInterceptor {

  @Override
  public Object invoke(MethodInvocation invocation) throws Throwable {
    final Message message = (Message) invocation.getArguments()[1];

    try {
      final String requestTraceId = findRequestTraceIdHeader(message);
      final String country = findRequestHeaders(Constants.COUNTRY_HEADER, message);
      
      ContextHolder.setRequestTraceId(requestTraceId);
      ContextHolder.setCountry(country);

      MDC.put(Constants.REQUEST_TRACE_ID_HEADER, requestTraceId);
      MDC.put(Constants.COUNTRY_HEADER, country);

      return invocation.proceed();
    } finally {
      MDC.clear();
    }
  }

  private String findRequestTraceIdHeader(final Message message) {
    final String requestTraceId =
        (String) message.getMessageProperties().getHeaders().get(Constants.REQUEST_TRACE_ID_HEADER);

    if (StringUtils.isEmpty(requestTraceId)) {
      throw new ListenerExecutionFailedException(
          "Undefined requestTraceId header.",
          new TraceIdException("Missing requestTraceId header on message."),
          message);
    }
    return requestTraceId;
  }

  private String findRequestHeaders(final String headerName, final Message message) {
    final String headerValue = (String) message.getMessageProperties().getHeaders().get(headerName);

    if (StringUtils.isEmpty(headerValue)) {
      throw new ListenerExecutionFailedException(
          String.format("Undefined %s header.", headerName),
          new ListenerException(String.format("Missing %s header on message.", headerName)),
          message);
    }
    return headerValue;
  }
}
