package com.abinbev.b2b.link.orderupload.utilities.configs;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfiguration {

	private WebClient.Builder webClientBuilder;

	@Value("${orderProcessor.weduu.baseUrl}")
	private String baseUrl;

	public WebClientConfiguration(WebClient.Builder webClientBuilder) {
	    this.webClientBuilder = webClientBuilder;
	  }

	@Bean("weduu")
	public WebClient webClient() {
		return webClientBuilder.baseUrl(this.baseUrl).build();
	}
}
