package com.abinbev.b2b.link.orderupload.utilities.exceptions;

public class ListenerException extends GlobalException {

	private static final long serialVersionUID = 4485216895229783712L;

	public ListenerException(final Issue issue) {
		super(issue);
	}

	public ListenerException(final Issue issue, final Exception ex) {
		super(issue, ex);
	}
}
