package com.abinbev.b2b.link.orderupload.utilities.services;

import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.abinbev.b2b.link.orderupload.utilities.interceptors.ContextHolder;

@Service
public class TranslationService {

	private final MessageSource messageSource;

	public TranslationService(final MessageSource messageSource) {
		this.messageSource = messageSource;
	}

	public String execute(String key, Object... args) {
		return this.messageSource.getMessage(key, args, ContextHolder.getLocale());
	}
}
