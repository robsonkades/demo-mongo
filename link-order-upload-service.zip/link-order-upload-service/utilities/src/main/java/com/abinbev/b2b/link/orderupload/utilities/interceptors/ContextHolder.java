package com.abinbev.b2b.link.orderupload.utilities.interceptors;

import com.abinbev.b2b.link.orderupload.utilities.helpers.Constants;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

import org.slf4j.MDC;

public class ContextHolder {

  private static ThreadLocal<Map<String, String>> requestContext = new ThreadLocal<>();

  private ContextHolder() {
    super();
  }

  private static synchronized Map<String, String> getContext() {
    Map<String, String> ctx = requestContext.get();

    if (ctx == null) {
      ctx = new HashMap<>();
      requestContext.set(ctx);
    }

    return ctx;
  }

  public static synchronized void clearContext() {
    requestContext.remove();
    MDC.remove(Constants.COUNTRY_HEADER);
    MDC.remove(Constants.REQUEST_TRACE_ID_HEADER);
  }

  public static void setCountry(final String country) {
    getContext().put(Constants.COUNTRY_HEADER, country);
    MDC.put(Constants.COUNTRY_HEADER, country);
  }

  public static void setRequestTraceId(final String requestTraceId) {
    getContext().put(Constants.REQUEST_TRACE_ID_HEADER, requestTraceId);
    MDC.put(Constants.REQUEST_TRACE_ID_HEADER, requestTraceId);
  }

  public static void setVendorId(final String vendorId) {
    getContext().put(Constants.VENDOR_ID, vendorId);
    MDC.put(Constants.VENDOR_ID, vendorId);
  }
  
  public static void setLocale(final String locale) {
	getContext().put(Constants.LOCALE, locale);
	MDC.put(Constants.LOCALE, locale);
  }

  public static String getCountry() {
    return getContext().get(Constants.COUNTRY_HEADER);
  }

  public static String getRequestTraceId() {
    return getContext().get(Constants.REQUEST_TRACE_ID_HEADER);
  }

  public static String getVendorId() {
    return getContext().get(Constants.VENDOR_ID);
  }
  
  public static Locale getLocale() {
	  String locale = getContext().get(Constants.LOCALE);
	  
	  if (Objects.isNull(locale)) {
		  return Locale.ENGLISH;
	  }
	  
	  return Locale.forLanguageTag(locale);
  }
}
