package com.abinbev.b2b.link.orderupload.utilities.domain;

public enum ItemStatus {
	UNAVAILABLE,
	AVAILABLE
}
