package com.abinbev.b2b.link.orderupload.utilities.services;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.Issue;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.IssueEnum;
import com.abinbev.b2b.link.orderupload.utilities.helpers.Constants;
import com.abinbev.b2b.link.orderupload.utilities.interceptors.ContextHolder;
import com.abinbev.b2b.link.orderupload.utilities.messages.AbstractRequest;
import com.abinbev.b2b.link.orderupload.utilities.messages.QueueEvent;

import static com.abinbev.b2b.link.orderupload.utilities.exceptions.GlobalException.globalException;

@Service
public class SendMessageService {

  private RabbitTemplate template;
  private ObjectMapper mapper;

  public SendMessageService(RabbitTemplate template, ObjectMapper mapper) {
    this.template = template;
    this.mapper = mapper;
  }

  public void execute(
      final AbstractRequest object, final String exchange, final String routingKey) {
    final QueueEvent event = new QueueEvent(object);
    Map<String, Object> headers = new HashMap<>();
    sendMessage(event, exchange, routingKey, headers);
  }
  
  public void execute(
      final AbstractRequest object, final String exchange, final String routingKey, Map<String, Object> headers) {
    final QueueEvent event = new QueueEvent(object);
    sendMessage(event, exchange, routingKey, headers);
  }

  private void sendMessage(final Object message, final String exchange, final String routingKey, Map<String, Object> headers) {
    final MessageProperties messageProperties = new MessageProperties();
    messageProperties.setHeader(Constants.COUNTRY_HEADER, ContextHolder.getCountry());
    messageProperties.setHeader(Constants.REQUEST_TRACE_ID_HEADER, ContextHolder.getRequestTraceId());    

    headers.keySet().forEach(item -> {
      var value = headers.get(item);
      messageProperties.setHeader(item, value);
    });
    
    sendMessage(message, exchange, messageProperties, routingKey);
  }

  private void sendMessage(
      final Object message,
      final String exchange,
      final MessageProperties messageProperties,
      final String routingKey) {

    try {
      messageProperties.setContentType(MediaType.APPLICATION_JSON_VALUE);
      template.convertAndSend(
          exchange,
          routingKey != null ? routingKey : messageProperties.getReceivedRoutingKey(),
          new Message(mapper.writeValueAsBytes(message), messageProperties));
    } catch (final Exception e) {
      throw globalException(new Issue(IssueEnum.INTERNAL_SERVER_ERROR, e.getMessage()));
    }
  }
}
