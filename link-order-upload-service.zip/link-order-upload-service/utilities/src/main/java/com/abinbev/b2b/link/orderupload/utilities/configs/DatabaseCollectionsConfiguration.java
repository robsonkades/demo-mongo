package com.abinbev.b2b.link.orderupload.utilities.configs;

import com.abinbev.b2b.link.orderupload.utilities.exceptions.BadRequestException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.IssueEnum;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.IssueHandler;
import com.abinbev.b2b.link.orderupload.utilities.helpers.Constants;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration("dbCollections")
@ConfigurationProperties(prefix = "database.collections")
public class DatabaseCollectionsConfiguration {

  private static final Logger logger =
      LoggerFactory.getLogger(DatabaseCollectionsConfiguration.class);

  private static final TypeReference<Map<String, String>> TYPE =
      new TypeReference<Map<String, String>>() {};

  @Value("#{environment.DATABASE_COLLECTIONS_ORDER_UPLOAD}")
  private String orderUploadCollectionsFromEnv;

  private Map<String, String> orderUpload;

  public void setOrderUpload(Map<String, String> orderUpload) {

    if (StringUtils.isNotBlank(this.orderUploadCollectionsFromEnv)) {

      try {
        this.orderUpload = new ObjectMapper().readValue(orderUploadCollectionsFromEnv, TYPE);
      } catch (final Exception e) {
        logger.error(e.getMessage(), e);
        this.orderUpload = null;
      }
    } else {
      this.orderUpload = orderUpload;
    }
  }

  public Map<String, String> getOrderUpload() {
    return orderUpload;
  }

  public String findOrderUploadCollectionByCountry(final String country) {

    if (orderUpload != null && StringUtils.isNotBlank(country)) {
      final String countryParam = country.toLowerCase();
      final String collectionName = orderUpload.get(countryParam);

      if (StringUtils.isNotBlank(collectionName)) {
        return collectionName;
      }
    }

    List<String> supportedCountries =
        orderUpload != null
            ? orderUpload.keySet().stream()
                .map(String::toLowerCase)
                .collect(Collectors.toList())
            : null;

    throw new BadRequestException(
        IssueHandler.createIssue(IssueEnum.UNSUPPORTED_COUNTRY, country, supportedCountries));
  }

  public String findOrderUploadCollectionByCountry() {
    final String country = MDC.get(Constants.COUNTRY_HEADER);
    return findOrderUploadCollectionByCountry(country);
  }

  public Set<String> getSupportedCountries() {

    if (this.orderUpload == null) {
      return Collections.emptySet();
    }
    return this.orderUpload.keySet();
  }
}
