package com.abinbev.b2b.link.orderupload.utilities.clients.weduu;

import java.io.IOException;
import java.net.ConnectException;
import java.nio.channels.ClosedChannelException;
import java.util.Optional;
import java.util.UUID;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.MultipartBodyBuilder;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.abinbev.b2b.link.orderupload.utilities.exceptions.BadRequestException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.GlobalException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.ServiceUnavailableException;
import com.abinbev.b2b.link.orderupload.utilities.helpers.Constants;
import com.google.common.io.Files;

import io.netty.channel.unix.Errors.NativeIoException;
import reactor.core.publisher.Mono;

@Component
public class WeduuClient {

	private final WebClient webClient;
	private final AuthCredential authCredential;

	public WeduuClient(@Qualifier("weduu") final WebClient webClient, @Qualifier("weduuCredentials") AuthCredential authCredential) {
		this.webClient = webClient;
		this.authCredential = authCredential;
	}

	public OrderUploaded uploadOrder(UUID accountId, MultipartFile file) {
		return webClient
				.post()
				.uri("/upload")
				.headers(httpHeaders -> httpHeaders.setBearerAuth(getToken().getToken()))
				.body(BodyInserters.fromMultipartData(generateBody(accountId, file)))
				.retrieve()
				.onStatus(HttpStatus::isError, response -> {
					if (HttpStatus.NOT_FOUND.equals(response.statusCode())
							|| HttpStatus.SERVICE_UNAVAILABLE.equals(response.statusCode())) {
						return Mono.error(ServiceUnavailableException.orderProcessorUnavailable());
					}
					return Mono.error(new IllegalStateException(
							String.format(Constants.FAILED_STATUS_CODE, response.statusCode())));
				})
				.bodyToMono(OrderUploaded.class)
				.onErrorMap(e -> {
					if (ExceptionUtils.getRootCause(e) instanceof ConnectException
							|| ExceptionUtils.getRootCause(e) instanceof ClosedChannelException
							|| ExceptionUtils.getRootCause(e) instanceof NativeIoException) {
						return ServiceUnavailableException.orderProcessorUnavailable();
					}
					return e;
				})
				.block();
	}

	public OrderProcessed getOrder(String orderId) {
		return webClient
				.post()
				.uri("/get_order/{orderId}", orderId)
				.headers(httpHeaders -> httpHeaders.setBearerAuth(getToken().getToken()))
				.retrieve()
				.onStatus(HttpStatus::isError, response -> {
					if (HttpStatus.NOT_FOUND.equals(response.statusCode())
							|| HttpStatus.SERVICE_UNAVAILABLE.equals(response.statusCode())) {
						return Mono.error(ServiceUnavailableException.orderProcessorUnavailable());
					}
					return Mono.error(new IllegalStateException(
							String.format(Constants.FAILED_STATUS_CODE, response.statusCode())));
				})
				.bodyToMono(OrderProcessed.class)
				.onErrorMap(e -> {
					if (ExceptionUtils.getRootCause(e) instanceof ConnectException
							|| ExceptionUtils.getRootCause(e) instanceof ClosedChannelException
							|| ExceptionUtils.getRootCause(e) instanceof NativeIoException) {
						return ServiceUnavailableException.orderProcessorUnavailable();
					}

					return e;
				})
				.block();
	}

	@Cacheable("orderprocessor.auth.token")
	private AuthToken getToken() {
		return webClient
				.post()
				.uri("/auth/login")
				.body(Mono.just(authCredential), AuthCredential.class)
				.retrieve()
				.onStatus(HttpStatus::isError, response -> {
					if (HttpStatus.NOT_FOUND.equals(response.statusCode())
							|| HttpStatus.SERVICE_UNAVAILABLE.equals(response.statusCode())
							|| HttpStatus.BAD_GATEWAY.equals(response.statusCode())) {
						return Mono.error(ServiceUnavailableException.orderProcessorUnavailable());
					}
					return Mono.error(new IllegalStateException(
							String.format(Constants.FAILED_STATUS_CODE, response.statusCode())));
				})
				.bodyToMono(AuthToken.class)
				.onErrorMap(e -> {
					if (ExceptionUtils.getRootCause(e) instanceof ConnectException
							|| ExceptionUtils.getRootCause(e) instanceof ClosedChannelException
							|| ExceptionUtils.getRootCause(e) instanceof NativeIoException) {
						return ServiceUnavailableException.orderProcessorUnavailable();
					}

					return e;
				})
				.block();

	}

	private MultiValueMap<String, HttpEntity<?>> generateBody(UUID accountId, MultipartFile file) {

		MultipartBodyBuilder builder = new MultipartBodyBuilder();
		
		String originalfileName = Optional.of(file.getOriginalFilename()).orElseThrow(BadRequestException::fileNameNotFound);
		
		String  filename = String.format("%s.%s", accountId, Files.getFileExtension(originalfileName));
		String header = String.format("form-data; name=%s; filename=%s", "file", filename);

		try {
			builder.part("id", UUID.randomUUID().toString());
			builder.part("file", new ByteArrayResource(file.getBytes())).header("Content-Disposition", header);
			builder.part("account_id", accountId.toString());
		} catch (IOException e) {
			throw GlobalException.globalException();
		}

		return builder.build();
	}

}
