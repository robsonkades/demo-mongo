package com.abinbev.b2b.link.orderupload.utilities.repositories.impl;

import static org.springframework.data.mongodb.core.query.Criteria.where;

import com.abinbev.b2b.link.orderupload.utilities.configs.DatabaseCollectionsConfiguration;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderUpload;
import com.abinbev.b2b.link.orderupload.utilities.repositories.OrderUploadRepository;
import com.google.common.collect.ImmutableSet;
import com.mongodb.BasicDBList;
import com.mongodb.client.result.UpdateResult;
import com.newrelic.api.agent.Trace;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

@Repository
public class OrderUploadRepositoryImpl implements OrderUploadRepository {

  private static final Logger LOGGER = LoggerFactory.getLogger(OrderUploadRepositoryImpl.class);

  private final DatabaseCollectionsConfiguration properties;
  private final MongoTemplate template;

  static final String ID_KEY = "_id";
  static final String ACCOUNT_ID = "accountId";
  static final String UPDATED_AT = "updatedAt";
  static final String STATUS = "status";
  static final String PROVIDER = "provider";
  static final String PROVIDER_ORDER_ID = "providerOrderId";
  static final String ITEMS = "items";
  static final String DELETED = "deleted";

  public OrderUploadRepositoryImpl(
      final DatabaseCollectionsConfiguration properties, final MongoTemplate template) {
    this.properties = properties;
    this.template = template;
  }

  @Override
  public Optional<OrderUpload> find(
      final String country, final String provider, final String orderId, final String accountId) {
    final String collection = this.properties.findOrderUploadCollectionByCountry(country);

    final Query query =
        Query.query(
            where(ID_KEY).is(orderId).and(ACCOUNT_ID).is(accountId).and(PROVIDER).is(provider).and(DELETED).is(false));

    return Optional.ofNullable(this.template.findOne(query, OrderUpload.class, collection));
  }

  @Override
  @Trace
  public List<OrderUpload> listAll(String country) {
    final String collection = this.properties.findOrderUploadCollectionByCountry(country);
    return this.template.findAll(OrderUpload.class, collection);
  }

  @Override
  @Trace
  public boolean upsert(final String country, final OrderUpload entity) {
    LOGGER.info("Starting upsert for the order upload '{}'", entity.getOrderId());
    final String collection = this.properties.findOrderUploadCollectionByCountry(country);
    final Document doc = createDocument(entity);

    final Query query = Query.query(where(ID_KEY).is(entity.getOrderId()));

    final UpdateResult result = this.template.upsert(query, buildUpdate(doc, ID_KEY), collection);
    final boolean wasSuccessful = result.getUpsertedId() != null || result.getModifiedCount() > 0;

    if (wasSuccessful) {
      LOGGER.info("Ending the order Upload '{}' upsert successfully", entity.getAccountId());
      return true;
    }

    LOGGER.info("Ending the order Upload '{}' upsert unsuccessfully", entity.getAccountId());
    return false;
  }

  Document createDocument(final OrderUpload orderUpload) {
    final Document document = new Document();
    document.put(ID_KEY, orderUpload.getOrderId());
    document.put(ACCOUNT_ID, orderUpload.getAccountId());
    document.put(STATUS, orderUpload.getStatus());
    document.put(UPDATED_AT, orderUpload.getUpdatedAt());
    document.put(PROVIDER, orderUpload.getProvider());
    document.put(PROVIDER_ORDER_ID, orderUpload.getProviderOrderId());
    document.put(ITEMS, orderUpload.getItems());
    document.put(DELETED, orderUpload.isDeleted());
    return document;
  }

  Update buildUpdate(final Document object, final String... ignoredFields) {
    final Set<String> ignoredFieldsSet = ImmutableSet.copyOf(ignoredFields);
    final Update update = new Update();

    for (Map.Entry<String, Object> entry : object.entrySet()) {

      if (ignoredFieldsSet.contains(entry.getKey())) {
        continue;
      }

      final Object value = entry.getValue();
      final boolean isNotEmpty =
          value instanceof BasicDBList ? !((BasicDBList) value).isEmpty() : value != null;

      if (isNotEmpty) {
        update.set(entry.getKey(), value);
      } else {
        update.unset(entry.getKey());
      }
    }
    return update;
  }
}
