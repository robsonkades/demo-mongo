package com.abinbev.b2b.link.orderupload.utilities.interceptors;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.METHOD, ElementType.TYPE})
public @interface RequestValidation {

  /**
   * Determines if requestTraceId is required.
   *
   * @return true when required
   */
  boolean requestTraceId() default true;

  /**
   * Determines if county is required.
   *
   * @return true when required
   */
  boolean country() default true;

  /**
   * Determines if x-bees-caller is required.
   *
   * @return true when required
   */
  boolean xBeesCaller() default false;

  /**
   * Determines if x-bees-origin is required.
   *
   * @return true when required
   */
  boolean xBeesOrigin() default false;
}
