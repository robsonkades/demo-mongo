package com.abinbev.b2b.link.orderupload.utilities.exceptions;

public class GlobalException extends RuntimeException {

	private static final long serialVersionUID = -5460482715460432544L;
	private final Issue issue;

	public GlobalException(final Issue issue) {
		this.issue = issue;
	}

	public GlobalException(final Issue issue, final Exception ex) {
		super(ex);
		this.issue = issue;
	}

	public Issue getIssue() {
		return issue;
	}
//  
//  public static GlobalException globalException(final Issue issue) {
//    return new GlobalException(issue);
//  }
//
//  public static GlobalException globalException() {
//    return new GlobalException(new Issue(IssueEnum.UNEXPECTED_ERROR));
//  }
}
