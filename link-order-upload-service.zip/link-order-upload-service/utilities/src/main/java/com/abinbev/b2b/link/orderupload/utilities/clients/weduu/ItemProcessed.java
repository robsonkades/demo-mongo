package com.abinbev.b2b.link.orderupload.utilities.clients.weduu;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ItemProcessed {

	@JsonProperty("cd_sku_output")
	private String sku;

	@JsonProperty("num_pedido")
	private String orderNumber;

	@JsonProperty("qty")
	private int quantity;

	@JsonProperty("status_curator")
	private String status;

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
