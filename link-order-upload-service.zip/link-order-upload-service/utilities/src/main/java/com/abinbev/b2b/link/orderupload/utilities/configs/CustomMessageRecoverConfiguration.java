package com.abinbev.b2b.link.orderupload.utilities.configs;

import com.abinbev.b2b.link.orderupload.utilities.helpers.Constants;
import com.abinbev.b2b.link.orderupload.utilities.helpers.RabbitConstant;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.retry.MessageRecoverer;
import org.springframework.amqp.rabbit.retry.RepublishMessageRecoverer;

public class CustomMessageRecoverConfiguration implements MessageRecoverer {

  private RabbitTemplate rabbitTemplate;

  public CustomMessageRecoverConfiguration(final RabbitTemplate rabbitTemplate) {
    this.rabbitTemplate = rabbitTemplate;
  }

  @Override
  public void recover(Message message, Throwable cause) {
    final String country = message.getMessageProperties().getHeader(Constants.COUNTRY_HEADER);
    final String routingKeyFormatted =
        String.format("%s-%s", country.toLowerCase(), RabbitConstant.DEAD_LETTER_SUFFIX);

    final RepublishMessageRecoverer republishMessageRecoverer =
        new RepublishMessageRecoverer(
            rabbitTemplate,
            message.getMessageProperties().getReceivedExchange(),
            routingKeyFormatted);
    republishMessageRecoverer.recover(message, cause);
  }
}
