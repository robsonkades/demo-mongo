package com.abinbev.b2b.link.orderupload.utilities.configs;

import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.caffeine.CaffeineCache;
import org.springframework.cache.support.SimpleCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.github.benmanes.caffeine.cache.Caffeine;
import com.github.benmanes.caffeine.cache.Ticker;

@Configuration
public class CacheConfiguration {
	
	@Value("${orderprocessor.weduu.auth.token:19800}")
	private int weduuTokenExpiresInSeconds;
	
	@Value("${bess.tokenExpiresIn:3000}")
	private int m2mTokenExpiresInSeconds;

	@Bean
	public CacheManager cacheManager(Ticker ticker) {
		CaffeineCache messageCache = buildCache("orderprocessor.auth.token", ticker, weduuTokenExpiresInSeconds);
		CaffeineCache notificationCache = buildCache("m2m-token", ticker, m2mTokenExpiresInSeconds);
		SimpleCacheManager manager = new SimpleCacheManager();
		manager.setCaches(Arrays.asList(messageCache, notificationCache));
		return manager;
	}

	private CaffeineCache buildCache(String name, Ticker ticker, int minutesToExpire) {
		return new CaffeineCache(name, Caffeine.newBuilder().expireAfterWrite(minutesToExpire, TimeUnit.SECONDS)
				.maximumSize(1).ticker(ticker).build());
	}

	@Bean
	public Ticker ticker() {
		return Ticker.systemTicker();
	}
}
