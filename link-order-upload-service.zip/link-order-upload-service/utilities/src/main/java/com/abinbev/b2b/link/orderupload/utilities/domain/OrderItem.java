package com.abinbev.b2b.link.orderupload.utilities.domain;

import org.springframework.data.annotation.Id;

public class OrderItem {

	@Id
	private String sku;
	private int quantity;
	private ItemStatus status;

	public OrderItem(String sku, int quantity) {
		this.sku = sku;
		this.quantity = quantity;
		this.status = quantity > 0 ? ItemStatus.AVAILABLE : ItemStatus.UNAVAILABLE;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public ItemStatus getStatus() {
		return status;
	}
	
	public void setStatus(ItemStatus status) {
		this.status = status;
	}

}
