package com.abinbev.b2b.link.orderupload.utilities.exceptions;

public class BadRequestException extends GlobalException {

	private static final long serialVersionUID = 804688946694461524L;

	public BadRequestException(final Issue issue) {
		super(issue);
	}
	
	public BadRequestException(final Issue issue, final Exception ex) {
		super(issue, ex);
	}

//	public static BadRequestException invalidParam(final IssueEnum issueType, final List<String> details) {
//		return new BadRequestException(new Issue(issueType, details));
//	}
//
//	public static BadRequestException invalidContentType() {
//		return new BadRequestException(new Issue(IssueEnum.INVALID_CONTENT_TYPE,
//				Collections.singletonList(Constants.SUPPORTED_EXTENSION_FILE)));
//	}
//
//	public static BadRequestException fileNotFound() {
//		return new BadRequestException(
//				new Issue(IssueEnum.BAD_REQUEST, Collections.singletonList("Order file not found.")));
//	}
//
//	public static BadRequestException orderNotFound(String orderId) {
//		return new BadRequestException(new Issue(IssueEnum.BAD_REQUEST,
//				Collections.singletonList(String.format("Order doesn't found with id '%s'", orderId))));
//	}
//	
//	public static BadRequestException fileNameNotFound() {
//		return new BadRequestException(new Issue(IssueEnum.BAD_REQUEST, Collections.singletonList("Order file name not found.")));
//	}
//
//	public static BadRequestException invalidFile(List<String> details) {
//		return new BadRequestException(new Issue(IssueEnum.INVALID_CONTENT_FILE, details));
//	}
//
//	public static BadRequestException invalidSizeFile(String maxfileSize) {
//		String detail = String.format(Constants.SIZE_LIMIT_EXCEEDED, maxfileSize);
//		return new BadRequestException(new Issue(IssueEnum.BAD_REQUEST, Collections.singletonList(detail)));
//	}
}
