package com.abinbev.b2b.link.orderupload.utilities.helpers;

public class RabbitConstant {

  private RabbitConstant() {}

  public static final String DEAD_LETTER_SUFFIX = "deadLetter";

  public static final String AMQPS_PROTOCOL = "amqps";

  public static final String AMQP_PROTOCOL = "amqp";

  public static final String RABBIT_URI_PATTERN = "%s://%s:%s@%s:%d/%s";

  public static final String TEXT_QUEUE_FORMAT = "%s-%s";
}
