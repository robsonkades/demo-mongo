package com.abinbev.b2b.link.orderupload.utilities.clients.weduu;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("weduuCredentials")
class AuthCredential {

	@Value("${orderProcessor.weduu.auth.email}")
	private String email;

	@Value("${orderProcessor.weduu.auth.password}")
	private String password;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
