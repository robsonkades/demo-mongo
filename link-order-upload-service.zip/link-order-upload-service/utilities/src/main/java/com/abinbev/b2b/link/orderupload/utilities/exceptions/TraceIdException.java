package com.abinbev.b2b.link.orderupload.utilities.exceptions;

public class TraceIdException extends GlobalException {

	private static final long serialVersionUID = -1813835171753833650L;

	public TraceIdException(Issue issue) {
		super(issue);
	}

	public TraceIdException(Issue issue, Exception ex) {
		super(issue, ex);
	}
}
