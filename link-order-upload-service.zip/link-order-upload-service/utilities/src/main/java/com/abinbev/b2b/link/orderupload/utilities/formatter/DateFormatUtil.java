package com.abinbev.b2b.link.orderupload.utilities.formatter;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import org.apache.commons.lang3.StringUtils;

public class DateFormatUtil {
  
  private DateFormatUtil() {}

  public static String toStringISOFromMillis(final Long epochMilli) {
    return epochMilli == null
        ? null
        : OffsetDateTime.ofInstant(Instant.ofEpochMilli(epochMilli), ZoneId.of("Z"))
            .format(DateTimeFormatter.ISO_DATE_TIME);
  }

  public static Long toTimeMilisWithOffset(final String offsetDateTime) {
    return StringUtils.isNotBlank(offsetDateTime)
        ? OffsetDateTime.parse(offsetDateTime, DateTimeFormatter.ISO_DATE_TIME)
            .toInstant()
            .toEpochMilli()
        : null;
  }
}
