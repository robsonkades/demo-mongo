package com.abinbev.b2b.link.orderupload.utilities.messages;

import com.abinbev.b2b.link.orderupload.utilities.domain.Provider;

public class OrderMessage extends AbstractRequest {

  private String orderId;
  private String accountId;
  private Provider provider;

  public String getOrderId() {
    return orderId;
  }

  public void setOrderId(String orderId) {
    this.orderId = orderId;
  }

  public String getAccountId() {
    return accountId;
  }

  public void setAccountId(String accountId) {
    this.accountId = accountId;
  }

  public Provider getProvider() {
    return provider;
  }

  public void setProvider(Provider provider) {
    this.provider = provider;
  }

  @Override
  public String toString() {
    return "Order [orderId=" + orderId + ", accountId=" + accountId + "]";
  }
}
