package com.abinbev.b2b.link.orderupload.utilities.exceptions;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class Issue implements Serializable {

	private static final long serialVersionUID = 608378656138245045L;

	private final String code;

	private final String message;

	private List<String> details;

	public Issue(final String code, final String message) {
		this.code = code;
		this.message = message;
	}

	public Issue(final String code, final String message, final List<String> details) {
		this.code = code;
		this.message = message;
		this.details = details;
	}

	public String getCode() {
		return code;
	}

	public List<String> getDetails() {
		return details;
	}

	public String getMessage() {
		return message;
	}

	@Override
	public String toString() {
		return String.format("Issue{code= %s, message='%s' details= '%s'}", code, message, details);
	}
}
