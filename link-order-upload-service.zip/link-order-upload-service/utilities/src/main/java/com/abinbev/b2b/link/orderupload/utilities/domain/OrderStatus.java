package com.abinbev.b2b.link.orderupload.utilities.domain;

public enum OrderStatus {
  PENDING,
  PROCESSED,
  ERROR
}
