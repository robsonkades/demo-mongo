package com.abinbev.b2b.link.orderupload.utilities.exceptions;

public class ServiceUnavailableException extends GlobalException {

	private static final long serialVersionUID = -1613240692772700998L;

	public ServiceUnavailableException(final Issue issue) {
		super(issue);
	}
	
	public ServiceUnavailableException(final Issue issue, final Exception ex) {
		super(issue, ex);
	}

//  public static ServiceUnavailableException build() {
//    return new ServiceUnavailableException(
//        new Issue(
//            IssueEnum.SERVICE_UNAVAILABLE,
//            Collections.singletonList(Constants.SERVICE_UNAVAILABLE)));
//  }
//
//  public static ServiceUnavailableException orderProcessorUnavailable() {
//    return new ServiceUnavailableException(
//        new Issue(
//            IssueEnum.SERVICE_UNAVAILABLE,
//            Collections.singletonList(
//                String.format(Constants.SERVICE_ORDER_PROCESSOR_UNAVAILABLE))));
//  }
}
