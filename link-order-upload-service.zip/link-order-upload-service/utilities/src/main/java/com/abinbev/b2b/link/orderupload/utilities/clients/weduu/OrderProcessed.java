package com.abinbev.b2b.link.orderupload.utilities.clients.weduu;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OrderProcessed {

	@JsonProperty("order_id")
	private String orderIdProcessor;

	private List<ItemProcessed> items;

	@JsonProperty("error")
	private boolean withError = false;

	private String file;

	private String status;

	private String uploaded;

	public String getOrderIdProcessor() {
		return orderIdProcessor;
	}

	public void setOrderIdProcessor(String orderIdProcessor) {
		this.orderIdProcessor = orderIdProcessor;
	}

	public List<ItemProcessed> getItems() {
		return items;
	}

	public void setItems(List<ItemProcessed> items) {
		this.items = items;
	}

	public boolean isWithError() {
		return withError;
	}

	public void setWithError(boolean withError) {
		this.withError = withError;
	}

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getUploaded() {
		return uploaded;
	}

	public void setUploaded(String uploaded) {
		this.uploaded = uploaded;
	}

}
