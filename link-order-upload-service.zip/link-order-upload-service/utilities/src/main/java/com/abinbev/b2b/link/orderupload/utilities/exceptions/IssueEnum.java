package com.abinbev.b2b.link.orderupload.utilities.exceptions;

public enum IssueEnum {

	UNEXPECTED_ERROR("OUS-0", "Unexpected error occurred, please contact the system administrator"),
	METHOD_NOT_ALLOWED("OUS-1", "%s method is not supported for this request. Supported methods are [%s]"),
	REQUEST_TRACE_ID_NOT_VALID("OUS-2", "Invalid 'requestTraceId'"),
	COUNTRY_NOT_VALID("OUS-3", "Invalid 'country'"),
	BAD_REQUEST("OUS-4", "Invalid request."),
	INVALID_JWT("OUS-5", "Invalid JWT"),
	INVALID_COUNTRY_JWT("OUS-6", "The user does not have access to country %s"),
	INVALID_CONTENT_TYPE("OUS-7", "Unsupported file type passed to upload."),
	INVALID_CONTENT_FILE("OUS-8", "Invalid file passed to upload."),
	SERVICE_UNAVAILABLE("OUS-9", "Service Unavailable."),
	UNSUPPORTED_COUNTRY("OUS-10", "The country '%s' is not supported. The supported countries are %s"),
	ORDER_NOT_FOUND("OUS-11", "The order doesn't found with id '%s' and country '%s'"),
	SERVICE_RETRY_TIMEOUT("OUS-12", "The order processor service response took too long."),
	INTERNAL_SERVER_ERROR("OUS-13", "An internal error has occurred [%s]"),
	SIZE_LIMIT_EXCEEDED("OUS-14", "File exceeds the configured maximum size of (%s)"),
	SERVICE_ORDER_PROCESSOR_UNAVAILABLE("OUS-15", "The order processor service is temporarily unavailable."),
	FAILED_STATUS_CODE("OUS-16", "Failed! %s"),
  FILE_NAME_NOT_FOUND("OUS-17", "Order file name not found."),
  FILE_NOT_FOUND("OUS-18", "Order file not found.");

	private final String code;

	private final String key;

	IssueEnum(final String code, final String key) {
		this.code = code;
		this.key = key;
	}

	public String getCode() {
		return code;
	}

	public String getKey() {
		return key;
	}
}
