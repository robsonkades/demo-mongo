package com.abinbev.b2b.link.orderupload.utilities.mock;

import com.abinbev.b2b.link.orderupload.utilities.messages.AbstractRequest;

public class RabbitMessageMock extends AbstractRequest {

  private String firstName;
  private String lastName;

  public RabbitMessageMock(String firstName, String lastName) {
    super();
    this.firstName = firstName;
    this.lastName = lastName;
  }

  public String getFirstName() {
    return firstName;
  }

  public void setFirstName(String firstName) {
    this.firstName = firstName;
  }

  public String getLastName() {
    return lastName;
  }

  public void setLastName(String lastName) {
    this.lastName = lastName;
  }
}
