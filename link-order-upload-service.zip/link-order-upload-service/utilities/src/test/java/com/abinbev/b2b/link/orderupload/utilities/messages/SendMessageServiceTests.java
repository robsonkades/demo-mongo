package com.abinbev.b2b.link.orderupload.utilities.messages;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.boot.json.JsonParseException;
import org.springframework.http.MediaType;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.GlobalException;
import com.abinbev.b2b.link.orderupload.utilities.helpers.Constants;
import com.abinbev.b2b.link.orderupload.utilities.helpers.RabbitUtil;
import com.abinbev.b2b.link.orderupload.utilities.interceptors.ContextHolder;
import com.abinbev.b2b.link.orderupload.utilities.mock.RabbitMessageMock;
import com.abinbev.b2b.link.orderupload.utilities.services.SendMessageService;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.doThrow;

@RunWith(MockitoJUnitRunner.class)
@ExtendWith(MockitoExtension.class)
class SendMessageServiceTests {

  private static final String TEST_EXCHANGE_VALUE = "testExchange";

  @Spy
  private ObjectMapper mapper;

  @Mock
  private RabbitTemplate template;

  @InjectMocks
  private SendMessageService sendMessageService;

  @BeforeEach
  public void each() {
    ContextHolder.setCountry("BR");
    ContextHolder.setRequestTraceId("cb3ef0d7-cf4c-4b00-a41c-a9e7ff1560f4");
  }

  @Test
  void testItShouldBeAbleToSendMessage() throws Exception {
    // Assemble
    final String routingKey = RabbitUtil.buildRoutingKey(ContextHolder.getCountry(), StringUtils.EMPTY);
    var messagePayload = new RabbitMessageMock("John", "Doe");

    // Action
    sendMessageService.execute(messagePayload, TEST_EXCHANGE_VALUE, routingKey);

    // Assertions
    final ArgumentCaptor<Message> captor = ArgumentCaptor.forClass(Message.class);
    Mockito.verify(template, Mockito.times(1)).convertAndSend(Mockito.eq(TEST_EXCHANGE_VALUE), Mockito.any(), captor.capture());

    final MessageProperties expectedMessageProperties = new MessageProperties();
    expectedMessageProperties.setHeader(Constants.COUNTRY_HEADER, ContextHolder.getCountry());
    expectedMessageProperties.setHeader(Constants.REQUEST_TRACE_ID_HEADER, ContextHolder.getRequestTraceId());
    expectedMessageProperties.setContentType(MediaType.APPLICATION_JSON_VALUE);

    final QueueEvent expectedEvent = new QueueEvent(messagePayload);
    final Message expectedMessage = new Message(mapper.writeValueAsBytes(expectedEvent), expectedMessageProperties);
    final Message currentMessage = captor.getValue();

    final String expectedBody = new String(expectedMessage.getBody());
    final String currentBody = new String(currentMessage.getBody());

    assertThat(expectedBody).isNotBlank();
    assertThat(currentBody).isNotBlank().isEqualTo(expectedBody);
  }
  
  @Test
  void testItShouldBeAbleToSendMessageWithHeaders() throws Exception {
    // Assemble
    final String routingKey = RabbitUtil.buildRoutingKey(ContextHolder.getCountry(), StringUtils.EMPTY);
    var messagePayload = new RabbitMessageMock("John", "Doe");

    // Action
    Map<String, Object> headers = new HashMap<>();
    headers.put(Constants.DELAY_HEADER, 5000);
    
    sendMessageService.execute(messagePayload, TEST_EXCHANGE_VALUE, routingKey, headers);

    // Assertions
    final ArgumentCaptor<Message> captor = ArgumentCaptor.forClass(Message.class);
    Mockito.verify(template, Mockito.times(1)).convertAndSend(Mockito.eq(TEST_EXCHANGE_VALUE), Mockito.any(), captor.capture());

    final MessageProperties expectedMessageProperties = new MessageProperties();
    expectedMessageProperties.setHeader(Constants.COUNTRY_HEADER, ContextHolder.getCountry());
    expectedMessageProperties.setHeader(Constants.REQUEST_TRACE_ID_HEADER, ContextHolder.getRequestTraceId());
    expectedMessageProperties.setHeader(Constants.DELAY_HEADER, 5000);
    expectedMessageProperties.setContentType(MediaType.APPLICATION_JSON_VALUE);

    final QueueEvent expectedEvent = new QueueEvent(messagePayload);
    final Message expectedMessage = new Message(mapper.writeValueAsBytes(expectedEvent), expectedMessageProperties);
    final Message currentMessage = captor.getValue();

    final String expectedBody = new String(expectedMessage.getBody());
    final String currentBody = new String(currentMessage.getBody());

    assertThat(expectedBody).isNotBlank();
    assertThat(currentBody).isNotBlank().isEqualTo(expectedBody);
  }
  
  @Test
  void testItShouldBeAbleToSendMessageWithoutRouterKey() throws Exception {
    // Assemble
    var messagePayload = new RabbitMessageMock("John", "Doe");

    // Action
    sendMessageService.execute(messagePayload, TEST_EXCHANGE_VALUE, null);

    // Assertions
    final ArgumentCaptor<Message> captor = ArgumentCaptor.forClass(Message.class);
    Mockito.verify(template, Mockito.times(1)).convertAndSend(Mockito.eq(TEST_EXCHANGE_VALUE), Mockito.any(), captor.capture());

    final MessageProperties expectedMessageProperties = new MessageProperties();
    expectedMessageProperties.setHeader(Constants.COUNTRY_HEADER, ContextHolder.getCountry());
    expectedMessageProperties.setHeader(Constants.REQUEST_TRACE_ID_HEADER, ContextHolder.getRequestTraceId());
    expectedMessageProperties.setContentType(MediaType.APPLICATION_JSON_VALUE);

    final QueueEvent expectedEvent = new QueueEvent(messagePayload);
    final Message expectedMessage = new Message(mapper.writeValueAsBytes(expectedEvent), expectedMessageProperties);
    final Message currentMessage = captor.getValue();

    final String expectedBody = new String(expectedMessage.getBody());
    final String currentBody = new String(currentMessage.getBody());

    assertThat(expectedBody).isNotBlank();
    assertThat(currentBody).isNotBlank().isEqualTo(expectedBody);
  }

  @Test
  void testItNotShouldBeAbleIfJsonParserException() throws Exception {
    // Assemble
    final String routingKey = RabbitUtil.buildRoutingKey(ContextHolder.getCountry(), StringUtils.EMPTY);
    var messagePayload = new RabbitMessageMock("John", "Doe");

    doThrow(new JsonParseException()).when(template).convertAndSend(Mockito.anyString(), Mockito.anyString(), Mockito.any(Message.class));

    // Action
    assertThrows(GlobalException.class, () -> sendMessageService.execute(messagePayload, TEST_EXCHANGE_VALUE, routingKey));
  }
}
