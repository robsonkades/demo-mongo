package com.abinbev.b2b.link.orderupload.utilities.configs;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.listener.RabbitListenerEndpointRegistry;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
@ExtendWith(MockitoExtension.class)
class RabbitConfigurationTests {

  @InjectMocks
  private RabbitConfiguration rabbitConfig;

  @Mock
  private RabbitListenerEndpointRegistry registry;

  @Mock
  private AmqpAdmin amqpAdmin;

  @Test
  void testItShouldBeAbleToCreateOrderUploadTopic() {
    final TopicExchange topicExchange = rabbitConfig.orderUploadExchange();
    assertNotNull(topicExchange);
    assertTrue(topicExchange.isDurable());
    assertFalse(topicExchange.isAutoDelete());
  }
}
