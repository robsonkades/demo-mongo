package com.abinbev.b2b.link.orderupload.consumer.services.weduu;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertThrows;

import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

import com.abinbev.b2b.link.orderupload.consumer.BaseSuite;
import com.abinbev.b2b.link.orderupload.consumer.dtos.ItemDto;
import com.abinbev.b2b.link.orderupload.utilities.clients.weduu.ItemProcessed;
import com.abinbev.b2b.link.orderupload.utilities.clients.weduu.OrderProcessed;
import com.abinbev.b2b.link.orderupload.utilities.clients.weduu.WeduuClient;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderStatus;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.BadRequestException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.GlobalException;

@SpringBootTest
@ActiveProfiles("test")
class GetOrderWeduuServiceTests extends BaseSuite {

	@Autowired
	private GetOrderWeduuService getOrderWeduuService;

	@MockBean
	private WeduuClient weduuClient;

	@Test
	void itShouldBeAbleToGetOrder() {
		// Assemble

		var items = List.of(
				createItemProcessed("54e599c7-467b-4b00-8340-567bb1346e75", "order-1",
						StatusItemEnum.PROCESSED.toString(), 11),
				createItemProcessed("9406aaa2-3aec-41b2-bff5-468a1e2ae3ae", "order-1",
						StatusItemEnum.PROCESSED.toString(), 22),
				createItemProcessed("71b140ce-2a24-44c7-a529-36bcd4c6c356", "order-1",
						StatusItemEnum.PROCESSED.toString(), 33),
				createItemProcessed("d18976d2-c803-44a7-b5fd-0babcd8e493c", "order-1",
						StatusItemEnum.PENDING.toString(), 44));

		OrderProcessed orderProcessed = new OrderProcessed();
		orderProcessed.setWithError(false);
		orderProcessed.setOrderIdProcessor("order-processor-id");
		orderProcessed.setStatus(StatusItemEnum.PROCESSED.toString());
		orderProcessed.setItems(items);

		Mockito.when(weduuClient.getOrder(Mockito.anyString())).thenReturn(orderProcessed);

		// Actions
		var response = getOrderWeduuService.execute("order-processor-id");

		// Assertions
		Assertions.assertEquals(OrderStatus.PROCESSED, response.getStatus());
		Assertions.assertEquals("order-1", response.getOrderId());
		Assertions.assertEquals(3, response.getItems().size());

		assertThat(response.getItems())
			.usingElementComparatorOnFields("sku", "quantity")
			.containsExactlyInAnyOrder(
					new ItemDto("54e599c7-467b-4b00-8340-567bb1346e75", 11),
					new ItemDto("9406aaa2-3aec-41b2-bff5-468a1e2ae3ae", 22),
					new ItemDto("71b140ce-2a24-44c7-a529-36bcd4c6c356", 33));
		
	}
	
	@Test
	void itShouldBeAbleToGetOrderWithEmptyItems() {
		// Assemble

		List<ItemProcessed> items = List.of();

		OrderProcessed orderProcessed = new OrderProcessed();
		orderProcessed.setWithError(false);
		orderProcessed.setOrderIdProcessor("order-processor-id");
		orderProcessed.setStatus(StatusItemEnum.PROCESSED.toString());
		orderProcessed.setItems(items);

		Mockito.when(weduuClient.getOrder(Mockito.anyString())).thenReturn(orderProcessed);

		// Actions
		var response = getOrderWeduuService.execute("order-processor-id");

		// Assertions
		Assertions.assertEquals(OrderStatus.PENDING, response.getStatus());
		Assertions.assertEquals(null, response.getOrderId());
		Assertions.assertEquals(0, response.getItems().size());
	}
	
	@Test
	void itShouldBeAbleToGetOrderWithNullItens() {
		// Assemble
		OrderProcessed orderProcessed = new OrderProcessed();
		orderProcessed.setWithError(false);
		orderProcessed.setOrderIdProcessor("order-processor-id");
		orderProcessed.setStatus(StatusItemEnum.PROCESSED.toString());
		orderProcessed.setItems(null);

		Mockito.when(weduuClient.getOrder(Mockito.anyString())).thenReturn(orderProcessed);

		// Actions
		var response = getOrderWeduuService.execute("order-processor-id");

		// Assertions
		Assertions.assertEquals(OrderStatus.PENDING, response.getStatus());
		Assertions.assertEquals(null, response.getOrderId());
		Assertions.assertEquals(0, response.getItems().size());
	}
	
	@Test
	void itShouldBeNotAbleToGetOrderIfHasErrors() {
		// Assemble

		var items = List.of(
				createItemProcessed("54e599c7-467b-4b00-8340-567bb1346e75", "order-1",
						StatusItemEnum.PROCESSED.toString(), 11),
				createItemProcessed("9406aaa2-3aec-41b2-bff5-468a1e2ae3ae", "order-1",
						StatusItemEnum.PROCESSED.toString(), 22),
				createItemProcessed("71b140ce-2a24-44c7-a529-36bcd4c6c356", "order-1",
						StatusItemEnum.PROCESSED.toString(), 33),
				createItemProcessed("d18976d2-c803-44a7-b5fd-0babcd8e493c", "order-1",
						StatusItemEnum.PENDING.toString(), 44));

		OrderProcessed orderProcessed = new OrderProcessed();
		orderProcessed.setWithError(true);
		orderProcessed.setOrderIdProcessor("order-processor-id");
		orderProcessed.setStatus(StatusItemEnum.PROCESSED.toString());
		orderProcessed.setItems(items);

		Mockito.when(weduuClient.getOrder(Mockito.anyString())).thenReturn(orderProcessed);

		// Actions
	    assertThrows(BadRequestException.class, () -> getOrderWeduuService.execute("order-processor-id"));
	}
	
	@Test
	void itShouldBeNotAbleToGetOrderIfHasGenericError() {
		// Assemble
		Mockito.when(weduuClient.getOrder(Mockito.anyString())).thenReturn(null);

		// Actions
	    assertThrows(GlobalException.class, () -> getOrderWeduuService.execute("order-processor-id"));
	}

	private ItemProcessed createItemProcessed(String sku, String orderNumber, String status, int quantity) {
		ItemProcessed itemProcessed = new ItemProcessed();
		itemProcessed.setSku(sku);
		itemProcessed.setStatus(status);
		itemProcessed.setQuantity(quantity);
		itemProcessed.setOrderNumber(orderNumber);
		return itemProcessed;
	}

}
