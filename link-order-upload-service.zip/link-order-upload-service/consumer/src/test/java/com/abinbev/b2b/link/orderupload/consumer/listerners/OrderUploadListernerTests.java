package com.abinbev.b2b.link.orderupload.consumer.listerners;

import static org.junit.Assert.assertThrows;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.rabbit.support.ListenerExecutionFailedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

import com.abinbev.b2b.link.orderupload.consumer.BaseSuite;
import com.abinbev.b2b.link.orderupload.consumer.dtos.ItemDto;
import com.abinbev.b2b.link.orderupload.consumer.dtos.OrderDto;
import com.abinbev.b2b.link.orderupload.consumer.listeners.OrderUploadListener;
import com.abinbev.b2b.link.orderupload.consumer.services.CheckItemsAvailableService;
import com.abinbev.b2b.link.orderupload.consumer.services.GetOrderService;
import com.abinbev.b2b.link.orderupload.consumer.services.SaveOrderService;
import com.abinbev.b2b.link.orderupload.consumer.services.weduu.GetOrderWeduuService;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderItem;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderStatus;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderUpload;
import com.abinbev.b2b.link.orderupload.utilities.domain.Provider;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.ListenerException;
import com.abinbev.b2b.link.orderupload.utilities.helpers.Constants;
import com.abinbev.b2b.link.orderupload.utilities.helpers.RabbitUtil;
import com.abinbev.b2b.link.orderupload.utilities.messages.OrderMessage;
import com.abinbev.b2b.link.orderupload.utilities.services.SendMessageService;

@SpringBootTest
@ActiveProfiles("test")
@ExtendWith(MockitoExtension.class)
class OrderUploadListernerTests extends BaseSuite {

	@Autowired
	private OrderUploadListener listener;
	@MockBean
	private GetOrderService getOrderService;
	@MockBean
	private GetOrderWeduuService getOrderWeduuService;
	@MockBean
	private SaveOrderService saveOrderService;
	@MockBean
	private SendMessageService sendMessageService;
	@MockBean
	private CheckItemsAvailableService checkItemsAvailableService;
	
	@Captor
	private ArgumentCaptor<List<OrderItem>> captor;
	
	@Value("${message.delay}")
	private int delay;

	@Value("${message.exchanges.orderUpload}")
	protected String orderUploadExchangeName;

	@Test
	void itShouldBeAbleToListenerOrderUpload() {
		// Assemble
		var message = new OrderMessage();
		message.setAccountId("account-id");
		message.setOrderId("order-id");
		message.setProvider(Provider.WEDUU);

		var orderUpload = new OrderUpload();
		orderUpload.setAccountId("account-id");
		orderUpload.setOrderId("order-id");
		orderUpload.setProvider(Provider.WEDUU);
		orderUpload.setProviderOrderId("provider-order-id");
		orderUpload.setStatus(OrderStatus.PENDING);

		var order = new OrderDto();
		order.setOrderId("provider-order-id");
		order.setStatus(OrderStatus.PROCESSED);
		order.addItem(new ItemDto("id-1", 10));
		order.addItem(new ItemDto("id-2", 20));
		order.addItem(new ItemDto("id-3", 30));

		Mockito
			.when(getOrderService.execute(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
			.thenReturn(Optional.of(orderUpload));

		Mockito
			.when(getOrderWeduuService.execute(Mockito.anyString()))
			.thenReturn(order);

		Mockito
			.when(saveOrderService.execute(Mockito.any()))
			.thenReturn(true);
		
		var items = order
			.getItems()
			.stream()
			.map(item -> new OrderItem(item.getSku(), item.getQuantity()))
			.collect(Collectors.toList());
		
		Mockito
			.when(checkItemsAvailableService.execute(Mockito.anyString(), Mockito.anyList()))
			.thenReturn(items);

		// Actions
		listener.receive("BR", "tracking-id", 0, message);

		// Assertions
		Mockito.verify(getOrderService, times(1)).execute("order-id", "account-id", Provider.WEDUU.name());
		Mockito.verify(getOrderWeduuService, times(1)).execute("provider-order-id");
		
		orderUpload.setStatus(OrderStatus.PROCESSED);
		
		Mockito.verify(checkItemsAvailableService, times(1)).execute(eq("account-id"), captor.capture());
		
		orderUpload.setItems(items);
		
		Mockito.verify(saveOrderService, times(1)).execute(orderUpload);
		Mockito.verify(sendMessageService, times(0)).execute(Mockito.any(), Mockito.any(), Mockito.any());
	}
	
	@Test
	void itShouldBeAbleToListenerOrderUploadWithRetry() {
		// Assemble
		var message = new OrderMessage();
		message.setAccountId("account-id");
		message.setOrderId("order-id");
		message.setProvider(Provider.WEDUU);

		var orderUpload = new OrderUpload();
		orderUpload.setAccountId("account-id");
		orderUpload.setOrderId("order-id");
		orderUpload.setProvider(Provider.WEDUU);
		orderUpload.setProviderOrderId("provider-order-id");
		orderUpload.setStatus(OrderStatus.PENDING);

		var order = new OrderDto();
		order.setOrderId("provider-order-id");
		order.setStatus(OrderStatus.PENDING);

		Mockito
			.when(getOrderService.execute(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
			.thenReturn(Optional.of(orderUpload));

		Mockito
			.when(getOrderWeduuService.execute(Mockito.anyString()))
			.thenReturn(order);

		Mockito
			.doNothing()
			.when(sendMessageService)
			.execute(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());

		// Actions
		listener.receive("BR", "tracking-id", 0, message);

		// Assertions
		Mockito.verify(getOrderService, times(1)).execute("order-id", "account-id", Provider.WEDUU.name());
		Mockito.verify(getOrderWeduuService, times(1)).execute("provider-order-id");	
		Mockito.verify(saveOrderService, times(0)).execute(Mockito.any());
		
		final String routingKey = RabbitUtil.buildRoutingKey("BR");
		
        Map<String, Object> headers = new HashMap<>();
        headers.put(Constants.DELAY_HEADER, delay);
        headers.put(Constants.RETRY_HEADER, 1);
        
		Mockito
			.verify(sendMessageService, times(1))
			.execute(message, orderUploadExchangeName, routingKey, headers);
	}
	
	@Test
	void itShouldBeAbleToListenerOrderUploadAlreadyProcessed() {
		// Assemble
		var message = new OrderMessage();
		message.setAccountId("account-id");
		message.setOrderId("order-id");
		message.setProvider(Provider.WEDUU);

		var orderUpload = new OrderUpload();
		orderUpload.setAccountId("account-id");
		orderUpload.setOrderId("order-id");
		orderUpload.setProvider(Provider.WEDUU);
		orderUpload.setProviderOrderId("provider-order-id");
		orderUpload.setStatus(OrderStatus.PROCESSED);

		Mockito
			.when(getOrderService.execute(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
			.thenReturn(Optional.of(orderUpload));
		
		// Actions
		listener.receive("BR", "tracking-id", 0, message);

		// Assertions
		Mockito.verify(getOrderService, times(1)).execute("order-id", "account-id", Provider.WEDUU.name());
		Mockito.verify(getOrderWeduuService, times(0)).execute(Mockito.any());	
		Mockito.verify(saveOrderService, times(0)).execute(Mockito.any());
		Mockito.verify(sendMessageService, times(0)).execute(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
	}
	
	@Test
	void itShouldNotBeAbleToListenerOrderUploadIfOrderNotFound() {
		// Assemble
		var message = new OrderMessage();
		message.setAccountId("account-id");
		message.setOrderId("order-id");
		message.setProvider(Provider.WEDUU);

		Mockito
			.when(getOrderService.execute(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
			.thenReturn(Optional.empty());
		
		// Actions
	    assertThrows(ListenerException.class, () -> listener.receive("BR", "tracking-id", 0, message));

		// Assertions
		Mockito.verify(getOrderService, times(1)).execute("order-id", "account-id", Provider.WEDUU.name());
		Mockito.verify(getOrderWeduuService, times(0)).execute(Mockito.any());	
		Mockito.verify(saveOrderService, times(0)).execute(Mockito.any());
		Mockito.verify(sendMessageService, times(0)).execute(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
	}
	
	@Test
	void itShouldNotBeAbleToListenerOrderUploadIfOrderWithMaxRetry() {
		// Assemble
		var message = new OrderMessage();
		message.setAccountId("account-id");
		message.setOrderId("order-id");
		message.setProvider(Provider.WEDUU);
		
		var orderUpload = new OrderUpload();
		orderUpload.setAccountId("account-id");
		orderUpload.setOrderId("order-id");
		orderUpload.setProvider(Provider.WEDUU);
		orderUpload.setProviderOrderId("provider-order-id");
		orderUpload.setStatus(OrderStatus.PROCESSED);

		Mockito
			.when(getOrderService.execute(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
			.thenReturn(Optional.of(orderUpload));
		
		Mockito
			.when(saveOrderService.execute(Mockito.any()))
			.thenReturn(true);
		
		// Actions
	    assertThrows(ListenerExecutionFailedException.class, () -> listener.receive("BR", "tracking-id", 60, message));

		// Assertions
		Mockito.verify(getOrderService, times(1)).execute("order-id", "account-id", Provider.WEDUU.name());
		Mockito.verify(saveOrderService, times(1)).execute(Mockito.any());
		Mockito.verify(getOrderWeduuService, times(0)).execute(Mockito.any());	
		Mockito.verify(sendMessageService, times(0)).execute(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
	}
}
