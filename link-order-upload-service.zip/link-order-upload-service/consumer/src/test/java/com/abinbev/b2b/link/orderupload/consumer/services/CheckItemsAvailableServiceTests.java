package com.abinbev.b2b.link.orderupload.consumer.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;

import com.abinbev.b2b.link.orderupload.consumer.BaseSuite;
import com.abinbev.b2b.link.orderupload.consumer.clients.catalog.CatalogClient;
import com.abinbev.b2b.link.orderupload.consumer.clients.catalog.CatalogItem;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderItem;

@SpringBootTest
@ActiveProfiles("test")
class CheckItemsAvailableServiceTests extends BaseSuite {

	@Autowired
	private CheckItemsAvailableService checkItemsAvailableService;
	
	@MockBean
	private CatalogClient catalogClient;

	@Test
	void itShouldBeAbleCheckItemsAvailable() {
		
		// Assemble
		CatalogItem[] items = {
				new CatalogItem("id-1", "sku-1", "account"),
				new CatalogItem("id-2", "sku-2", "account"),
				new CatalogItem("id-3", "sku-3", "account"),
				new CatalogItem("id-4", "sku-4", "account")};
		
		List<OrderItem> providerItems = List.of(
				new OrderItem("sku-1", 10),
				new OrderItem("sku-2", 20),
				new OrderItem("sku-5", 6),
				new OrderItem("sku-10", 10));
		
		Mockito
			.when(catalogClient.getItems(anyString(), anyList()))
			.thenReturn(items);
		
		List<OrderItem> itemsAvailable = checkItemsAvailableService.execute("account", providerItems);	
		
		assertThat(itemsAvailable)
		.usingElementComparatorOnFields("sku", "quantity", "status")
		.containsExactlyInAnyOrder(
				new OrderItem("sku-1", 10),
				new OrderItem("sku-2", 20),
				new OrderItem("sku-5", 0),
				new OrderItem("sku-10", 0));
		
		Mockito
			.verify(catalogClient, Mockito.times(1))
			.getItems("account", List.of("sku-1", "sku-2", "sku-5", "sku-10"));
	}
}
