package com.abinbev.b2b.link.orderupload.consumer;

import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest
@ActiveProfiles("test")
class LinkOrderUploadServiceConsumerApplicationTests extends BaseSuite {

  @Test
  void testContextLoads() {
    int value = 10 * 2;
    Assert.assertEquals(20, value);
  }
}
