package com.abinbev.b2b.link.orderupload.consumer;

import java.time.Duration;

import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.containers.wait.strategy.Wait;
import org.testcontainers.images.builder.ImageFromDockerfile;
import org.testcontainers.utility.DockerImageName;

public abstract class BaseSuite {

	private static final GenericContainer<?> mongoDBContainer = new GenericContainer<>(DockerImageName.parse("mongo:4.0.10"));
	private static final GenericContainer<?> rabbitMQContainer = new GenericContainer<>(new ImageFromDockerfile()
			.withDockerfileFromBuilder(builder -> 
				builder.from("rabbitmq:3-management-alpine")
					.run("apk add curl")
					.run("curl -L https://github.com/rabbitmq/rabbitmq-delayed-message-exchange/releases/download/3.9.0/rabbitmq_delayed_message_exchange-3.9.0.ez > $RABBITMQ_HOME/plugins/rabbitmq_delayed_message_exchange.ez")
					.run("chown rabbitmq:rabbitmq $RABBITMQ_HOME/plugins/rabbitmq_delayed_message_exchange.ez")
					.run("rabbitmq-plugins enable --offline rabbitmq_delayed_message_exchange")
					.env("RABBITMQ_DEFAULT_VHOST", "b2b")
					.build()));

	@DynamicPropertySource
	private static void dynamicProperties(DynamicPropertyRegistry registry) {
		rabbitMQContainer.withExposedPorts(5672, 15672);
		mongoDBContainer.withExposedPorts(27017);
		mongoDBContainer.setWaitStrategy(Wait.forListeningPort().withStartupTimeout(Duration.ofMinutes(2)));
		mongoDBContainer.start();
		
		rabbitMQContainer.start();

		var uri = String.format("mongodb://%s:%s", mongoDBContainer.getContainerIpAddress(), mongoDBContainer.getMappedPort(27017));

		registry.add("spring.data.mongodb.uri", () -> uri);
		registry.add("spring.rabbitmq.host", rabbitMQContainer::getContainerIpAddress);
		registry.add("spring.rabbitmq.port", () -> rabbitMQContainer.getMappedPort(5672));
	}
}