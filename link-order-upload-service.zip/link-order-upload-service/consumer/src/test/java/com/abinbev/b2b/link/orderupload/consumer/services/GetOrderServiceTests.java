package com.abinbev.b2b.link.orderupload.consumer.services;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.OffsetDateTime;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.test.context.ActiveProfiles;

import com.abinbev.b2b.link.orderupload.consumer.BaseSuite;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderItem;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderStatus;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderUpload;
import com.abinbev.b2b.link.orderupload.utilities.domain.Provider;
import com.abinbev.b2b.link.orderupload.utilities.interceptors.ContextHolder;

@SpringBootTest
@ActiveProfiles("test")
class GetOrderServiceTests extends BaseSuite {

	@Autowired
	private GetOrderService getOrderService;

	@Autowired
	private SaveOrderService saveOrderService;

	@Autowired
	private MongoTemplate template;

	@BeforeEach
	void each() {
		ContextHolder.setCountry("BR");
		ContextHolder.setRequestTraceId(UUID.randomUUID().toString());
		template.dropCollection(OrderUpload.class);
	}

	@Test
	void itShouldBeAbleToGetOrder() {
		// Assemble
		var items = List.of(new OrderItem("sku-1", 1), new OrderItem("sku-2", 2));

		OrderUpload orderUpload = new OrderUpload();
		orderUpload.setOrderId("order-fake");
		orderUpload.setAccountId("account-fake");
		orderUpload.setItems(items);
		orderUpload.setProvider(Provider.WEDUU);
		orderUpload.setStatus(OrderStatus.PENDING);
		orderUpload.setProviderOrderId("order-provider-fake");
		orderUpload.setUpdatedAt(OffsetDateTime.now());

		// Actions
		boolean isSaved = saveOrderService.execute(orderUpload);
		var response = getOrderService.execute("order-fake", "account-fake", Provider.WEDUU.name());

		// Assertions
		Assertions.assertTrue(isSaved);
		assertThat(response).usingRecursiveComparison()
				.ignoringFields("orderId", "accountId", "status", "provider", "providerOrderId").isEqualTo(response);
	}

	@Test
	void itNotShouldBeAbleToGetOrderIfNonExisting() {
		// Actions
		var response = getOrderService.execute("order-fake", "account-fake", Provider.WEDUU.name());

		// Assertions
		Assertions.assertEquals(true, response.isEmpty());
	}

	@Test
	void itNotShouldBeAbleToGetOrderWithOtherCountry() {
		// Assemble
		var items = List.of(new OrderItem("sku-1", 1), new OrderItem("sku-2", 2));

		OrderUpload orderUpload = new OrderUpload();
		orderUpload.setOrderId("order-fake");
		orderUpload.setAccountId("account-fake");
		orderUpload.setItems(items);
		orderUpload.setProvider(Provider.WEDUU);
		orderUpload.setStatus(OrderStatus.PENDING);
		orderUpload.setProviderOrderId("order-provider-fake");
		orderUpload.setUpdatedAt(OffsetDateTime.now());

		// Actions
		boolean isSaved = saveOrderService.execute(orderUpload);
		ContextHolder.setCountry("US");
		var response = getOrderService.execute("order-fake", "account-fake", Provider.WEDUU.name());

		// Assertions
		Assertions.assertTrue(isSaved);
		Assertions.assertEquals(true, response.isEmpty());
	}
}
