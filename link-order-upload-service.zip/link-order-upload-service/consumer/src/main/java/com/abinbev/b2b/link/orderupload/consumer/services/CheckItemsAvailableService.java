package com.abinbev.b2b.link.orderupload.consumer.services;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.abinbev.b2b.link.orderupload.consumer.clients.catalog.CatalogClient;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderItem;

@Service
public class CheckItemsAvailableService {

	private final CatalogClient client;

	public CheckItemsAvailableService(final CatalogClient client) {
		this.client = client;
	}

	public List<OrderItem> execute(String accountId, List<OrderItem> items) {
		var itemsId = items.stream().map(OrderItem::getSku).collect(Collectors.toList());
		var response = client.getItems(accountId, itemsId);

		return items
				.stream()
				.parallel()
				.map(item -> {
					var hasItem = Arrays
							.asList(response)
							.stream()
							.parallel()
							.filter(b -> b.getSku().equalsIgnoreCase(item.getSku()))
							.findFirst();
		
					if (hasItem.isPresent()) {
						var catalogItem = hasItem.get();
						return new OrderItem(catalogItem.getSku(), item.getQuantity());
					}

					return new OrderItem(item.getSku(), 0);
					})
				.collect(Collectors.toList());
	}
}
