package com.abinbev.b2b.link.orderupload.consumer.services;

import com.abinbev.b2b.link.orderupload.utilities.domain.OrderUpload;
import com.abinbev.b2b.link.orderupload.utilities.interceptors.ContextHolder;
import com.abinbev.b2b.link.orderupload.utilities.repositories.OrderUploadRepository;
import java.util.Optional;
import org.springframework.stereotype.Service;

@Service
public class GetOrderService {

  private final OrderUploadRepository repository;

  public GetOrderService(final OrderUploadRepository repository) {
    this.repository = repository;
  }

  public Optional<OrderUpload> execute(
      final String orderId, final String accountId, final String provider) {
    return repository.find(ContextHolder.getCountry(), provider, orderId, accountId);
  }
}
