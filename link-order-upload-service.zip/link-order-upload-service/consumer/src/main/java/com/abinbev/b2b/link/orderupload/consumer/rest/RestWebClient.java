package com.abinbev.b2b.link.orderupload.consumer.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

@Component
public class RestWebClient {
  private static final Logger LOGGER = LoggerFactory.getLogger(RestWebClient.class);

  protected WebClient webClient;

  private RestWebClient() {
    final WebClient.Builder clientBuilder = 
    		WebClient.builder().defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
    webClient = clientBuilder.build();
  }

  public <T> T postEncodedData(
	  final String url,
      final MultiValueMap<String, String> encodedData,
      final MultiValueMap<String, String> headerParams,
      final Class<T> expectedResponseType) {

    LOGGER.debug("Sending a post on url {}", url);

    final WebClient.RequestHeadersSpec<?> requestToken =
        webClient
            .post()
            .uri(url)
            .headers(httpHeaders -> httpHeaders.addAll(headerParams))
            .body(BodyInserters.fromFormData(encodedData));
    
    return requestToken
        .retrieve()
        .bodyToMono(expectedResponseType)
        .onErrorMap(e -> new Exception("An error occurred while sending a post request", e))
        .block();
  }
  
  public <T> T get(
		  final String url,
	      final MultiValueMap<String, String> headerParams,
	      final Class<T> expectedResponseType) {

	    LOGGER.debug("Sending a get on url {}", url);

	    final WebClient.RequestHeadersSpec<?> request =
	        webClient
	            .get()
	            .uri(url)
	            .headers(httpHeaders -> httpHeaders.addAll(headerParams));
	    
	    return request
	        .retrieve()
	        .bodyToMono(expectedResponseType)
	        .onErrorMap(e -> new Exception("An error occurred while sending a post request", e))
	        .block();
	  }
}
