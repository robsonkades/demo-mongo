package com.abinbev.b2b.link.orderupload.consumer.services;

import com.abinbev.b2b.link.orderupload.consumer.dtos.OrderDto;

public interface GetOrderProviderService {
  OrderDto execute(String orderId);
}
