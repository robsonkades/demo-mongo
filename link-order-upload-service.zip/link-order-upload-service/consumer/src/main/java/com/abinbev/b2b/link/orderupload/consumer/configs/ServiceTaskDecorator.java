package com.abinbev.b2b.link.orderupload.consumer.configs;

import java.util.Map;
import org.slf4j.MDC;
import org.springframework.core.task.TaskDecorator;
import org.springframework.lang.NonNull;

public class ServiceTaskDecorator implements TaskDecorator {

  @Override
  public Runnable decorate(@NonNull final Runnable runnable) {
    final Map<String, String> contextMap = MDC.getCopyOfContextMap();

    return () -> {
      try {
        MDC.setContextMap(contextMap);
        runnable.run();
      } finally {
        MDC.clear();
      }
    };
  }
}
