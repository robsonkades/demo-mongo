package com.abinbev.b2b.link.orderupload.consumer.dtos;

import com.abinbev.b2b.link.orderupload.utilities.domain.OrderStatus;
import java.util.ArrayList;
import java.util.List;

public class OrderDto {

  private String orderId;
  private OrderStatus status = OrderStatus.PENDING;
  private List<ItemDto> items = new ArrayList<>();

  public String getOrderId() {
    return orderId;
  }

  public void setOrderId(String orderId) {
    this.orderId = orderId;
  }

  public OrderStatus getStatus() {
    return status;
  }

  public void setStatus(OrderStatus status) {
    this.status = status;
  }

  public List<ItemDto> getItems() {
    return items;
  }

  public void addItem(ItemDto itemDto) {
    items.add(itemDto);
  }
}
