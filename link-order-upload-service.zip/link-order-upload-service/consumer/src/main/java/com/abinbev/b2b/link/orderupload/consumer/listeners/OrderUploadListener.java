package com.abinbev.b2b.link.orderupload.consumer.listeners;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.support.ListenerExecutionFailedException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import com.abinbev.b2b.link.orderupload.consumer.dtos.OrderDto;
import com.abinbev.b2b.link.orderupload.consumer.services.CheckItemsAvailableService;
import com.abinbev.b2b.link.orderupload.consumer.services.GetOrderProviderService;
import com.abinbev.b2b.link.orderupload.consumer.services.GetOrderService;
import com.abinbev.b2b.link.orderupload.consumer.services.GetProviderService;
import com.abinbev.b2b.link.orderupload.consumer.services.SaveOrderService;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderItem;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderStatus;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderUpload;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.IssueEnum;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.ListenerException;
import com.abinbev.b2b.link.orderupload.utilities.helpers.Constants;
import com.abinbev.b2b.link.orderupload.utilities.helpers.RabbitUtil;
import com.abinbev.b2b.link.orderupload.utilities.messages.OrderMessage;
import com.abinbev.b2b.link.orderupload.utilities.services.SendMessageService;
import com.newrelic.api.agent.NewRelic;
import com.newrelic.api.agent.Trace;

@ConditionalOnProperty("listeners.orderUpload.enabled")
@Component
public class OrderUploadListener {

  private static final Logger LOGGER = LoggerFactory.getLogger(OrderUploadListener.class);
  
  private static final int MAX_RETRY = 60;

  private final GetProviderService getProviderService;
  private final GetOrderService getOrderService;
  private final SaveOrderService saveOrderService;
  private final SendMessageService sendMessageService;
  private final CheckItemsAvailableService checkItemsAvailableService;
  
  @Value("${message.delay}")
  private int delay;

  @Value("${message.exchanges.orderUpload}")
  protected String orderUploadExchangeName;

  public OrderUploadListener(final GetProviderService getProviderService,
      final GetOrderService getOrderService, final SaveOrderService saveOrderService,
      final SendMessageService sendMessageService,
      final CheckItemsAvailableService checkItemsAvailableService) {
    this.getProviderService = getProviderService;
    this.getOrderService = getOrderService;
    this.saveOrderService = saveOrderService;
    this.sendMessageService = sendMessageService;
    this.checkItemsAvailableService = checkItemsAvailableService;
  }

  @Trace(dispatcher = true)
  @RabbitListener(queues = {"#{messageQueues.getOrderUploadQueues()}"}, containerFactory = "simpleContainerFactoryOrderUpload")
  public void receive(
      @Header final String country, 
      @Header final String requestTraceId,
      @Header(defaultValue = "0") final int retry,
      @Valid @Payload final OrderMessage message) {

    NewRelic.addCustomParameter(Constants.COUNTRY_HEADER, country);
    NewRelic.addCustomParameter(Constants.REQUEST_TRACE_ID_HEADER, requestTraceId);

    Optional<OrderUpload> orderUploadOptional = getOrderService.execute(message.getOrderId(),
        message.getAccountId(), message.getProvider().name());

    var orderUpload = orderUploadOptional
        .orElseThrow(() -> new ListenerException(IssueEnum.ORDER_NOT_FOUND.getFormattedMessage(message.getOrderId(), country)));
    
    if (retry >= MAX_RETRY) {
    	orderUpload.setStatus(OrderStatus.ERROR);
    	saveOrderService.execute(orderUpload);
        throw new ListenerExecutionFailedException(
            "The maximum number of attempts is reached",
            new ListenerException("The maximum number of attempts is reached"));
      }
    
    if (orderUpload.getStatus().equals(OrderStatus.PENDING)) {
      
      GetOrderProviderService getOrderProviderService = getProviderService.getOrderProvider(message.getProvider().name());
      OrderDto orderDto = getOrderProviderService.execute(orderUpload.getProviderOrderId());
      
      if (orderDto.getStatus().equals(OrderStatus.PROCESSED)) {
        orderUpload.setStatus(OrderStatus.PROCESSED);

        List<OrderItem> items = orderDto
            .getItems()
            .stream()
            .map(item -> new OrderItem(item.getSku(), item.getQuantity()))
            .collect(Collectors.toList());
   
        List<OrderItem> itemsAvailable = checkItemsAvailableService.execute(orderUpload.getAccountId(), items);
      
        orderUpload.setItems(itemsAvailable);

        saveOrderService.execute(orderUpload);
        LOGGER.info("The order processed with id '{}' and country '{}'", message.getOrderId(), country);
      } else {
        LOGGER.info("The order was not processed with id '{}' and country '{}'", message.getOrderId(), country);
        final String routingKey = RabbitUtil.buildRoutingKey(country);
        
        Map<String, Object> headers = new HashMap<>();
        headers.put(Constants.DELAY_HEADER, delay);
        headers.put(Constants.RETRY_HEADER, retry + 1);
        
        sendMessageService.execute(message, orderUploadExchangeName, routingKey, headers);
      }
    }
  }
}
