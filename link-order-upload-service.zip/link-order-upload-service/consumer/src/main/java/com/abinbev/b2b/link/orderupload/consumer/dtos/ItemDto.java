package com.abinbev.b2b.link.orderupload.consumer.dtos;

public class ItemDto {

  private String sku;
  private int quantity;

  public ItemDto(String sku, int quantity) {
    this.sku = sku;
    this.quantity = quantity;
  }

  public String getSku() {
    return sku;
  }

  public int getQuantity() {
    return quantity;
  }
}
