package com.abinbev.b2b.link.orderupload.consumer.clients.catalog;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class CatalogItem {

	private String id;
	private String sku;
	private String accountId;
	
	public CatalogItem(String id, String sku, String accountId) {
		this.id = id;
		this.sku = sku;
		this.accountId = accountId;
	}
	
	public CatalogItem() {}
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}

	public String getSku() {
		return sku;
	}

	public void setSku(String sku) {
		this.sku = sku;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
}
