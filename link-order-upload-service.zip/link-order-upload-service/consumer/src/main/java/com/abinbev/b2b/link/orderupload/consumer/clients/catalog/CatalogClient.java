package com.abinbev.b2b.link.orderupload.consumer.clients.catalog;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.abinbev.b2b.link.orderupload.consumer.clients.auth.AuthClient;
import com.abinbev.b2b.link.orderupload.consumer.clients.auth.AuthTokenResponse;
import com.abinbev.b2b.link.orderupload.consumer.rest.RestWebClient;
import com.abinbev.b2b.link.orderupload.utilities.helpers.Constants;
import com.abinbev.b2b.link.orderupload.utilities.interceptors.ContextHolder;

@Component
public class CatalogClient {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(CatalogClient.class);

	private final RestWebClient restWebClient;
	private final AuthClient authClient;
	
	@Value("${bees.baseUrl}")
	private String host;

	public CatalogClient(final RestWebClient restWebClient, AuthClient authClient) {
		this.restWebClient = restWebClient;
		this.authClient = authClient;
	}

	public CatalogItem[] getItems(String accountId, List<String> skus) {
		
		LOGGER.info("Get catalog items to account {}", accountId);
		
		AuthTokenResponse tokenResponse = authClient.getToken();
	
		String authorization = String.format("Bearer %s", tokenResponse.getAccessToken());
		
		final MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
		headers.add(Constants.REQUEST_TRACE_ID_HEADER, ContextHolder.getRequestTraceId());
		headers.add(Constants.COUNTRY_HEADER, ContextHolder.getCountry());
		headers.add(HttpHeaders.AUTHORIZATION, authorization);
		
		var ids = skus.stream().collect(Collectors.joining(","));
		
		String uri = String.format("%s/api/v1/catalog-service/catalog/items?accountId=%s&projection=SMALL&orderBy=RANK&inStock=true&itemIds=%s", host, accountId, ids);
		
		return restWebClient.get(uri, headers, CatalogItem[].class);
	}
}
