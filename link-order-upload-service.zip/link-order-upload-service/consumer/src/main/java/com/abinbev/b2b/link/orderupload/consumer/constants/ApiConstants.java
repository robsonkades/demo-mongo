package com.abinbev.b2b.link.orderupload.consumer.constants;

public class ApiConstants {
  
  private ApiConstants() {}

  public static final String NEW_RELIC_TRANSACTION_CATEGORY = "LinkOrderUploadConsumer";

  public static final String AUTHORIZATION_HEADER = "Authorization";

  public static final String HEADER_CONTENT_TYPE = "Content-Type";

  public static final String REQUEST_URI_HEADER = "requestUri";

  public static final String X_BEES_CALLER_HEADER = "x-bees-caller";

  public static final String X_BEES_ORIGIN_HEADER = "x-bees-origin";

  public static final String NOT_VALID_PARAM_ERROR_MSG = "%s not valid";

  public static final String MANDATORY_PARAM_ERROR_MSG = "%s is mandatory";

  public static final String COUNTRY_JWT = "country";

  public static final String SUB_JWT = "sub";
}
