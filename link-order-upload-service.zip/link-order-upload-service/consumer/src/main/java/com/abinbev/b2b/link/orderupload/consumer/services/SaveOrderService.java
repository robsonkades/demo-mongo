package com.abinbev.b2b.link.orderupload.consumer.services;

import com.abinbev.b2b.link.orderupload.utilities.domain.OrderUpload;
import com.abinbev.b2b.link.orderupload.utilities.interceptors.ContextHolder;
import com.abinbev.b2b.link.orderupload.utilities.repositories.OrderUploadRepository;
import org.springframework.stereotype.Service;

@Service
public class SaveOrderService {

  private final OrderUploadRepository repository;

  public SaveOrderService(final OrderUploadRepository repository) {
    this.repository = repository;
  }

  public boolean execute(OrderUpload orderUpload) {
    return repository.upsert(ContextHolder.getCountry(), orderUpload);
  }
}
