package com.abinbev.b2b.link.orderupload.consumer.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "bees.credential")
public class M2MCredential {

	private String clientId;
	private String secretKey;
	private String scope;
	
	public String getClientId() {
		return clientId;
	}
	
	public String getSecretKey() {
		return secretKey;
	}
	
	public String getScope() {
		return scope;
	}
	
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	
	public void setSecretKey(String secretKey) {
		this.secretKey = secretKey;
	}
	
	public void setScope(String scope) {
		this.scope = scope;
	}
}
