package com.abinbev.b2b.link.orderupload.consumer.clients.auth;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.abinbev.b2b.link.orderupload.consumer.properties.M2MCredential;
import com.abinbev.b2b.link.orderupload.consumer.rest.RestWebClient;
import com.abinbev.b2b.link.orderupload.utilities.helpers.Constants;
import com.abinbev.b2b.link.orderupload.utilities.interceptors.ContextHolder;

@Component
public class AuthClient {

	private static final Logger LOGGER = LoggerFactory.getLogger(AuthClient.class);
	
	private static final String GRANT_TYPE = "grant_type";
	private static final String SCOPE = "scope";
	private static final String CLIENT_ID = "client_id";
	private static final String CLIENT_SECRET = "client_secret";
	private static final String CLIENT_CREDENTIALS = "client_credentials";

	private final RestWebClient restWebClient;
	private final M2MCredential credential;
	
	@Value("${bees.baseUrl}")
	private String host;

	public AuthClient(final RestWebClient restWebClient, M2MCredential credential) {
		this.restWebClient = restWebClient;
		this.credential = credential;
	}

	@Cacheable("m2m-token")
	public AuthTokenResponse getToken() {
		
		LOGGER.info("Request new token");
		
		final MultiValueMap<String, String> encodedData = new LinkedMultiValueMap<>();
		encodedData.add(SCOPE, credential.getScope());
		encodedData.add(CLIENT_ID, credential.getClientId());
		encodedData.add(CLIENT_SECRET, credential.getSecretKey());
		encodedData.add(GRANT_TYPE, CLIENT_CREDENTIALS);

		final MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
		headers.add(Constants.REQUEST_TRACE_ID_HEADER, ContextHolder.getRequestTraceId());
		headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE);
		
		String url = String.format("%s/api/auth/token", host);
	
		return restWebClient.postEncodedData(url, encodedData, headers, AuthTokenResponse.class);
	}
}
