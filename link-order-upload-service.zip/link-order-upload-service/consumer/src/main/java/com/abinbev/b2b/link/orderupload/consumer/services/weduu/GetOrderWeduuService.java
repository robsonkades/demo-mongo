package com.abinbev.b2b.link.orderupload.consumer.services.weduu;

import java.util.Collections;

import org.springframework.stereotype.Service;

import com.abinbev.b2b.link.orderupload.consumer.dtos.ItemDto;
import com.abinbev.b2b.link.orderupload.consumer.dtos.OrderDto;
import com.abinbev.b2b.link.orderupload.consumer.services.GetOrderProviderService;
import com.abinbev.b2b.link.orderupload.utilities.clients.weduu.OrderProcessed;
import com.abinbev.b2b.link.orderupload.utilities.clients.weduu.WeduuClient;
import com.abinbev.b2b.link.orderupload.utilities.domain.OrderStatus;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.BadRequestException;
import com.abinbev.b2b.link.orderupload.utilities.exceptions.GlobalException;

@Service("GET_ORDER_WEDUU")
public class GetOrderWeduuService implements GetOrderProviderService {

	private final WeduuClient weduuClient;

	public GetOrderWeduuService(final WeduuClient weduuClient) {
		this.weduuClient = weduuClient;
	}

	@Override
	public OrderDto execute(final String orderId) {
		OrderDto order = new OrderDto();

		OrderProcessed orderProcessed = weduuClient.getOrder(orderId);

		if (orderProcessed == null) {
			throw GlobalException.globalException();
		}

		if (orderProcessed.isWithError()) {
			throw BadRequestException.invalidFile(Collections.singletonList(orderProcessed.getStatus()));
		}

		if (orderProcessed.getItems() != null && !orderProcessed.getItems().isEmpty()) {
			order.setOrderId(orderProcessed.getItems().get(0).getOrderNumber());
			order.setStatus(OrderStatus.PROCESSED);
			orderProcessed.getItems().forEach(item -> {
				if (item.getStatus().equals(StatusItemEnum.PROCESSED.toString())) {
					order.addItem(new ItemDto(item.getSku(), item.getQuantity()));
				}
			});
		}

		return order;
	}
}
