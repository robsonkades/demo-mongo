package com.abinbev.b2b.link.orderupload.consumer.services;

import java.util.Map;
import java.util.Objects;
import org.springframework.stereotype.Service;

@Service
public class GetProviderService {

  private final Map<String, GetOrderProviderService> getOrderProviderServiceMap;

  public GetProviderService(final Map<String, GetOrderProviderService> getOrderProviderServiceMap) {
    this.getOrderProviderServiceMap = getOrderProviderServiceMap;
  }

  public GetOrderProviderService getOrderProvider(String providerName) {
    var type = String.format("GET_ORDER_%s", providerName);
    GetOrderProviderService provider = getOrderProviderServiceMap.get(type);

    if (Objects.isNull(provider)) {
      throw new IllegalArgumentException(
          String.format("The provider '%s' not supported", providerName));
    }
    return provider;
  }
}
