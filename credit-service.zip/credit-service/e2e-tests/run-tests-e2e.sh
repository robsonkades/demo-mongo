#!/bin/sh

if [ -z $ENV ]; then
    echo "You must to inform the ENV env-var (e.g DEV)"
    exit 1
fi

if [ -z $RESULTS_PATH ]; then
    RESULTS_PATH=/opt/results
fi

robot -d $RESULTS_PATH -x $RESULTS_PATH/TEST-robot.xml
