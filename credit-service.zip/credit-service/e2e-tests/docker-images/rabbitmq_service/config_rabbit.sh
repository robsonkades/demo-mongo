#!/bin/bash

# This script needs to be executed just once
if [ -f /$0.completed ] ; then
  echo "$0 `date` /$0.completed found, skipping run"
  exit 0
fi

# Wait for RabbitMQ startup
for (( ; ; )) ; do
  sleep 5
  rabbitmqctl -q node_health_check > /dev/null 2>&1
  if [ $? -eq 0 ] ; then
    echo "$0 `date` rabbitmq is now running"
    break
  else
    echo "$0 `date` waiting for rabbitmq startup"
  fi
done

# Create Rabbitmq user
rabbitmqctl add_vhost robot_vh_1 ;
rabbitmqctl add_user robot_user robot_user 2>/dev/null ;
rabbitmqctl set_user_tags robot_user administrator ;
rabbitmqctl set_permissions -p robot_vh_1 robot_user  ".*" ".*" ".*" ;
rabbitmqctl set_permissions -p / robot_user  ".*" ".*" ".*" ;

# Create mark so script is not run again
touch /$0.completed