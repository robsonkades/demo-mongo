#!/bin/bash

/config_rabbit.sh &
# Launch
#/docker-entrypoint.sh rabbitmq-server
rabbitmq-server