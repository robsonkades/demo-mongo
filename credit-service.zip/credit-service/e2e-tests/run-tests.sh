#!/bin/sh
COMPOSE_PROJECT_NAME=$1 docker-compose -f $2 down
COMPOSE_PROJECT_NAME=$1 docker-compose -f $2 up --build --abort-on-container-exit --exit-code-from robot
