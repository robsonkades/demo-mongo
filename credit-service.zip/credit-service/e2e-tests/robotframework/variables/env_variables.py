import json
from robot.libraries.BuiltIn import BuiltIn
from datetime import datetime

allowed_environments = ["docker", "dev", "qa", "sit", "uat"]


def get_env_vars(env):
    env_vars_file = "./robotframework/variables/envs/{0}.json".format(env)
    f = open(env_vars_file, "r")
    env_vars = f.read()
    f.close()
    return json.loads(env_vars)


ENV = BuiltIn().get_variable_value("${ENV}", "docker").lower()

if ENV not in allowed_environments:
    ENV = "docker"

BuiltIn().set_global_variable("${ENV}", ENV)

vars = get_env_vars(ENV)

COUNTRY = BuiltIn().get_variable_value("${COUNTRY}", "PY")
if ENV == "docker":
    COUNTRY = "ZA"

BuiltIn().set_global_variable("${COUNTRY}", COUNTRY)

RELAY = vars["relay"]

API = vars["api"]

CONSUMER = vars["consumer"]

MONGO = vars["mongodb"]

RABBITMQ = vars["rabbitmq"]

JSON_SERVER = vars["jsonserver"]

API_VALID_HEADERS = {"content-type": "application/json",
                     "requestTraceId": "test-robot-credit"}

REQUEST_TRACE_ID = "test-robot-credit-{0}-{1}".format(
    ENV, datetime.now().strftime('%Y-%m-%d-%H:%M:%S'))

# variables
JWT_TOKEN = "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhYi1pbmJldiIsImF1ZCI6ImFiaS1taWNyb3NlcnZpY2VzIiwiZXhwIjoxNjA2Njk0NDAwLCJpYXQiOjE1MzY5NjMyNTcsInVwZGF0ZWRfYXQiOjE1MzY5NjMyNTcsIm5hbWUiOiJmaWxpcGVyaWJlaXJvKzFAY2lhbmR0LmNvbSIsImFjY291bnRJRCI6IjAxMTMyNDc4MDAwNjQyIiwidmVuZG9ySWQiOiIxMjM0NTY3ODkiLCJ1c2VySUQiOiIxMSIsInJvbGVzIjpbIlJPTEVfQ1VTVE9NRVIiXX0.a5oWSA2CCun6KX7Ya5VQ0viYRdyj0B9R0qLPUjMQwR8"
JWT_TOKEN_WITHOUT_VENDOR_ID = "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhYi1pbmJldiIsImF1ZCI6ImFiaS1taWNyb3NlcnZpY2VzIiwiZXhwIjoxNjQ4MDQzNTQ3LCJpYXQiOjE1MzY5NjMyNTcsInVwZGF0ZWRfYXQiOjE1MzY5NjMyNTcsIm5hbWUiOiJ1bml0QHRlc3QuY29tIiwic2lnbkluTmFtZXMuZW1haWxBZGRyZXNzIjoidW5pdEB0ZXN0LmNvbSIsImFjY291bnRJRCI6IjAxMTMyNDc4MDAwNjQyIiwidXNlcklEIjoiMTk5NTciLCJhY2NvdW50cyI6WyIwMTEzMjQ3ODAwMDcyMyJdLCJyb2xlcyI6WyJST0xFX0NVU1RPTUVSIl19.ApmVk1USBW8nYOuNL2V_wBkaQrbnus5cYCyu_Iz7los"
BASIC_AUTHORIZATION = "Basic cm9vdDpyb290"
BASIC_AUTHORIZATION_INVALID = "123456"
BASIC_AUTHORIZATION_UNAUTHORIZED_USER = "Basic Zm9vOmJhcg =="

ID_PREFIX = "1234-4321"
ACCOUNT_ID_PREFIX = "robot-test"
VENDOR_ID_PREFIX = "vendor-robot-test"
DEFAULT_ID = 123456

UPDATED_AT = 1596335930000    # 2020-08-02T02:38:50.123Z
LT_UPDATED_AT = 1596330930000    # 2020-08-02T01:15:30.432Z
GT_UPDATED_AT = 1596358930000    # 2020-08-02T09:02:10.456Z

CREDIT_STATEMENT_MAX_RESULTS = 3
FIRST_DATE = "02/2018"
SECOND_DATE = "03/2018"
THIRD_DATE = "04/2018"

# Request files
CREDIT_EXCHANGE = "credits.exchange"
CREDIT_QUEUE = "credits-ms"
CREDIT_DEAD_LETTER_QUEUE = "credits-ms.deadLetter"
CREDIT_BATCH_QUEUE = "credits-ms-batch"
CREDIT_BATCH_DEAD_LETTER_QUEUE = "credits-ms-batch.deadLetter"
SHARED_CREDIT_BATCH_QUEUE = "shared-credits-ms-batch"
SHARED_CREDIT_BATCH_DEAD_LETTER_QUEUE = "shared-credits-ms-batch.deadLetter"
SHARED_CREDIT_QUEUE = "shared-credits-ms"
SHARED_CREDIT_DEAD_LETTER_QUEUE = "shared-credits-ms.deadLetter"

# Request files
CREDIT_CONSUMPTION_FILE = "./robotframework/resources/credits/credit_consumption.json"
CREDIT_CONSUMPTION_WRONG_ACCOUNT_ID_FILE = "./robotframework/resources/credits/credit_consumption_wrong_account_id.json"
CREDIT_JSON_FILE = "./robotframework/resources/credits/credit.json"
EMPTY_JSON = "./robotframework/resources/credits/empty_json.json"
BASIC_CREDIT_JSON_FILE = "./robotframework/resources/credits/basic_credit.json"
BASIC_CREDIT_VENDOR_ACCOUNT_ID_JSON_FILE = "./robotframework/resources/credits/basic_credit_vendor_account_id.json"
CREDIT_GZIP_FILE = "./robotframework/resources/credits/credit1000.gz"
CREDIT_GZIP_INVALID_AMOUNT_FILE = "./robotframework/resources/credits/credit11000.gz"
CREDIT_INVALID_SIZE_NUMERIC_FIELDS_JSON_FILE = "./robotframework/resources/credits/credit_invalid_size_numeric_fields.json"
CREDIT_INVALID_SIZE_STRING_FIELDS_JSON_FILE = "./robotframework/resources/credits/credit_invalid_size_string_fields.json"
CREDIT_DUPLICATED_ACCOUNT_ID_VENDOR_ACCOUNT_ID_FIELDS = "./robotframework/resources/credits/credit_duplicated_account_id_vendor_account_id_fields.json"

# Response errors files
CREDIT_RESPONSE_EMPTY_JSON = "./robotframework/resources/errors/credit_response_empty_json.json"
CREDIT_RESPONSE_INVALID_SIZE_NUMERIC_FIELDS = "./robotframework/resources/errors/credit_response_invalid_size_numeric_fields.json"
CREDIT_RESPONSE_INVALID_SIZE_STRING_FIELDS = "./robotframework/resources/errors/credit_response_invalid_size_string_fields.json"
GZIP_RESPONSE_INVALID_AMOUNT = "./robotframework/resources/errors/gzip_response_invalid_amount.json"
RESPONSE_INVALID_COUNTRY_HEADER = "./robotframework/resources/errors/response_invalid_country_header.json"
GZIP_RESPONSE_INVALID_CONTENT_ENCODING = "./robotframework/resources/errors/gzip_response_invalid_content_encoding.json"
RESPONSE_ACCESS_DENIED = "./robotframework/resources/errors/credit_response_access_denied.json"
RESPONSE_DUPLICATED_ACCOUNT_ID_VENDOR_ACCOUNT_ID_FIELDS = "./robotframework/resources/errors/credit_duplicated_account_id_vendor_account_id_fields.json"

# Credit statement files
LIST_OF_CREDIT_STATEMENT_VALID = "./robotframework/resources/credits/statements/list_of_valid_statements.json"
ONE_CREDIT_STATEMENT_INVALID_BALANCE = "./robotframework/resources/credits/statements/one_statement_with_invalid_balance.json"
ONE_CREDIT_STATEMENT_INVALID_DATE = "./robotframework/resources/credits/statements/one_statement_with_invalid_date.json"
LIST_OF_STATEMENT_ONE_INVALID_BALANCE = "./robotframework/resources/credits/statements/list_of_statement_with_one_invalid_balance.json"
LIST_OF_STATEMENT_ONE_INVALID_DATE = "./robotframework/resources/credits/statements/list_of_statement_with_one_invalid_date.json"