import requests
import gzip

def post_request_file(url, file, headers):
    with open(file, 'rb') as content_file:
        content = content_file.read()

    return requests.post(url, data=content, headers=headers)
