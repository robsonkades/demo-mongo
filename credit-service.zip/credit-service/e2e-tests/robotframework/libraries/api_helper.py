from datetime import datetime, timezone, timedelta
import random
import requests
import gzip
import json
from robot.api import logger
from robot.libraries.BuiltIn import BuiltIn
import traceback
from bson.decimal128 import Decimal128


def generate_datetime(seconds_to_add=0, format='%Y-%m-%dT%H:%M:%SZ'):
    seconds_param = int(seconds_to_add)
    date = datetime.now() + timedelta(seconds=seconds_param)
    return date.strftime(format)


def generate_epoch_datetime(seconds_to_add=0):
    seconds_param = int(seconds_to_add)
    date = (datetime.now(timezone.utc) +
            timedelta(seconds=0)).timestamp() * 1e3
    return int(date)


def convert_timestamp(timestamp):
    date = datetime.utcfromtimestamp(
        int(timestamp) / 1000).strftime('%Y-%m-%dT%H:%M:%SZ')
    return date

def get_json_file_to_obj(file):
    f = open(file, "r")
    file_content = f.read()
    f.close()
    return json.loads(file_content)


def load_json_from_string(json_string):
    return json.loads(json_string.replace('\n', '\\n'))


def get_key_from_dict(dict, key):
    return dict.get(key, None)

def get_dictionary_from_list(list, key, value):
    for dictionary in list:
        if dictionary[key] == value:
            return dictionary
    return {}

def get_random_number():
    random.seed(datetime.now())
    return random.randint(10000, 99999)


def convert_decimal_values_to_float(dict):
    for key in dict.keys():
        value = dict[key]
        if isinstance(value, Decimal128):
          dict[key] = float(value.to_decimal())
    