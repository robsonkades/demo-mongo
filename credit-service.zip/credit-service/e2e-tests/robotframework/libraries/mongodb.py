import pymongo
import datetime
from robot.api import logger
import copy
import json
import time
from robot.libraries.BuiltIn import BuiltIn


def remove_mongodb_records(connection_string, database, collection, query):
    logger.info("Removing data in collection {0}.{1} with query {2}.".format(
        database, collection, query), html=True, also_console=False)
    query = "{}" if query is None else json.loads(query)
    client = pymongo.MongoClient(connection_string)
    db = client[database]
    cols = db.collection_names(collection)
    for c in cols:
        if collection in c:
            col = db[c]
            col.delete_many(query)
    client.close()


def insert_credits(connection_string, database, collection, credit):
    logger.info("Inserting credits in collection {0}.{1}.".format(
        database, collection), html=True, also_console=False)
    document = copy.deepcopy(credit)
    update_format = '%Y-%m-%dT%H:%M:%SZ'
    logger.info(document)
    for i, d in enumerate(document):
        document[i]['updatedAt'] = datetime.datetime.strptime(
            document[i]['updatedAt'], update_format)

    client = pymongo.MongoClient(connection_string)
    db = client[database]
    col = db[collection]
    try:
        col.insert_many(document)
    except pymongo.errors.BulkWriteError as e:
        raise e
    finally:
        client.close()
    return document


def find_credits(connection_string, database, collection, query, expected_count=1, attempts=1):
    logger.info("Finding credits in collection {0}.{1} with query {2}.".format(
        database, collection, query), html=True, also_console=False)
    query = json.loads("{}") if query is None else json.loads(query)
    client = pymongo.MongoClient(connection_string)
    db = client[database]
    col = db[collection]
    update_format = '%Y-%m-%dT%H:%M:%SZ'

    i = 0
    while i < attempts:
        credits = list(col.find(query))
        for credit in credits:
            if 'updatedAt' in credit:
                credit['updatedAt'] = datetime.datetime.strftime(credit['updatedAt'], update_format)
        if len(credits) >= expected_count:
            client.close()
            return credits
        i += 1
        time.sleep(0.5)
    client.close()
    return credits