import datetime
from robot.api import logger
import copy
import json
import requests
from robot.libraries.BuiltIn import BuiltIn


def publish_message(exchange, routing_key, payload, properties):
    logger.info("Publishing message in exchange {0} using routing key {1}.".format(
        exchange, routing_key), html=True, also_console=False)

    rabbitmq = BuiltIn().get_variable_value("${RABBITMQ}")

    path = rabbitmq['publishPath'].format(
        rabbitmq['vhost'], exchange)

    url = "{0}://{1}:{2}{3}".format(
        rabbitmq['protocol'], rabbitmq['host'], rabbitmq['webPort'], path)
    body = {
        "properties": properties,
        "routing_key": routing_key,
        "payload": payload,
        "payload_encoding": "string"
    }
    headers = {'Content-Type': 'application/json'}
    auth = (rabbitmq['user'], rabbitmq['password'])
    r = requests.post(url, headers=headers, auth=auth, data=json.dumps(body))
    if r.status_code == 200:
        logger.info("Message has been published successfully",
                    html=True, also_console=False)


def get_message(queue_name, count=5):
    rabbitmq = BuiltIn().get_variable_value("${RABBITMQ}")

    path = rabbitmq['getQueueContentPath'].format(
        rabbitmq['vhost'], queue_name)

    url = "{0}://{1}:{2}{3}".format(
        rabbitmq['protocol'], rabbitmq['host'], rabbitmq['webPort'], path)
    body = {
        "count": count,
        "ackmode": "ack_requeue_true",
        "requeue": True,
        "encoding": "auto",
        "truncate": 50000
    }

    headers = {'Content-Type': 'application/json'}
    auth = (rabbitmq['user'], rabbitmq['password'])
    return requests.post(url, headers=headers, auth=auth,
                         data=json.dumps(body)).json()


def purge_queue_contents(queue_name):
    logger.info("Purging all messages from queue {0}".format(
        queue_name), html=True, also_console=False)
    rabbitmq = BuiltIn().get_variable_value("${RABBITMQ}")
    path = rabbitmq['deleteQueueContentPath'].format(
        rabbitmq['vhost'], queue_name)

    url = "{0}://{1}:{2}{3}".format(rabbitmq['protocol'],
                                    rabbitmq['host'], rabbitmq['webPort'], path)

    headers = {'Content-Type': 'application/json'}
    auth = (rabbitmq['user'], rabbitmq['password'])

    r = requests.delete(url, headers=headers, auth=auth)
    if r.status_code == 200:
        logger.info("Message has purged successfully",
                    html=True, also_console=False)
    return r
