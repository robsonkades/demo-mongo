import json
import requests
import api_helper
from robot.libraries.BuiltIn import BuiltIn
from robot.api import logger
import traceback


def get_tm4j_vars():
    tm4j_vars_file = "./robotframework/variables/tm4j.json"
    f = open(tm4j_vars_file, "r")
    tm4j_vars = f.read()
    f.close()
    return json.loads(tm4j_vars)


def get_service_version():
    api = BuiltIn().get_variable_value("${API}", "")
    url = "{0}://{1}:{2}{3}/actuator/info".format(
        api['protocol'], api['host'], api['port'], api['path'])
    return requests.get(url).json()['build']['version']


def create_test_cycle():
    try:
        env = BuiltIn().get_variable_value("${ENV}", "")
        build_version = get_service_version()
        build_uri = "https://ab-inbev.visualstudio.com/GHQ_B2B_Delta/_build/results?buildId={0}".format(
            build_version.split("-")[1])
        tm4j = get_tm4j_vars()
        BuiltIn().set_global_variable("${projectKey}", tm4j['projectKey'])
        body = {
            "projectKey": tm4j['projectKey'],
            "name": "[credit-service] - Build: {0} - Env: {1}".format(build_version, env),
            "description": "Credits - Robot Tests<br><br><a href=\"{0}\">Build link</a>".format(build_uri),
            "plannedStartDate": api_helper.generate_datetime(format="%Y-%m-%dT%H:%M:%SZ"),
            "plannedEndDate": api_helper.generate_datetime(format="%Y-%m-%dT%H:%M:%SZ"),
            "statusName": "Not Executed",
            "folderId": tm4j['projectTestCycleFolder']
        }
        headers = {'Content-Type': 'application/json',
                   'Authorization': tm4j['token']}
        test_cycle_id = requests.post(
            "{0}/testcycles".format(tm4j['baseUrl']), headers=headers, data=json.dumps(body), timeout=10).json()['key']
        logger.info("Test Cycle created: {0}".format(
            test_cycle_id), html=True, also_console=False)
        BuiltIn().set_global_variable("${testCycleKey}", test_cycle_id)
    except Exception:
        logger.info(traceback.print_exc(), html=True, also_console=False)
        raise


def create_test_execution_for_test_suite(test_results):
    try:
        tm4j = get_tm4j_vars()
        test_cycle_id = BuiltIn().get_variable_value("${testCycleKey}")
        for test_result in test_results:
            headers = {'Content-Type': 'application/json',
                       'Authorization': tm4j['token']}
            body = {
                "projectKey": tm4j['projectKey'],
                "testCaseKey": test_result.get('testCaseKey'),
                "testCycleKey": test_cycle_id,
                "statusName": test_result.get('statusName').capitalize(),
                "environmentName": "Docker",
                "actualEndDate": test_result.get('executionTime'),
                "comment": test_result.get('comment', None)
            }
            requests.post(
                "{0}/testexecutions".format(tm4j['baseUrl']), headers=headers, data=json.dumps(body), timeout=10)
            logger.info("Test Execution created:  Test Case: {0} - Test Cycle: {1}".format(
                test_result.get('testCaseKey'), test_cycle_id), html=True, also_console=False)
    except Exception:
        logger.info(traceback.print_exc(), html=True, also_console=False)
        raise
