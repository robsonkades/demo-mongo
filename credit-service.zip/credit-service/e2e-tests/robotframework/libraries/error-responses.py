import json


def get_errors_from_file(service):
    error_file = {
        "relay": "./robotframework/resources/errors/error_relay_types.json",
        "api":   "./robotframework/resources/errors/api.json"
    }

    f = open(error_file.get(service), "r")
    errors = f.read()
    f.close()
    return json.loads(errors)


def get_expected_error_response(service, expected_error, attributes=None):
    errors = get_errors_from_file(service)
    error = errors.get(expected_error, None)
    details = []
    if attributes:
        for v in attributes.split(','):
            details.append({
                "code": error['code'],
                "message": error['message'],
                "attribute": v
            })
    else:
        details.append({
            "code": error['code'],
            "message": error['message'],
            "attribute": None
        })
    expected_error_response = {
        "message": "",
        "httpCode": error['httpCode'],
        "details": details
    }
    return expected_error_response


def get_expected_error_relay_response(service, expected_errors, error_message_accepted_types):
    errors = get_errors_from_file(service)
    details = []
    for e in expected_errors:
        error = errors.get(e['type'], None)
        code = error['code']

        if error.get('details') is not None:
            details = error['details']

        if error_message_accepted_types is not None:
            message = error['message'].replace(
                '{acceptedTypes}', error_message_accepted_types)
        else:
            message = error['message']

        for f in e['fields']:
            details.append(f + error['errorMessage'])
    expected_error_response = {
        "message": message,
        "code": code,
        "details": details
    }
    return expected_error_response
