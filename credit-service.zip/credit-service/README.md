# Credit Microservice
​
B2B Microservice design to manage and store informations about credits;
​
## Technologies​
* Spring Boot
* RabbitMQ
* MongoDB
​
## How do I get set up?
### Prerequisites
   * [JDK 11.0.7+10](https://www.azul.com/downloads/zulu-community/?version=java-11-lts&architecture=x86-64-bit&package=jdk)
   * [Maven-3](https://maven.apache.org/download.cgi)
   * [Git](https://git-scm.com/downloads)
 
​
## Credit Data Migrator - Documentation

In order to read data from the account database in the Account Service and republish it in credits.exchange we have a script that performs the following steps:
1. Read all accounts that have credit and generate a DUMP file with all the IDs of those accounts
2. Given a batch size setting, load all ID's into memory and break them into batches, for each batch search for accounts in the Accounts database and publish in the RabbitMQ _credits.exchange_.
3. At the end, an output is generated in the terminal of how many credits were successful, if the batch has failed, a report will be generated in the temp folder with the ID's that were not processed successfully.

### Steps to execute the data migrator script
1. Adjust the mongo export tool path in the _/credit-service/scripts/data-migration/config.json_ file. Example:
```
{
    "mongoExportApp": "/home/thiagoteixeira/tools/mongodb-database-tools-amazon-x86_64-100.3.0/bin/mongoexport"
    ...
}
```
2. Add environment configuration in the _/credit-service/scripts/data-migration/config.json_ file. Example:
```
{
    ...
    "environments": {
        "dev": {
            "rabbitmq": {
                "protocol": "http",
                "host": "127.0.0.1",
                "port": "5672",
                "exchangeName": "credits.exchange",
                "vhost": "b2b",
                "user": "guest",
                "password": "guest"
            },
            "database": {
                "uri": "mongodb://localhost:27017",
                "name": "Accounts",
                "collectionBase": "%s-Accounts"
            }
        }
    }
}
```
3. Run the script for the configured environment. Example:
```
cd /credit-service/scripts/data-migration
python3 run.py DEV DO
```
Just wait for the result. Like this:
```
2021-03-04T08:37:00.814-0300	connected to: mongodb://localhost:27017
2021-03-04T08:37:00.827-0300	exported 2 records
2021-03-04 08:37:00,848 [INFO] Connecting to 127.0.0.1:5672 [Thread-1]
2021-03-04 08:37:00,852 [INFO] Created channel=1 [Thread-1]
2021-03-04 08:37:00,853 [INFO] 1 - Message was sent successful with 2 credits [Thread-1]
2021-03-04 08:37:00,855 [INFO] Total execution time 0:00:00.134923 [MainThread]
2021-03-04 08:37:00,855 [INFO] Result: '2' from '2' credits were republished successful [MainThread]
2021-03-04 08:37:00,855 [INFO] All credits were republished successful [MainThread]
```
If any credit has failed it is possible to reprocess those that have failed use the following command pointed to the file containing the failed ID's. Example
```
python3 run.py DEV DO dev-DO-credit-unsuccessful-2021-03-03T23:13:50.443812.csv
```


#### Who do I talk to about this service? 
* Financial Integration Services Team
  * [Thiago Teixeira](mailto:thiago.teixeira-ext@ab-inbev.com)
  * [Marcelo Delgado](mailto:Marcelo.DelgadodosSantos-ext@ab-Inbev.com)
  * [Fábio De Pierri](mailto:Fabio.DePierri-ext@ab-Inbev.com)
  * [Felipe Castor](mailto:felipe.castor@ab-inbev.com)
  * [Sheniece Simms](mailto:Sheniece.Simms@ab-inbev.com)
  * [Roberta de Paula](mailto:Roberta.Fonseca-ext@ab-Inbev.com)


