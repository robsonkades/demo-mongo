package com.abinbev.b2b.credit.relay.helper;

import static com.abinbev.b2b.credit.relay.helper.UrlHelper.isTrustedUrl;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class UrlHelperTest {
    @Test
    public void trustedUrlReturnTrue() {
        assertTrue(isTrustedUrl("/swagger-ui.html"));
    }

    @Test
    public void trustedUrlReturnFalse() {
        assertFalse(isTrustedUrl("/xpto"));
    }
}
