package com.abinbev.b2b.credit.relay.helper;

import static com.abinbev.b2b.credit.relay.helper.RabbitHelper.buildDeadLetterRoutingKey;
import static com.abinbev.b2b.credit.relay.helper.RabbitHelper.buildQueueName;
import static com.abinbev.b2b.credit.relay.helper.RabbitHelper.buildRoutingKey;
import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class RabbitHelperTest {

    private static final String COUNTRY = "BR";

    @Test
    public void testBuildQueueName() {
        assertThat(buildQueueName(COUNTRY, "credits")).isEqualTo("br-credits");
    }

    @Test
    public void testBuildRoutingKey() {
        assertThat(buildRoutingKey(COUNTRY)).isEqualTo("br");
    }

    @Test
    public void testBuildRoutingKeyUsingBatch() {
        assertThat(buildRoutingKey(COUNTRY, "batch")).isEqualTo("br-batch");
    }

    @Test
    public void testBuildDeadLetterRoutingKey() {
        assertThat(buildDeadLetterRoutingKey(COUNTRY)).isEqualTo("br-dlq");
    }

    @Test
    public void testBuildDeadLetterRoutingKeyUsingBatch() {
        assertThat(buildDeadLetterRoutingKey(String.format("%s-%s", COUNTRY, "batch"))).isEqualTo("br-batch-dlq");
    }

}
