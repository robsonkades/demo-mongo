package com.abinbev.b2b.credit.relay.jwt;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

@RunWith(MockitoJUnitRunner.class)
public class JwtTokenManagerTest {

    @InjectMocks
    private JwtTokenManager jwtTokenManager;

    @Mock
    private SecurityContext securityContext;

    final private UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(null, null, null);

    @Test
    public void testGetVendorId() {
        authentication.setDetails(new JwtDetails("123456789"));
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);

        assertThat(jwtTokenManager.getVendorId()).isNotNull().isEqualTo("123456789");
    }

    @Test
    public void testGetVendorIdJwtDetailsNull() {
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);

        assertThat(jwtTokenManager.getVendorId()).isNull();
    }

    @Test
    public void testGetVendorIdVendorIdNull() {
        authentication.setDetails(new JwtDetails());
        when(securityContext.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(securityContext);

        assertThat(jwtTokenManager.getVendorId()).isNull();
    }

}
