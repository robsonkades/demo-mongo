package com.abinbev.b2b.credit.relay.config;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.abinbev.b2b.common.toggle.core.toggler.ABIToggler;

@RunWith(MockitoJUnitRunner.class)
public class AbiToggleConfigTest {

    public static final String ENABLE_VENDOR_ID_JWT_VALIDATION_PER_COUNTRY_VALUE = "enabledVendorIdJwtValidationPerCountry";

    @InjectMocks
    private AbiToggleConfigImpl toggleConfig;

    @Mock
    private ABIToggler toggler;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(toggleConfig, "enabledVendorIdJwtValidationPerCountry", ENABLE_VENDOR_ID_JWT_VALIDATION_PER_COUNTRY_VALUE);
    }

    @Test
    public void getToggleValueEnabledVendorIdJwtValidationPerCountry() {
        final String country = "US";

        ArgumentCaptor<Map<String, Object>> attributes = ArgumentCaptor.forClass(Map.class);

        when(toggler.isFeatureEnabled(eq(ENABLE_VENDOR_ID_JWT_VALIDATION_PER_COUNTRY_VALUE), anyString(), attributes.capture())).thenReturn(true);

        final var toggleValue = toggleConfig.isEnabledVendorIdJwtValidationPerCountry(country);

        assertThat(toggleValue).isTrue();
        assertThat(attributes.getValue()).containsEntry("country", country);

    }
}