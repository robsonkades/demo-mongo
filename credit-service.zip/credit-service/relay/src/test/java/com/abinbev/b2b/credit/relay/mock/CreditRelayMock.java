package com.abinbev.b2b.credit.relay.mock;

import java.math.BigDecimal;

import com.abinbev.b2b.credit.relay.vo.CreditRequest;
import com.google.common.collect.ImmutableList;

public class CreditRelayMock {

    public static final String ACCOUNT_ID = "123";

    public static final String PAYMENT_TERMS = "CASH";

    public static CreditRequest mockCreditRequest() {
        final CreditRequest request = new CreditRequest();
        request.setAccountId(ImmutableList.of(ACCOUNT_ID));
        request.setAvailable(BigDecimal.TEN);
        request.setBalance(BigDecimal.TEN);
        request.setConsumption(BigDecimal.TEN);
        request.setOverdue(BigDecimal.TEN);
        request.setPaymentTerms(PAYMENT_TERMS);
        request.setTotal(BigDecimal.TEN);
        return request;
    }
}
