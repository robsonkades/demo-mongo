package com.abinbev.b2b.credit.relay.helper;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.abinbev.b2b.credit.relay.config.property.MessageQueueProperties;
import com.abinbev.b2b.credit.relay.exception.BadRequestException;
import com.abinbev.b2b.credit.relay.exception.IssueEnum;

@RunWith(MockitoJUnitRunner.class)
public class ControllerValidationHelperTest {

    private static final String INVALID_COUNTRY = "bla";

    public static final String BR = "BR";

    public static final List<String> SUPPORTED_COUNTRIES = Arrays.asList("br", "ar", "za");

    @InjectMocks
    private ControllerValidationHelper validationHelper;

    @Mock
    private MessageQueueProperties messageQueueProperties;

    @Before
    public void setUp() {
        when(messageQueueProperties.getCountries()).thenReturn(SUPPORTED_COUNTRIES);
    }

    @Test
    public void validateCountry() {
        validationHelper.validateCountry(BR);
        validationHelper.validateIfCountryIsSupported(BR);
    }

    @Test(expected = BadRequestException.class)
    public void validateInvalidCountry() {
        try {
            validationHelper.validateCountry(INVALID_COUNTRY);
        } catch (final BadRequestException e) {
            assertThat(e.getIssues()).isNotEmpty();
            assertThat(e
                               .getIssues()
                               .size()).isOne();
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getCode()).isEqualTo(IssueEnum.INVALID_COUNTRY.getCode());
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getMessage()).isEqualTo(IssueEnum.INVALID_COUNTRY.getFormattedMessage(INVALID_COUNTRY));
            throw e;
        }
    }

    @Test(expected = BadRequestException.class)
    public void validateUnsupportedCountry() {
        final var japanCountry = "JP";
        try {
            validationHelper.validateIfCountryIsSupported(japanCountry);
        } catch (final BadRequestException e) {
            assertThat(e.getIssues()).isNotEmpty();
            assertThat(e
                               .getIssues()
                               .size()).isOne();
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getCode()).isEqualTo(IssueEnum.UNSUPPORTED_COUNTRY.getCode());
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getMessage()).isEqualTo(IssueEnum.UNSUPPORTED_COUNTRY.getFormattedMessage(japanCountry, SUPPORTED_COUNTRIES
                    .stream()
                    .map(String::toUpperCase)
                    .collect(Collectors.toList())));
            throw e;
        }

    }

}
