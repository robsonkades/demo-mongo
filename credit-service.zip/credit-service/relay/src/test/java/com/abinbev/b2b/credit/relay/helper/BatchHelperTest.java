package com.abinbev.b2b.credit.relay.helper;

import static com.abinbev.b2b.credit.relay.mock.CreditRelayMock.mockCreditRequest;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.abinbev.b2b.credit.relay.config.BatchConfiguration;
import com.abinbev.b2b.credit.relay.config.BatchConfiguration.Publisher;
import com.abinbev.b2b.credit.relay.exception.BadRequestException;
import com.abinbev.b2b.credit.relay.exception.IssueEnum;
import com.abinbev.b2b.credit.relay.mock.CreditRelayMock;
import com.abinbev.b2b.credit.relay.vo.AbstractRequest;
import com.abinbev.b2b.credit.relay.vo.CreditRequest;
import com.google.common.collect.ImmutableSet;

@RunWith(MockitoJUnitRunner.class)
public class BatchHelperTest {
    private Set<ConstraintViolation<AbstractRequest>> FIELD_CONSTRAINT_VIOLATIONS = ImmutableSet.of(ConstraintViolationImpl.forBeanValidation(null, null, null, null, null, null, null, null, null, null, null));

    @InjectMocks
    private BatchHelper helper;

    @Mock
    private BatchConfiguration configuration;

    @Before
    public void setUp() {
        configuration = new BatchConfiguration();
        configuration.setMaxDeletePayloadSize(1);
        configuration.setMaxPayloadSize(2);
        final Publisher publisher = new Publisher();
        publisher.setChunkSize(1);
        configuration.setPublisher(publisher);
        ReflectionTestUtils.setField(helper, "configuration", configuration);
    }

    @Test
    public void defineTimestampSuccessfully() {
        final CreditRequest request = mockCreditRequest();
        assertNull(request.getUpdatedAt());
        helper.defineTimestampForBatchRequest(Arrays.asList(request));
        assertNotNull(request.getUpdatedAt());
    }

    @Test
    public void defineTimestampWithCollectionNullOrEmpty() {
        assertThatCode(() -> helper.defineTimestampForBatchRequest(new ArrayList<>())).doesNotThrowAnyException();
        assertThatCode(() -> helper.defineTimestampForBatchRequest(null)).doesNotThrowAnyException();
    }

    @Test
    public void validateDivideChunksForValidObjects() {
        final List<List<? extends AbstractRequest>> invalidObjects = BatchHelper.divideChunksForValidObjects(
                Arrays.asList(createAccountAbstractRequest(false), createAccountAbstractRequest(false), createAccountAbstractRequest(true), createAccountAbstractRequest(false), createAccountAbstractRequest(false)));
        assertNotNull(invalidObjects);
        assertEquals(4, invalidObjects.size());
        assertEquals(1, invalidObjects
                .get(0)
                .size());
        assertEquals(1, invalidObjects
                .get(1)
                .size());
        assertEquals(1, invalidObjects
                .get(2)
                .size());
        assertEquals(1, invalidObjects
                .get(3)
                .size());

    }

    @Test
    public void validateDivideChunksForInvalidObjects() {
        final List<List<? extends AbstractRequest>> invalidObjects = BatchHelper.divideChunksForInvalidObjects(
                Arrays.asList(createAccountAbstractRequest(false), createAccountAbstractRequest(true), createAccountAbstractRequest(true), createAccountAbstractRequest(false), createAccountAbstractRequest(false)));
        assertNotNull(invalidObjects);
        assertEquals(2, invalidObjects.size());
        assertEquals(1, invalidObjects
                .get(0)
                .size());
        assertEquals(1, invalidObjects
                .get(1)
                .size());
    }

    @Test
    public void validateExtractValidObjects() {
        final List<AbstractRequest> abstractRequests = BatchHelper.extractValidObjects(Arrays.asList(createAccountAbstractRequest(false), createAccountAbstractRequest(true), createAccountAbstractRequest(true)));
        assertNotNull(abstractRequests);
        assertEquals(1, abstractRequests.size());
    }

    @Test
    public void validateExtractInvalidObjects() {
        final List<AbstractRequest> abstractRequests = BatchHelper.extractInvalidObjects(Arrays.asList(createAccountAbstractRequest(false), createAccountAbstractRequest(true), createAccountAbstractRequest(true)));
        assertNotNull(abstractRequests);
        assertEquals(2, abstractRequests.size());
    }

    @Test(expected = BadRequestException.class)
    public void getExceptionByMaxPayloadSizeViolation() {
        final List<? extends AbstractRequest> request = Arrays.asList(createAccountAbstractRequest(false), createAccountAbstractRequest(true), createAccountAbstractRequest(true));
        try {
            BatchHelper.handleAndValidateBatchRequest(request, Boolean.FALSE);
        } catch (BadRequestException ex) {
            assertThat(ex
                               .getIssues()
                               .get(0)
                               .getCode()).isEqualTo(IssueEnum.BATCH_MAX_PAYLOAD_SIZE.getCode());
            throw ex;
        }
    }

    @Test(expected = BadRequestException.class)
    public void getExceptionByMaxDeletePayloadSizeViolation() {
        final List<? extends AbstractRequest> request = Arrays.asList(createAccountAbstractRequest(false), createAccountAbstractRequest(true));
        try {
            BatchHelper.handleAndValidateBatchRequest(request, Boolean.TRUE);
        } catch (BadRequestException ex) {
            assertThat(ex
                               .getIssues()
                               .get(0)
                               .getCode()).isEqualTo(IssueEnum.BATCH_MAX_DELETE_PAYLOAD_SIZE.getCode());
            throw ex;
        }
    }

    @Test(expected = ConstraintViolationException.class)
    public void getSingleConstraintViolation() {
        final CreditRequest invalidRequest = CreditRelayMock.mockCreditRequest();
        invalidRequest.setAccountId(null);
        final List<? extends AbstractRequest> request = Arrays.asList(invalidRequest);
        BatchHelper.handleAndValidateBatchRequest(request, Boolean.FALSE);
    }

    @Test
    public void getMultipleConstraintViolation() {
        final CreditRequest invalidRequest = CreditRelayMock.mockCreditRequest();
        invalidRequest.setAccountId(null);
        final List<? extends AbstractRequest> request = Arrays.asList(invalidRequest, invalidRequest);
        BatchHelper.handleAndValidateBatchRequest(request, Boolean.FALSE);
        assertThat(request
                           .get(0)
                           .hasError()).isTrue();
        assertThat(request
                           .get(1)
                           .hasError()).isTrue();
        assertThat(request
                           .get(0)
                           .getConstraintViolations()).isNotEmpty();
        assertThat(request
                           .get(1)
                           .getConstraintViolations()).isNotEmpty();
    }

    private AbstractRequest createAccountAbstractRequest(final boolean hasError) {
        final AbstractRequest request = CreditRelayMock.mockCreditRequest();
        if (hasError) {
            request.setHasError(true);
            request.setConstraintViolations(FIELD_CONSTRAINT_VIOLATIONS);
        }
        return request;
    }
}
