package com.abinbev.b2b.credit.relay.helper;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.abinbev.b2b.credit.relay.config.AbiToggleConfig;
import com.abinbev.b2b.credit.relay.exception.JwtException;
import com.abinbev.b2b.credit.relay.jwt.JwtTokenManager;
import com.abinbev.b2b.credit.relay.mock.CreditRelayMock;

@RunWith(MockitoJUnitRunner.class)
public class JwtVendorHelperTest {

    private static final String COUNTRY_BR = "BR";

    @InjectMocks
    private JwtVendorHelper jwtVendorHelper;

    @Mock
    private JwtTokenManager jwtTokenManager;

    @Mock
    private AbiToggleConfig abiToggleConfig;

    @Test
    public void testFillVendorId() {
        var credits = List.of(CreditRelayMock.mockCreditRequest(), CreditRelayMock.mockCreditRequest(), CreditRelayMock.mockCreditRequest());
        var expectedCredits = List.of(CreditRelayMock.mockCreditRequest(), CreditRelayMock.mockCreditRequest(), CreditRelayMock.mockCreditRequest());
        expectedCredits.get(0).setVendorId("12345");
        expectedCredits.get(1).setVendorId("12345");
        expectedCredits.get(2).setVendorId("12345");

        when(jwtTokenManager.getVendorId()).thenReturn("12345");
        jwtVendorHelper.validateAndFillVendorId(COUNTRY_BR, credits);

        assertThat(credits).isNotEmpty().isEqualTo(expectedCredits);
    }

    @Test(expected = JwtException.class)
    public void testFillVendorIdNullValidateTrue() {
        var credits = List.of(CreditRelayMock.mockCreditRequest(), CreditRelayMock.mockCreditRequest(), CreditRelayMock.mockCreditRequest());

        when(jwtTokenManager.getVendorId()).thenReturn(null);
        when(abiToggleConfig.isEnabledVendorIdJwtValidationPerCountry(COUNTRY_BR)).thenReturn(true);
        jwtVendorHelper.validateAndFillVendorId(COUNTRY_BR, credits);
    }

    @Test
    public void testFillVendorIdNullValidateFalse() {
        var credits = List.of(CreditRelayMock.mockCreditRequest(), CreditRelayMock.mockCreditRequest(), CreditRelayMock.mockCreditRequest());

        when(jwtTokenManager.getVendorId()).thenReturn(null);
        when(abiToggleConfig.isEnabledVendorIdJwtValidationPerCountry(COUNTRY_BR)).thenReturn(false);
        jwtVendorHelper.validateAndFillVendorId(COUNTRY_BR, credits);
        assertThat(credits).isNotEmpty().isEqualTo(credits);
    }
    
}