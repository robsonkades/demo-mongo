package com.abinbev.b2b.credit.relay.service;

import static com.abinbev.b2b.credit.relay.helper.constants.Constants.COUNTRY_HEADER;
import static com.abinbev.b2b.credit.relay.helper.constants.Constants.REQUEST_TRACE_ID_HEADER;
import static com.abinbev.b2b.credit.relay.mock.CreditRelayMock.ACCOUNT_ID;
import static com.abinbev.b2b.credit.relay.mock.CreditRelayMock.PAYMENT_TERMS;
import static com.abinbev.b2b.credit.relay.mock.CreditRelayMock.mockCreditRequest;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import org.apache.logging.log4j.util.Strings;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;
import org.springframework.test.util.ReflectionTestUtils;

import com.abinbev.b2b.credit.relay.domain.BatchCreation;
import com.abinbev.b2b.credit.relay.queue.domain.BaseCreditMessage;
import com.abinbev.b2b.credit.relay.queue.domain.CreditMessage;
import com.abinbev.b2b.credit.relay.queue.domain.MessageDto;
import com.abinbev.b2b.credit.relay.queue.domain.SharedCreditMessage;
import com.abinbev.b2b.credit.relay.queue.service.RabbitMQService;
import com.abinbev.b2b.credit.relay.vo.CreditRequest;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;

@RunWith(MockitoJUnitRunner.class)
public class CreditServiceImplTest {

    private static final String EXCHANGE = "credits.exchange";

    private static final String ROUTING_KEY = "batch";

    private static final String SHARED_ROUTING_KEY = "shared-batch";

    private static final String SHARED_BATCH_ROUTING_KEY = "shared-batch";

    private static final String COUNTRY_BR = "BR";

    private static final String REQUEST_TRACE_ID_UNIT_123 = "unit-123";

    @Spy
    @InjectMocks
    private CreditServiceImpl service;

    @Mock
    private RabbitMQService rabbit;

    @Before
    public void setUp() {
        ReflectionTestUtils.setField(service, "creditExchange", EXCHANGE);
        ReflectionTestUtils.setField(service, "creditBatchRoutingKey", ROUTING_KEY);
        ReflectionTestUtils.setField(service, "sharedCreditRoutingKey", SHARED_ROUTING_KEY);
        ReflectionTestUtils.setField(service, "sharedCreditBatchRoutingKey", SHARED_BATCH_ROUTING_KEY);
        MDC.put(REQUEST_TRACE_ID_HEADER, REQUEST_TRACE_ID_UNIT_123);
        MDC.put(COUNTRY_HEADER, COUNTRY_BR);
    }

    @Test
    public void createCredits() {
        final CreditRequest credit = mockCreditRequest();
        final BatchCreation<CreditRequest> creditsBatch = BatchCreation
                .builder(Arrays.asList(credit))
                .build();

        service.createCredits(creditsBatch);

        ArgumentCaptor<MessageDto> captor = ArgumentCaptor.forClass(MessageDto.class);
        verify(rabbit, times(1)).sendBatchMessages(captor.capture());

        final MessageDto captured = captor.getValue();
        assertThat(captured).isNotNull();
        assertThat(captured.getExchange()).isEqualTo(EXCHANGE);
        assertThat(captured.getNormalRoutingKey()).isEqualTo(Strings.EMPTY);
        assertThat(captured.getBatchRoutingKey()).isEqualTo(ROUTING_KEY);
        assertThat(captured.getDeleted()).isFalse();
        assertThat(captured.getProperties()).isNotNull();
        assertThat(captured.getProperties().getCountry()).isNotBlank().isEqualTo(COUNTRY_BR);
        assertThat(captured.getProperties().getRequestTraceId()).isNotBlank().isEqualTo(REQUEST_TRACE_ID_UNIT_123);
        assertThat(captured.getObjects()).isNotEmpty().hasSize(1);

        final BaseCreditMessage messageCaptured = captured.getObjects().get(0);
        assertThat(messageCaptured).isInstanceOf(CreditMessage.class);

        assertThat(((CreditMessage)messageCaptured).getAccountId()).isEqualTo(ACCOUNT_ID);
        assertThat(messageCaptured.getPaymentTerms()).isEqualTo(PAYMENT_TERMS);
        assertThat(messageCaptured.getAvailable()).isEqualTo(BigDecimal.TEN);
        assertThat(messageCaptured.getBalance()).isEqualTo(BigDecimal.TEN);
        assertThat(messageCaptured.getConsumption()).isEqualTo(BigDecimal.TEN);
        assertThat(messageCaptured.getOverdue()).isEqualTo(BigDecimal.TEN);
        assertThat(messageCaptured.getTotal()).isEqualTo(BigDecimal.TEN);
    }

    @Test
    public void createSharedCredits() {
        final CreditRequest sharedCreditA = mockCreditRequest();
        sharedCreditA.setAccountId(ImmutableList.of("a","b","c","b","c"));
        final CreditRequest sharedCreditB = mockCreditRequest();
        sharedCreditB.setAccountId(ImmutableList.of("d","e","f"));

        final ImmutableList<CreditRequest> input = ImmutableList.of(sharedCreditA, sharedCreditB);

        final BatchCreation<CreditRequest> creditsBatch = BatchCreation
                .builder(input)
                .build();

        service.createCredits(creditsBatch);

        ArgumentCaptor<MessageDto> captor = ArgumentCaptor.forClass(MessageDto.class);
        verify(rabbit, times(1)).sendBatchMessages(captor.capture());

        final MessageDto captured = captor.getValue();
        assertThat(captured).isNotNull();
        assertThat(captured.getExchange()).isEqualTo(EXCHANGE);
        assertThat(captured.getNormalRoutingKey()).isEqualTo(SHARED_ROUTING_KEY);
        assertThat(captured.getBatchRoutingKey()).isEqualTo(SHARED_BATCH_ROUTING_KEY);
        assertThat(captured.getDeleted()).isFalse();
        assertThat(captured.getProperties()).isNotNull();
        assertThat(captured.getProperties().getCountry()).isNotBlank().isEqualTo(COUNTRY_BR);
        assertThat(captured.getProperties().getRequestTraceId()).isNotBlank().isEqualTo(REQUEST_TRACE_ID_UNIT_123);
        assertThat(captured.getObjects()).isNotEmpty().hasSize(2);

        List<BaseCreditMessage> sharedResult = captured.getObjects();
        assertThat(sharedResult).isNotEmpty();
        assertThat(sharedResult.size()).isEqualTo(2);

        assertThat(sharedResult.get(0)).isEqualToIgnoringGivenFields(sharedCreditA, "accountId");
        assertThat(sharedResult.get(0)).isInstanceOf(SharedCreditMessage.class);
        assertThat(((SharedCreditMessage) sharedResult.get(0)).getAccountId()).isEqualTo(ImmutableSet.of("a", "b", "c"));
        assertThat(sharedResult.get(1)).isEqualToIgnoringGivenFields(sharedCreditB, "accountId");
        assertThat(sharedResult.get(1)).isInstanceOf(SharedCreditMessage.class);
        assertThat(((SharedCreditMessage) sharedResult.get(1)).getAccountId()).isEqualTo(ImmutableSet.of("d","e","f"));
    }

    @Test
    public void createDifferentKindOfCredits() {
        final CreditRequest normalCreditA = mockCreditRequest();
        final CreditRequest normalCreditB = mockCreditRequest();
        final CreditRequest normalCreditC = mockCreditRequest();
        final CreditRequest sharedCreditA = mockCreditRequest();
        sharedCreditA.setAccountId(ImmutableList.of("a","b","c","b","c"));
        final CreditRequest sharedCreditB = mockCreditRequest();
        sharedCreditB.setAccountId(ImmutableList.of("d","e","f"));

        final ImmutableList<CreditRequest> input = ImmutableList.of(sharedCreditA, sharedCreditB, normalCreditA, normalCreditB, normalCreditC);

        final BatchCreation<CreditRequest> creditsBatch = BatchCreation
                .builder(input)
                .build();

        service.createCredits(creditsBatch);

        ArgumentCaptor<MessageDto> captor = ArgumentCaptor.forClass(MessageDto.class);

        verify(rabbit, times(2)).sendBatchMessages(captor.capture());

        assertThat(captor.getAllValues()).isNotEmpty().hasSize(2);

        final MessageDto normalCaptured = captor.getAllValues().get(0);
        assertThat(normalCaptured).isNotNull();
        assertThat(normalCaptured.getExchange()).isEqualTo(EXCHANGE);
        assertThat(normalCaptured.getNormalRoutingKey()).isEqualTo(Strings.EMPTY);
        assertThat(normalCaptured.getBatchRoutingKey()).isEqualTo(ROUTING_KEY);
        assertThat(normalCaptured.getDeleted()).isFalse();
        assertThat(normalCaptured.getProperties()).isNotNull();
        assertThat(normalCaptured.getProperties().getCountry()).isNotBlank().isEqualTo(COUNTRY_BR);
        assertThat(normalCaptured.getProperties().getRequestTraceId()).isNotBlank().isEqualTo(REQUEST_TRACE_ID_UNIT_123);
        assertThat(normalCaptured.getObjects()).isNotEmpty().hasSize(3);

        List<BaseCreditMessage> normalResult = normalCaptured.getObjects();

        assertThat(normalResult.get(0)).isEqualToIgnoringGivenFields(normalCreditA, "accountId");
        assertThat(normalResult.get(0)).isInstanceOf(CreditMessage.class);
        assertThat(((CreditMessage) normalResult.get(0)).getAccountId()).isEqualTo("123");
        assertThat(normalResult.get(1)).isEqualToIgnoringGivenFields(normalCreditB, "accountId");
        assertThat(normalResult.get(1)).isInstanceOf(CreditMessage.class);
        assertThat(((CreditMessage) normalResult.get(1)).getAccountId()).isEqualTo("123");
        assertThat(normalResult.get(2)).isEqualToIgnoringGivenFields(normalCreditC, "accountId");
        assertThat(normalResult.get(2)).isInstanceOf(CreditMessage.class);
        assertThat(((CreditMessage) normalResult.get(2)).getAccountId()).isEqualTo("123");

        final MessageDto sharedCaptured = captor.getAllValues().get(1);
        assertThat(sharedCaptured).isNotNull();
        assertThat(sharedCaptured.getExchange()).isEqualTo(EXCHANGE);
        assertThat(sharedCaptured.getNormalRoutingKey()).isEqualTo(SHARED_ROUTING_KEY);
        assertThat(sharedCaptured.getBatchRoutingKey()).isEqualTo(SHARED_BATCH_ROUTING_KEY);
        assertThat(sharedCaptured.getDeleted()).isFalse();
        assertThat(sharedCaptured.getProperties()).isNotNull();
        assertThat(sharedCaptured.getProperties().getCountry()).isNotBlank().isEqualTo(COUNTRY_BR);
        assertThat(sharedCaptured.getProperties().getRequestTraceId()).isNotBlank().isEqualTo(REQUEST_TRACE_ID_UNIT_123);
        assertThat(sharedCaptured.getObjects()).isNotEmpty().hasSize(2);

        List<BaseCreditMessage> sharedResult = sharedCaptured.getObjects();

        assertThat(sharedResult.get(0)).isEqualToIgnoringGivenFields(sharedCreditA, "accountId");
        assertThat(sharedResult.get(0)).isInstanceOf(SharedCreditMessage.class);
        assertThat(((SharedCreditMessage) sharedResult.get(0)).getAccountId()).isEqualTo(ImmutableSet.of("a", "b", "c"));
        assertThat(sharedResult.get(1)).isEqualToIgnoringGivenFields(sharedCreditB, "accountId");
        assertThat(sharedResult.get(1)).isInstanceOf(SharedCreditMessage.class);
        assertThat(((SharedCreditMessage) sharedResult.get(1)).getAccountId()).isEqualTo(ImmutableSet.of("d","e","f"));
    }

    @Test
    public void extractSharedCredits() {
        final CreditRequest sharedCreditA = mockCreditRequest();
        sharedCreditA.setAccountId(ImmutableList.of("a","b","c"));
        final CreditRequest sharedCreditB = mockCreditRequest();
        sharedCreditB.setAccountId(ImmutableList.of("d","e","f"));

        final ImmutableList<CreditRequest> input = ImmutableList.of(sharedCreditA, sharedCreditB, mockCreditRequest(), mockCreditRequest(), mockCreditRequest());

        final List<CreditRequest> result = service.extractSharedCredits(input);
        assertThat(result).isNotEmpty();
        assertThat(result.size()).isEqualTo(2);
        assertThat(result).isEqualTo(ImmutableList.of(sharedCreditA,sharedCreditB));
    }

    @Test
    public void extractSharedCreditsWithNullArgument() {
        final List<CreditRequest> result = service.extractSharedCredits(null);
        assertThat(result).isEmpty();
    }

}
