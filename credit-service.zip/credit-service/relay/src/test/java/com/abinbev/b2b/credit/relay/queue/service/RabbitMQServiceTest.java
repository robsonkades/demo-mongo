package com.abinbev.b2b.credit.relay.queue.service;

import static com.abinbev.b2b.credit.relay.helper.RabbitHelper.buildRoutingKey;
import static com.abinbev.b2b.credit.relay.helper.constants.Constants.COUNTRY_HEADER;
import static com.abinbev.b2b.credit.relay.helper.constants.Constants.REQUEST_TRACE_ID_HEADER;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;

import com.abinbev.b2b.credit.relay.config.BatchConfiguration;
import com.abinbev.b2b.credit.relay.domain.BatchCreation;
import com.abinbev.b2b.credit.relay.helper.BatchHelper;
import com.abinbev.b2b.credit.relay.helper.MessageHelper;
import com.abinbev.b2b.credit.relay.mock.CreditRelayMock;
import com.abinbev.b2b.credit.relay.queue.domain.MessageDto;
import com.abinbev.b2b.credit.relay.queue.domain.QueueEvent;
import com.abinbev.b2b.credit.relay.vo.AbstractRequest;
import com.abinbev.b2b.credit.relay.vo.CreditRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableSet;

@RunWith(MockitoJUnitRunner.class)
public class RabbitMQServiceTest {

    private static final String EXCHANGE_VALUE = "creditExchange";

    private static final String BATCH_ROUTING_KEY = "batch";

    private static final String BATCH_DEAD_LETTER_ROUTING_KEY = "batch.deadLetter";

    private static final String COUNTRY_BR = "BR";

    private static final String REQUEST_TRACE_ID_UNIT_123 = "unit-123";

    private Set<ConstraintViolation<AbstractRequest>> FIELD_CONSTRAINT_VIOLATIONS = ImmutableSet.of(ConstraintViolationImpl.forBeanValidation(null, null, null, null, null, null, null, null, null, null, null));

    @InjectMocks
    private RabbitMQService service;

    @Spy
    private ObjectMapper mapper;

    @Mock
    private RabbitTemplate template;

    @Mock
    private BatchConfiguration batchConfiguration;

    @Before
    public void setUp() {
        MDC.put(REQUEST_TRACE_ID_HEADER, REQUEST_TRACE_ID_UNIT_123);
        MDC.put(COUNTRY_HEADER, COUNTRY_BR);
        ReflectionTestUtils.setField(BatchHelper.class, "configuration", batchConfiguration);

    }

    @Test
    public void sendMessageSuccessfully() throws Exception {
        final CreditRequest creditCreationRequest = CreditRelayMock.mockCreditRequest();
        final BatchCreation creation = BatchCreation
                .builder(Arrays.asList(creditCreationRequest))
                .build();
        final String routingKey = buildRoutingKey(COUNTRY_BR, StringUtils.EMPTY);

        service.sendMessage(creditCreationRequest, creation.getProperties(), EXCHANGE_VALUE, routingKey, Boolean.FALSE);

        final ArgumentCaptor<Message> captor = ArgumentCaptor.forClass(Message.class);
        verify(template, times(1)).convertAndSend(eq(EXCHANGE_VALUE), any(), captor.capture());

        final MessageProperties expectedMessageProperties = new MessageProperties();
        expectedMessageProperties.setHeader(COUNTRY_HEADER, COUNTRY_BR);
        expectedMessageProperties.setHeader(REQUEST_TRACE_ID_HEADER, REQUEST_TRACE_ID_UNIT_123);
        expectedMessageProperties.setContentType(MediaType.APPLICATION_JSON_VALUE);

        final QueueEvent expectedEvent = new QueueEvent(Boolean.FALSE, COUNTRY_BR, creditCreationRequest);

        final Message expectedMessage = new Message(this.mapper.writeValueAsBytes(expectedEvent), expectedMessageProperties);
        final Message currentMessage = captor.getValue();
        final String expectedBody = new String(expectedMessage.getBody());
        final String currentBody = new String(currentMessage.getBody());

        assertThat(expectedBody).isNotBlank();
        assertThat(currentBody)
                .isNotBlank()
                .isEqualTo(expectedBody);
    }

    @Test
    public void sendBatchMessagesToBatchQueueWithPublisherChunkEnabled() {
        final int expectedMessageNumber = 3;

        final CreditRequest ac1 = CreditRelayMock.mockCreditRequest();
        final CreditRequest ac2 = CreditRelayMock.mockCreditRequest();
        final CreditRequest ac3 = CreditRelayMock.mockCreditRequest();
        final CreditRequest ac4 = CreditRelayMock.mockCreditRequest();
        final CreditRequest ac5 = CreditRelayMock.mockCreditRequest();

        final List<CreditRequest> request = Arrays.asList(ac1, ac2, ac3, ac4, ac5);

        final BatchCreation creation = BatchCreation
                .builder(request)
                .build();

        final String routingKey = buildRoutingKey(COUNTRY_BR, BATCH_ROUTING_KEY);

        when(batchConfiguration.findPublisherChunkSize()).thenReturn(2);
        when(batchConfiguration.isPublisherChunkEnabled()).thenReturn(true);

        final MessageDto dto = MessageDto
                .builder()
                .withObjects(MessageHelper.convertToCreditMessage(request, false))
                .withProperties(creation.getProperties())
                .withExchange(EXCHANGE_VALUE)
                .withBatchRoutingKey(BATCH_ROUTING_KEY)
                .withIsDeleted(Boolean.FALSE)
                .build();

        service.sendBatchMessages(dto);

        final ArgumentCaptor<Message> captor = ArgumentCaptor.forClass(Message.class);
        verify(template, times(expectedMessageNumber)).convertAndSend(eq(EXCHANGE_VALUE), eq(routingKey), captor.capture());

        assertThat(captor.getAllValues()).isNotEmpty();
        assertThat(captor
                           .getAllValues()
                           .size()).isEqualTo(expectedMessageNumber);
    }

    @Test
    public void sendBatchMessagesToBatchQueueWithPublisherChunkDisabled() {
        final int expectedMessageNumber = 5;

        final CreditRequest ac1 = CreditRelayMock.mockCreditRequest();
        final CreditRequest ac2 = CreditRelayMock.mockCreditRequest();
        final CreditRequest ac3 = CreditRelayMock.mockCreditRequest();
        final CreditRequest ac4 = CreditRelayMock.mockCreditRequest();
        final CreditRequest ac5 = CreditRelayMock.mockCreditRequest();

        final List<CreditRequest> request = Arrays.asList(ac1, ac2, ac3, ac4, ac5);

        final BatchCreation creation = BatchCreation
                .builder(request)
                .build();

        final String routingKey = buildRoutingKey(COUNTRY_BR, null);

        when(batchConfiguration.isPublisherChunkEnabled()).thenReturn(false);

        final MessageDto dto = MessageDto
                .builder()
                .withObjects((MessageHelper.convertToCreditMessage(request, false)))
                .withProperties(creation.getProperties())
                .withExchange(EXCHANGE_VALUE)
                .withNormalRoutingKey(null)
                .withBatchRoutingKey(null)
                .withIsDeleted(Boolean.FALSE)
                .build();

        service.sendBatchMessages(dto);

        final ArgumentCaptor<Message> captor = ArgumentCaptor.forClass(Message.class);
        verify(template, times(expectedMessageNumber)).convertAndSend(eq(EXCHANGE_VALUE), eq(routingKey), captor.capture());

        assertThat(captor.getAllValues()).isNotEmpty();
        assertThat(captor
                           .getAllValues()
                           .size()).isEqualTo(expectedMessageNumber);
    }

    @Test
    public void sendBatchMessagesToBatchDeadLetterQueueWithPublisherChunkEnabled() {
        final int expectedMessageNumber = 1;

        final CreditRequest ac1 = CreditRelayMock.mockCreditRequest();
        ac1.setConstraintViolations(FIELD_CONSTRAINT_VIOLATIONS);
        final CreditRequest ac2 = CreditRelayMock.mockCreditRequest();
        ac1.setConstraintViolations(FIELD_CONSTRAINT_VIOLATIONS);

        final List<CreditRequest> request = Arrays.asList(ac1, ac2);

        final BatchCreation creation = BatchCreation
                .builder(request)
                .build();

        final String routingKey = buildRoutingKey(COUNTRY_BR, BATCH_DEAD_LETTER_ROUTING_KEY);

        when(batchConfiguration.findPublisherChunkSize()).thenReturn(2);
        when(batchConfiguration.isPublisherChunkEnabled()).thenReturn(true);

        final MessageDto dto = MessageDto
                .builder()
                .withObjects((MessageHelper.convertToCreditMessage(request, false)))
                .withProperties(creation.getProperties())
                .withExchange(EXCHANGE_VALUE)
                .withBatchRoutingKey(BATCH_DEAD_LETTER_ROUTING_KEY)
                .withIsDeleted(Boolean.FALSE)
                .build();

        service.sendBatchMessages(dto);

        final ArgumentCaptor<Message> captor = ArgumentCaptor.forClass(Message.class);
        verify(template, times(expectedMessageNumber)).convertAndSend(eq(EXCHANGE_VALUE), eq(routingKey), captor.capture());

        assertThat(captor.getAllValues()).isNotEmpty();
        assertThat(captor
                           .getAllValues()
                           .size()).isEqualTo(expectedMessageNumber);
    }

    @Test
    public void sendBatchMessagesWithPublisherChunkEnabled() {
        final CreditRequest correctAccount = CreditRelayMock.mockCreditRequest();
        final CreditRequest wrongAccount = CreditRelayMock.mockCreditRequest();
        wrongAccount.setConstraintViolations(FIELD_CONSTRAINT_VIOLATIONS);

        final List<CreditRequest> request = Arrays.asList(correctAccount, wrongAccount);

        final BatchCreation creation = BatchCreation
                .builder(request)
                .build();

        final String routingKey = buildRoutingKey(COUNTRY_BR, BATCH_DEAD_LETTER_ROUTING_KEY);

        when(batchConfiguration.findPublisherChunkSize()).thenReturn(2);
        when(batchConfiguration.isPublisherChunkEnabled()).thenReturn(true);

        final MessageDto dto = MessageDto
                .builder()
                .withObjects((MessageHelper.convertToCreditMessage(request, false)))
                .withProperties(creation.getProperties())
                .withExchange(EXCHANGE_VALUE)
                .withBatchRoutingKey(BATCH_DEAD_LETTER_ROUTING_KEY)
                .withIsDeleted(Boolean.FALSE)
                .build();

        service.sendBatchMessages(dto);

        final ArgumentCaptor<Message> captorForCorrect = ArgumentCaptor.forClass(Message.class);
        verify(template, times(1)).convertAndSend(eq(EXCHANGE_VALUE), eq(routingKey), captorForCorrect.capture());

        final ArgumentCaptor<Message> captorForWrongAccount = ArgumentCaptor.forClass(Message.class);
        verify(template, times(1)).convertAndSend(eq(EXCHANGE_VALUE), eq(routingKey), captorForWrongAccount.capture());

        assertThat(captorForCorrect.getAllValues()).isNotEmpty();
        assertThat(captorForCorrect
                           .getAllValues()
                           .size()).isEqualTo(1);

        assertThat(captorForWrongAccount.getAllValues()).isNotEmpty();
        assertThat(captorForWrongAccount
                           .getAllValues()
                           .size()).isEqualTo(1);
    }

    @Test
    public void sendMessagesToDeadLetterQueue() {
        final int expectedMessageNumber = 1;

        final CreditRequest ac1 = CreditRelayMock.mockCreditRequest();
        ac1.setConstraintViolations(FIELD_CONSTRAINT_VIOLATIONS);
        final CreditRequest ac2 = CreditRelayMock.mockCreditRequest();
        ac1.setConstraintViolations(FIELD_CONSTRAINT_VIOLATIONS);

        final List<CreditRequest> request = Arrays.asList(ac1, ac2);

        final BatchCreation creation = BatchCreation
                .builder(request)
                .build();

        final String routingKey = buildRoutingKey(COUNTRY_BR, BATCH_DEAD_LETTER_ROUTING_KEY);

        service.sendMessageToDeadLetter(request, creation.getProperties(), EXCHANGE_VALUE, routingKey, Boolean.FALSE);

        final ArgumentCaptor<Message> captor = ArgumentCaptor.forClass(Message.class);
        verify(template, times(expectedMessageNumber)).convertAndSend(eq(EXCHANGE_VALUE), eq(routingKey), captor.capture());

        assertThat(captor.getAllValues()).isNotEmpty();
        assertThat(captor
                           .getAllValues()
                           .size()).isEqualTo(expectedMessageNumber);
    }

    @Test
    public void sendMessageToDeadLetterQueue() {
        final int expectedMessageNumber = 1;

        final AbstractRequest ac1 = CreditRelayMock.mockCreditRequest();
        ac1.setConstraintViolations(FIELD_CONSTRAINT_VIOLATIONS);

        final List<AbstractRequest> request = Arrays.asList(ac1);

        final BatchCreation creation = BatchCreation
                .builder(request)
                .build();

        final String routingKey = buildRoutingKey(COUNTRY_BR, BATCH_DEAD_LETTER_ROUTING_KEY);

        service.sendMessageToDeadLetter(ac1, creation.getProperties(), EXCHANGE_VALUE, Boolean.FALSE, routingKey);

        final ArgumentCaptor<Message> captor = ArgumentCaptor.forClass(Message.class);
        verify(template, times(expectedMessageNumber)).convertAndSend(eq(EXCHANGE_VALUE), eq(routingKey), captor.capture());

        assertThat(captor.getAllValues()).isNotEmpty();
        assertThat(captor
                           .getAllValues()
                           .size()).isEqualTo(expectedMessageNumber);
    }
}
