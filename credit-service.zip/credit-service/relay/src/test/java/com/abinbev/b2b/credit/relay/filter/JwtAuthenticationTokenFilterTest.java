package com.abinbev.b2b.credit.relay.filter;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.security.core.context.SecurityContextHolder;

import com.abinbev.b2b.credit.relay.config.JwtValidationConfiguration;
import com.abinbev.b2b.credit.relay.exception.ErrorResponse;
import com.abinbev.b2b.credit.relay.exception.Issue;
import com.abinbev.b2b.credit.relay.exception.IssueEnum;
import com.abinbev.b2b.credit.relay.exception.IssueHandler;
import com.abinbev.b2b.credit.relay.exception.JwtException;
import com.abinbev.b2b.credit.relay.jwt.JwtDetails;
import com.abinbev.b2b.credit.relay.jwt.JwtToken;
import com.auth0.jwt.JWT;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.google.gson.Gson;

@RunWith(MockitoJUnitRunner.class)
public class JwtAuthenticationTokenFilterTest {

    private static final String BEARER_PREFIX = "Bearer";

    private static final String JWT_AUTH_WITH_VENDOR_ID = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhYi1pbmJldiIsImF1ZCI6ImFiaS1taWNyb3NlcnZpY2VzIiwiZXhwIjoxNjQ4MDQzNTQ3LCJpYXQiOjE1MzY5NjMyNTcsInVwZGF0ZWRfYXQiOjE1MzY5NjMyNTcsIm5hbWUiOiJ1bml0QHRlc3QuY29tIiwic2lnbkluTmFtZXMuZW1haWxBZGRyZXNzIjoidW5pdEB0ZXN0LmNvbSIsImFjY291bnRJRCI6IjAxMTMyNDc4MDAwNjQyIiwidXNlcklEIjoiMTk5NTciLCJhY2NvdW50cyI6WyIwMTEzMjQ3ODAwMDcyMyJdLCJyb2xlcyI6WyJST0xFX0NVU1RPTUVSIl0sInZlbmRvcklkIjoiMTIxMjEyIn0.zFx2VDvaaRKHu62cCN5HlDwaFOkiotoO6zGEq72Mvyw";

    private static final String JWT_AUTH_WITHOUT_VENDOR_ID = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhYi1pbmJldiIsImF1ZCI6ImFiaS1taWNyb3NlcnZpY2VzIiwiZXhwIjoxNjQ4MDQzNTQ3LCJpYXQiOjE1MzY5NjMyNTcsInVwZGF0ZWRfYXQiOjE1MzY5NjMyNTcsIm5hbWUiOiJ1bml0QHRlc3QuY29tIiwic2lnbkluTmFtZXMuZW1haWxBZGRyZXNzIjoidW5pdEB0ZXN0LmNvbSIsImFjY291bnRJRCI6IjAxMTMyNDc4MDAwNjQyIiwidXNlcklEIjoiMTk5NTciLCJhY2NvdW50cyI6WyIwMTEzMjQ3ODAwMDcyMyJdLCJyb2xlcyI6WyJST0xFX0NVU1RPTUVSIl0sInZlbmRvcklkIjpudWxsfQ.XawmuQcrOnt8hdwHk3ibjoyPkuwsSnp4haYWo2ejQfA";

    private static final String JWT_AUTH_WITHOUT_VENDOR_ID_CLAIM = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhYi1pbmJldiIsImF1ZCI6ImFiaS1taWNyb3NlcnZpY2VzIiwiZXhwIjoxNjQ4MDQzNTQ3LCJpYXQiOjE1MzY5NjMyNTcsInVwZGF0ZWRfYXQiOjE1MzY5NjMyNTcsIm5hbWUiOiJ1bml0QHRlc3QuY29tIiwic2lnbkluTmFtZXMuZW1haWxBZGRyZXNzIjoidW5pdEB0ZXN0LmNvbSIsImFjY291bnRJRCI6IjAxMTMyNDc4MDAwNjQyIiwidXNlcklEIjoiMTk5NTciLCJhY2NvdW50cyI6WyIwMTEzMjQ3ODAwMDcyMyJdLCJyb2xlcyI6WyJST0xFX0NVU1RPTUVSIl19.ApmVk1USBW8nYOuNL2V_wBkaQrbnus5cYCyu_Iz7los";

    public static final String VENDOR_ID_CLAIM = "vendorId";

    @InjectMocks
    private JwtAuthenticationTokenFilter filter;

    @Mock
    private JwtToken jwtToken;

    @Mock
    private JwtValidationConfiguration jwtValidationConfiguration;

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpServletResponse response;

    @Mock
    private FilterChain filterChain;

    @BeforeClass
    public static void setUp() {
        SecurityContextHolder.clearContext();
    }

    @Test
    public void trustedUrlShouldBeFilteredSuccessfully() throws IOException, ServletException {
        when(request.getRequestURI()).thenReturn("/swagger-resource");

        filter.doFilterInternal(request, response, filterChain);
        verify(filterChain, times(1)).doFilter(request, response);
    }

    @Test
    public void nonTrustedUrlShouldBeFilteredSuccessfully() throws IOException, ServletException {
        final DecodedJWT decodedJWT = JWT.decode(JWT_AUTH_WITH_VENDOR_ID);
        final String authHeader = BEARER_PREFIX + " " + JWT_AUTH_WITH_VENDOR_ID;

        when(jwtValidationConfiguration.getVendorIdClaim()).thenReturn(VENDOR_ID_CLAIM);
        when(request.getRequestURI()).thenReturn("/");
        when(request.getHeader(HttpHeaders.AUTHORIZATION)).thenReturn(authHeader);
        when(jwtToken.decodeToken(authHeader)).thenReturn(decodedJWT);

        filter.doFilterInternal(request, response, filterChain);

        verify(jwtToken, times(1)).decodeToken(authHeader);
        verify(filterChain, times(1)).doFilter(request, response);

        JwtDetails jwtDetails = (JwtDetails) SecurityContextHolder.getContext().getAuthentication().getDetails();
        assertThat(jwtDetails.getVendorId()).isNotNull().isEqualTo("121212");
    }

    @Test
    public void nonTrustedUrlDecodeException() throws IOException, ServletException {
        final String authHeader = BEARER_PREFIX + "  invalid";
        Issue issue = IssueHandler.createIssue(IssueEnum.FORBIDDEN);
        ErrorResponse errorResponse = new ErrorResponse(issue.getMessage(), List.of(issue));

        when(request.getRequestURI()).thenReturn("/");
        when(request.getHeader(HttpHeaders.AUTHORIZATION)).thenReturn(authHeader);
        when(jwtToken.decodeToken(authHeader)).thenThrow(new JwtException(IssueHandler.createIssue(IssueEnum.FORBIDDEN)));

        StringWriter responseWriter = new StringWriter();
        when(response.getWriter()).thenReturn(new PrintWriter(responseWriter));

        filter.doFilterInternal(request, response, filterChain);

        verify(jwtToken, times(1)).decodeToken(authHeader);
        verify(filterChain, times(0)).doFilter(request, response);

        assertThat(responseWriter).hasToString(new Gson().toJson(errorResponse));
    }


    @Test
    public void nonTrustedUrlDecodedTokenNull() throws IOException, ServletException {
        final String authHeader = BEARER_PREFIX + " " + JWT_AUTH_WITH_VENDOR_ID;

        when(request.getRequestURI()).thenReturn("/");
        when(request.getHeader(HttpHeaders.AUTHORIZATION)).thenReturn(authHeader);
        when(jwtToken.decodeToken(authHeader)).thenReturn(null);

        filter.doFilterInternal(request, response, filterChain);

        verify(jwtToken, times(1)).decodeToken(authHeader);
        verify(filterChain, times(1)).doFilter(request, response);

        JwtDetails jwtDetails = (JwtDetails) SecurityContextHolder.getContext().getAuthentication().getDetails();
        assertThat(jwtDetails.getVendorId()).isNull();
    }

    @Test
    public void nonTrustedUrlVendorIdBlank() throws IOException, ServletException {
        final DecodedJWT decodedJWT = JWT.decode(JWT_AUTH_WITHOUT_VENDOR_ID);
        final String authHeader = BEARER_PREFIX + " " + JWT_AUTH_WITHOUT_VENDOR_ID;

        when(jwtValidationConfiguration.getVendorIdClaim()).thenReturn(VENDOR_ID_CLAIM);
        when(request.getRequestURI()).thenReturn("/");
        when(request.getHeader(HttpHeaders.AUTHORIZATION)).thenReturn(authHeader);
        when(jwtToken.decodeToken(authHeader)).thenReturn(decodedJWT);

        filter.doFilterInternal(request, response, filterChain);

        verify(jwtToken, times(1)).decodeToken(authHeader);
        verify(filterChain, times(1)).doFilter(request, response);

        JwtDetails jwtDetails = (JwtDetails) SecurityContextHolder.getContext().getAuthentication().getDetails();
        assertThat(jwtDetails.getVendorId()).isNull();
    }


    @Test
    public void nonTrustedUrlVendorIdClaimNotConfigured() throws IOException, ServletException {
        final DecodedJWT decodedJWT = JWT.decode(JWT_AUTH_WITHOUT_VENDOR_ID);
        final String authHeader = BEARER_PREFIX + " " + JWT_AUTH_WITHOUT_VENDOR_ID;

        when(jwtValidationConfiguration.getVendorIdClaim()).thenReturn(null);
        when(request.getRequestURI()).thenReturn("/");
        when(request.getHeader(HttpHeaders.AUTHORIZATION)).thenReturn(authHeader);
        when(jwtToken.decodeToken(authHeader)).thenReturn(decodedJWT);

        filter.doFilterInternal(request, response, filterChain);

        verify(jwtToken, times(1)).decodeToken(authHeader);
        verify(filterChain, times(1)).doFilter(request, response);

        JwtDetails jwtDetails = (JwtDetails) SecurityContextHolder.getContext().getAuthentication().getDetails();
        assertThat(jwtDetails.getVendorId()).isNull();
    }

   @Test
    public void nonTrustedUrlVendorIdClaimAbsent() throws IOException, ServletException {
        final DecodedJWT decodedJWT = JWT.decode(JWT_AUTH_WITHOUT_VENDOR_ID_CLAIM);
        final String authHeader = BEARER_PREFIX + " " + JWT_AUTH_WITHOUT_VENDOR_ID_CLAIM;

        when(jwtValidationConfiguration.getVendorIdClaim()).thenReturn(VENDOR_ID_CLAIM);
        when(request.getRequestURI()).thenReturn("/");
        when(request.getHeader(HttpHeaders.AUTHORIZATION)).thenReturn(authHeader);
        when(jwtToken.decodeToken(authHeader)).thenReturn(decodedJWT);

        filter.doFilterInternal(request, response, filterChain);

        verify(jwtToken, times(1)).decodeToken(authHeader);
        verify(filterChain, times(1)).doFilter(request, response);

       JwtDetails jwtDetails = (JwtDetails) SecurityContextHolder.getContext().getAuthentication().getDetails();
       assertThat(jwtDetails.getVendorId()).isNull();
    }

}