package com.abinbev.b2b.credit.relay.helper;

import static com.abinbev.b2b.credit.relay.mock.CreditRelayMock.mockCreditRequest;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import com.abinbev.b2b.credit.relay.queue.domain.BaseCreditMessage;
import com.abinbev.b2b.credit.relay.queue.domain.CreditMessage;
import com.abinbev.b2b.credit.relay.queue.domain.SharedCreditMessage;
import com.abinbev.b2b.credit.relay.vo.CreditRequest;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;

@RunWith(MockitoJUnitRunner.class)
class MessageHelperTest {

    @Test
    public void convertToCreditMessage() {
        final CreditRequest a = mockCreditRequest();
        final CreditRequest b = mockCreditRequest();
        final CreditRequest c = mockCreditRequest();
        final List<CreditRequest> input = ImmutableList.of(a, b, c);

        final List<BaseCreditMessage> result = MessageHelper.convertToCreditMessage(input, false);
        assertThat(result).isNotEmpty();
        assertThat(result.size()).isEqualTo(3);
        assertThat(result.get(0)).isEqualToIgnoringGivenFields(a, "accountId");
        assertThat(result.get(0)).isInstanceOf(CreditMessage.class);
        assertThat(((CreditMessage)result.get(0)).getAccountId()).isEqualTo("123");
        assertThat(result.get(1)).isEqualToIgnoringGivenFields(b, "accountId");
        assertThat(result.get(1)).isInstanceOf(CreditMessage.class);
        assertThat(((CreditMessage)result.get(1)).getAccountId()).isEqualTo("123");
        assertThat(result.get(2)).isEqualToIgnoringGivenFields(c, "accountId");
        assertThat(result.get(2)).isInstanceOf(CreditMessage.class);
        assertThat(((CreditMessage)result.get(2)).getAccountId()).isEqualTo("123");
    }

    @Test
    public void convertToSharedCreditMessage() {
        final CreditRequest sharedCreditA = mockCreditRequest();
        sharedCreditA.setAccountId(ImmutableList.of("a","b","c","c","b"));
        final CreditRequest sharedCreditB = mockCreditRequest();
        sharedCreditB.setAccountId(ImmutableList.of("d","e","f"));

        final ImmutableList<CreditRequest> input = ImmutableList.of(sharedCreditA, sharedCreditB);

        final List<BaseCreditMessage> result = MessageHelper.convertToCreditMessage(input, true);
        assertThat(result).isNotEmpty();
        assertThat(result.size()).isEqualTo(2);
        assertThat(result.get(0)).isEqualToIgnoringGivenFields(sharedCreditA, "accountId");
        assertThat(result.get(0)).isInstanceOf(SharedCreditMessage.class);
        assertThat(((SharedCreditMessage)result.get(0)).getAccountId()).isEqualTo(ImmutableSet.of("a", "b", "c"));
        assertThat(result.get(1)).isEqualToIgnoringGivenFields(sharedCreditB, "accountId");
        assertThat(result.get(1)).isInstanceOf(SharedCreditMessage.class);
        assertThat(((SharedCreditMessage)result.get(1)).getAccountId()).isEqualTo(ImmutableSet.of("d","e","f"));
    }

    @Test
    public void convertToCreditMessageReceivingNullArgument() {
        final List<BaseCreditMessage> result = MessageHelper.convertToCreditMessage(null, false);
        assertThat(result).isEmpty();
    }

    @Test
    public void convertToSharedCreditMessageReceivingNullArgument() {
        final List<BaseCreditMessage> result = MessageHelper.convertToCreditMessage(null, true);
        assertThat(result).isEmpty();
    }
}