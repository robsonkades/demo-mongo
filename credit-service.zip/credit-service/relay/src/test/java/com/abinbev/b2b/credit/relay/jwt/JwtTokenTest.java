package com.abinbev.b2b.credit.relay.jwt;

import static com.abinbev.b2b.credit.relay.jwt.JwtTestConstants.BEARER_PREFIX;
import static com.abinbev.b2b.credit.relay.jwt.JwtTestConstants.TOKEN_WITH_VENDOR_ID;
import static org.assertj.core.api.Assertions.assertThat;

import org.apache.logging.log4j.util.Strings;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.abinbev.b2b.credit.relay.exception.JwtException;
import com.auth0.jwt.interfaces.DecodedJWT;

@RunWith(MockitoJUnitRunner.class)
public class JwtTokenTest {

    @InjectMocks
    private JwtToken jwtToken;

    @Test
    public void testToken() {
        DecodedJWT decodedJwt = jwtToken.decodeToken(TOKEN_WITH_VENDOR_ID);

        assertThat(decodedJwt.getClaim("vendorId").asString()).isEqualTo("vendorId-123");
    }

    @Test
    public void testBearerToken() {
        DecodedJWT decodedJwt = jwtToken.decodeToken(getTokenWithBearer(TOKEN_WITH_VENDOR_ID));

        assertThat(decodedJwt.getClaim("vendorId").asString()).isEqualTo("vendorId-123");
    }

    @Test
    public void testNullToken() {
        DecodedJWT decodedJwt = jwtToken.decodeToken(null);

        assertThat(decodedJwt).isNull();
    }

    @Test
    public void testEmptyToken() {
        DecodedJWT decodedJwt = jwtToken.decodeToken(Strings.EMPTY);

        assertThat(decodedJwt).isNull();
    }

    @Test(expected = JwtException.class)
    public void testDecodeTokenError() {
        DecodedJWT decodedJwt = jwtToken.decodeToken("invalid-token");
    }

    private String getTokenWithBearer(final String token) {
        return new StringBuilder(BEARER_PREFIX)
                .append(" ")
                .append(token)
                .toString();
    }
}
