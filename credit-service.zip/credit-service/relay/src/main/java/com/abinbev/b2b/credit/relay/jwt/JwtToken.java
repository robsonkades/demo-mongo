package com.abinbev.b2b.credit.relay.jwt;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.abinbev.b2b.credit.relay.exception.IssueEnum;
import com.abinbev.b2b.credit.relay.exception.IssueHandler;
import com.abinbev.b2b.credit.relay.exception.JwtException;
import com.auth0.jwt.JWT;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.interfaces.DecodedJWT;

@Service
public class JwtToken {

    private static final Logger logger = LoggerFactory.getLogger(JwtToken.class);

    private static final String BEARER_PREFIX = "Bearer ";

    public DecodedJWT decodeToken(final String receivedToken) {

        final String token = normalizeToken(receivedToken);

        if (StringUtils.isNotBlank(token)) {
            try {
                return JWT.decode(token);
            } catch (final JWTDecodeException exception) {
                logger.error("Error when decoding token, {}", exception.getMessage());
                throw new JwtException(IssueHandler.createIssue(IssueEnum.FORBIDDEN));
            }
        }
        return null;
    }

    private String normalizeToken(final String receivedToken) {
        if (StringUtils.isNotBlank(receivedToken) && receivedToken.startsWith(BEARER_PREFIX)) {
            return receivedToken.substring(BEARER_PREFIX.length());
        }
        return receivedToken;
    }
}