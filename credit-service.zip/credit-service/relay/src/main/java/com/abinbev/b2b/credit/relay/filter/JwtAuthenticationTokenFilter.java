package com.abinbev.b2b.credit.relay.filter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import com.abinbev.b2b.credit.relay.config.JwtValidationConfiguration;
import com.abinbev.b2b.credit.relay.exception.ErrorResponse;
import com.abinbev.b2b.credit.relay.exception.JwtException;
import com.abinbev.b2b.credit.relay.helper.UrlHelper;
import com.abinbev.b2b.credit.relay.jwt.JwtDetails;
import com.abinbev.b2b.credit.relay.jwt.JwtToken;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.google.gson.Gson;

public class JwtAuthenticationTokenFilter extends OncePerRequestFilter {

    @Autowired
    private JwtToken jwtToken;

    @Autowired
    private JwtValidationConfiguration jwtValidationConfiguration;

    @Override
    protected void doFilterInternal(final HttpServletRequest request, final HttpServletResponse response, final FilterChain chain) throws IOException, ServletException {

        try {
            final var jwtDetails = new JwtDetails();
            UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(null, null, null);

            if (!UrlHelper.isTrustedUrl(request.getRequestURI())) {
                final String authorization = request.getHeader(HttpHeaders.AUTHORIZATION);

                final DecodedJWT decodedToken = jwtToken.decodeToken(authorization);
                jwtDetails.setVendorId(getVendorIdFromJwt(decodedToken));
            }

            authentication.setDetails(jwtDetails);
            SecurityContextHolder.getContext().setAuthentication(authentication);
            chain.doFilter(request, response);

        } catch (final JwtException ex) {
            final var errorResponse = new ErrorResponse(ex.getIssues().get(0).getMessage(), ex.getIssues());

            response.setContentType(MediaType.APPLICATION_JSON_VALUE);
            response.setCharacterEncoding(StandardCharsets.UTF_8.name());

            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            response.getWriter().write(new Gson().toJson(errorResponse));
        }
    }

    private String getVendorIdFromJwt(final DecodedJWT decodedToken) {
        if (decodedToken != null) {
            final String vendorIdClaim = jwtValidationConfiguration.getVendorIdClaim();
            if (StringUtils.isNotBlank(vendorIdClaim) && decodedToken.getClaims().get(vendorIdClaim) != null) {
                return decodedToken.getClaims().get(vendorIdClaim).asString();
            }
        }
        return null;
    }

}

