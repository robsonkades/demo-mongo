package com.abinbev.b2b.credit.relay.exception;

import java.util.IllegalFormatException;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.abinbev.b2b.credit.relay.helper.constants.Constants;

public enum IssueEnum {
    // Note: the comments are placed just to prevent auto formatting add
    // the constants to the same line.
    //
    GENERIC_EXCEPTION("credit-relay-service.generic-exception"),
    //
    INVALID_COUNTRY("credit-relay-service.invalid-country"),
    //
    BATCH_MAX_DELETE_PAYLOAD_SIZE("credit-batch-max-delete-payload-size"),
    //
    BATCH_MAX_PAYLOAD_SIZE("credit-batch-max-payload-size"),
    //
    UNSUPPORTED_COUNTRY("credit-relay-service.unsupported-country"),
    //
    FORBIDDEN("credit-relay-service.forbidden"),
    //
    DUPLICATED_ACCOUNT_ID_VENDOR_ACCOUNT_ID_FIELDS("credit-relay-service.duplicated-account-id-vendor-account-id-fields");

    private final String code;

    /**
     * Invalid attribute from Object
     */
    private String attribute;

    private String message;

    private ResourceBundle bundle;

    // not static because ENUMS are initialized before static fields by JVM
    private final Logger logger = LoggerFactory.getLogger(IssueEnum.class);

    IssueEnum(final String code) {
        this(code, null);
    }

    IssueEnum(final String code, final String attribute) {
        init();
        this.code = code;
        this.attribute = attribute;

        try {
            message = bundle.getString(this.code);
        } catch (final MissingResourceException e) {
            logger.warn(e.getMessage(), e);
            message = "";
        }
    }

    private void init() {
        if (bundle == null) {
            bundle = ResourceBundle.getBundle(Constants.RESOURCE_BUNDLE_FILE_NAME);
        }
    }

    public String getCode() {
        return code;
    }

    public String getAttribute() {
        return attribute;
    }

    public String getFormattedMessage(final Object... args) {
        if (message == null) {
            return message;
        }

        try {
            return String.format(message, args);
        } catch (final IllegalFormatException e) {
            logger.warn(e.getMessage(), e);
            return message.replace("%s", "");
        }
    }

    public IssueEnum withAttribute(final String attribute) {
        this.attribute = attribute;
        return this;
    }
}
