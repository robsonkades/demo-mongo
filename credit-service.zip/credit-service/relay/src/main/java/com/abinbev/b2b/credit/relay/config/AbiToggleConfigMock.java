package com.abinbev.b2b.credit.relay.config;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

@Profile("e2e")
@Component
public class AbiToggleConfigMock implements AbiToggleConfig {

    final Type type = new TypeToken<Map<String, Boolean>>() {}.getType();

    @Value("#{environment.ENABLE_VENDOR_ID_JWT_VALIDATION_PER_COUNTRY}")
    private String enabledVendorIdJwtValidationPerCountryFromEnv;

    private Map<String, Boolean> enabledVendorIdJwtValidationPerCountry = new HashMap<>();

    @Override
    public boolean isEnabledVendorIdJwtValidationPerCountry(final String country) {
        if (StringUtils.isNotBlank(this.enabledVendorIdJwtValidationPerCountryFromEnv)) {
            this.enabledVendorIdJwtValidationPerCountry = new Gson().fromJson(enabledVendorIdJwtValidationPerCountryFromEnv, type);
        }

        return enabledVendorIdJwtValidationPerCountry.getOrDefault(StringUtils.lowerCase(country), true);
    }
}
