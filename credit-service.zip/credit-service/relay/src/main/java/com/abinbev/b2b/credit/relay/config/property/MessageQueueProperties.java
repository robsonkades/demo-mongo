package com.abinbev.b2b.credit.relay.config.property;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "message")
public class MessageQueueProperties {

    private List<String> countries = new ArrayList<>();

    private Map<String, String> queues = new HashMap<>();

    private Map<String, String> exchanges = new HashMap<>();

    private Map<String, String> routingKeys = new HashMap<>();

    public List<String> getCountries() {
        return countries;
    }

    public void setCountries(final List<String> countries) {
        this.countries = countries;
    }

    public Map<String, String> getQueues() {
        return queues;
    }

    public void setQueues(final Map<String, String> queues) {
        this.queues = queues;
    }

    public Map<String, String> getExchanges() {
        return exchanges;
    }

    public void setExchanges(final Map<String, String> exchanges) {
        this.exchanges = exchanges;
    }

    public Map<String, String> getRoutingKeys() {
        return routingKeys;
    }

    public void setRoutingKeys(final Map<String, String> routingKeys) {
        this.routingKeys = routingKeys;
    }
}
