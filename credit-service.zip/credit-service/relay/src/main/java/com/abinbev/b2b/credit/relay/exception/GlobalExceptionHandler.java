package com.abinbev.b2b.credit.relay.exception;

import java.nio.file.AccessDeniedException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.NoHandlerFoundException;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.exc.InvalidFormatException;

@ControllerAdvice
@RestController
public class GlobalExceptionHandler {
    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    private static final String MALFORMED_REQUEST = "Malformed Request";

    private static final String FIELD_ERROR_MESSAGE_SEPARATOR = ": ";

    @ExceptionHandler(Exception.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    protected ResponseEntity<Object> processExceptions(final Exception ex, final WebRequest request) {
        logger.error(ex.getMessage(), ex);
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(buildErrorResponse(IssueHandler.createIssue(ex)));
    }

    @ExceptionHandler(RuntimeException.class)
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    protected ResponseEntity<Object> processException(final RuntimeException ex, final WebRequest request) {
        logger.error(ex.getMessage(), ex);
        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(buildErrorResponse(IssueHandler.createIssue(ex)));
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    @ResponseStatus(code = HttpStatus.METHOD_NOT_ALLOWED, value = HttpStatus.METHOD_NOT_ALLOWED)
    protected ResponseEntity<Object> processHttpRequestMethodNotSupportedException(final HttpRequestMethodNotSupportedException ex, final WebRequest request) {
        logger.error(ex.getMessage(), ex);
        return ResponseEntity
                .status(HttpStatus.METHOD_NOT_ALLOWED)
                .body(buildErrorResponse(IssueHandler.createIssue(ex)));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    protected ResponseEntity<Object> handleMethodArgumentNotValid(final MethodArgumentNotValidException ex, final WebRequest request) {
        logger.error(ex.getMessage(), ex);
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(buildErrorResponse(IssueHandler.createIssue(ex)));
    }

    @ExceptionHandler(NoHandlerFoundException.class)
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    protected ResponseEntity<Object> handleNotFoundException(final NoHandlerFoundException ex, final WebRequest request) {
        logger.error(ex.getMessage(), ex);
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(buildErrorResponse(IssueHandler.createIssue(ex)));
    }

    @ExceptionHandler(AccessDeniedException.class)
    @ResponseStatus(value = HttpStatus.FORBIDDEN)
    protected ResponseEntity<Object> accessDenied(final Exception ex, final WebRequest request) {
        logger.error(ex.getMessage(), ex);
        return ResponseEntity
                .status(HttpStatus.FORBIDDEN)
                .body(buildErrorResponse(IssueHandler.createIssue(ex)));
    }

    @ExceptionHandler({ BadRequestException.class })
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    protected ResponseEntity<Object> processBadRequestException(final GlobalException ex, final WebRequest request) {
        logger.error(ex.getMessage(), ex);
        return ResponseEntity
                .status(ex.getHttpStatus())
                .body(buildErrorResponse(ex.getIssues()));
    }

    @ExceptionHandler(ExternalServiceException.class)
    @ResponseStatus(HttpStatus.SERVICE_UNAVAILABLE)
    public MessageResponse handlerExternalServiceError(final ExternalServiceException ex) {
        logger.error(ex.getMessage(), ex);
        return new MessageResponse(HttpStatus.SERVICE_UNAVAILABLE.value(), ex.getMessage());
    }

    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public MessageResponse handleValidationError(final ConstraintViolationException ex) {
        final List<String> errors = new ArrayList<>();

        final Set<ConstraintViolation<?>> violations = ex.getConstraintViolations();
        for (final ConstraintViolation<?> violation : violations) {
            final StringBuilder sb = new StringBuilder();
            sb.append(violation.getPropertyPath());
            sb.append(FIELD_ERROR_MESSAGE_SEPARATOR);
            sb.append(violation.getMessage());
            errors.add(sb.toString());
        }
        logger.error(ex.getMessage(), ex);
        return new MessageResponse(HttpStatus.BAD_REQUEST.value(), MALFORMED_REQUEST, errors);
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public MessageResponse handlerJsonDeserializeError(final HttpMessageNotReadableException ex) {
        String message = "Can not deserialize JSON";
        if (ex.getCause() instanceof InvalidFormatException) {
            final InvalidFormatException cause = (InvalidFormatException) ex.getCause();
            if (Enum.class.isAssignableFrom(cause.getTargetType())) {
                message = String.format("One of the following values were expected %s but the value found was %s", getEnumValues((Enum[]) cause
                        .getTargetType()
                        .getEnumConstants()), cause.getValue());
            }
        } else if (ex.getRootCause() != null && ex.getRootCause() instanceof BadRequestException) {
            message = ex.getRootCause().getMessage();
        }
        logger.error(ex.getMessage(), ex);
        return new MessageResponse(HttpStatus.BAD_REQUEST.value(), message);
    }

    @ExceptionHandler(JwtException.class)
    @ResponseStatus(value = HttpStatus.FORBIDDEN)
    protected ResponseEntity<Object> handleJwtException(final JwtException ex) {
        final var errorResponse = new ErrorResponse(ex.getIssues().get(0).getMessage(), ex.getIssues());

        return ResponseEntity.status(ex.getHttpStatus()).body(errorResponse);
    }

    private ErrorResponse buildErrorResponse(final Issue issue) {
        return new ErrorResponse(issue.getMessage(), Arrays.asList(issue));
    }

    private ErrorResponse buildErrorResponse(final List<Issue> issues) {
        return new ErrorResponse(issues
                                         .get(0)
                                         .getMessage(), issues);
    }

    private String getEnumValues(final Enum[] enumValues) {
        final List<String> values = new ArrayList<>();
        Stream
                .of(enumValues)
                .forEach(value -> values.add(value.name()));
        return String.join(",", values);
    }

    @JsonInclude(JsonInclude.Include.NON_NULL)
    public static class MessageResponse {

        @JsonProperty
        private final Integer code;

        @JsonProperty
        private final String message;

        @JsonProperty
        private final List<String> details;

        public MessageResponse(final Integer code, final String message) {
            this(code, message, null);
        }

        public MessageResponse(final Integer code, final String message, final List<String> details) {
            super();
            this.code = code;
            this.message = message;
            this.details = details;
        }

        public Integer getCode() {
            return code;
        }

        public String getMessage() {
            return message;
        }

        public List<String> getDetails() {
            return details;
        }
    }
}
