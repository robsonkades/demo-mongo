package com.abinbev.b2b.credit.relay.queue.domain;

import static com.abinbev.b2b.credit.relay.helper.DateFormatHelper.toStringISOFromMillis;
import static com.abinbev.b2b.credit.relay.helper.DateFormatHelper.toTimeMillisWithOffset;

import com.abinbev.b2b.credit.relay.vo.AbstractRequest;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonUnwrapped;

public class QueueEvent {
    @JsonProperty
    private Long updatedAt;

    @JsonProperty
    private Boolean deleted;

    @JsonProperty
    private String country;

    @JsonUnwrapped
    private Object messageObject;

    public QueueEvent(final Boolean deleted, final Object messageObject, final String country) {
        this.deleted = deleted;
        this.messageObject = messageObject;
        this.country = country;
        this.setUpdatedAt(System.currentTimeMillis());
    }

    public QueueEvent(final Boolean deleted, final String country, final AbstractRequest messageObject) {
        this.updatedAt = messageObject.getUpdatedAt();
        this.deleted = deleted;
        this.country = country;
        this.messageObject = messageObject;
    }

    @JsonIgnore
    public Long getUpdatedAt() {
        return this.updatedAt;
    }

    public void setDeleted(final Boolean deleted) {
        this.deleted = deleted;
    }

    public String getCountry() {
        return this.country;
    }

    public void setCountry(final String country) {
        this.country = country;
    }

    public void setMessageObject(final Object messageObject) {
        this.messageObject = messageObject;
    }

    @JsonProperty("updatedAt")
    public void setUpdatedAt(final String updatedAt) {
        this.updatedAt = toTimeMillisWithOffset(updatedAt);
    }

    @JsonProperty("updatedAt")
    public String getUpdatedAtAsString() {
        return toStringISOFromMillis(this.updatedAt);
    }

    public boolean isDeleted() {
        return this.deleted;
    }

    public void setUpdatedAt(final Long updatedAt) {
        this.updatedAt = updatedAt;
    }
}
