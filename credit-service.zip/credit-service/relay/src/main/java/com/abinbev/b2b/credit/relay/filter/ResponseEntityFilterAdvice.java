package com.abinbev.b2b.credit.relay.filter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.core.MethodParameter;
import org.springframework.http.MediaType;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.http.server.ServletServerHttpResponse;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseBodyAdvice;

import com.abinbev.b2b.credit.relay.helper.constants.Constants;

@ControllerAdvice
public class ResponseEntityFilterAdvice<T> implements ResponseBodyAdvice<T> {
    @Override
    public boolean supports(final MethodParameter methodParameter, final Class<? extends HttpMessageConverter<?>> aClass) {
        return true;
    }

    @Override
    public T beforeBodyWrite(final T body, final MethodParameter methodParameter, final MediaType mediaType, final Class<? extends HttpMessageConverter<?>> aClass, final ServerHttpRequest serverHttpRequest,
                             final ServerHttpResponse serverHttpResponse) {
        // Doing this in this filter is a better approach than javax.servlet.Filter, because both success and error responses pass through here.
        addRequestTraceIdHeaderToResponse(serverHttpRequest, serverHttpResponse);
        return body;
    }

    /**
     * Add requestTraceId header to all HTTP responses.
     *
     * @param request  The {@link ServerHttpRequest} instance
     * @param response The {@link ServerHttpResponse} instance
     */
    private void addRequestTraceIdHeaderToResponse(final ServerHttpRequest request, final ServerHttpResponse response) {
        final HttpServletRequest req = ((ServletServerHttpRequest) request).getServletRequest();
        final HttpServletResponse resp = ((ServletServerHttpResponse) response).getServletResponse();
        final String requestTraceId = req.getHeader(Constants.REQUEST_TRACE_ID_HEADER);
        resp.addHeader(Constants.REQUEST_TRACE_ID_HEADER, requestTraceId);
    }
}
