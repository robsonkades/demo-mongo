package com.abinbev.b2b.credit.relay.domain;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

public class BatchOperationProperties {

    private String requestTraceId;

    private String country;

    public String getRequestTraceId() {
        return requestTraceId;
    }

    public void setRequestTraceId(final String requestTraceId) {
        this.requestTraceId = requestTraceId;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(final String country) {
        this.country = country;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o)
            return true;

        if (o == null || getClass() != o.getClass())
            return false;

        final BatchOperationProperties that = (BatchOperationProperties) o;

        return new EqualsBuilder()
                .append(requestTraceId, that.requestTraceId)
                .append(country, that.country)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(requestTraceId)
                .append(country)
                .toHashCode();
    }
}
