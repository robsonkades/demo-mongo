package com.abinbev.b2b.credit.relay.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.logging.log4j.util.Strings;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.abinbev.b2b.credit.relay.domain.BatchCreation;
import com.abinbev.b2b.credit.relay.helper.MessageHelper;
import com.abinbev.b2b.credit.relay.queue.domain.MessageDto;
import com.abinbev.b2b.credit.relay.queue.service.RabbitMQService;
import com.abinbev.b2b.credit.relay.vo.CreditRequest;

@Service
public class CreditServiceImpl implements CreditService {

    private static final Logger logger = LoggerFactory.getLogger(CreditServiceImpl.class);

    @Value("${message.exchanges.credits}")
    protected String creditExchange;

    @Value("${message.routingKeys.creditsBatch}")
    private String creditBatchRoutingKey;

    @Value("${message.routingKeys.sharedCredits}")
    private String sharedCreditRoutingKey;

    @Value("${message.routingKeys.sharedCreditsBatch}")
    private String sharedCreditBatchRoutingKey;

    private RabbitMQService rabbit;

    @Autowired
    public CreditServiceImpl(final RabbitMQService rabbit) {
        this.rabbit = rabbit;
    }

    @Override
    public void createCredits(final BatchCreation<CreditRequest> creditsBatch) {
        final List<CreditRequest> sharedCredits = extractSharedCredits(creditsBatch.getObjects());
        List<CreditRequest> credits = new ArrayList<>(creditsBatch.getObjects());
        credits.removeAll(sharedCredits);

        if(!CollectionUtils.isEmpty(credits)) {
            final int batchSize = credits.size();
            logger.info("Starting creation of '{}' credits", batchSize);
            final MessageDto dto = MessageDto
                    .builder()
                    .withObjects(MessageHelper.convertToCreditMessage(credits, false))
                    .withProperties(creditsBatch.getProperties())
                    .withExchange(this.creditExchange)
                    .withNormalRoutingKey(Strings.EMPTY)
                    .withBatchRoutingKey(this.creditBatchRoutingKey)
                    .withIsDeleted(Boolean.FALSE)
                    .build();
            rabbit.sendBatchMessages(dto);
            logger.info("Finishing creation of '{}' credits", batchSize);
        }

        if(!CollectionUtils.isEmpty(sharedCredits)) {
            final int batchSize = sharedCredits.size();
            logger.info("Starting creation of '{}' shared credits", batchSize);
            final MessageDto dto = MessageDto
                    .builder()
                    .withObjects(MessageHelper.convertToCreditMessage(sharedCredits, true))
                    .withProperties(creditsBatch.getProperties())
                    .withExchange(this.creditExchange)
                    .withNormalRoutingKey(this.sharedCreditRoutingKey)
                    .withBatchRoutingKey(this.sharedCreditBatchRoutingKey)
                    .withIsDeleted(Boolean.FALSE)
                    .build();
            rabbit.sendBatchMessages(dto);
            logger.info("Finishing creation of '{}' shared credits", batchSize);
        }
    }

    List<CreditRequest> extractSharedCredits(final List<CreditRequest> list){
        return list == null ? Collections.emptyList() : list.stream().filter(c -> c.getAccountId() != null && c.getAccountId().size() > 1).collect(Collectors.toList());
    }
}
