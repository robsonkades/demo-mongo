package com.abinbev.b2b.credit.relay.helper;

import java.util.Arrays;

public abstract class UrlHelper {
    private UrlHelper() {
    }

    protected static final String[] TRUSTED_URLS = { "/swagger-ui.html", "/webjars", "/webjars/**", "/v2/api-docs", "/swagger-resource", "/swagger-resource/**", "/swagger-resources/**", "/actuator/health",
            "/actuator/info", "/csrf" };

    public static boolean isTrustedUrl(final String urlPath) {
        return Arrays
                .asList(TRUSTED_URLS)
                .stream()
                .anyMatch(urlPath::startsWith);
    }
}
