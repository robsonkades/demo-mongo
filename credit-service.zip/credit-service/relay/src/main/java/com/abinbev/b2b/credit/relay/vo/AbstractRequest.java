package com.abinbev.b2b.credit.relay.vo;

import java.util.Set;

import javax.validation.ConstraintViolation;

import com.fasterxml.jackson.annotation.JsonIgnore;

public abstract class AbstractRequest {

    @JsonIgnore
    private Long updatedAt;

    @JsonIgnore
    private transient boolean hasError;

    @JsonIgnore
    private transient Set<ConstraintViolation<AbstractRequest>> constraintViolations;

    public Long getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(final Long updatedAt) {
        this.updatedAt = updatedAt;
    }

    public boolean hasError() {
        return hasError;
    }

    public void setHasError(final boolean hasError) {
        this.hasError = hasError;
    }

    public Set<ConstraintViolation<AbstractRequest>> getConstraintViolations() {
        return constraintViolations;
    }

    public void setConstraintViolations(final Set<ConstraintViolation<AbstractRequest>> constraintViolations) {
        this.constraintViolations = constraintViolations;
    }
}
