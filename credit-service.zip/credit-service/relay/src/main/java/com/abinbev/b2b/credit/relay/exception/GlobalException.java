package com.abinbev.b2b.credit.relay.exception;

import java.util.Collections;
import java.util.List;

import org.springframework.http.HttpStatus;

public class GlobalException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    private final HttpStatus httpStatus;

    private final List<Issue> issues;

    protected GlobalException(final Issue issue, final HttpStatus httpStatus) {
        super(issue.getMessage());
        this.issues = Collections.singletonList(issue);
        this.httpStatus = httpStatus;
    }

    protected GlobalException(final Issue issue, final HttpStatus httpStatus, final Throwable cause) {
        super(issue.getMessage(), cause);
        this.issues = Collections.singletonList(issue);
        this.httpStatus = httpStatus;
    }

    protected GlobalException(final String message, final List<Issue> issues, final HttpStatus httpStatus) {
        super(message);
        this.issues = issues;
        this.httpStatus = httpStatus;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public List<Issue> getIssues() {
        return issues;
    }
}
