package com.abinbev.b2b.credit.relay.controller;

import static com.abinbev.b2b.credit.relay.domain.BatchCreation.builder;
import static com.abinbev.b2b.credit.relay.helper.BatchHelper.handleAndValidateBatchCreationRequest;
import static com.abinbev.b2b.credit.relay.helper.constants.Constants.COUNTRY_HEADER;
import static javax.servlet.http.HttpServletResponse.SC_BAD_REQUEST;
import static javax.servlet.http.HttpServletResponse.SC_SERVICE_UNAVAILABLE;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.abinbev.b2b.credit.relay.exception.GlobalExceptionHandler.MessageResponse;
import com.abinbev.b2b.credit.relay.helper.ControllerValidationHelper;
import com.abinbev.b2b.credit.relay.helper.JwtVendorHelper;
import com.abinbev.b2b.credit.relay.interceptor.annotation.RequestTraceIdValidation;
import com.abinbev.b2b.credit.relay.service.CreditService;
import com.abinbev.b2b.credit.relay.vo.CreditRequest;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestTraceIdValidation
@Api(tags = "Credit")
public class CreditController {

    private static final Logger logger = LoggerFactory.getLogger(CreditController.class);

    private final CreditService service;

    private final ControllerValidationHelper validationHelper;

    private final JwtVendorHelper jwtVendorHelper;

    @Autowired
    public CreditController(final CreditService service, final ControllerValidationHelper validationHelper, final JwtVendorHelper jwtVendorHelper) {
        this.service = service;
        this.validationHelper = validationHelper;
        this.jwtVendorHelper = jwtVendorHelper;
    }

    @ApiOperation(value = "Credits Creation", notes = "Creates or updates the credit information for accounts.")
    @ApiImplicitParam(name = HttpHeaders.CONTENT_ENCODING, dataType = "string", paramType = "header", value = "its value indicates which encodings were applied to the entity-body(<b>Accepted: gzip</b>)")
    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
    @ApiResponses(value = { @ApiResponse(code = SC_BAD_REQUEST, response = MessageResponse.class, message = "The credit request is invalid"),
            @ApiResponse(code = SC_SERVICE_UNAVAILABLE, response = MessageResponse.class, message = "Service Unavailable. This error can be a result of queue infrastructure not available. In this case, nothing will be processed.") })
    @ResponseStatus(HttpStatus.ACCEPTED)
    public ResponseEntity<Void> createCredits(@ApiParam(value = "Country/region. ISO 3166 alpha-2 country code", required = true) @RequestHeader(value = COUNTRY_HEADER) final String country,
                                              @RequestBody final List<CreditRequest> credits) {
        logger.info("Creating {} credits", credits.size());
        validationHelper.validateCountry(country);
        validationHelper.validateIfCountryIsSupported(country);
        jwtVendorHelper.validateAndFillVendorId(country, credits);
        handleAndValidateBatchCreationRequest(credits);
        service.createCredits(builder(credits).build());
        logger.info("Credits created");
        return ResponseEntity
                .status(HttpStatus.ACCEPTED)
                .build();
    }
}
