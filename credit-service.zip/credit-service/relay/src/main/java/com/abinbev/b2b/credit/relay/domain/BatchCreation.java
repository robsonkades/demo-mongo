package com.abinbev.b2b.credit.relay.domain;

import static com.abinbev.b2b.credit.relay.helper.constants.Constants.COUNTRY_HEADER;
import static com.abinbev.b2b.credit.relay.helper.constants.Constants.REQUEST_TRACE_ID_HEADER;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.slf4j.MDC;

import com.abinbev.b2b.credit.relay.helper.BatchHelper;
import com.abinbev.b2b.credit.relay.vo.AbstractRequest;

public class BatchCreation<T extends AbstractRequest> {

    private List<T> objects;

    private BatchOperationProperties properties;

    public BatchCreation(final List<T> objects, final BatchOperationProperties properties) {
        this.objects = objects;
        this.properties = properties;
    }

    public List<T> getObjects() {
        return objects;
    }

    public BatchOperationProperties getProperties() {
        return properties;
    }

    public static BatchCreationBuilder builder(final List<? extends AbstractRequest> objects) {
        return new BatchCreationBuilder(objects);
    }

    public static BatchCreationBuilder builder(final Set<? extends AbstractRequest> objects) {
        return new BatchCreationBuilder(objects
                                                .stream()
                                                .collect(Collectors.toList()));
    }

    public static class BatchCreationBuilder {
        final List<? extends AbstractRequest> objects;

        private BatchCreationBuilder(final List<? extends AbstractRequest> objects) {
            this.objects = objects;
        }

        public BatchCreation build() {
            BatchHelper.defineTimestampForBatchRequest(objects);
            final BatchOperationProperties properties = new BatchOperationProperties();
            properties.setRequestTraceId(MDC.get(REQUEST_TRACE_ID_HEADER));
            properties.setCountry(MDC.get(COUNTRY_HEADER));
            return new BatchCreation(objects, properties);
        }
    }
}
