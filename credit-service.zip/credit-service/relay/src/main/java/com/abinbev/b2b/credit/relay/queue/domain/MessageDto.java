package com.abinbev.b2b.credit.relay.queue.domain;

import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;

import com.abinbev.b2b.credit.relay.domain.BatchOperationProperties;

public class MessageDto {

    private List<BaseCreditMessage> objects;

    private BatchOperationProperties properties;

    private String exchange;

    private String normalRoutingKey;

    private String batchRoutingKey;

    private Boolean isDeleted;

    private MessageDto() {
        super();
    }

    public List<BaseCreditMessage> getObjects() {
        return objects;
    }

    public BatchOperationProperties getProperties() {
        return properties;
    }

    public String getExchange() {
        return exchange;
    }

    public String getNormalRoutingKey() {
        return normalRoutingKey;
    }

    public String getBatchRoutingKey() {
        return batchRoutingKey;
    }

    public Boolean getDeleted() {
        return isDeleted;
    }

    public static MessageDtoBuilder builder(){
        return new MessageDtoBuilder();
    }

    public static class MessageDtoBuilder {
        private MessageDto instance = new MessageDto();

        public MessageDtoBuilder withObjects(final List<BaseCreditMessage> objects){
            this.instance.objects = objects;
            return this;
        }

        public MessageDtoBuilder withProperties(final BatchOperationProperties properties){
            this.instance.properties = properties;
            return this;
        }

        public MessageDtoBuilder withExchange(final String exchange){
            this.instance.exchange = exchange;
            return this;
        }

        public MessageDtoBuilder withNormalRoutingKey(final String normalRoutingKey){
            this.instance.normalRoutingKey = normalRoutingKey;
            return this;
        }

        public MessageDtoBuilder withBatchRoutingKey(final String batchRoutingKey){
            this.instance.batchRoutingKey = batchRoutingKey;
            return this;
        }

        public MessageDtoBuilder withIsDeleted(final Boolean isDeleted){
            this.instance.isDeleted = isDeleted;
            return this;
        }

        public MessageDto build() {
            return this.instance;
        }
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o)
            return true;

        if (o == null || getClass() != o.getClass())
            return false;

        final MessageDto dto = (MessageDto) o;

        return new EqualsBuilder()
                .append(objects, dto.objects)
                .append(properties, dto.properties)
                .append(exchange, dto.exchange)
                .append(normalRoutingKey, dto.normalRoutingKey)
                .append(batchRoutingKey, dto.batchRoutingKey)
                .append(isDeleted, dto.isDeleted)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(objects)
                .append(properties)
                .append(exchange)
                .append(normalRoutingKey)
                .append(batchRoutingKey)
                .append(isDeleted)
                .toHashCode();
    }
}
