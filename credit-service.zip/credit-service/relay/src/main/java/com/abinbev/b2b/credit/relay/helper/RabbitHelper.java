package com.abinbev.b2b.credit.relay.helper;

import org.apache.commons.lang3.StringUtils;

public class RabbitHelper {

    private static final String DEAD_LETTER = "dlq";

    private static final String TEXT_QUEUE_FORMAT = "%s-%s";

    private RabbitHelper() {
    }

    public static String buildQueueName(final String country, final String queueSuffixName) {
        return String.format(TEXT_QUEUE_FORMAT, country.toLowerCase(), queueSuffixName);
    }

    public static String buildRoutingKey(final String country) {
        return country.toLowerCase();
    }

    public static String buildRoutingKey(final String country, final String routingKeySuffixName) {
        if (StringUtils.isEmpty(routingKeySuffixName)) {
            return buildRoutingKey(country);
        }
        return String.format(TEXT_QUEUE_FORMAT, country.toLowerCase(), routingKeySuffixName);
    }

    public static String buildDeadLetterRoutingKey(final String routingKey) {
        return String.format(TEXT_QUEUE_FORMAT, routingKey.toLowerCase(), DEAD_LETTER);
    }

}
