package com.abinbev.b2b.credit.relay.helper;

import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.abinbev.b2b.credit.relay.config.property.MessageQueueProperties;
import com.abinbev.b2b.credit.relay.exception.BadRequestException;
import com.abinbev.b2b.credit.relay.exception.IssueEnum;
import com.abinbev.b2b.credit.relay.exception.IssueHandler;
import com.google.common.collect.ImmutableSet;

@Component
public class ControllerValidationHelper {

    private static final Set<String> ISO_COUNTRIES = ImmutableSet.copyOf(Locale.getISOCountries());

    private final MessageQueueProperties messageQueueProperties;

    @Autowired
    public ControllerValidationHelper(final MessageQueueProperties messageQueueProperties) {
        this.messageQueueProperties = messageQueueProperties;
    }

    public void validateCountry(final String country) {
        if (StringUtils.isBlank(country) || !ISO_COUNTRIES.contains(country)) {
            throw new BadRequestException(IssueHandler.createIssue(IssueEnum.INVALID_COUNTRY, country));
        }
    }

    public void validateIfCountryIsSupported(final String country) {
        final List<String> supportedCountries = this.messageQueueProperties.getCountries();
        if (!supportedCountries.contains(country.toLowerCase())) {
            throw new BadRequestException(IssueHandler.createIssue(IssueEnum.UNSUPPORTED_COUNTRY, country, supportedCountries
                    .stream()
                    .map(String::toUpperCase)
                    .collect(Collectors.toList())));
        }
    }
}
