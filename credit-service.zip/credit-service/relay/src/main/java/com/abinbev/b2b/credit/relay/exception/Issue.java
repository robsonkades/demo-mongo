package com.abinbev.b2b.credit.relay.exception;

import java.io.Serializable;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class Issue implements Serializable {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty(notes = "${resources.errorResponse.issue.code}", dataType = "java.lang.String", example = "\"credit-relay-service.required-field\"")
    @JsonProperty
    private final String code;

    @ApiModelProperty(position = 1, notes = "${resources.errorResponse.issue.message}", dataType = "java.lang.String", example = "\"The field value is required\"")
    @JsonProperty
    private final String message;

    @ApiModelProperty(position = 2, notes = "${resources.errorResponse.issue.attribute}", dataType = "java.lang.String", example = "\"firstName\"")
    @JsonProperty
    @JsonInclude(Include.NON_NULL)
    private String attribute;

    public Issue(final String code, final String message) {
        this.code = code;
        this.message = message;
    }

    public Issue(final String code, final String message, final String attribute) {
        this(code, message);
        this.attribute = attribute;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public String getAttribute() {
        return attribute;
    }

    public void setAttribute(final String attribute) {
        this.attribute = attribute;
    }

    @Override
    public String toString() {
        return new ReflectionToStringBuilder(this, ToStringStyle.JSON_STYLE).toString();
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final Issue issue = (Issue) o;

        return new EqualsBuilder()
                .append(code, issue.code)
                .append(message, issue.message)
                .append(attribute, issue.attribute)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
                .append(code)
                .append(message)
                .append(attribute)
                .toHashCode();
    }
}
