package com.abinbev.b2b.credit.relay.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "batch")
public class BatchConfiguration {
    private static final int DEFAULT_CHUNK_SIZE = 100;

    private static final boolean DEFAULT_CHUNK_ENABLED = true;

    private Integer maxPayloadSize;

    private Integer maxDeletePayloadSize;

    private Publisher publisher;

    public int findPublisherChunkSize() {
        return this.publisher != null && this.publisher.chunkSize != null ? this.publisher.chunkSize : DEFAULT_CHUNK_SIZE;
    }

    public boolean isPublisherChunkEnabled() {
        return this.publisher != null ? this.publisher.chunkEnabled : DEFAULT_CHUNK_ENABLED;
    }

    public Integer getMaxPayloadSize() {
        return maxPayloadSize;
    }

    public void setMaxPayloadSize(final Integer maxPayloadSize) {
        this.maxPayloadSize = maxPayloadSize;
    }

    public Integer getMaxDeletePayloadSize() {
        return maxDeletePayloadSize;
    }

    public void setMaxDeletePayloadSize(final Integer maxDeletePayloadSize) {
        this.maxDeletePayloadSize = maxDeletePayloadSize;
    }

    public Publisher getPublisher() {
        return publisher;
    }

    public void setPublisher(final Publisher publisher) {
        this.publisher = publisher;
    }

    public static class Publisher {

        private Boolean chunkEnabled;

        private Integer chunkSize;

        public Boolean getChunkEnabled() {
            return chunkEnabled;
        }

        public void setChunkEnabled(final Boolean chunkEnabled) {
            this.chunkEnabled = chunkEnabled;
        }

        public Integer getChunkSize() {
            return chunkSize;
        }

        public void setChunkSize(final Integer chunkSize) {
            this.chunkSize = chunkSize;
        }
    }
}
