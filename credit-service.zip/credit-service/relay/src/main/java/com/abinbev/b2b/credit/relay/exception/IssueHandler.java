package com.abinbev.b2b.credit.relay.exception;

public class IssueHandler {
    private IssueHandler() {
        throw new IllegalStateException("Utility class");
    }

    public static Issue createIssue(final IssueEnum issueEnum, final Object... args) {
        return new Issue(issueEnum.getCode(), issueEnum.getFormattedMessage(args), issueEnum.getAttribute());
    }

    public static Issue createIssue(final Exception ex) {
        return new Issue(IssueEnum.GENERIC_EXCEPTION.getCode(), ex.getLocalizedMessage());
    }
}
