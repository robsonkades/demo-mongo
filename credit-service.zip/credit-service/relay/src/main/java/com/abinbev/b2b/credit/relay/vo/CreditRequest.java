package com.abinbev.b2b.credit.relay.vo;

import java.math.BigDecimal;
import java.util.List;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.util.CollectionUtils;

import com.abinbev.b2b.credit.relay.exception.BadRequestException;
import com.abinbev.b2b.credit.relay.exception.IssueEnum;
import com.abinbev.b2b.credit.relay.exception.IssueHandler;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class CreditRequest extends AbstractRequest {

    @JsonProperty
    @Digits(integer = 30, fraction = 8)
    @ApiModelProperty("The credit that the customer used and thus owes ABI following his/her payment term.")
    protected BigDecimal balance;

    @JsonProperty
    @Digits(integer = 30, fraction = 8)
    @ApiModelProperty("The sum total of credits (overdue or not) of the account. Credits can be used to make purchases without to paying the invoice when the order is delivered.")
    protected BigDecimal total;

    @JsonProperty
    @Digits(integer = 30, fraction = 8)
    @ApiModelProperty("The amount of available credit left to place orders.")
    protected BigDecimal available;

    @JsonProperty
    @Digits(integer = 30, fraction = 8)
    @ApiModelProperty("The credit that the customer used but past due.")
    protected BigDecimal overdue;

    @JsonProperty
    @Size(max = 255)
    @ApiModelProperty("The method of how POCs pay ABI.")
    protected String paymentTerms;

    @JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY)
    @NotNull
    @Size(min = 1)
    @JsonProperty
    @ApiModelProperty(value = "The POC account identifier(s) as string or a list.", example = "accountId-001")
    private List<@NotBlank String> accountId;

    @JsonProperty
    @ApiModelProperty(hidden = true)
    private String vendorAccountId;

    @JsonProperty
    @ApiModelProperty(hidden = true)
    private String vendorId;

    @JsonProperty
    @Digits(integer = 30, fraction = 8)
    @Min(0)
    @ApiModelProperty("Credit consumed on B2B Platform before last credit update.")
    private BigDecimal consumption;

    public CreditRequest() {
        super();
    }

    @JsonCreator
    public CreditRequest(@JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY) @JsonProperty("vendorAccountId") final List<String> vendorAccountId,
                         @JsonFormat(with = JsonFormat.Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY) @JsonProperty("accountId") final List<String> accountId) {
        if (!CollectionUtils.isEmpty(vendorAccountId) && !CollectionUtils.isEmpty(accountId)) {
            throw new BadRequestException(IssueHandler.createIssue(IssueEnum.DUPLICATED_ACCOUNT_ID_VENDOR_ACCOUNT_ID_FIELDS));
        }
        if (!CollectionUtils.isEmpty(vendorAccountId)) {
            this.accountId = vendorAccountId;
        } else {
            this.accountId = accountId;
        }
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(final BigDecimal balance) {
        this.balance = balance;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(final BigDecimal total) {
        this.total = total;
    }

    public BigDecimal getAvailable() {
        return available;
    }

    public void setAvailable(final BigDecimal available) {
        this.available = available;
    }

    public BigDecimal getOverdue() {
        return overdue;
    }

    public void setOverdue(final BigDecimal overdue) {
        this.overdue = overdue;
    }

    public String getPaymentTerms() {
        return paymentTerms;
    }

    public void setPaymentTerms(final String paymentTerms) {
        this.paymentTerms = paymentTerms;
    }

    public List<String> getAccountId() {
        return accountId;
    }

    public void setAccountId(final List<String> accountId) {
        this.accountId = accountId;
    }

    public BigDecimal getConsumption() {
        return consumption;
    }

    public void setConsumption(final BigDecimal consumption) {
        this.consumption = consumption;
    }

    public String getVendorId() {
        return vendorId;
    }

    public void setVendorId(final String vendorId) {
        this.vendorId = vendorId;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final var creditRequest = (CreditRequest) o;

        return new EqualsBuilder()
                .append(balance, creditRequest.balance)
                .append(total, creditRequest.total)
                .append(available, creditRequest.available)
                .append(overdue, creditRequest.overdue)
                .append(paymentTerms, creditRequest.paymentTerms)
                .append(accountId, creditRequest.accountId)
                .append(vendorId, creditRequest.vendorId)
                .append(consumption, creditRequest.consumption)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
                .append(balance)
                .append(total)
                .append(available)
                .append(overdue)
                .append(paymentTerms)
                .append(accountId)
                .append(vendorId)
                .append(consumption)
                .toHashCode();
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}
