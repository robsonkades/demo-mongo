package com.abinbev.b2b.credit.relay.helper;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import com.abinbev.b2b.credit.relay.queue.domain.BaseCreditMessage;
import com.abinbev.b2b.credit.relay.queue.domain.CreditMessage;
import com.abinbev.b2b.credit.relay.queue.domain.SharedCreditMessage;
import com.abinbev.b2b.credit.relay.vo.CreditRequest;
import com.google.common.collect.ImmutableSet;

public final class MessageHelper {

    private MessageHelper() {
        super();
    }

    public static List<BaseCreditMessage> convertToCreditMessage(final List<CreditRequest> list, final boolean isSharedCredit){
        if(list == null){
            return Collections.emptyList();
        }
        return list
                .stream()
                .map(c -> {
                    final BaseCreditMessage message;
                    if(isSharedCredit){
                        message = new SharedCreditMessage();
                        ((SharedCreditMessage)message).setAccountId(ImmutableSet.copyOf(c.getAccountId()));
                    } else {
                        message = new CreditMessage();
                        ((CreditMessage) message).setAccountId(c.getAccountId() == null ? null : c.getAccountId().get(0));
                    }

                    message.setAvailable(c.getAvailable());
                    message.setBalance(c.getBalance());
                    message.setConsumption(c.getConsumption());
                    message.setOverdue(c.getOverdue());
                    message.setPaymentTerms(c.getPaymentTerms());
                    message.setTotal(c.getTotal());
                    message.setVendorId(c.getVendorId());
                    message.setUpdatedAt(c.getUpdatedAt());
                    message.setHasError(c.hasError());
                    message.setConstraintViolations(c.getConstraintViolations());
                    return message;
                })
                .collect(Collectors.toList());
    }
}
