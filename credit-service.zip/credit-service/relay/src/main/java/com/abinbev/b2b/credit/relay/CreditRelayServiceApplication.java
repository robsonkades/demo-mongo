package com.abinbev.b2b.credit.relay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CreditRelayServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CreditRelayServiceApplication.class, args);
	}

}
