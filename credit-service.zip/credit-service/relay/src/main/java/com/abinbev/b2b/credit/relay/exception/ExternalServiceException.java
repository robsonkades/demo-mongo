package com.abinbev.b2b.credit.relay.exception;

public class ExternalServiceException extends RuntimeException {
    public ExternalServiceException(final String message) {
        super(message);
    }

    public ExternalServiceException(final String message, final Exception ex) {
        super(message, ex);
    }

    public static ExternalServiceException errorCallingExternalService(final Exception ex) {
        return new ExternalServiceException("Error calling external service", ex);
    }

    public static ExternalServiceException rabbitConnectionError(final Exception ex) {
        return new ExternalServiceException("Error sending message. Please contact an administrator", ex);
    }

    public static ExternalServiceException errorOnReturnValidation() {
        return new ExternalServiceException("An error occurred in backend integration.");
    }
}
