package com.abinbev.b2b.credit.relay.config;

import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.abinbev.b2b.common.toggle.core.toggler.ABIToggler;
import com.abinbev.b2b.credit.relay.helper.constants.Constants;

@Profile("!e2e")
@Component
public class AbiToggleConfigImpl implements AbiToggleConfig {

    private static final Logger logger = LoggerFactory.getLogger(AbiToggleConfigImpl.class);

    @Value("${abi.toggle.vendorIdJwtValidationEnabled}")
    private String enabledVendorIdJwtValidationPerCountry;

    @Autowired
    private ABIToggler toggler;

    @Override
    public boolean isEnabledVendorIdJwtValidationPerCountry(final String country) {

        final Map<String, Object> attributes = Map.of(Constants.COUNTRY_HEADER, country);
        final var featureEnabled = toggler.isFeatureEnabled(enabledVendorIdJwtValidationPerCountry, UUID.randomUUID().toString(), attributes);

        logger.info("Feature toggle '{}' has value '{}' for country '{}' by Optimizely.", enabledVendorIdJwtValidationPerCountry, featureEnabled, country);

        return featureEnabled;
    }
}
