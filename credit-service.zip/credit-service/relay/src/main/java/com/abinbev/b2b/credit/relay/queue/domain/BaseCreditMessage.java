package com.abinbev.b2b.credit.relay.queue.domain;

import java.math.BigDecimal;

import com.abinbev.b2b.credit.relay.vo.AbstractRequest;

public abstract class BaseCreditMessage extends AbstractRequest {

    private BigDecimal balance;

    private BigDecimal total;

    private BigDecimal available;

    private BigDecimal overdue;

    private String paymentTerms;

    private BigDecimal consumption;

    private String vendorId;

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(final BigDecimal balance) {
        this.balance = balance;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(final BigDecimal total) {
        this.total = total;
    }

    public BigDecimal getAvailable() {
        return available;
    }

    public void setAvailable(final BigDecimal available) {
        this.available = available;
    }

    public BigDecimal getOverdue() {
        return overdue;
    }

    public void setOverdue(final BigDecimal overdue) {
        this.overdue = overdue;
    }

    public String getPaymentTerms() {
        return paymentTerms;
    }

    public void setPaymentTerms(final String paymentTerms) {
        this.paymentTerms = paymentTerms;
    }

    public BigDecimal getConsumption() {
        return consumption;
    }

    public void setConsumption(final BigDecimal consumption) {
        this.consumption = consumption;
    }

    public String getVendorId() {
        return vendorId;
    }

    public void setVendorId(final String vendorId) {
        this.vendorId = vendorId;
    }

}
