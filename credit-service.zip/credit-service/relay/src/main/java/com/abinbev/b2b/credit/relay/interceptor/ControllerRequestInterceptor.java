package com.abinbev.b2b.credit.relay.interceptor;

import java.lang.reflect.Method;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.abinbev.b2b.credit.relay.helper.UrlHelper;
import com.abinbev.b2b.credit.relay.helper.constants.Constants;
import com.abinbev.b2b.credit.relay.interceptor.annotation.RequestTraceIdValidation;

@Component
public class ControllerRequestInterceptor extends HandlerInterceptorAdapter {

    @Override
    public boolean preHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler) throws Exception {
        if (!UrlHelper.isTrustedUrl(request.getRequestURI())) {
            final String country = request.getHeader(Constants.COUNTRY_HEADER);
            MDC.put(Constants.COUNTRY_HEADER, country);

            if (shouldValidateRequestTraceIdHeader(handler)) {
                final String requestTraceId = getRequestTraceId(request);
                MDC.put(Constants.REQUEST_TRACE_ID_HEADER, requestTraceId);
            }
        }
        return true;
    }

    @Override
    public void afterCompletion(final HttpServletRequest request, final HttpServletResponse response, final Object handler, final Exception ex) throws Exception {
        MDC.clear();
    }

    /**
     * Validate if the class or method of the HandlerMethod bean instance are
     * annotated with {@link RequestTraceIdValidation}
     *
     * @param object The HandlerMethod instance
     * @return TRUE if the class or method are annotated with
     * {@link RequestTraceIdValidation}, otherwise FALSE:
     */
    private boolean shouldValidateRequestTraceIdHeader(final Object object) {
        if (object instanceof HandlerMethod) {
            final HandlerMethod handler = (HandlerMethod) object;
            final Class<? extends Object> beanClass = handler
                    .getBean()
                    .getClass();
            final Method beanMethod = handler.getMethod();

            final boolean isPresentInClass = beanClass != null && beanClass.isAnnotationPresent(RequestTraceIdValidation.class);
            final boolean isPresentInMethod = beanMethod != null && beanMethod.isAnnotationPresent(RequestTraceIdValidation.class);

            return isPresentInClass || isPresentInMethod;
        }
        return false;
    }

    private String getRequestTraceId(HttpServletRequest request) {
        final String requestTraceId = request.getHeader(Constants.REQUEST_TRACE_ID_HEADER);
        if (StringUtils.isBlank(requestTraceId)) {
            return UUID
                    .randomUUID()
                    .toString();
        }
        return requestTraceId;
    }
}
