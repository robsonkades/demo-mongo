package com.abinbev.b2b.credit.relay.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "features.jwtvalidation")
public class JwtValidationConfiguration {

    private String vendorIdClaim;

    public String getVendorIdClaim() {
        return vendorIdClaim;
    }

    public void setVendorIdClaim(final String vendorIdClaim) {
        this.vendorIdClaim = vendorIdClaim;
    }

}
