package com.abinbev.b2b.credit.relay.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.abinbev.b2b.credit.relay.interceptor.ControllerRequestInterceptor;
import com.planetj.servlet.filter.compression.CompressingFilter;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    private static final String[] COMPRESS_FILTER_PATHS = { "/" };

    @Autowired
    private ControllerRequestInterceptor controllerRequestInterceptor;

    @Override
    public void addInterceptors(final InterceptorRegistry registry) {
        registry.addInterceptor(controllerRequestInterceptor);
    }

    @Override
    public void addResourceHandlers(final ResourceHandlerRegistry registry) {
        registry
                .addResourceHandler("swagger-ui.html")
                .addResourceLocations("classpath:/META-INF/resources/");

        registry
                .addResourceHandler("/webjars/**")
                .addResourceLocations("classpath:/META-INF/resources/webjars/");
    }

    @Bean
    public FilterRegistrationBean<CompressingFilter> compressingFilter() {
        final FilterRegistrationBean<CompressingFilter> registration = new FilterRegistrationBean<>(new CompressingFilter());
        registration.setName("CompressingFilter");
        registration.setOrder(2);
        registration.addUrlPatterns(COMPRESS_FILTER_PATHS);
        return registration;
    }
}
