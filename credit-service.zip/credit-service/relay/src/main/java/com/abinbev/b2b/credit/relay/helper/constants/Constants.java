package com.abinbev.b2b.credit.relay.helper.constants;

public class Constants {

    public static final String RESOURCE_BUNDLE_FILE_NAME = "messages";

    public static final String COUNTRY_HEADER = "country";

    public static final String REQUEST_TRACE_ID_HEADER = "requestTraceId";

    private Constants() {
    }
}
