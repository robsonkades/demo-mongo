package com.abinbev.b2b.credit.relay.exception;

import org.springframework.http.HttpStatus;

public class BadRequestException extends GlobalException {
    private static final long serialVersionUID = 1L;

    public BadRequestException(final Issue issue) {
        super(issue, HttpStatus.BAD_REQUEST);
    }
}
