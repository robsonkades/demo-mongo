package com.abinbev.b2b.credit.relay.helper;

import java.time.Instant;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

import org.apache.commons.lang3.StringUtils;

public class DateFormatHelper {

    private DateFormatHelper() {
        super();
    }

    public static String toStringISOFromMillis(final Long epochMilli) {
        return epochMilli == null ?
                null :
                OffsetDateTime
                        .ofInstant(Instant.ofEpochMilli(epochMilli), ZoneId.of("Z"))
                        .format(DateTimeFormatter.ISO_DATE_TIME);
    }

    public static Long toTimeMillisWithOffset(final String offsetDateTime) {
        return StringUtils.isNotBlank(offsetDateTime) ?
                OffsetDateTime
                        .parse(offsetDateTime, DateTimeFormatter.ISO_DATE_TIME)
                        .toInstant()
                        .toEpochMilli() :
                null;
    }

}
