package com.abinbev.b2b.credit.relay.helper;

import static com.abinbev.b2b.credit.relay.helper.constants.Constants.COUNTRY_HEADER;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validation;
import javax.validation.Validator;

import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import com.abinbev.b2b.credit.relay.config.BatchConfiguration;
import com.abinbev.b2b.credit.relay.exception.BadRequestException;
import com.abinbev.b2b.credit.relay.exception.IssueEnum;
import com.abinbev.b2b.credit.relay.exception.IssueHandler;
import com.abinbev.b2b.credit.relay.vo.AbstractRequest;

@Component
public class BatchHelper {

    private static final Validator VALIDATOR = Validation
            .buildDefaultValidatorFactory()
            .getValidator();

    private static BatchConfiguration configuration;

    @Autowired
    private BatchConfiguration batchConfiguration;

    private BatchHelper() {
    }

    private static void setConfiguration(final BatchConfiguration batchConfiguration) {
        BatchHelper.configuration = batchConfiguration;
    }

    @PostConstruct
    private void postConstruct() {
        setConfiguration(batchConfiguration);
    }

    public static List<List<? extends AbstractRequest>> divideChunksForValidObjects(final List<? extends AbstractRequest> request) {
        final List<AbstractRequest> validList = extractValidObjects(request);
        final int chunkSize = configuration.findPublisherChunkSize();
        return extractChunks(validList, chunkSize);
    }

    public static List<List<? extends AbstractRequest>> divideChunksForInvalidObjects(final List<? extends AbstractRequest> request) {
        final List<AbstractRequest> invalidList = extractInvalidObjects(request);
        final int chunkSize = configuration.findPublisherChunkSize();
        return extractChunks(invalidList, chunkSize);
    }

    public static List<AbstractRequest> extractValidObjects(final List<? extends AbstractRequest> request) {
        return request
                .stream()
                .filter(ac -> !ac.hasError())
                .collect(Collectors.toList());
    }

    public static List<AbstractRequest> extractInvalidObjects(final List<? extends AbstractRequest> request) {
        return request
                .stream()
                .filter(AbstractRequest::hasError)
                .collect(Collectors.toList());
    }

    private static List<List<? extends AbstractRequest>> extractChunks(final List<AbstractRequest> request, final int chunkSize) {
        final List<List<? extends AbstractRequest>> chunks = new ArrayList<>();
        for (int i = 0; i < request.size(); i += chunkSize) {
            final List<AbstractRequest> chunk = request.subList(i, Math.min(request.size(), i + chunkSize));
            chunks.add(chunk);
        }
        return chunks;
    }

    public static void defineTimestampForBatchRequest(List<? extends AbstractRequest> objects) {
        // all objects must have the same timestamp in batch requests
        final long timestamp = System.currentTimeMillis();
        if (objects != null) {
            objects
                    .parallelStream()
                    .forEach(req -> {
                        if (req != null) {
                            req.setUpdatedAt(timestamp);
                        }
                    });
        }
    }

    public static void handleAndValidateBatchDeletionRequest(final Set<? extends AbstractRequest> request) {
        handleAndValidateBatchRequest(new ArrayList<>(request), true);
    }

    public static void handleAndValidateBatchCreationRequest(final List<? extends AbstractRequest> request) {
        handleAndValidateBatchRequest(request, false);
    }

    public static void handleAndValidateBatchRequest(final List<? extends AbstractRequest> request, boolean isDeletionRequest) {
        final int requestSize = request.size();
        if (isDeletionRequest && requestSize > configuration.getMaxDeletePayloadSize()) {
            throw new BadRequestException(IssueHandler.createIssue(IssueEnum.BATCH_MAX_DELETE_PAYLOAD_SIZE, configuration.getMaxDeletePayloadSize()));
        } else if (requestSize > configuration.getMaxPayloadSize()) {
            throw new BadRequestException(IssueHandler.createIssue(IssueEnum.BATCH_MAX_PAYLOAD_SIZE, configuration.getMaxPayloadSize()));
        }

        final boolean isSingleRequest = requestSize == 1;

        if (isSingleRequest) {
            final Set<ConstraintViolation<AbstractRequest>> constraintViolations = VALIDATOR.validate(request.get(0));
            if (!CollectionUtils.isEmpty(constraintViolations)) {
                throw new ConstraintViolationException(constraintViolations);
            }
        } else {
            final String country = MDC.get(COUNTRY_HEADER);
            request
                    .parallelStream()
                    .forEach(req -> {
                        MDC.put(COUNTRY_HEADER, country);
                        final Set<ConstraintViolation<AbstractRequest>> constraintViolations = VALIDATOR.validate(req);
                        if (!CollectionUtils.isEmpty(constraintViolations)) {
                            req.setHasError(true);
                            req.setConstraintViolations(constraintViolations);
                        }
                    });
        }
    }
}
