package com.abinbev.b2b.credit.relay.helper;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.abinbev.b2b.credit.relay.config.AbiToggleConfig;
import com.abinbev.b2b.credit.relay.exception.IssueEnum;
import com.abinbev.b2b.credit.relay.exception.IssueHandler;
import com.abinbev.b2b.credit.relay.exception.JwtException;
import com.abinbev.b2b.credit.relay.jwt.JwtTokenManager;
import com.abinbev.b2b.credit.relay.vo.CreditRequest;

@Component
public class JwtVendorHelper {

    private static final Logger logger = LoggerFactory.getLogger(JwtVendorHelper.class);

    private final JwtTokenManager jwtTokenManager;

    private final AbiToggleConfig abiToggleConfig;

    @Autowired
    public JwtVendorHelper(final JwtTokenManager jwtTokenManager, final AbiToggleConfig abiToggleConfig) {
        this.jwtTokenManager = jwtTokenManager;
        this.abiToggleConfig = abiToggleConfig;
    }

    public void validateAndFillVendorId(final String country, final List<CreditRequest> credits) {
        if (StringUtils.isNotBlank(jwtTokenManager.getVendorId())) {
            final String vendorId = jwtTokenManager.getVendorId();
            logger.info("Credit(s) will be created with vendorId '{}'", vendorId);
            credits.parallelStream().forEach(creditRequest -> creditRequest.setVendorId(vendorId));
        } else {
            if (abiToggleConfig.isEnabledVendorIdJwtValidationPerCountry(country)) {
                logger.error("Invalid token. The informed token does not contain a vendorId");
                throw new JwtException(IssueHandler.createIssue(IssueEnum.FORBIDDEN));
            }
        }
    }

}