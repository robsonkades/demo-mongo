package com.abinbev.b2b.credit.relay.config;

import java.time.OffsetTime;
import java.util.Arrays;

import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RequestMethod;

import com.abinbev.b2b.credit.relay.helper.constants.Constants;
import com.google.common.collect.ImmutableList;

import io.swagger.annotations.Api;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.ParameterBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.builders.ResponseMessageBuilder;
import springfox.documentation.schema.ModelRef;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Parameter;
import springfox.documentation.service.ResponseMessage;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.UiConfiguration;
import springfox.documentation.swagger.web.UiConfigurationBuilder;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
@PropertySource("classpath:version.properties")
public class SwaggerConfig {

    private static final String HEADER = "header";

    private static final String STRING = "string";

    @Autowired
    private Environment env;

    @Value("${swaggerBaseUrl}")
    private String baseUrl;

    @Value("${resources.headers.requestTraceId.value}")
    private String requestTraceIdDescription;

    @Value("${resources.headers.authorization.value}")
    private String authorizationDescription;

    @Value("${resources.headers.country.value}")
    private String countryDescription;

    @Bean
    public Docket productApi() {
        // parameters
        final Parameter requestTraceId = new ParameterBuilder()
                .order(2)
                .name(Constants.REQUEST_TRACE_ID_HEADER)
                .description(requestTraceIdDescription)
                .modelRef(new ModelRef(STRING))
                .parameterType(HEADER)
                .required(false)
                .build();

        final Parameter headerCountry = new ParameterBuilder()
                .order(3)
                .name(Constants.COUNTRY_HEADER)
                .description(countryDescription)
                .modelRef(new ModelRef(STRING))
                .parameterType(HEADER)
                .required(true)
                .build();

        final Parameter authorization = new ParameterBuilder()
                .order(1)
                .name("Authorization")
                .description(authorizationDescription)
                .modelRef(new ModelRef(STRING))
                .parameterType(HEADER)
                .required(true)
                .build();

        // responses
        final ResponseMessage unauthorizedResponse = new ResponseMessageBuilder()
                .code(HttpStatus.UNAUTHORIZED.value())
                .message("Unauthorized access")
                .build();

        return new Docket(DocumentationType.SWAGGER_2)
                .directModelSubstitute(OffsetTime.class, String.class)
                .apiInfo(metaData())
                .useDefaultResponseMessages(false)
                .host(baseUrl)
                .select()
                .apis(RequestHandlerSelectors.withClassAnnotation(Api.class))
                .build()
                .globalOperationParameters(Arrays.asList(requestTraceId, authorization, headerCountry))
                .globalResponseMessage(RequestMethod.POST, ImmutableList.of(unauthorizedResponse));
    }

    @Bean
    public UiConfiguration uiConfig() {
        return UiConfigurationBuilder
                .builder()
                .displayRequestDuration(true)
                // disabling to avoid error with the micro-service version in
                // the URL. See issue #35886
                .validatorUrl(Strings.EMPTY)
                .build();
    }

    private ApiInfo metaData() {
        return new ApiInfoBuilder()
                .title("AB-InBev Credit Relay Service")
                .description("REST API for AB-InBev Credit Relay Service")
                .version(env.getProperty("API_VERSION"))
                .license("Anheuser-Busch InBev © 2021")
                .build();
    }
}
