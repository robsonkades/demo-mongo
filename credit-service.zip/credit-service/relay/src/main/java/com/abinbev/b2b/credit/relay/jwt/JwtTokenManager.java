package com.abinbev.b2b.credit.relay.jwt;

import org.apache.commons.lang3.StringUtils;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

@Service
public class JwtTokenManager {

    public String getVendorId() {
        final JwtDetails jwtUserDetails = (JwtDetails) SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getDetails();
        if (jwtUserDetails == null || StringUtils.isBlank(jwtUserDetails.getVendorId())) {
            return null;
        }
        return jwtUserDetails.getVendorId();
    }
}