package com.abinbev.b2b.credit.relay.queue.domain;

import java.util.Set;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class SharedCreditMessage extends BaseCreditMessage {

    private Set<String> accountId;

    public Set<String> getAccountId() {
        return accountId;
    }

    public void setAccountId(final Set<String> accountId) {
        this.accountId = accountId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("accountId", accountId)
                .toString();
    }
}
