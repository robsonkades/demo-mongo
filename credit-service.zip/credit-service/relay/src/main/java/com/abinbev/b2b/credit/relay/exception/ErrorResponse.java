package com.abinbev.b2b.credit.relay.exception;

import java.util.List;

import io.swagger.annotations.ApiModelProperty;

public class ErrorResponse {
    @ApiModelProperty(notes = "${resources.errorResponse.message}", dataType = "java.lang.String", example = "\"Invalid field values\"")
    private String message;

    @ApiModelProperty(position = 1, notes = "${resources.errorResponse.details}")
    private List<Issue> details;

    public ErrorResponse(final String message, final List<Issue> details) {
        this.message = message;
        this.details = details;
    }

    public String getMessage() {
        return message;
    }

    public List<Issue> getDetails() {
        return details;
    }
}
