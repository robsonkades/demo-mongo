package com.abinbev.b2b.credit.relay.service;

import com.abinbev.b2b.credit.relay.domain.BatchCreation;
import com.abinbev.b2b.credit.relay.vo.CreditRequest;

public interface CreditService {

    void createCredits(BatchCreation<CreditRequest> creditsBatch);
}
