package com.abinbev.b2b.credit.relay.queue.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;

public class CreditMessage extends BaseCreditMessage {

    private String accountId;

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(final String accountId) {
        this.accountId = accountId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this)
                .append("accountId", accountId)
                .toString();
    }
}
