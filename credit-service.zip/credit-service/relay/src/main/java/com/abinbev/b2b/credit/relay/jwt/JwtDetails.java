package com.abinbev.b2b.credit.relay.jwt;

public class JwtDetails {

    private String vendorId;

    public JwtDetails() {
    }

    public JwtDetails(final String vendorId) {
        this.vendorId = vendorId;
    }

    public String getVendorId() {
        return vendorId;
    }

    public void setVendorId(final String vendorId) {
        this.vendorId = vendorId;
    }

}
