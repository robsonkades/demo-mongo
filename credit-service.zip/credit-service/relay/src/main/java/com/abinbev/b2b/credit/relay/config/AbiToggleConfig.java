package com.abinbev.b2b.credit.relay.config;

public interface AbiToggleConfig {
    boolean isEnabledVendorIdJwtValidationPerCountry(final String country);
}
