package com.abinbev.b2b.credit.relay.exception;

import org.springframework.http.HttpStatus;

public class JwtException extends GlobalException {

    public JwtException(final Issue issue) {
        super(issue, HttpStatus.FORBIDDEN);
    }

}
