package com.abinbev.b2b.credit.relay.queue.service;

import static com.abinbev.b2b.credit.relay.helper.RabbitHelper.buildDeadLetterRoutingKey;
import static com.abinbev.b2b.credit.relay.helper.RabbitHelper.buildRoutingKey;
import static com.abinbev.b2b.credit.relay.helper.constants.Constants.COUNTRY_HEADER;
import static com.abinbev.b2b.credit.relay.helper.constants.Constants.REQUEST_TRACE_ID_HEADER;
import static org.springframework.amqp.rabbit.retry.RepublishMessageRecoverer.X_EXCEPTION_MESSAGE;
import static org.springframework.amqp.rabbit.retry.RepublishMessageRecoverer.X_EXCEPTION_STACKTRACE;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import com.abinbev.b2b.credit.relay.config.BatchConfiguration;
import com.abinbev.b2b.credit.relay.domain.BatchOperationProperties;
import com.abinbev.b2b.credit.relay.exception.ExternalServiceException;
import com.abinbev.b2b.credit.relay.helper.BatchHelper;
import com.abinbev.b2b.credit.relay.queue.domain.BaseCreditMessage;
import com.abinbev.b2b.credit.relay.queue.domain.MessageDto;
import com.abinbev.b2b.credit.relay.queue.domain.QueueEvent;
import com.abinbev.b2b.credit.relay.vo.AbstractRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Service
public class RabbitMQService {
    private static final Logger logger = LoggerFactory.getLogger(RabbitMQService.class);

    @Autowired
    private ObjectMapper mapper;

    @Autowired
    private RabbitTemplate template;

    @Autowired
    private BatchConfiguration batchConfiguration;

    public void sendObjectMessage(final Object object, final String exchange, final Boolean isDeleted, final String routingKey) {
        final QueueEvent event = new QueueEvent(isDeleted, object, MDC.get(COUNTRY_HEADER));
        sendMessage(event, exchange, routingKey);
    }

    public void sendMessage(final AbstractRequest object, final String exchange, final Boolean isDeleted, final String routingKey) {
        final QueueEvent event = new QueueEvent(isDeleted, object, MDC.get(COUNTRY_HEADER));
        sendMessage(event, exchange, routingKey);
    }

    public void sendMessage(final AbstractRequest object, final BatchOperationProperties properties, final String exchange, final String routingKey, final Boolean isDeleted) {
        final QueueEvent event = new QueueEvent(isDeleted, properties.getCountry(), object);
        sendMessage(event, exchange, properties, routingKey);
    }

    public void sendBatchMessages(final MessageDto dto) {
        final List<BaseCreditMessage> objects = dto.getObjects();
        final BatchOperationProperties properties = dto.getProperties();
        final String exchange = dto.getExchange();
        final Boolean isDeleted = dto.getDeleted();

        if (batchConfiguration.isPublisherChunkEnabled()) {
            final List<List<? extends AbstractRequest>> validChunks = BatchHelper.divideChunksForValidObjects(objects);
            final List<List<? extends AbstractRequest>> invalidChunks = BatchHelper.divideChunksForInvalidObjects(objects);

            final String routingKeyParam = buildRoutingKey(properties.getCountry(), dto.getBatchRoutingKey());
            logger.info("Publishing '{}' valid chunks to '{}' exchange and '{}' routing key ", validChunks.size(), exchange, routingKeyParam);
            validChunks
                    .parallelStream()
                    .forEach(obj -> this.sendMessage(obj, properties, exchange, routingKeyParam, isDeleted));
            logger.info("Publication finished of valid chunks to '{}' exchange and '{}' routing key", exchange, routingKeyParam);

            final String deadLetterRoutingKey = buildDeadLetterRoutingKey(routingKeyParam);

            logger.info("Publishing '{}' invalid chunks to '{}' exchange and '{}' routing key", invalidChunks.size(), exchange, deadLetterRoutingKey);
            invalidChunks
                    .parallelStream()
                    .forEach(obj -> this.sendMessageToDeadLetter(obj, properties, exchange, deadLetterRoutingKey, isDeleted));
            logger.info("Publication finished of invalid chunks to '{}' exchange and '{}' routing key", exchange, deadLetterRoutingKey);

        } else {
            final List<AbstractRequest> validObjects = BatchHelper.extractValidObjects(objects);
            final String routingKeyParam = StringUtils.isBlank(dto.getNormalRoutingKey()) ? buildRoutingKey(properties.getCountry()) : buildRoutingKey(properties.getCountry(), dto.getNormalRoutingKey());
            logger.info("Publishing '{}' valid objects to '{}' exchange and '{}' routing key", validObjects.size(), exchange, routingKeyParam);
            validObjects
                    .parallelStream()
                    .forEach(obj -> this.sendMessage(obj, properties, exchange, routingKeyParam, isDeleted));
            logger.info("Publication finished of valid objects to '{}' exchange and '{}' routing key", exchange, routingKeyParam);

            final List<AbstractRequest> invalidObjects = BatchHelper.extractInvalidObjects(objects);
            final String deadLetterRoutingKey = buildDeadLetterRoutingKey(properties.getCountry());
            logger.info("Publishing '{}' invalid objects to '{}' exchange and '{}' routing key", invalidObjects.size(), exchange, deadLetterRoutingKey);
            invalidObjects
                    .parallelStream()
                    .forEach(obj -> this.sendMessageToDeadLetter(obj, properties, exchange, isDeleted, deadLetterRoutingKey));
            logger.info("Publication finished of invalid objects to '{}' exchange and '{}' routing key", exchange, deadLetterRoutingKey);
        }
    }

    public void sendMessage(final List<? extends AbstractRequest> object, final BatchOperationProperties properties, final String exchange, final String routingKey, final Boolean isDeleted) {
        final List<QueueEvent> event = new ArrayList<>();
        for (final AbstractRequest obj : object) {
            event.add(new QueueEvent(isDeleted, properties.getCountry(), obj));
        }
        sendMessage(event, exchange, properties, routingKey);
    }

    public void sendMessageToDeadLetter(final AbstractRequest object, final BatchOperationProperties properties, final String exchange, final Boolean isDeleted, final String deadLetterRoutingKey) {
        final QueueEvent event = new QueueEvent(isDeleted, properties.getCountry(), object);
        sendMessageErrorMessage(event, exchange, properties, deadLetterRoutingKey, new ConstraintViolationException(object.getConstraintViolations()));
    }

    public void sendMessageToDeadLetter(final List<? extends AbstractRequest> object, final BatchOperationProperties properties, final String exchange, final String routingKey, final Boolean isDeleted) {
        final List<QueueEvent> event = new ArrayList<>();
        final Set<ConstraintViolation<AbstractRequest>> allViolations = new HashSet<>();
        for (final AbstractRequest obj : object) {
            event.add(new QueueEvent(isDeleted, properties.getCountry(), obj));
            if (obj.hasError()) {
                allViolations.addAll(obj.getConstraintViolations());
            }
        }
        sendMessageErrorMessage(event, exchange, properties, routingKey, new ConstraintViolationException(allViolations));
    }

    private void sendMessage(final Object message, final String exchange, final String routingKey) {
        final MessageProperties messageProperties = new MessageProperties();
        messageProperties.setHeader(COUNTRY_HEADER, MDC.get(COUNTRY_HEADER));
        messageProperties.setHeader(REQUEST_TRACE_ID_HEADER, MDC.get(REQUEST_TRACE_ID_HEADER));
        sendMessage(message, exchange, messageProperties, routingKey);
    }

    private void sendMessage(final Object message, final String exchange, final BatchOperationProperties properties, final String routingKey) {
        final MessageProperties messageProperties = new MessageProperties();
        messageProperties.setHeader(COUNTRY_HEADER, properties.getCountry());
        messageProperties.setHeader(REQUEST_TRACE_ID_HEADER, properties.getRequestTraceId());
        sendMessage(message, exchange, messageProperties, routingKey);
    }

    private void sendMessageErrorMessage(final Object message, final String exchange, final BatchOperationProperties properties, final String routingKey, final Exception exception) {
        final MessageProperties messageProperties = new MessageProperties();
        messageProperties.setHeader(COUNTRY_HEADER, properties.getCountry());
        messageProperties.setHeader(REQUEST_TRACE_ID_HEADER, properties.getRequestTraceId());
        messageProperties.setHeader(X_EXCEPTION_STACKTRACE, exception);
        messageProperties.setHeader(X_EXCEPTION_MESSAGE, exception.getMessage());
        sendMessage(message, exchange, messageProperties, routingKey);
    }

    private void sendMessage(final Object message, final String exchange, final MessageProperties messageProperties, final String routingKey) {
        try {
            messageProperties.setContentType(MediaType.APPLICATION_JSON_VALUE);
            template.convertAndSend(exchange, routingKey != null ? routingKey : messageProperties.getReceivedRoutingKey(), new Message(this.mapper.writeValueAsBytes(message), messageProperties));
        } catch (final JsonProcessingException e) {
            logger.error("Error sending message: {}", message, e);
            throw ExternalServiceException.rabbitConnectionError(e);
        }
    }

}
