**Required**
- [ ] Jira updated to Ready for Code Review
- [ ] The commit and PR title both have the Jira Issue. Example: _[BEESCOS-150] Doing something_
- [ ] Sonar has no issues or explaining why Sonar has an issue.
- [ ] Build checker green
- [ ] PR rebase with master
- [ ] Test evidences on DEV environment attached

**Optional**
- [ ] Application properties created/updated for ALL environments
- [ ] Helm validation ran and attached
- [ ] Configuration pull requests created
    - [ ] DEV configuration
    - [ ] SIT configuration
    - [ ] UAT configuration
    - [ ] PROD configuration
- [ ] If this is a bug fix, unit and/or E2E tests with bug scenario(s) was(were) created