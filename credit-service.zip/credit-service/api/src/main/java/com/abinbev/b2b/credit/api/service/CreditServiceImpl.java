package com.abinbev.b2b.credit.api.service;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpStatusCodeException;

import com.abinbev.b2b.credit.api.config.CreditConsumptionFeatureProperties;
import com.abinbev.b2b.credit.api.helper.constant.ApiConstants;
import com.abinbev.b2b.credit.api.remote.client.AccountClient;
import com.abinbev.b2b.credit.utilities.domain.Credit;
import com.abinbev.b2b.credit.utilities.exception.IssueEnum;
import com.abinbev.b2b.credit.utilities.exception.IssueHandler;
import com.abinbev.b2b.credit.utilities.exception.NotFoundException;
import com.abinbev.b2b.credit.utilities.exception.RemoteServiceErrorException;
import com.abinbev.b2b.credit.utilities.repository.CreditDao;
import com.abinbev.b2b.credit.utilities.vo.CreditConsumptionRequest;

@Service
public class CreditServiceImpl implements CreditService {

    private static final Logger logger = LoggerFactory.getLogger(CreditServiceImpl.class);

    private final CreditDao dao;

    private final CreditConsumptionFeatureProperties consumptionProperties;

    private final AccountClient accountClient;

    @Autowired
    public CreditServiceImpl(final CreditDao dao, final CreditConsumptionFeatureProperties consumptionProperties, final AccountClient accountClient) {
        this.dao = dao;
        this.consumptionProperties = consumptionProperties;
        this.accountClient = accountClient;
    }

    @Override
    public Optional<Credit> findById(final String country, final String id) {
        logger.info("Start retrieving credit '{}'", id);
        final Optional<Credit> creditOpt = dao.findById(country, id);
        if(creditOpt.isPresent() && StringUtils.isNotBlank(creditOpt.get().getParentId())){
            final Credit child = creditOpt.get();
            logger.info("Start retrieving parent credit '{}' for shared credit '{}'", child.getParentId(), id);
            final Optional<Credit> parentOpt = dao.findById(country, child.getParentId());
            if(parentOpt.isPresent() && !CollectionUtils.isEmpty(parentOpt.get().getChildIds()) && parentOpt.get().getChildIds().contains(id)){
                final Credit parent = parentOpt.get();
                logger.info("The parent credit '{}' was found for shared credit '{}'", child.getParentId(), id);
                final Credit credit = Credit
                        .builder()
                        .withAccountId(child.getAccountId())
                        .withConsumption(parent.getConsumption())
                        .withTotal(parent.getTotal())
                        .withAvailable(parent.getAvailable())
                        .withOverdue(parent.getOverdue())
                        .withBalance(parent.getBalance())
                        .withPaymentTerms(parent.getPaymentTerms())
                        .withUpdatedAt(parent.getUpdatedAt())
                        .build();
                return Optional.of(credit);
            }
            logger.info("The parent credit '{}' was not found for shared credit '{}'", child.getParentId(), id);
            return Optional.empty();
        }
        return creditOpt;
    }

    @Override
    public void updateCreditConsumption(final String country, final boolean isAccountService, final CreditConsumptionRequest request) {
        final String accountId = request.getAccountId();
        logger.info("Starting the credit consumption with '{}' for accountId '{}'", request.getConsumption(), request.getAccountId());

        final Optional<Credit> credit = this.dao.findById(country, request.getAccountId());

        if (credit.isEmpty()) {
            logger.error("Credit with accountId '{}' was not found in database", accountId);
            throw new NotFoundException(IssueHandler.createIssue(IssueEnum.ACCOUNT_ID_NOT_FOUND, accountId));
        }
        final Credit persistedCredit = credit.get();

        final String tmpAccountId;
        final OffsetDateTime tmpUpdatedAt;
        final BigDecimal oldConsumption;
        final BigDecimal newConsumption;

        final boolean isSharedCredit = StringUtils.isNotBlank(persistedCredit.getParentId());
        if (isSharedCredit) {
            logger.info("The credit '{}' is shared and the parent credit is '{}'", accountId, persistedCredit.getParentId());
            final Optional<Credit> parentCredit = this.dao.findById(country, persistedCredit.getParentId());
            if (parentCredit.isEmpty() || parentCredit
                    .get()
                    .getChildIds() == null || !parentCredit
                    .get()
                    .getChildIds()
                    .contains(accountId)) {
                logger.error("The parent credit '{}' was not found with shared credit '{}'", persistedCredit.getParentId(), accountId);
                throw new NotFoundException(IssueHandler.createIssue(IssueEnum.ACCOUNT_ID_NOT_FOUND, accountId));
            }
            final Credit persistedParentCredit = parentCredit.get();
            tmpAccountId = persistedParentCredit.getAccountId();
            tmpUpdatedAt = persistedParentCredit.getUpdatedAt();
            oldConsumption = persistedParentCredit.getConsumption();
            newConsumption = buildNewConsumption(persistedParentCredit, request);
        } else {
            tmpAccountId = persistedCredit.getAccountId();
            tmpUpdatedAt = persistedCredit.getUpdatedAt();
            oldConsumption = persistedCredit.getConsumption();
            newConsumption = buildNewConsumption(persistedCredit, request);
        }

        logger.info("Calling credit consumption update from '{}' to '{}' for accountId '{}'", oldConsumption, newConsumption, tmpAccountId);
        final boolean wasSuccessful = this.dao.updateCreditConsumption(country, tmpUpdatedAt, tmpAccountId, newConsumption);

        if(!isAccountService && wasSuccessful && !isSharedCredit && this.consumptionProperties.shouldReplicateToAccountService(country)){
            replicateConsumptionToAccountService(country, tmpAccountId, tmpUpdatedAt, oldConsumption, request.getConsumption());
        } else {
            logger.info("Ignoring the credit data replication to account-service");
        }
    }

    @Override
    public List<Credit> findByAccountIds(final String country, final List<String> accountIds) {
        logger.info("Start retrieving credits '{}'", accountIds);
        final List<Credit> credits = dao.findByAccountIds(country, accountIds);

        if(!CollectionUtils.isEmpty(credits)) {
            final Map<Credit, String> childMap = credits
                    .stream()
                    .filter(c -> StringUtils.isNotBlank(c.getParentId()))
                    .collect(Collectors.toMap(c -> c, Credit::getParentId));
            final int sharedCreditsSize = childMap.size();
            if (sharedCreditsSize > 0) {
                logger.info("'{}' are shared credits", sharedCreditsSize);
                return retrieveAndJoinSharedCredits(country, credits, childMap);
            }
        }

        return credits;
    }

    void replicateConsumptionToAccountService(final String country, final String accountId, final OffsetDateTime updatedAt, final BigDecimal oldConsumption, final BigDecimal consumption) {
        try {
            logger.info("Starting the credit data replication to account-service");
            this.accountClient.creditConsumption(country, accountId, consumption);
            logger.info("Finishing the credit data replication to account-service");
        } catch (final Exception ex) {
            logger.error("An error has occurred during credit consumption in the account-service, then rolling it back");
            this.dao.updateCreditConsumption(country, updatedAt, accountId, oldConsumption);

            if (ex instanceof HttpStatusCodeException) {
                final HttpStatusCodeException statusCodeException = (HttpStatusCodeException) ex;

                if (HttpStatus.NOT_FOUND.equals(statusCodeException.getStatusCode())) {
                    logger.error("The credit for accountId '{}' was not found in the account-service.", accountId);
                    throw new NotFoundException(IssueHandler.createIssue(IssueEnum.ACCOUNT_ID_NOT_FOUND, accountId));
                } else {
                    logger.error("Received error with status '{}' and message '{}' when trying to call the account-service consumption.", statusCodeException.getStatusCode(), statusCodeException.getMessage());
                    throw new RemoteServiceErrorException(IssueHandler.createIssue(IssueEnum.REMOTE_SERVICE_ERROR, ApiConstants.ACCOUNT_REMOTE_SERVICE, statusCodeException.getMessage()));
                }
            }
            throw ex;
        }
    }

    private List<Credit> retrieveAndJoinSharedCredits(final String country, final List<Credit> persistedCredits, final Map<Credit, String> childMap) {
        final List<Credit> response = new ArrayList<>();
        // adding non shared persistedCredits in the response
        response.addAll(persistedCredits
                                .stream()
                                .filter(c -> StringUtils.isBlank(c.getParentId()))
                                .collect(Collectors.toList()));

        final int sharedCreditsSize = childMap.size();
        final Collection<String> parentIds = new HashSet<>(childMap.values());
        logger.info("Start retrieving parent credits '{}'", parentIds);
        final List<Credit> parents = dao.findByAccountIds(country, parentIds);

        if (!CollectionUtils.isEmpty(parents)) {
            logger.info("'{}' parent credits were not found for '{}' shared credits", parents.size(), sharedCreditsSize);
            final Map<String, Credit> parentsMap = parents
                    .stream()
                    .collect(Collectors.toMap(Credit::getAccountId, c -> c));

            for (final Map.Entry<Credit, String> entry : childMap.entrySet()) {
                final Credit parent = parentsMap.get(entry.getValue());
                final String childAccountId = entry
                        .getKey()
                        .getAccountId();
                if (parent != null && !CollectionUtils.isEmpty(parent.getChildIds()) && parent.getChildIds().contains(childAccountId)) {
                    logger.info("Setting shared credit data to '{}' from parent credit '{}'", childAccountId, parent.getAccountId());
                    final Credit credit = Credit
                            .builder()
                            .withAccountId(childAccountId)
                            .withConsumption(parent.getConsumption())
                            .withTotal(parent.getTotal())
                            .withAvailable(parent.getAvailable())
                            .withOverdue(parent.getOverdue())
                            .withBalance(parent.getBalance())
                            .withPaymentTerms(parent.getPaymentTerms())
                            .withUpdatedAt(parent.getUpdatedAt())
                            .build();
                    response.add(credit);
                } else {
                    logger.info("Parent credit '{}' was not found for shared credit '{}'", entry.getValue(), childAccountId);
                }
            }
            return response;
        }
        logger.info("The parent credits '{}' were not found for '{}' shared credits", parentIds, sharedCreditsSize);
        return response;
    }

    private BigDecimal buildNewConsumption(final Credit credit, final CreditConsumptionRequest request) {
        if (credit.getConsumption() != null) {
            return credit.getConsumption().add(request.getConsumption());
        } else {
            return request.getConsumption();
        }
    }
}
