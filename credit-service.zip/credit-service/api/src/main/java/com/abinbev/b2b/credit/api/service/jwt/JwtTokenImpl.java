package com.abinbev.b2b.credit.api.service.jwt;

import com.auth0.jwt.JWT;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.interfaces.DecodedJWT;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class JwtTokenImpl implements JwtToken {

	private static final Logger LOGGER = LoggerFactory.getLogger(JwtTokenImpl.class);

	private static final String BEARER_PREFIX = "Bearer ";

	public DecodedJWT decodeToken(final String receivedToken) {

		final String token = normalizeToken(receivedToken);

		if(StringUtils.isNotBlank(token)) {
			try {
				return JWT.decode(token);
			} catch (final JWTDecodeException exception) {
				LOGGER.error(exception.getMessage(), exception);
			}
		}
		return null;
	}

	private String normalizeToken(final String receivedToken) {
		if (StringUtils.isNotBlank(receivedToken) && receivedToken.startsWith(BEARER_PREFIX)) {
			return receivedToken.substring(7);
		}
		return receivedToken;
	}
}
