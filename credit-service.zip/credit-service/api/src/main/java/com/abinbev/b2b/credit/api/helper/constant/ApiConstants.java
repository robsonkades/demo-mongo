package com.abinbev.b2b.credit.api.helper.constant;

public class ApiConstants {

    public static final String REQUEST_TRACE_ID_HEADER = "requestTraceId";

    public static final String COUNTRY_HEADER = "country";

    public static final String AUTHORIZATION = "Authorization";

    public static final String STATUS_200_OK = "OK";

    public static final String STATUS_400_BAD_REQUEST = "Bad Request";

    public static final String STATUS_404_NOT_FOUND = "Not found";

    public static final String STATUS_503_SERVICE_UNAVAILABLE = "Service Unavailable";

    public static final String ACCOUNT_REMOTE_SERVICE = "account-service";

    private ApiConstants() {
        super();
    }
}

