package com.abinbev.b2b.credit.api.remote.client;

import java.math.BigDecimal;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

import com.abinbev.b2b.credit.api.helper.constant.ApiConstants;
import com.abinbev.b2b.credit.utilities.remote.client.RemoteClient;

@Component
public class AccountClient {

	private static final Logger logger = LoggerFactory.getLogger(AccountClient.class);

	private static final String CREDIT_CONSUMPTION_PATH = "credit/consumption";

	static final String IS_CREDIT_SERVICE_HEADER = "isCreditService";

	static final String STRING_TRUE_VALUE = "true";

	@Value("${microservices.accountService.url}")
	private String url;

	private final RemoteClient remoteClient;

	@Autowired
	public AccountClient(final RemoteClient remoteClient) {
		this.remoteClient = remoteClient;
	}

	public void creditConsumption(final String country, final String accountId, final BigDecimal consumption) {
        logger.info("Calling '{}' credit consumption for accountId: '{}' and consumption: '{}'", ApiConstants.ACCOUNT_REMOTE_SERVICE, accountId, consumption);
        final String uri = UriComponentsBuilder
                .fromHttpUrl(this.url)
                .path(CREDIT_CONSUMPTION_PATH)
                .toUriString();
        remoteClient.postForObject(
                uri,
				buildRequestHeader(country),
				new CreditConsumptionRequest(accountId, consumption),
				null,
                ApiConstants.ACCOUNT_REMOTE_SERVICE);
        logger.info("The '{}' credit consumption was successful", ApiConstants.ACCOUNT_REMOTE_SERVICE);
	}

	private HttpHeaders buildRequestHeader(final String country) {
		final HttpHeaders headers = new HttpHeaders();
		headers.add(ApiConstants.COUNTRY_HEADER, country);
		headers.add(ApiConstants.REQUEST_TRACE_ID_HEADER, String.valueOf(MDC.get(ApiConstants.REQUEST_TRACE_ID_HEADER)));
		headers.add(IS_CREDIT_SERVICE_HEADER, STRING_TRUE_VALUE);
		return headers;
	}

	static class CreditConsumptionRequest {

		private String accountId;

		private BigDecimal consumption;

		CreditConsumptionRequest(final String accountId, final BigDecimal consumption) {
			this.accountId = accountId;
			this.consumption = consumption;
		}

		public String getAccountId() {
			return accountId;
		}

		public BigDecimal getConsumption() {
			return consumption;
		}

		@Override
		public boolean equals(final Object o) {
			if (this == o)
				return true;

			if (o == null || getClass() != o.getClass())
				return false;

			final CreditConsumptionRequest that = (CreditConsumptionRequest) o;

			return new EqualsBuilder()
					.append(accountId, that.accountId)
					.append(consumption, that.consumption)
					.isEquals();
		}

		@Override
		public int hashCode() {
			return new HashCodeBuilder(17, 37)
					.append(accountId)
					.append(consumption)
					.toHashCode();
		}
	}
}
