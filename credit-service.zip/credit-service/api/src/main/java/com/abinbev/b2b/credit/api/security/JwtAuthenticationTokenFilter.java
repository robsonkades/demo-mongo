package com.abinbev.b2b.credit.api.security;

import static com.abinbev.b2b.credit.api.helper.constant.UrlHelper.isTrustedUrl;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import com.abinbev.b2b.credit.api.config.JwtValidationTokenConfiguration;
import com.abinbev.b2b.credit.api.exception.JwtException;
import com.abinbev.b2b.credit.api.service.jwt.JwtToken;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.google.common.net.HttpHeaders;
import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

public class JwtAuthenticationTokenFilter extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(JwtAuthenticationTokenFilter.class);

    private static final Type ACCOUNT_ID_TYPE_TOKEN = new TypeToken<List<String>>() {
    }.getType();

    @Autowired
    private JwtToken jwtToken;

    @Autowired
    private JwtValidationTokenConfiguration configuration;

    @Override
    protected void doFilterInternal(final HttpServletRequest request, final HttpServletResponse response, final FilterChain chain) throws ServletException, IOException {
        final String token = request.getHeader(HttpHeaders.AUTHORIZATION);

        try {
            JwtUserDetails jwtUserDetails = null;
            final var authentication = new UsernamePasswordAuthenticationToken(null, null, null);

            if (!isTrustedUrl(request.getRequestURI())) {
                final DecodedJWT decodedToken = jwtToken.decodeToken(token);
                if (decodedToken != null) {
                    jwtUserDetails = new JwtUserDetails(findTypeInJwt(decodedToken), findUserIdInJwt(decodedToken), findAccountIdsInJwt(decodedToken), findAppTypeInJwt(decodedToken));
                }
            }
            authentication.setDetails(jwtUserDetails);
            SecurityContextHolder
                    .getContext()
                    .setAuthentication(authentication);
            chain.doFilter(request, response);
        } catch (final JwtException e) {
            log.error("Invalid token: {} message: {}", token, e.getMessage(), e);
            JwtResponseExceptionHandler.handleException(response, e);
        }
    }

    private JwtTypeEnum findTypeInJwt(final DecodedJWT decodedJwt) {
        final var roles = decodedJwt
                .getClaims()
                .get(configuration.getRolesClaim());
        if (roles != null && configuration.getServerToServerRoles() != null) {
            final var tokenRoles = roles.asList(String.class);
            final var serverToServerRoles = configuration.getServerToServerRoles().stream().map(String::toLowerCase).collect(Collectors.toList());
            if (tokenRoles != null && tokenRoles.stream().anyMatch(role -> serverToServerRoles.contains(role.toLowerCase()))) {
                return JwtTypeEnum.SERVER_TO_SERVER;
            }
        }
        return JwtTypeEnum.USER_TO_SERVER;
    }

    private String findAppTypeInJwt(final DecodedJWT decodedJwt) {
        final var appType = decodedJwt
                .getClaims()
                .get(configuration.getAppTypeClaim());
        if (appType != null) {
            return appType.asString();
        }
        return null;
    }

    private String findUserIdInJwt(final DecodedJWT decodedJwt) {
        final var magentoUserId = decodedJwt
                .getClaims()
                .get(configuration.getMagentoUserIdClaim());
        if (magentoUserId != null) {
            return magentoUserId.asString();
        }
        final var b2bUserId = decodedJwt
                .getClaims()
                .get(configuration.getB2bUserIdClaim());
        if (b2bUserId != null) {
            return b2bUserId.asString();
        }
        return null;
    }

    private List<String> findAccountIdsInJwt(final DecodedJWT decodedJwt) {
        final var b2bAccountIds = decodedJwt
                .getClaims()
                .get(configuration.getB2bAccountIdsClaim());
        if (b2bAccountIds != null) {
            final String accountIdsAsString = b2bAccountIds.asString();
            return new Gson().fromJson(accountIdsAsString, ACCOUNT_ID_TYPE_TOKEN);
        }
        final var magentoAccountIds = decodedJwt
                .getClaims()
                .get(configuration.getMagentoAccountIdsClaim());
        if (magentoAccountIds != null) {
            return magentoAccountIds.asList(String.class);
        }
        return Collections.emptyList();
    }
}
