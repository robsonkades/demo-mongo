package com.abinbev.b2b.credit.api.service;

import com.abinbev.b2b.credit.api.domain.CreditStatement;
import com.abinbev.b2b.credit.api.remote.client.FileManagementClient;
import com.abinbev.b2b.credit.api.remote.response.FileManagementResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Collection;
import java.util.List;
import java.util.function.Function;

import static java.lang.String.format;
import static java.time.YearMonth.parse;
import static java.time.format.DateTimeFormatter.ofPattern;
import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.toList;
import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.apache.commons.lang3.math.NumberUtils.createBigDecimal;

@Service
public class CreditStatementServiceImpl implements CreditStatementService {

	private static final Logger logger = LoggerFactory.getLogger(CreditStatementServiceImpl.class);

	private final FileManagementClient fileManagementClient;

	@Value("${microservices.fileManagement.response.fields.date}")
	private String metadataDateField;

	@Value("${microservices.fileManagement.response.fields.balance}")
	private String metadataBalanceField;

	@Value("${microservices.fileManagement.params.values.metadata-accountId}")
	private String accountParameterName;

	@Value("${microservices.fileManagement.params.values.purpose}")
	private String fileManagementPurposeValue;

	@Value("${microservices.fileManagement.maxResults}")
	private Integer fileManagementMaxResults;

	@Value("${microservices.fileManagement.dateFormat}")
	private String pattern;

	@Autowired
	public CreditStatementServiceImpl(final FileManagementClient fileManagementClient) {
		this.fileManagementClient = fileManagementClient;
	}


	@Override
	public List<CreditStatement> findByCountryAndAccountId(final String country, final String accountId, final String authorization) {
		final DateTimeFormatter dateFormatter = ofPattern(pattern);

		final Collection<FileManagementResponse> files = fileManagementClient.findByAccountId(country, buildMetadataParameter(accountParameterName, accountId), fileManagementPurposeValue, authorization);

		return files.stream()
					.filter(this::validResponse)
					.map(response -> new CreditStatement(response.getUrl(), response.getUrlExpiresAt(), response.getFromMetadata(metadataDateField), createBigDecimal(response.getFromMetadata(metadataBalanceField))))
					.sorted(comparing(compareDate(dateFormatter)))
					.skip(files.size() <= fileManagementMaxResults ? 0 : files.size() - fileManagementMaxResults)
					.collect(toList());
	}

	private boolean validResponse(final FileManagementResponse response) {
		final String date = response.getFromMetadata(metadataDateField);
		final String balance = response.getFromMetadata(metadataBalanceField);
		return isDateValid(date, ofPattern(pattern)) && isBalanceValid(balance);
	}

	private boolean isBalanceValid(final String balance) {
		try {
			createBigDecimal(balance);
			return true;
		}
		catch(final NumberFormatException exception) {
			logger.error("Could not parse balance {} on Credit Statement Service.", balance, exception);
			return false;
		}
	}

	private boolean isDateValid(final String date, final DateTimeFormatter dateFormatter) {
		if (isNotBlank(date)) {
			try {
				parse(date, dateFormatter);
				return true;
			} catch (DateTimeParseException exception) {
				logger.error("Could not parse date {} on Credit Statement Service.", date, exception);
			}
		}
		return false;
	}

	private Function<CreditStatement, YearMonth> compareDate(final DateTimeFormatter dateFormatter) {
		return (CreditStatement c) -> parse(c.getDate(), dateFormatter);
	}

	private String buildMetadataParameter(final String name, final String value) {
		return format("%s:%s", name, value);
	}
}
