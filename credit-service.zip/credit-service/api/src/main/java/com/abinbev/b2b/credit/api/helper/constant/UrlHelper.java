package com.abinbev.b2b.credit.api.helper.constant;

import java.util.Arrays;

public final class UrlHelper {

    private UrlHelper() {
        super();
    }

    protected static final String[] TRUSTED_URLS = { "/swagger-ui", "/swagger-resource", "/webjars", "/v2/api-docs", "/actuator/health", "/actuator/info", "/csrf", "/favicon.ico" };

    public static boolean isTrustedUrl(final String urlPath) {
        return Arrays
                .asList(TRUSTED_URLS)
                .stream()
                .anyMatch(urlPath::startsWith);
    }

}
