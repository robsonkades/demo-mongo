package com.abinbev.b2b.credit.api.exception;

import com.abinbev.b2b.credit.utilities.exception.GlobalException;
import com.abinbev.b2b.credit.utilities.exception.Issue;
import org.springframework.http.HttpStatus;

public class JwtException extends GlobalException {

    private static final long serialVersionUID = 1L;
    public JwtException(final Issue issue) {
        super(issue, HttpStatus.FORBIDDEN);
    }
}
