package com.abinbev.b2b.credit.api.service;


import com.abinbev.b2b.credit.api.domain.CreditStatement;

import java.util.List;

public interface CreditStatementService {

	List<CreditStatement> findByCountryAndAccountId(final String country, final String accountId, final String authorization);

}
