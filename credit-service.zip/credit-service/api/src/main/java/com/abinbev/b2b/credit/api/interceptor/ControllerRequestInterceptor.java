package com.abinbev.b2b.credit.api.interceptor;

import static com.abinbev.b2b.credit.api.helper.constant.ApiConstants.COUNTRY_HEADER;
import static com.abinbev.b2b.credit.api.helper.constant.ApiConstants.REQUEST_TRACE_ID_HEADER;
import static com.newrelic.api.agent.NewRelic.addCustomParameter;

import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.abinbev.b2b.credit.api.helper.ControllerValidator;
import com.abinbev.b2b.credit.api.interceptor.annotation.RequiredHeadersValidation;

@Component
public class ControllerRequestInterceptor extends HandlerInterceptorAdapter {

    private static final Logger logger = LoggerFactory.getLogger(ControllerRequestInterceptor.class);

    @Autowired
    private ControllerValidator controllerValidator;

    @Override
    public boolean preHandle(final HttpServletRequest request, final HttpServletResponse response, final Object handler) throws Exception {
        if (shouldValidateHeaders(handler)) {
            logger.info("Starting headers validation");
            final String requestTraceId = request.getHeader(REQUEST_TRACE_ID_HEADER);
            this.controllerValidator.validateRequestTraceId(requestTraceId);
            MDC.put(REQUEST_TRACE_ID_HEADER, requestTraceId);
            addCustomParameter(REQUEST_TRACE_ID_HEADER, requestTraceId);

            final String country = request.getHeader(COUNTRY_HEADER);
            this.controllerValidator.validateCountry(country);
            this.controllerValidator.validateIfCountryIsSupported(country);
            MDC.put(COUNTRY_HEADER, country);
            addCustomParameter(COUNTRY_HEADER, country);
        }
        return true;
    }

    @Override
    public void afterCompletion(final HttpServletRequest request, HttpServletResponse response, final Object handler, @Nullable final Exception ex) {
        MDC.clear();
    }

    /**
     * Validate if the class or method of the HandlerMethod bean instance are
     * annotated with {@link RequiredHeadersValidation}
     *
     * @param object The HandlerMethod instance
     * @return TRUE if the class or method are annotated with
     * {@link RequiredHeadersValidation}, otherwise FALSE:
     */
    private boolean shouldValidateHeaders(final Object object) {
        if (object instanceof HandlerMethod) {
            final HandlerMethod handler = (HandlerMethod) object;
            final Class<? extends Object> beanClass = handler.getBean() == null ? null : handler.getBean().getClass();
            final Method beanMethod = handler.getMethod();

            final boolean isPresentInClass = beanClass != null && beanClass.isAnnotationPresent(RequiredHeadersValidation.class);
            final boolean isPresentInMethod = beanMethod != null && beanMethod.isAnnotationPresent(RequiredHeadersValidation.class);

            return isPresentInClass || isPresentInMethod;
        }
        return false;
    }
}
