package com.abinbev.b2b.credit.api.remote.client;


import com.abinbev.b2b.credit.api.helper.constant.ApiConstants;
import com.abinbev.b2b.credit.api.remote.response.FileManagementResponse;
import com.abinbev.b2b.credit.utilities.remote.client.RemoteClient;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpStatusCodeException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static java.lang.String.format;

@Component
public class FileManagementClient {

	private static final Logger logger = LoggerFactory.getLogger(FileManagementClient.class);

	private static final String QUERY_PARAMETERS = "?purpose={purpose}&metadata={metadata}";

	private static final String REMOTE_SERVICE_FILE_MANAGEMENT = "file-management-service";

	@Value("${microservices.fileManagement.url}")
	private String fileManagementServiceUrl;

	private final RemoteClient remoteClient;

	@Autowired
	public FileManagementClient(final RemoteClient remoteClient) {
		this.remoteClient = remoteClient;
	}

	public List<FileManagementResponse> findByAccountId(final String country, final String accountId, final String purpose, final String authorization) {

		try {
			final ResponseEntity<FileManagementResponse[]> exchange = remoteClient.getForObject(
					buildUrl(),
					buildRequestHeader(country, authorization),
					FileManagementResponse[].class,
					REMOTE_SERVICE_FILE_MANAGEMENT,
					purpose,
					accountId);

			final FileManagementResponse[] files = exchange.getBody();
			return files == null || files.length == 0 ? new ArrayList<>() : Arrays.asList(files);
		} catch (final HttpStatusCodeException ex) {
			logger.error(ex.getMessage(), ex);
			throw ex;
		}
	}

	private HttpHeaders buildRequestHeader(final String country, final String authorization){
		final HttpHeaders headers = new HttpHeaders();
		headers.add(ApiConstants.COUNTRY_HEADER, country);
		headers.add(ApiConstants.REQUEST_TRACE_ID_HEADER, String.valueOf(MDC.get(ApiConstants.REQUEST_TRACE_ID_HEADER)));
		if (StringUtils.isNotEmpty(authorization)) {
			headers.add(HttpHeaders.AUTHORIZATION, authorization);
		}
		return headers;
	}

	private String buildUrl() {
		return format("%s%s", fileManagementServiceUrl, QUERY_PARAMETERS);
	}
}
