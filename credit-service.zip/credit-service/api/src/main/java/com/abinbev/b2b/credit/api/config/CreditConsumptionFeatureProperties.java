package com.abinbev.b2b.credit.api.config;

import java.lang.reflect.Type;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

@Configuration
@ConfigurationProperties(prefix = "features.creditconsumption")
public class CreditConsumptionFeatureProperties {

    private static final Logger logger = LoggerFactory.getLogger(CreditConsumptionFeatureProperties.class);

    static final String DEFAULT_KEY = "default";

    private static final Type TYPE_MAP_STRING_BOOLEAN = new TypeToken<Map<String, Boolean>>() {}.getType();

    @Value("#{environment.FEATURES_CREDITCONSUMPTION_DATAREPLICATIONENABLEDPERCOUNTRY}")
    private String dataReplicationEnabledPerCountryFromEnv;

    private Map<String, Boolean> dataReplicationEnabledPerCountry;

    public Map<String, Boolean> getDataReplicationEnabledPerCountry() {
        return dataReplicationEnabledPerCountry;
    }

    public void setDataReplicationEnabledPerCountry(final Map<String, Boolean> dataReplicationEnabledPerCountry) {
        if (StringUtils.isNotBlank(this.dataReplicationEnabledPerCountryFromEnv)) {
            try {
                this.dataReplicationEnabledPerCountry = new Gson().fromJson(dataReplicationEnabledPerCountryFromEnv, TYPE_MAP_STRING_BOOLEAN);
            } catch (final Exception e) {
                logger.error(e.getMessage(), e);
            }
        } else {
            this.dataReplicationEnabledPerCountry = dataReplicationEnabledPerCountry;
        }
    }

    public boolean shouldReplicateToAccountService(final String country) {
        if(StringUtils.isBlank(country) || this.dataReplicationEnabledPerCountry == null){
            return false;
        }
        return this.dataReplicationEnabledPerCountry.getOrDefault(country.toLowerCase(), this.dataReplicationEnabledPerCountry.getOrDefault(DEFAULT_KEY, false));
    }
}