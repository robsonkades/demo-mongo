package com.abinbev.b2b.credit.api.domain;

import io.swagger.annotations.ApiModelProperty;

import java.math.BigDecimal;

public class CreditStatement {

    @ApiModelProperty(notes = "${resources.creditStatement.url}", example = "https://www.example.com/files/file.pdf")
    private String url;

    @ApiModelProperty(notes = "${resources.creditStatement.date}", example = "03/2019")
    private String date;

    @ApiModelProperty(notes = "${resources.creditStatement.urlExpiresAt}", example = "2019-04-22T13:58:21.763Z")
    private String urlExpiresAt;

    @ApiModelProperty(notes = "${resources.creditStatement.balance}", example = "1000.00")
    private BigDecimal balance;

    public CreditStatement() {
        super();
    }

    public CreditStatement(final String url, final String urlExpiresAt, final String date, final BigDecimal balance) {
        this.url = url;
        this.urlExpiresAt = urlExpiresAt;
        this.date = date;
        this.balance = balance;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(final String url) {
        this.url = url;
    }

    public String getDate() {
        return date;
    }

    public void setDate(final String date) {
        this.date = date;
    }

    public String getUrlExpiresAt() {
        return urlExpiresAt;
    }

    public void setUrlExpiresAt(final String urlExpiresAt) {
        this.urlExpiresAt = urlExpiresAt;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(final BigDecimal balance) {
        this.balance = balance;
    }
}
