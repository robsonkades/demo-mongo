package com.abinbev.b2b.credit.api.service.jwt;

import com.auth0.jwt.interfaces.DecodedJWT;

public interface JwtToken {

    DecodedJWT decodeToken(final String receivedToken);
}
