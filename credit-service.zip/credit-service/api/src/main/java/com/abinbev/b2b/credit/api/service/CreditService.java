package com.abinbev.b2b.credit.api.service;

import com.abinbev.b2b.credit.utilities.domain.Credit;
import com.abinbev.b2b.credit.utilities.vo.CreditConsumptionRequest;

import java.util.List;
import java.util.Optional;

public interface CreditService {
    Optional<Credit> findById(final String country, final String id);

    void updateCreditConsumption(final String country, final boolean isAccountService, final CreditConsumptionRequest request);

    List<Credit> findByAccountIds(final String country, final List<String> accountIds);
}
