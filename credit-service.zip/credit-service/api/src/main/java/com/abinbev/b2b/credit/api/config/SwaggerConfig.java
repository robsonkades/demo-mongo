package com.abinbev.b2b.credit.api.config;

import com.abinbev.b2b.credit.api.helper.constant.ApiConstants;
import com.google.common.collect.ImmutableList;
import io.swagger.annotations.Api;
import org.apache.logging.log4j.util.Strings;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.builders.RequestParameterBuilder;
import springfox.documentation.builders.ResponseBuilder;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.ParameterType;
import springfox.documentation.service.Tag;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.UiConfiguration;
import springfox.documentation.swagger.web.UiConfigurationBuilder;

import java.util.Arrays;

@Configuration
@PropertySource("classpath:version.properties")
public class SwaggerConfig {

    @Autowired
    private Environment env;

    @Value("${swaggerBaseUrl}")
    private String baseUrl;

    @Value("${resources.headers.requestTraceId.value}")
    private String requestTraceIdDescription;

    @Value("${resources.headers.authorization.value}")
    private String authorizationDescription;

    @Bean
    public Docket creditApi() {
        // parameters
        var requestTraceId = new RequestParameterBuilder()
                .parameterIndex(0)
                .name(ApiConstants.REQUEST_TRACE_ID_HEADER)
                .description(requestTraceIdDescription)
                .in(ParameterType.HEADER)
                .required(true)
                .build();

        var authorization = new RequestParameterBuilder()
                .parameterIndex(1)
                .name(HttpHeaders.AUTHORIZATION)
                .description(authorizationDescription)
                .in(ParameterType.HEADER)
                .required(true)
                .build();

        var unauthorizedResponse = new ResponseBuilder()
                .code(String.valueOf(HttpStatus.UNAUTHORIZED.value()))
                .description(HttpStatus.UNAUTHORIZED.getReasonPhrase())
                .build();

        var forbiddenResponse = new ResponseBuilder()
                .code(String.valueOf(HttpStatus.FORBIDDEN.value()))
                .description(HttpStatus.FORBIDDEN.getReasonPhrase())
                .build();

        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(metaData())
                .useDefaultResponseMessages(false)
                .host(baseUrl)
                .select()
                .apis(RequestHandlerSelectors.withClassAnnotation(Api.class))
                .build()
                .globalRequestParameters(Arrays.asList(requestTraceId, authorization))
                .globalResponses(HttpMethod.GET, ImmutableList.of(unauthorizedResponse, forbiddenResponse))
                .globalResponses(HttpMethod.POST, ImmutableList.of(unauthorizedResponse, forbiddenResponse))
                .tags(new Tag("Credits", "Credits Information"));
    }

    @Bean
    public UiConfiguration uiConfig() {
        return UiConfigurationBuilder
                .builder()
                .displayRequestDuration(true)
                // disabling to avoid error with the micro-service version in
                // the URL. See issue #35886
                .validatorUrl(Strings.EMPTY)
                .build();
    }

    private ApiInfo metaData() {
        return new ApiInfoBuilder()
                .title("AB-InBev Credit API Service")
                .description("REST API for AB-InBev Credit API Service")
                .version(env.getProperty("API_VERSION"))
                .license("Anheuser-Busch InBev © 2021")
                .build();
    }
}
