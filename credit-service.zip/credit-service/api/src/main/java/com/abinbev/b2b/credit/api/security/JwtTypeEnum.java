package com.abinbev.b2b.credit.api.security;

public enum JwtTypeEnum {
	USER_TO_SERVER,
	SERVER_TO_SERVER;
}
