package com.abinbev.b2b.credit.api.controller;

import com.abinbev.b2b.credit.api.domain.CreditStatement;
import com.abinbev.b2b.credit.api.helper.JwtValidator;
import com.abinbev.b2b.credit.api.interceptor.annotation.RequiredHeadersValidation;
import com.abinbev.b2b.credit.api.service.CreditService;
import com.abinbev.b2b.credit.api.service.CreditStatementService;
import com.abinbev.b2b.credit.utilities.domain.Credit;
import com.abinbev.b2b.credit.utilities.vo.CreditConsumptionRequest;
import io.swagger.annotations.Api;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

@RequiredHeadersValidation
@Api(tags = "Credits")
@RestController
public class CreditControllerImpl implements CreditController {

    private static final Logger logger = LoggerFactory.getLogger(CreditControllerImpl.class);

    private final CreditService service;

    private final JwtValidator validator;

    private final CreditStatementService creditStatementService;

    public CreditControllerImpl(final CreditService service, final JwtValidator validator, final CreditStatementService creditStatementService) {
        this.service = service;
        this.validator = validator;
        this.creditStatementService = creditStatementService;
    }

    //Using @ApiIgnore to hide the get by id from swagger, in the future if the endpoint is not needed, remove the implementation and robot tests for it.
    @ApiIgnore
    @GetMapping("/{id}")
    @Override
    public ResponseEntity<Credit> get(final String country, final String id) {

        logger.info("Retrieving credit by id '{}'", id);

        var optional = this.service.findById(country, id);
        if (optional.isPresent()) {
            final Credit credit = optional.get();
            validator.validate(country, credit.getAccountId());
            logger.info("Credit '{}' found.", id);
            return ResponseEntity.ok(credit);
        }

        logger.info("Credit '{}' not found.", id);
        return ResponseEntity
                .notFound()
                .build();
    }

    @PostMapping(path = "/consumption", produces = MediaType.APPLICATION_JSON_VALUE)
    @Override
    public ResponseEntity<Void> updateCreditConsumption(final String country, final boolean isAccountService, final CreditConsumptionRequest request) {
        validator.validate(country, request.getAccountId());
        this.service.updateCreditConsumption(country, isAccountService, request);
        return ResponseEntity
                .ok()
                .build();
    }

    @GetMapping("/statement")
    @Override
    public ResponseEntity<List<CreditStatement>> getCreditStatement(
            final String country,
            final String authorization,
            final String accountId) {

        logger.info("Retrieving credit statement for accountId: '{}'", accountId);
        validator.validate(country, accountId);
        return ResponseEntity.ok(this.creditStatementService.findByCountryAndAccountId(country, accountId, authorization));
    }

    @GetMapping("/")
    @Override
    public ResponseEntity<List<Credit>> list(
            final String country,
            final List<String> accountIds) {

        logger.info("Retrieving a list of credits by accountId list: '{}'", accountIds);
        validator.validate(country, accountIds);
        final List<Credit> credits = this.service.findByAccountIds(country, accountIds);
        logger.info("'{}' credits were found", credits.size());
        return ResponseEntity.ok(credits);
    }
}
