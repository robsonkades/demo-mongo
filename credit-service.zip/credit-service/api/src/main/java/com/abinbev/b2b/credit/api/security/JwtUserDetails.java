package com.abinbev.b2b.credit.api.security;

import java.util.List;

public class JwtUserDetails {
    private JwtTypeEnum type;

    private String userId;

    private List<String> accountIds;

    private String appType;

    public JwtUserDetails(final JwtTypeEnum type, final String userId, final List<String> accountIds, final String appType) {
        this.type = type;
        this.userId = userId;
        this.accountIds = accountIds;
        this.appType = appType;
    }

    public String getUserId() {
        return userId;
    }

    public List<String> getAccountIds() {
        return accountIds;
    }

    public JwtTypeEnum getType() {
        return type;
    }

    public String getAppType() {
        return appType;
    }
}
