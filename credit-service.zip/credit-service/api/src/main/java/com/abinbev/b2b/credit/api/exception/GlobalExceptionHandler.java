package com.abinbev.b2b.credit.api.exception;

import java.nio.file.AccessDeniedException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.NoHandlerFoundException;

import com.abinbev.b2b.credit.utilities.exception.BadRequestException;
import com.abinbev.b2b.credit.utilities.exception.GlobalException;
import com.abinbev.b2b.credit.utilities.exception.Issue;
import com.abinbev.b2b.credit.utilities.exception.IssueHandler;
import com.abinbev.b2b.credit.utilities.exception.NotFoundException;

@ControllerAdvice
@RestController
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(Exception.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    protected ResponseEntity<Object> handleException(final Exception ex) {
        logger.error(ex.getMessage(), ex);
        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(buildErrorResponse(IssueHandler.createIssue(ex)));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    protected ResponseEntity<Object> handleMethodArgumentNotValid(final MethodArgumentNotValidException ex, final WebRequest request) {
        logger.error(ex.getMessage(), ex);
        final List<Issue> issues = new ArrayList<>();
        for (final FieldError error : ex.getBindingResult().getFieldErrors()) {
            issues.add(IssueHandler.createIssue(error.getDefaultMessage()));
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(buildErrorResponse(issues));
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<Object> handlerJsonDeserializeError(final HttpMessageNotReadableException ex) {
        logger.error(ex.getMessage(), ex);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(buildErrorResponse(IssueHandler.createIssue("Can not deserialize JSON")));
    }

    @ExceptionHandler(RuntimeException.class)
    @ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
    protected ResponseEntity<Object> handleRuntimeException(final RuntimeException ex) {
        logger.error(ex.getMessage(), ex);
        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(buildErrorResponse(IssueHandler.createIssue(ex)));
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    @ResponseStatus(code = HttpStatus.METHOD_NOT_ALLOWED, value = HttpStatus.METHOD_NOT_ALLOWED)
    protected ResponseEntity<Object> handleHttpRequestMethodNotSupportedException(final HttpRequestMethodNotSupportedException ex) {
        logger.error(ex.getMessage(), ex);
        return ResponseEntity
                .status(HttpStatus.METHOD_NOT_ALLOWED)
                .body(buildErrorResponse(IssueHandler.createIssue(ex)));
    }

    @ExceptionHandler(NoHandlerFoundException.class)
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    protected ResponseEntity<Object> handleNotFoundException(final NoHandlerFoundException ex) {
        logger.error(ex.getMessage(), ex);
        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(buildErrorResponse(IssueHandler.createIssue(ex)));
    }

    @ExceptionHandler({
            NotFoundException.class
    })
    @ResponseStatus(value = HttpStatus.NOT_FOUND)
    protected ResponseEntity<Object> processNotFoundException(final GlobalException ex, final WebRequest request) {
        logger.debug(ex.getMessage(), ex);
        return ResponseEntity.status(ex.getHttpStatus()).body(buildErrorResponse(ex.getIssues()));
    }

    @ExceptionHandler(AccessDeniedException.class)
    @ResponseStatus(value = HttpStatus.FORBIDDEN)
    protected ResponseEntity<Object> handleAccessDenied(final AccessDeniedException ex) {
        logger.error(ex.getMessage(), ex);
        return ResponseEntity
                .status(HttpStatus.FORBIDDEN)
                .body(buildErrorResponse(IssueHandler.createIssue(ex)));
    }

    @ExceptionHandler(BadRequestException.class)
    @ResponseStatus(value = HttpStatus.BAD_REQUEST)
    protected ResponseEntity<Object> handleBadRequestException(final GlobalException ex) {
        logger.error(ex.getMessage(), ex);
        return ResponseEntity
                .status(ex.getHttpStatus())
                .body(buildErrorResponse(ex.getIssues()));
    }

    @ExceptionHandler(JwtException.class)
    @ResponseStatus(value = HttpStatus.FORBIDDEN)
    protected ResponseEntity<Object> handleJwtException(final JwtException ex) {
        return ResponseEntity
                .status(ex.getHttpStatus())
                .body(buildErrorResponse(ex.getMessage(), ex.getIssues()));
    }

    private ErrorResponse buildErrorResponse(final Issue issue) {
        return new ErrorResponse(issue.getMessage(), Arrays.asList(issue));
    }

    private ErrorResponse buildErrorResponse(final List<Issue> issues) {
        return new ErrorResponse(issues
                                         .get(0)
                                         .getMessage(), issues);
    }

    private ErrorResponse buildErrorResponse(final String message, final List<Issue> issues) {
        return new ErrorResponse(message, issues);
    }
}

