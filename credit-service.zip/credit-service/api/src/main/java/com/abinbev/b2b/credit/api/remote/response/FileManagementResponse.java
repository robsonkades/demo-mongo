package com.abinbev.b2b.credit.api.remote.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Map;

public class FileManagementResponse {

	@JsonProperty
	private String title;

	@JsonProperty
	private String type;

	@JsonProperty
	private String url;

	@JsonProperty
	private Map<String, String> metadata;

	@JsonProperty
	private String creationDate;

	@JsonProperty
	private String urlExpiresAt;

	public String getTitle() {
		return title;
	}

	public void setTitle(final String title) {
		this.title = title;
	}

	public String getType() {
		return type;
	}

	public void setType(final String type) {
		this.type = type;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(final String url) {
		this.url = url;
	}

	public Map<String, String> getMetadata() {
		return metadata;
	}

	public void setMetadata(final Map<String, String> metadata) {
		this.metadata = metadata;
	}

	public String getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(final String creationDate) {
		this.creationDate = creationDate;
	}

	public String getUrlExpiresAt() {
		return urlExpiresAt;
	}

	public void setUrlExpiresAt(final String urlExpiresAt) {
		this.urlExpiresAt = urlExpiresAt;
	}

	public String getFromMetadata(final String key) {
		return metadata.getOrDefault(key, null);
	}
}
