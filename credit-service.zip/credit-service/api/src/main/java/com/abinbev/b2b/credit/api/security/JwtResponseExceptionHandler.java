package com.abinbev.b2b.credit.api.security;

import com.abinbev.b2b.credit.api.exception.JwtException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.MediaType;

import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

class JwtResponseExceptionHandler {

    private static final Logger logger = LogManager.getLogger(JwtResponseExceptionHandler.class);

    private JwtResponseExceptionHandler() {
        super();
    }

    static void handleException(final HttpServletResponse response, final JwtException ex) throws IOException {
        try {
            response.setStatus(ex.getHttpStatus().value());
            response.setContentType(MediaType.APPLICATION_JSON_VALUE);
            final ObjectMapper mapper = new ObjectMapper();
            final PrintWriter writer;
            writer = response.getWriter();
            writer.print(mapper.writeValueAsString(ex.getIssues()));
            writer.flush();
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
            throw e;
        }
    }
}
