package com.abinbev.b2b.credit.api.helper;

import com.abinbev.b2b.credit.api.config.JwtValidationTokenConfiguration;
import com.abinbev.b2b.credit.api.exception.JwtException;
import com.abinbev.b2b.credit.api.security.JwtTypeEnum;
import com.abinbev.b2b.credit.api.security.JwtUserDetails;
import com.abinbev.b2b.credit.utilities.exception.IssueEnum;
import com.abinbev.b2b.credit.utilities.exception.IssueHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.util.Collections;
import java.util.List;

@Component
public class JwtValidator {

    private static final Logger logger = LoggerFactory.getLogger(JwtValidator.class);

    private final JwtValidationTokenConfiguration configuration;

    @Autowired
    public JwtValidator(final JwtValidationTokenConfiguration configuration) {
        this.configuration = configuration;
    }

    public void validate(final String country, final String id) {
        this.validate(country, Collections.singletonList(id));
    }

    public void validate(final String country, final List<String> ids) {
        if (!shouldContinueValidation(country)) {
            return;
        }

        final String jwtUserId = getUserId();
        final List<String> tokenAccounts = this.findAccountIds();
        logger.info("Starting JWT validation for user '{}' with JWT accounts '{}' searching for credits '{}'", jwtUserId, tokenAccounts, ids);

        if (CollectionUtils.isEmpty(ids)) {
            logger.error("The user '{}' with no accounts on JWT is not allowed to search credits", jwtUserId);
            throw new JwtException(IssueHandler.createIssue(IssueEnum.FORBIDDEN));
        }

        for (String accountId : ids) {
            if (!tokenAccounts.contains(accountId)) {
                logger.error("The user '{}' is not allowed to use credit '{}'", jwtUserId, accountId);
                throw new JwtException(IssueHandler.createIssue(IssueEnum.FORBIDDEN));
            }
        }
        logger.info("The user '{}' is allowed to continue", jwtUserId);
    }


    private boolean shouldContinueValidation(final String country) {
        if (!configuration.shouldValidateTokenForCountry(country)) {
            logger.info("Ignoring JWT validation because it is disabled for country '{}'", country);
            return false;
        }

        if (isServerToServerCall()) {
            logger.info("Ignoring JWT validation because it is a server to server call");
            return false;
        }

        if (configuration.isEnabledOnlyB2B() && !isAppTypeB2B()) {
            logger.info("Ignoring JWT validation because it is not a B2B call");
            return false;
        }

        return true;
    }
    
    private boolean isServerToServerCall() {
        final JwtUserDetails jwtUserDetails = getJwtUserDetails();
        if (jwtUserDetails == null || jwtUserDetails.getType() == null) {
            return true;
        }
        return JwtTypeEnum.SERVER_TO_SERVER.equals(jwtUserDetails.getType());
    }

    private String getUserId() {
        final JwtUserDetails jwtUserDetails = getJwtUserDetails();
        if (jwtUserDetails == null || jwtUserDetails.getUserId() == null) {
            return null;
        }
        return jwtUserDetails.getUserId();
    }

    private boolean isAppTypeB2B() {
        final JwtUserDetails jwtUserDetails = getJwtUserDetails();

        if (jwtUserDetails == null) {
            return false;
        }

        if (jwtUserDetails.getAppType() == null || jwtUserDetails.getAppType().isEmpty()) {
            return true;
        }

        return jwtUserDetails.getAppType().equalsIgnoreCase(configuration.getB2bAppTypeClaimValue());
    }

    private JwtUserDetails getJwtUserDetails() {
        return (JwtUserDetails) SecurityContextHolder
                .getContext()
                .getAuthentication()
                .getDetails();
    }

    public List<String> findAccountIds() {
        final JwtUserDetails jwtUserDetails = getJwtUserDetails();

        if (jwtUserDetails == null || jwtUserDetails.getAccountIds() == null) {
            return Collections.emptyList();
        }
        return jwtUserDetails.getAccountIds();
    }
}
