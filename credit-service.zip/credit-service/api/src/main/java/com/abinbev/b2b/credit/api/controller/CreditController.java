package com.abinbev.b2b.credit.api.controller;

import com.abinbev.b2b.credit.api.domain.CreditStatement;
import com.abinbev.b2b.credit.api.exception.ErrorResponse;
import com.abinbev.b2b.credit.api.helper.constant.ApiConstants;
import com.abinbev.b2b.credit.utilities.domain.Credit;
import com.abinbev.b2b.credit.utilities.vo.CreditConsumptionRequest;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;

import javax.validation.Valid;
import java.util.List;

import static com.abinbev.b2b.credit.api.helper.constant.ApiConstants.STATUS_503_SERVICE_UNAVAILABLE;
import static javax.servlet.http.HttpServletResponse.SC_BAD_REQUEST;
import static javax.servlet.http.HttpServletResponse.SC_SERVICE_UNAVAILABLE;

public interface CreditController {

    @ApiOperation(value = "Retrieves a credit given an id")
    @ApiResponses(value = { @ApiResponse(code = 200, message = ApiConstants.STATUS_200_OK), @ApiResponse(code = 400, response = ErrorResponse.class, message = ApiConstants.STATUS_400_BAD_REQUEST),
            @ApiResponse(code = 404, message = ApiConstants.STATUS_404_NOT_FOUND), })
    ResponseEntity<Credit> get(@ApiParam(value = "Country/region. ISO 3166 alpha-2 country code", required = true) @RequestHeader(value = "country") final String country,
                               @ApiParam(value = "Credit unique identifier", required = true) @PathVariable("id") final String id);

    @ApiOperation(value = "Update b2b credit consumption")
    @ApiResponses(value = { @ApiResponse(code = SC_BAD_REQUEST, message = ApiConstants.STATUS_400_BAD_REQUEST), @ApiResponse(code = 404, message = ApiConstants.STATUS_404_NOT_FOUND),
            @ApiResponse(code = SC_SERVICE_UNAVAILABLE, message = STATUS_503_SERVICE_UNAVAILABLE) })
    @ResponseStatus(HttpStatus.OK)
    ResponseEntity<Void> updateCreditConsumption(@ApiParam(value = "Country/region. ISO 3166 alpha-2 country code", required = true) @RequestHeader(value = "country") final String country,
                                                 @ApiParam(hidden = true) @RequestHeader(value = "isAccountService", required = false) final boolean isAccountService,
                                                 @Valid @RequestBody final CreditConsumptionRequest request);

    @ApiOperation(value = "Retrieve Credit Statement by Account ID.")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = ApiConstants.STATUS_200_OK),
            @ApiResponse(code = 400, response = ErrorResponse.class, message = ApiConstants.STATUS_400_BAD_REQUEST),
    })
    ResponseEntity<List<CreditStatement>> getCreditStatement(
            @ApiParam(value = "Country/region. ISO 3166 alpha-2 country code", required = true)
            @RequestHeader(value = "country") final String country,
            @RequestHeader(name = ApiConstants.AUTHORIZATION, required = false) final String authorization,
            @ApiParam(value = "Point of consumption unique identifier", required = true)
            @RequestParam(value = "accountId") final String accountId
    );

    @ApiOperation(value = "Retrieves a list of credit given a list of accountIds")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = ApiConstants.STATUS_200_OK),
            @ApiResponse(code = 400, response = ErrorResponse.class, message = ApiConstants.STATUS_400_BAD_REQUEST)
    })
    ResponseEntity<List<Credit>> list(
            @ApiParam(value = "Country/region. ISO 3166 alpha-2 country code", required = true)
            @RequestHeader(value = "country") final String country,
            @ApiParam("Point of consumption unique identifier")
            @RequestParam(value = "accountId")  final List<String> accountIds
    );
}
