package com.abinbev.b2b.credit.api.security;

import com.abinbev.b2b.credit.api.exception.JwtException;
import com.abinbev.b2b.credit.utilities.exception.IssueEnum;
import com.abinbev.b2b.credit.utilities.exception.IssueHandler;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.web.access.AccessDeniedHandler;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

class AccessDeniedExceptionHandler implements AccessDeniedHandler {
    @Override
    public void handle(final HttpServletRequest request, final HttpServletResponse response, final AccessDeniedException accessDeniedException) throws IOException, ServletException {
        JwtResponseExceptionHandler.handleException(response, new JwtException(IssueHandler.createIssue(IssueEnum.FORBIDDEN)));
    }
}
