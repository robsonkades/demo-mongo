package com.abinbev.b2b.credit.api.helper;

import com.abinbev.b2b.credit.utilities.config.DatabaseCollectionsConfiguration;
import com.abinbev.b2b.credit.utilities.exception.BadRequestException;
import com.abinbev.b2b.credit.utilities.exception.IssueEnum;
import com.abinbev.b2b.credit.utilities.exception.IssueHandler;
import com.google.common.collect.ImmutableSet;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Locale;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class ControllerValidator {

    private static final Set<String> ISO_COUNTRIES = ImmutableSet.copyOf(Locale.getISOCountries());

    private final DatabaseCollectionsConfiguration collectionsConfiguration;

    @Autowired
    public ControllerValidator(final DatabaseCollectionsConfiguration collectionsConfiguration) {
        this.collectionsConfiguration = collectionsConfiguration;
    }

    public void validateRequestTraceId(final String requestTraceId) {

        if (StringUtils.isBlank(requestTraceId)) {
            throw new BadRequestException(IssueHandler.createIssue(IssueEnum.REQUEST_TRACE_ID_NOT_VALID, requestTraceId));
        }
    }

    public void validateCountry(final String country) {
        if (StringUtils.isBlank(country) || !ISO_COUNTRIES.contains(country)) {
            throw new BadRequestException(IssueHandler.createIssue(IssueEnum.INVALID_COUNTRY, country));
        }
    }

    public void validateIfCountryIsSupported(final String country) {
        final Set<String> supportedCountries = this.collectionsConfiguration.getSupportedCountries();
        if (!supportedCountries.contains(country.toLowerCase())) {
            throw new BadRequestException(IssueHandler.createIssue(IssueEnum.UNSUPPORTED_COUNTRY, country, supportedCountries
                    .stream()
                    .map(String::toUpperCase)
                    .collect(Collectors.toSet())));
        }
    }
}
