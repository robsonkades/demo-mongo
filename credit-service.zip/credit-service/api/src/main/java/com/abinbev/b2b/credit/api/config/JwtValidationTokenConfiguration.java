package com.abinbev.b2b.credit.api.config;

import java.lang.reflect.Type;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

@Configuration
@ConfigurationProperties(prefix = "features.jwtvalidation")
public class JwtValidationTokenConfiguration {

	private static final Logger logger = LoggerFactory.getLogger(JwtValidationTokenConfiguration.class);

	private static final String DEFAULT_KEY = "default";

	private static final String COMMA_SEPARATOR = ",";

	private static final boolean DEFAULT_VALUE = false;

	@Value("#{environment.FEATURES_JWT_VALIDATION_ENABLED_PER_COUNTRY}")
	private String enabledPerCountryFromEnv;

	private Map<String, Boolean> enabledPerCountry;

	@Value("#{environment.FEATURES_JWT_VALIDATION_SERVER_TO_SERVER_ROLES}")
	private String serverToServerRolesFromEnv;

	private Set<String> serverToServerRoles;

	private boolean enabledOnlyB2B;

	private String rolesClaim;

	private String magentoUserIdClaim;

	private String magentoAccountIdsClaim;

	private String b2bUserIdClaim;

	private String b2bAccountIdsClaim;

	private String appTypeClaim;

	private String b2bAppTypeClaimValue;

	public boolean isEnabledOnlyB2B() {
		return enabledOnlyB2B;
	}

	public void setEnabledOnlyB2B(final boolean enabledOnlyB2B) {
		this.enabledOnlyB2B = enabledOnlyB2B;
	}

	public String getRolesClaim() {
		return rolesClaim;
	}

	public void setRolesClaim(final String rolesClaim) {
		this.rolesClaim = rolesClaim;
	}

	public String getMagentoUserIdClaim() {
		return magentoUserIdClaim;
	}

	public void setMagentoUserIdClaim(final String magentoUserIdClaim) {
		this.magentoUserIdClaim = magentoUserIdClaim;
	}

	public String getMagentoAccountIdsClaim() {
		return magentoAccountIdsClaim;
	}

	public void setMagentoAccountIdsClaim(final String magentoAccountIdsClaim) {
		this.magentoAccountIdsClaim = magentoAccountIdsClaim;
	}

	public String getB2bUserIdClaim() {
		return b2bUserIdClaim;
	}

	public void setB2bUserIdClaim(final String b2bUserIdClaim) {
		this.b2bUserIdClaim = b2bUserIdClaim;
	}

	public String getB2bAccountIdsClaim() {
		return b2bAccountIdsClaim;
	}

	public void setB2bAccountIdsClaim(final String b2bAccountIdsClaim) {
		this.b2bAccountIdsClaim = b2bAccountIdsClaim;
	}

	public String getAppTypeClaim() {
		return appTypeClaim;
	}

	public void setAppTypeClaim(final String appTypeClaim) {
		this.appTypeClaim = appTypeClaim;
	}

	public String getB2bAppTypeClaimValue() {
		return b2bAppTypeClaimValue;
	}

	public void setB2bAppTypeClaimValue(final String b2bAppTypeClaimValue) {
		this.b2bAppTypeClaimValue = b2bAppTypeClaimValue;
	}

	public Map<String, Boolean> getEnabledPerCountry() {
		return enabledPerCountry;
	}

	public void setEnabledPerCountry(final Map<String, Boolean> enabledPerCountry) {
		if (StringUtils.isNotBlank(this.enabledPerCountryFromEnv)) {
			try {
				final Type type = new TypeToken<Map<String, Boolean>>() {
				}.getType();
				this.enabledPerCountry = new Gson().fromJson(enabledPerCountryFromEnv, type);
			} catch (final Exception e) {
				logger.error(e.getMessage(), e);
			}
		} else {
			this.enabledPerCountry = enabledPerCountry;
		}
	}

	public Set<String> getServerToServerRoles() {
		return serverToServerRoles;
	}

	public void setServerToServerRoles(final Set<String> serverToServerRoles) {
		if (StringUtils.isNotBlank(this.serverToServerRolesFromEnv)) {
			try {
				this.serverToServerRoles = Stream.of(this.serverToServerRolesFromEnv.trim().split(COMMA_SEPARATOR))
						.map(String::trim)
						.collect(Collectors.toSet());
			} catch (final Exception e) {
				logger.error(e.getMessage(), e);
			}
		} else {
			this.serverToServerRoles = serverToServerRoles;
		}
	}

	public boolean shouldValidateTokenForCountry(final String country) {
		return country != null && enabledPerCountry != null && this.enabledPerCountry.getOrDefault(country.toLowerCase(), enabledPerCountry.getOrDefault(DEFAULT_KEY, DEFAULT_VALUE));
	}
}