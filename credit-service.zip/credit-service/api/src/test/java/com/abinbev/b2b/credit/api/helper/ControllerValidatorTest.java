package com.abinbev.b2b.credit.api.helper;

import com.abinbev.b2b.credit.utilities.config.DatabaseCollectionsConfiguration;
import com.abinbev.b2b.credit.utilities.exception.BadRequestException;
import com.abinbev.b2b.credit.utilities.exception.IssueEnum;
import com.google.common.collect.ImmutableSet;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Collections;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class ControllerValidatorTest {

    @Mock
    private DatabaseCollectionsConfiguration collectionProperties;

    @InjectMocks
    private ControllerValidator validator;

    @Test
    public void testValidateRequestTraceId() {
        assertThatCode(() -> this.validator.validateRequestTraceId(UUID
                                                                           .randomUUID()
                                                                           .toString())).doesNotThrowAnyException();
    }

    @Test(expected = BadRequestException.class)
    public void testValidateNullRequestTraceId() {
        try {
            this.validator.validateRequestTraceId(null);
        } catch (final BadRequestException e) {
            assertThat(e.getIssues()).isNotEmpty();
            assertThat(e
                               .getIssues()
                               .size()).isOne();
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getCode()).isEqualTo(IssueEnum.REQUEST_TRACE_ID_NOT_VALID.getCode());
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getMessage()).isEqualTo(IssueEnum.REQUEST_TRACE_ID_NOT_VALID.getFormattedMessage(null));
            throw e;
        }
    }

    @Test(expected = BadRequestException.class)
    public void testValidateEmptyRequestTraceId() {
        try {
            this.validator.validateRequestTraceId(StringUtils.EMPTY);
        } catch (final BadRequestException e) {
            assertThat(e.getIssues()).isNotEmpty();
            assertThat(e
                               .getIssues()
                               .size()).isOne();
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getCode()).isEqualTo(IssueEnum.REQUEST_TRACE_ID_NOT_VALID.getCode());
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getMessage()).isEqualTo(IssueEnum.REQUEST_TRACE_ID_NOT_VALID.getFormattedMessage(StringUtils.EMPTY));
            throw e;
        }
    }

    @Test(expected = BadRequestException.class)
    public void testValidateSpaceRequestTraceId() {
        try {
            this.validator.validateRequestTraceId(StringUtils.SPACE);
        } catch (final BadRequestException e) {
            assertThat(e.getIssues()).isNotEmpty();
            assertThat(e
                               .getIssues()
                               .size()).isOne();
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getCode()).isEqualTo(IssueEnum.REQUEST_TRACE_ID_NOT_VALID.getCode());
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getMessage()).isEqualTo(IssueEnum.REQUEST_TRACE_ID_NOT_VALID.getFormattedMessage(StringUtils.SPACE));
            throw e;
        }
    }

    @Test
    public void testValidateCountry() {
        assertThatCode(() -> this.validator.validateCountry("BR")).doesNotThrowAnyException();
    }

    @Test(expected = BadRequestException.class)
    public void testValidateNullCountry() {
        try {
            this.validator.validateCountry(null);
        } catch (final BadRequestException e) {
            assertThat(e.getIssues()).isNotEmpty();
            assertThat(e
                               .getIssues()
                               .size()).isOne();
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getCode()).isEqualTo(IssueEnum.INVALID_COUNTRY.getCode());
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getMessage()).isEqualTo(IssueEnum.INVALID_COUNTRY.getFormattedMessage(null));
            throw e;
        }
    }

    @Test(expected = BadRequestException.class)
    public void testValidateInvalidCountry() {
        final String invalidCountry = "XPTO";
        try {
            this.validator.validateCountry(invalidCountry);
        } catch (final BadRequestException e) {
            assertThat(e.getIssues()).isNotEmpty();
            assertThat(e
                               .getIssues()
                               .size()).isOne();
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getCode()).isEqualTo(IssueEnum.INVALID_COUNTRY.getCode());
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getMessage()).isEqualTo(IssueEnum.INVALID_COUNTRY.getFormattedMessage(invalidCountry));
            throw e;
        }
    }

    @Test(expected = BadRequestException.class)
    public void testValidateEmptyCountry() {
        try {
            this.validator.validateCountry(StringUtils.EMPTY);
        } catch (final BadRequestException e) {
            assertThat(e.getIssues()).isNotEmpty();
            assertThat(e
                               .getIssues()
                               .size()).isOne();
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getCode()).isEqualTo(IssueEnum.INVALID_COUNTRY.getCode());
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getMessage()).isEqualTo(IssueEnum.INVALID_COUNTRY.getFormattedMessage(StringUtils.EMPTY));
            throw e;
        }
    }

    @Test(expected = BadRequestException.class)
    public void testValidateSpaceCountry() {
        try {
            this.validator.validateCountry(StringUtils.SPACE);
        } catch (final BadRequestException e) {
            assertThat(e.getIssues()).isNotEmpty();
            assertThat(e
                               .getIssues()
                               .size()).isOne();
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getCode()).isEqualTo(IssueEnum.INVALID_COUNTRY.getCode());
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getMessage()).isEqualTo(IssueEnum.INVALID_COUNTRY.getFormattedMessage(StringUtils.SPACE));
            throw e;
        }
    }

    @Test
    public void testValidateSupportedCountry() {
        when(collectionProperties.getSupportedCountries()).thenReturn(ImmutableSet.of("ar","br"));
        assertThatCode(() -> this.validator.validateIfCountryIsSupported("AR")).doesNotThrowAnyException();
    }

    @Test(expected = BadRequestException.class)
    public void testValidateSupportedCountryEmptySupportedCountries() {
        when(collectionProperties.getSupportedCountries()).thenReturn(Collections.emptySet());
        try {
            this.validator.validateIfCountryIsSupported("PY");
        } catch (final BadRequestException e) {
            assertThat(e.getIssues()).isNotEmpty();
            assertThat(e
                               .getIssues()
                               .size()).isOne();
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getCode()).isEqualTo(IssueEnum.UNSUPPORTED_COUNTRY.getCode());
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getMessage()).isEqualTo("The country 'PY' is not supported. The supported countries are []");
            throw e;
        }
    }

    @Test(expected = BadRequestException.class)
    public void testValidateUnsupportedCountry() {
        when(collectionProperties.getSupportedCountries()).thenReturn(ImmutableSet.of("ar","br"));
        try {
            this.validator.validateIfCountryIsSupported("US");
        } catch (BadRequestException e) {
            assertThat(e.getIssues()).isNotEmpty();
            assertThat(e
                               .getIssues()
                               .size()).isOne();
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getCode()).isEqualTo(IssueEnum.UNSUPPORTED_COUNTRY.getCode());
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getMessage()).isEqualTo("The country 'US' is not supported. The supported countries are [BR, AR]");
            throw e;
        }
    }
}