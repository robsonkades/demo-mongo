package com.abinbev.b2b.credit.api.remote.client;

import static com.abinbev.b2b.credit.api.helper.constant.ApiConstants.ACCOUNT_REMOTE_SERVICE;
import static com.abinbev.b2b.credit.api.remote.client.AccountClient.IS_CREDIT_SERVICE_HEADER;
import static com.abinbev.b2b.credit.api.remote.client.AccountClient.STRING_TRUE_VALUE;
import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpClientErrorException;

import com.abinbev.b2b.credit.api.helper.constant.ApiConstants;
import com.abinbev.b2b.credit.api.remote.client.AccountClient.CreditConsumptionRequest;
import com.abinbev.b2b.credit.utilities.remote.client.RemoteClient;
import com.google.common.collect.ImmutableList;

@RunWith(MockitoJUnitRunner.class)
public class AccountClientTest {

    @Mock
    private RemoteClient remoteClient;

    @InjectMocks
    private AccountClient client;

    @Captor
    private ArgumentCaptor<HttpHeaders> headerCaptor;

    @Before
    public void setUp() throws Exception {
        ReflectionTestUtils.setField(this.client, "url", "http://account-service");
    }

    @Test
    public void creditConsumption() {
        MDC.put(ApiConstants.REQUEST_TRACE_ID_HEADER, "test-123");

        this.client.creditConsumption("DO", "123", BigDecimal.TEN);
        verify(this.remoteClient, times(1)).postForObject(eq("http://account-service/credit/consumption"), headerCaptor.capture(), eq(new CreditConsumptionRequest("123", BigDecimal.TEN)), any() , eq(ACCOUNT_REMOTE_SERVICE));

        final HttpHeaders value = headerCaptor.getValue();
        assertThat(value).isNotNull();
        assertThat(value.get(ApiConstants.COUNTRY_HEADER)).isNotEmpty().hasSize(1).isEqualTo(ImmutableList.of("DO"));
        assertThat(value.get(ApiConstants.REQUEST_TRACE_ID_HEADER)).isNotEmpty().hasSize(1).isEqualTo(ImmutableList.of("test-123"));
        assertThat(value.get(IS_CREDIT_SERVICE_HEADER)).isNotEmpty().hasSize(1).isEqualTo(ImmutableList.of(STRING_TRUE_VALUE));
    }

    @Test(expected = HttpClientErrorException.class)
    public void creditConsumptionWithError() {
        MDC.put(ApiConstants.REQUEST_TRACE_ID_HEADER, "test-123");

        final HttpHeaders headers = new HttpHeaders();
        headers.add(ApiConstants.COUNTRY_HEADER, "DO");
        headers.add(ApiConstants.REQUEST_TRACE_ID_HEADER, String.valueOf(MDC.get(ApiConstants.REQUEST_TRACE_ID_HEADER)));
        headers.add(IS_CREDIT_SERVICE_HEADER, STRING_TRUE_VALUE);

        when(this.remoteClient.postForObject("http://account-service/credit/consumption", headers, new CreditConsumptionRequest("123", BigDecimal.TEN), null , ACCOUNT_REMOTE_SERVICE)).thenThrow(new HttpClientErrorException(
                HttpStatus.BAD_REQUEST));

        try {
            this.client.creditConsumption("DO", "123", BigDecimal.TEN);
        } catch (final HttpClientErrorException e) {
            verify(this.remoteClient, times(1)).postForObject("http://account-service/credit/consumption", headers, new CreditConsumptionRequest("123", BigDecimal.TEN), null , ACCOUNT_REMOTE_SERVICE);
            throw e;
        }
    }
}