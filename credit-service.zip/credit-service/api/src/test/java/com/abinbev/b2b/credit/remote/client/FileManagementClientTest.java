package com.abinbev.b2b.credit.remote.client;


import com.abinbev.b2b.credit.api.helper.constant.ApiConstants;
import com.abinbev.b2b.credit.api.remote.client.FileManagementClient;
import com.abinbev.b2b.credit.api.remote.response.FileManagementResponse;
import com.abinbev.b2b.credit.utilities.remote.client.RemoteClient;
import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.slf4j.MDC;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static java.lang.String.format;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class FileManagementClientTest {

    private static final BigDecimal BALANCE_VALUE = BigDecimal.valueOf(100.1);
    private static final String BALANCE_KEY = "creditBalance";
    private static final String ACCOUNT_ID_VALUE = "12345";
    private static final String ACCOUNT_ID_KEY = "accountId";
    private static final String DATE_VALUE = "04/2018";
    private static final String DATE_KEY = "date";
    private static final String QUERY_PARAMETERS = "?purpose={purpose}&metadata={metadata}";
    private static final String FILE_MANAGEMENT_SERVICE_URL = "http://localhost:8080/files";
    private static final String COUNTRY_BR = "br";
    private static final String AUTHORIZATION = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9";
    private static final String REMOTE_SERVICE_FILE_MANAGEMENT = "file-management-service";
    private static final String PURPOSE = "credit-statement";
    private static final String FORMAT_PATTERN_COLON = "%s:%s";
    private static final String FORMAT_PATTERN = "%s%s";
    private static final String URL_EXPIRES_AT = "2019-04-22T13:58:21.763Z";
    private static final String CREATION_DATE = "2019-04-22T20:30:34Z";
    private static final String FILE_TYPE = "pdf";
    private static final String TITLE = "Title";
    private static final String FILE_URL = "https://www.example.com/files/file1.pdf";
    private static final String REQUEST_TRACE_ID = "unit-test";

    @InjectMocks
    private FileManagementClient client;

    @Mock
    private RemoteClient remoteClient;

    @Before
    public void setup() {
        MDC.put(ApiConstants.REQUEST_TRACE_ID_HEADER, REQUEST_TRACE_ID);
        final String fileManagementServiceUrl = FILE_MANAGEMENT_SERVICE_URL;
        ReflectionTestUtils.setField(client, "remoteClient", remoteClient);
        ReflectionTestUtils.setField(client, "fileManagementServiceUrl", fileManagementServiceUrl);
    }

    @Test
    public void findExistentFile()  {
        final FileManagementResponse[] fileManagementResponse = buildFileManagementResponse();
        final String accountId = String.format(FORMAT_PATTERN, ACCOUNT_ID_KEY, ACCOUNT_ID_VALUE);
        when(remoteClient.getForObject(buildUrl(), buildRequestHeader(COUNTRY_BR, AUTHORIZATION, REQUEST_TRACE_ID), FileManagementResponse[].class, REMOTE_SERVICE_FILE_MANAGEMENT, PURPOSE, String.format(FORMAT_PATTERN, ACCOUNT_ID_KEY, ACCOUNT_ID_VALUE))).thenReturn(ResponseEntity.ok(fileManagementResponse));
        final List<FileManagementResponse> fileManagementResponseList = client.findByAccountId(COUNTRY_BR, accountId, PURPOSE, AUTHORIZATION);

        assertThat(fileManagementResponseList).isNotEmpty();
        assertThat(fileManagementResponseList.get(0)).isEqualTo(fileManagementResponse[0]);
        verify(remoteClient, times(1)).getForObject(buildUrl(), buildRequestHeader(COUNTRY_BR, AUTHORIZATION, REQUEST_TRACE_ID), FileManagementResponse[].class, REMOTE_SERVICE_FILE_MANAGEMENT, PURPOSE, String.format(FORMAT_PATTERN, ACCOUNT_ID_KEY, ACCOUNT_ID_VALUE));
    }

    @Test
    public void findNonExistentFile() {
        final FileManagementResponse[] fileManagementResponse = {};
        final String accountId = String.format(FORMAT_PATTERN, ACCOUNT_ID_KEY, ACCOUNT_ID_VALUE);
        when(remoteClient.getForObject(buildUrl(), buildRequestHeader(COUNTRY_BR, AUTHORIZATION, REQUEST_TRACE_ID), FileManagementResponse[].class, REMOTE_SERVICE_FILE_MANAGEMENT, PURPOSE, String.format(FORMAT_PATTERN, ACCOUNT_ID_KEY, ACCOUNT_ID_VALUE))).thenReturn(ResponseEntity.ok(fileManagementResponse));
        final List<FileManagementResponse> responseCollection = client.findByAccountId(COUNTRY_BR, accountId, PURPOSE, AUTHORIZATION);
        assertThat(responseCollection).isEmpty();
        verify(remoteClient, times(1)).getForObject(buildUrl(), buildRequestHeader(COUNTRY_BR, AUTHORIZATION, REQUEST_TRACE_ID), FileManagementResponse[].class, REMOTE_SERVICE_FILE_MANAGEMENT, PURPOSE, String.format(FORMAT_PATTERN, ACCOUNT_ID_KEY, ACCOUNT_ID_VALUE));
    }

    private String buildUrl() {
        return format(FORMAT_PATTERN, FILE_MANAGEMENT_SERVICE_URL, QUERY_PARAMETERS);
    }

    private HttpHeaders buildRequestHeader(final String country, final String authorization, final String requestTraceId){
        final HttpHeaders headers = new HttpHeaders();
        headers.add(ApiConstants.COUNTRY_HEADER, country);
        headers.add(ApiConstants.REQUEST_TRACE_ID_HEADER, requestTraceId);
        if (StringUtils.isNotEmpty(authorization)) {
            headers.add(HttpHeaders.AUTHORIZATION, authorization);
        }
        return headers;
    }

    private FileManagementResponse[] buildFileManagementResponse() {
        final List<FileManagementResponse> responseList = new ArrayList<>();
        final FileManagementResponse response = new FileManagementResponse();
        response.setTitle(TITLE);
        response.setType(FILE_TYPE);
        response.setUrl(FILE_URL);
        response.setUrlExpiresAt(URL_EXPIRES_AT);
        response.setCreationDate(CREATION_DATE);

        final Map<String, String> metadata = new HashMap<>();
        metadata.put(DATE_KEY, DATE_VALUE);
        metadata.put(BALANCE_KEY, BALANCE_VALUE.toString());
        metadata.put(ACCOUNT_ID_KEY, ACCOUNT_ID_VALUE);
        response.setMetadata(metadata);

        responseList.add(response);

        return responseList.toArray(new FileManagementResponse[responseList.size()]);
    }
}
