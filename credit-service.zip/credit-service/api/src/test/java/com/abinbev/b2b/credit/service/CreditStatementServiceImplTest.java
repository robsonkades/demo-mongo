package com.abinbev.b2b.credit.service;

import com.abinbev.b2b.credit.api.domain.CreditStatement;
import com.abinbev.b2b.credit.api.remote.client.FileManagementClient;
import com.abinbev.b2b.credit.api.remote.response.FileManagementResponse;
import com.abinbev.b2b.credit.api.service.CreditStatementServiceImpl;
import com.google.common.collect.ImmutableList;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CreditStatementServiceImplTest {

    private static final BigDecimal BALANCE_VALUE = BigDecimal.valueOf(100.1);
    private static final String BALANCE_KEY = "creditBalance";
    private static final String DATE_VALUE = "04/2018";
    private static final String DATE_KEY = "date";
    private static final String ACCOUNT_ID_VALUE = "12345";
    private static final String ACCOUNT_ID_KEY = "accountId";
    private static final String URL_EXPIRES_AT = "2019-04-22T13:58:21.763Z";
    private static final String CREATION_DATE = "2019-04-22T20:30:34Z";
    private static final String FILE_TYPE = "pdf";
    private static final String TITLE = "Title";
    private static final String DATE_PATTERN = "MM/yyyy";
    private static final String COUNTRY_BR = "br";
    private static final String PURPOSE = "credit-statement";
    private static final String AUTHORIZATION = "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9";
    private static final String FILE_URL = "https://www.example.com/files/file1.pdf";
    private static final String FORMAT_PATTERN = "%s:%s";

    @Mock
    private FileManagementClient fileManagementClient;

    @InjectMocks
    private CreditStatementServiceImpl service;

    @Before
    public void setUp() {
        final Integer fileManagementMaxResults = 3;
        final String pattern = DATE_PATTERN;
        final String metadataDateField = DATE_KEY;
        final String accountParameterName = ACCOUNT_ID_KEY;
        final String fileManagementPurposeValue = PURPOSE;
        final String metadataBalanceField = BALANCE_KEY;
        ReflectionTestUtils.setField(service, "fileManagementMaxResults", fileManagementMaxResults);
        ReflectionTestUtils.setField(service, "pattern", pattern);
        ReflectionTestUtils.setField(service, "metadataDateField", metadataDateField);
        ReflectionTestUtils.setField(service, "accountParameterName", accountParameterName);
        ReflectionTestUtils.setField(service, "fileManagementPurposeValue", fileManagementPurposeValue);
        ReflectionTestUtils.setField(service, "metadataBalanceField", metadataBalanceField);
    }

    @Test
    public void testFindByAccountId() {
        final String accountId = String.format(FORMAT_PATTERN, ACCOUNT_ID_KEY, ACCOUNT_ID_VALUE);
        when(fileManagementClient.findByAccountId(COUNTRY_BR, accountId, PURPOSE, AUTHORIZATION)).thenReturn(buildFileManagementResponse());

        service.findByCountryAndAccountId(COUNTRY_BR, ACCOUNT_ID_VALUE, AUTHORIZATION);
        verify(fileManagementClient, times(1)).findByAccountId(COUNTRY_BR, accountId, PURPOSE, AUTHORIZATION);
    }

    @Test
    public void testGetCreditStatementSuccessWithValues() {
        final String accountId = String.format(FORMAT_PATTERN, ACCOUNT_ID_KEY, ACCOUNT_ID_VALUE);
        when(fileManagementClient.findByAccountId(COUNTRY_BR, accountId, PURPOSE, AUTHORIZATION)).thenReturn(buildFileManagementResponse());
        final List<CreditStatement> creditStatements = service.findByCountryAndAccountId(COUNTRY_BR, ACCOUNT_ID_VALUE, AUTHORIZATION);
        assertThat(creditStatements).isNotEmpty();
        final CreditStatement creditStatement = creditStatements.get(0);
        assertThat(creditStatement.getUrl()).isEqualTo(FILE_URL);
        assertThat(creditStatement.getBalance()).isEqualTo(BALANCE_VALUE);
        assertThat(creditStatement.getDate()).isEqualTo(DATE_VALUE);
        assertThat(creditStatement.getUrlExpiresAt()).isEqualTo(URL_EXPIRES_AT);
    }

    @Test
    public void testGetCreditStatementSuccessWithEmptyList() {
        final String accountId = String.format(FORMAT_PATTERN, ACCOUNT_ID_KEY, ACCOUNT_ID_VALUE);
        when(fileManagementClient.findByAccountId(COUNTRY_BR, accountId, PURPOSE, AUTHORIZATION)).thenReturn(Collections.emptyList());
        final List<CreditStatement> creditStatements = service.findByCountryAndAccountId(COUNTRY_BR, ACCOUNT_ID_VALUE, AUTHORIZATION);
        assertThat(creditStatements).isEmpty();
    }

    private List<FileManagementResponse> buildFileManagementResponse() {
        final FileManagementResponse response = new FileManagementResponse();
        response.setTitle(TITLE);
        response.setType(FILE_TYPE);
        response.setUrl(FILE_URL);
        response.setUrlExpiresAt(URL_EXPIRES_AT);
        response.setCreationDate(CREATION_DATE);

        final Map<String, String> metadata = new HashMap<>();
        metadata.put(DATE_KEY, DATE_VALUE);
        metadata.put(BALANCE_KEY, BALANCE_VALUE.toString());
        metadata.put(ACCOUNT_ID_KEY, ACCOUNT_ID_VALUE);
        response.setMetadata(metadata);

        return ImmutableList.of(response);
    }
}
