package com.abinbev.b2b.credit.api.config;

import static com.abinbev.b2b.credit.api.config.CreditConsumptionFeatureProperties.DEFAULT_KEY;
import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;

import org.apache.logging.log4j.util.Strings;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.google.common.collect.ImmutableMap;

@RunWith(MockitoJUnitRunner.class)
public class CreditConsumptionFeaturePropertiesTest {

    private static final String COUNTRY_BR = "br";

    private static final String COUNTRY_DO = "do";

    private static final String COUNTRY_ZA = "za";

    @InjectMocks
    private CreditConsumptionFeatureProperties properties;

    @Test
    public void shouldReplicateToAccountService() {
        this.properties.setDataReplicationEnabledPerCountry(ImmutableMap.of(COUNTRY_BR, true, COUNTRY_DO, false, DEFAULT_KEY, true));

        assertThat(this.properties.shouldReplicateToAccountService(COUNTRY_BR.toLowerCase())).isTrue();
        assertThat(this.properties.shouldReplicateToAccountService(COUNTRY_BR.toUpperCase())).isTrue();
        assertThat(this.properties.shouldReplicateToAccountService(COUNTRY_DO.toLowerCase())).isFalse();
        assertThat(this.properties.shouldReplicateToAccountService(COUNTRY_DO.toUpperCase())).isFalse();
        assertThat(this.properties.shouldReplicateToAccountService(COUNTRY_ZA.toLowerCase())).isTrue();
        assertThat(this.properties.shouldReplicateToAccountService(COUNTRY_ZA.toUpperCase())).isTrue();
    }

    @Test
    public void shouldReplicateToAccountServiceFromEnv() {

        final String json = ImmutableMap
                .of(COUNTRY_BR, false, COUNTRY_DO, true, DEFAULT_KEY, false)
                .toString();

        ReflectionTestUtils.setField(this.properties, "dataReplicationEnabledPerCountryFromEnv", json);

        this.properties.setDataReplicationEnabledPerCountry(ImmutableMap.of(COUNTRY_BR, true, COUNTRY_DO, false, DEFAULT_KEY, true));

        assertThat(this.properties.shouldReplicateToAccountService(COUNTRY_BR.toLowerCase())).isFalse();
        assertThat(this.properties.shouldReplicateToAccountService(COUNTRY_BR.toUpperCase())).isFalse();
        assertThat(this.properties.shouldReplicateToAccountService(COUNTRY_DO.toLowerCase())).isTrue();
        assertThat(this.properties.shouldReplicateToAccountService(COUNTRY_DO.toUpperCase())).isTrue();
        assertThat(this.properties.shouldReplicateToAccountService(COUNTRY_ZA.toLowerCase())).isFalse();
        assertThat(this.properties.shouldReplicateToAccountService(COUNTRY_ZA.toUpperCase())).isFalse();
    }

    @Test
    public void shouldReplicateToAccountServiceWithNullProperties() {
        this.properties.setDataReplicationEnabledPerCountry(null);
        assertThat(this.properties.shouldReplicateToAccountService(COUNTRY_BR)).isFalse();
    }

    @Test
    public void shouldReplicateToAccountServiceWithBlankArgument() {
        assertThat(this.properties.shouldReplicateToAccountService(null)).isFalse();
        assertThat(this.properties.shouldReplicateToAccountService(Strings.EMPTY)).isFalse();
        assertThat(this.properties.shouldReplicateToAccountService("  ")).isFalse();
    }
}