package com.abinbev.b2b.credit.api.config;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class JwtValidationTokenConfigurationTest {

    private static final String DEFAULT_VALUE = "default";

    private static final String RAW_SERVER_TO_SERVER_ROLES = "Write,,,,  Read  , Space Role ,";

    private static final String WRITE_ROLE = "Write";

    private static final String EMPTY_ROLE = "";

    private static final String READ_ROLE = "Read";

    private static final String SPACE_ROLE = "Space Role";

    private static final Boolean IS_ENABLED_DEFAULT = false;

    private static final String SPACE_STRING = " ";

    private static final String EMPTY_STRING = "";

    private static final String UNMAPPED_COUNTRY = "bla";

    private static final String COUNTRY_ZA = "za";

    private static final Boolean IS_ENABLED_COUNTRY_ZA = false;

    private static final String COUNTRY_BR = "br";

    private static final Boolean IS_ENABLED_COUNTRY_BR = true;

    private static final Map<String, Boolean> enabledPerCountry = new HashMap<>();

    private static final Set<String> serverToServerRoles = new HashSet<>();

    @InjectMocks
    private JwtValidationTokenConfiguration config;

    @Before
    public void setUp() {
        enabledPerCountry.put(DEFAULT_VALUE, IS_ENABLED_DEFAULT);
        enabledPerCountry.put(COUNTRY_BR, IS_ENABLED_COUNTRY_BR);
        enabledPerCountry.put(COUNTRY_ZA, IS_ENABLED_COUNTRY_ZA);
        serverToServerRoles.add(WRITE_ROLE);
        serverToServerRoles.add(EMPTY_ROLE);
        serverToServerRoles.add(READ_ROLE);
        serverToServerRoles.add(SPACE_ROLE);
        ReflectionTestUtils.setField(config, "enabledPerCountry", enabledPerCountry);
        ReflectionTestUtils.setField(config, "serverToServerRoles", serverToServerRoles);
    }

    @Test
    public void testValidateTokenForCountryValid() {
        assertThat(config.shouldValidateTokenForCountry(COUNTRY_ZA)).isEqualTo(IS_ENABLED_COUNTRY_ZA);
        assertThat(config.shouldValidateTokenForCountry(COUNTRY_BR)).isEqualTo(IS_ENABLED_COUNTRY_BR);
    }

    @Test
    public void testValidateTokenForCountryInvalid() {
        assertThat(config.shouldValidateTokenForCountry(UNMAPPED_COUNTRY)).isEqualTo(IS_ENABLED_DEFAULT);
        assertThat(config.shouldValidateTokenForCountry(null)).isEqualTo(IS_ENABLED_DEFAULT);
        assertThat(config.shouldValidateTokenForCountry(EMPTY_STRING)).isEqualTo(IS_ENABLED_DEFAULT);
        assertThat(config.shouldValidateTokenForCountry(SPACE_STRING)).isEqualTo(IS_ENABLED_DEFAULT);
    }

    @Test
    public void testLoadFromEnv() {
        ReflectionTestUtils.setField(config, "enabledPerCountryFromEnv", enabledPerCountry.toString());
        ReflectionTestUtils.setField(config, "serverToServerRolesFromEnv", RAW_SERVER_TO_SERVER_ROLES);

        config.setEnabledPerCountry(null);
        config.setServerToServerRoles(null);
        assertThat(config.getEnabledPerCountry()).isEqualTo(enabledPerCountry);
        assertThat(config.getServerToServerRoles()).isEqualTo(serverToServerRoles);
    }
}