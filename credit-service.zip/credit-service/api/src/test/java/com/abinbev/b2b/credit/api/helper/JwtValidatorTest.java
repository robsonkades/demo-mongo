package com.abinbev.b2b.credit.api.helper;

import com.abinbev.b2b.credit.api.config.JwtValidationTokenConfiguration;
import com.abinbev.b2b.credit.api.exception.JwtException;
import com.abinbev.b2b.credit.api.security.JwtTypeEnum;
import com.abinbev.b2b.credit.api.security.JwtUserDetails;
import org.apache.logging.log4j.util.Strings;
import org.junit.Test;
import org.junit.runner.RunWith;
import static org.mockito.ArgumentMatchers.any;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Collections;
import java.util.List;

@RunWith(MockitoJUnitRunner.class)
public class JwtValidatorTest {

    private static final String USER_ID = "5d0caa55-a5d8-4c12-ad9c-2c306eddc2c9";
    private static final String ACCOUNT_ID = "3211124";
    private static final List<String> TOKEN_ACCOUNTS = Collections.singletonList(ACCOUNT_ID);
    private static final String COUNTRY_ZA = "ZA";
    private static final String INVALID_ACCOUNT_ID = "112233";
    private static final String JWT_APP_TYPE = "appType";

    private final UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(null, null, null);

    @InjectMocks
    private JwtValidator jwtValidator;

    @Mock
    private JwtValidationTokenConfiguration jwtValidationTokenConfiguration;


    @Test
    public void testValidatePermissionOnTokenWithValidTokenAccounts() {
        doReturn(true).when(jwtValidationTokenConfiguration).shouldValidateTokenForCountry(any(String.class));
        setUpContextHolder(JwtTypeEnum.USER_TO_SERVER, TOKEN_ACCOUNTS);
        jwtValidator.validate(COUNTRY_ZA, ACCOUNT_ID);
        setUpContextHolder(JwtTypeEnum.SERVER_TO_SERVER, TOKEN_ACCOUNTS);
        jwtValidator.validate(COUNTRY_ZA, ACCOUNT_ID);
    }

    @Test(expected = JwtException.class)
    public void testValidatePermissionOnTokenWithTokenAccountListWithEmptyAccounts() {
        doReturn(true).when(jwtValidationTokenConfiguration).shouldValidateTokenForCountry(any(String.class));
        setUpContextHolder(JwtTypeEnum.USER_TO_SERVER, Collections.emptyList());
        jwtValidator.validate(COUNTRY_ZA, ACCOUNT_ID);
    }

    @Test(expected = JwtException.class)
    public void testValidatePermissionOnTokenWithNullTokenAccountList() {
        doReturn(true).when(jwtValidationTokenConfiguration).shouldValidateTokenForCountry(any(String.class));
        setUpContextHolder(JwtTypeEnum.USER_TO_SERVER, null);
        jwtValidator.validate(COUNTRY_ZA, ACCOUNT_ID);
    }

    @Test(expected = JwtException.class)
    public void testValidatePermissionOnTokenWithInvalidTokenAccountList() {
        doReturn(true).when(jwtValidationTokenConfiguration).shouldValidateTokenForCountry(any(String.class));
        setUpContextHolder(JwtTypeEnum.USER_TO_SERVER, Collections.singletonList(INVALID_ACCOUNT_ID));
        jwtValidator.validate(COUNTRY_ZA, ACCOUNT_ID);
    }

    @Test(expected = JwtException.class)
    public void testValidatePermissionOnTokenWithEmptyIdsAndEmptyTokenAccounts() {
        doReturn(true).when(jwtValidationTokenConfiguration).shouldValidateTokenForCountry(any(String.class));
        setUpContextHolder(JwtTypeEnum.USER_TO_SERVER, Collections.emptyList());
        jwtValidator.validate(COUNTRY_ZA, Strings.EMPTY);
    }

    @Test(expected = JwtException.class)
    public void testValidatePermissionOnTokenWithInvalidAccountsRequest() {
        doReturn(true).when(jwtValidationTokenConfiguration).shouldValidateTokenForCountry(any(String.class));
        setUpContextHolder(JwtTypeEnum.USER_TO_SERVER, TOKEN_ACCOUNTS);
        jwtValidator.validate(COUNTRY_ZA, INVALID_ACCOUNT_ID);
    }

    @Test
    public void testValidatePermissionWithNoAuthorizationHeader() {
        final SecurityContext context = mock(SecurityContext.class);
        doReturn(true).when(jwtValidationTokenConfiguration).shouldValidateTokenForCountry(any(String.class));

        final UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(null, null, null);
        authentication.setDetails(null);
        SecurityContextHolder
                .getContext()
                .setAuthentication(authentication);

        when(context.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(context);

        jwtValidator.validate(COUNTRY_ZA, ACCOUNT_ID);
    }

    @Test
    public void testValidatePermissionOnTokenWithNullType() {
        doReturn(true).when(jwtValidationTokenConfiguration).shouldValidateTokenForCountry(any(String.class));
        setUpContextHolder(null, TOKEN_ACCOUNTS);
        jwtValidator.validate(COUNTRY_ZA, ACCOUNT_ID);
    }

    @Test
    public void testValidatePermissionOnTokenWithNullUserId() {
        final SecurityContext context = mock(SecurityContext.class);
        doReturn(true).when(jwtValidationTokenConfiguration).shouldValidateTokenForCountry(any(String.class));

        final UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(null, null, null);

        authentication.setDetails(new JwtUserDetails(JwtTypeEnum.USER_TO_SERVER, null, TOKEN_ACCOUNTS, null));
        context.setAuthentication(authentication);
        when(context.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(context);

        jwtValidator.validate(COUNTRY_ZA, ACCOUNT_ID);
    }

    public void testValidatePermissionOnTokenWhenIsEnabledOnlyB2B() {
        final SecurityContext context = mock(SecurityContext.class);
        doReturn(true).when(jwtValidationTokenConfiguration).shouldValidateTokenForCountry(any(String.class));
        doReturn(true).when(jwtValidationTokenConfiguration).isEnabledOnlyB2B();
        doReturn(JWT_APP_TYPE).when(jwtValidationTokenConfiguration).getB2bAppTypeClaimValue();

        final UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(null, null, null);

        authentication.setDetails(new JwtUserDetails(JwtTypeEnum.USER_TO_SERVER, null, TOKEN_ACCOUNTS, JWT_APP_TYPE));
        context.setAuthentication(authentication);
        when(context.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(context);

        jwtValidator.validate(COUNTRY_ZA, ACCOUNT_ID);
    }

    @Test(expected = JwtException.class)
    public void testValidatePermissionOnTokenWhenIsEnabledOnlyB2BWithInvalidAccountsRequest() {
        final SecurityContext context = mock(SecurityContext.class);
        doReturn(true).when(jwtValidationTokenConfiguration).shouldValidateTokenForCountry(any(String.class));
        doReturn(true).when(jwtValidationTokenConfiguration).isEnabledOnlyB2B();
        doReturn(JWT_APP_TYPE).when(jwtValidationTokenConfiguration).getB2bAppTypeClaimValue();

        final UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(null, null, null);

        authentication.setDetails(new JwtUserDetails(JwtTypeEnum.USER_TO_SERVER, null, TOKEN_ACCOUNTS, JWT_APP_TYPE));
        context.setAuthentication(authentication);
        when(context.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(context);

        jwtValidator.validate(COUNTRY_ZA, INVALID_ACCOUNT_ID);
    }

    @Test
    public void testValidatePermissionOnTokenWhenIsEnabledOnlyB2BWithNullAppType() {
        final SecurityContext context = mock(SecurityContext.class);
        doReturn(true).when(jwtValidationTokenConfiguration).shouldValidateTokenForCountry(any(String.class));
        doReturn(true).when(jwtValidationTokenConfiguration).isEnabledOnlyB2B();

        final UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(null, null, null);

        authentication.setDetails(new JwtUserDetails(JwtTypeEnum.USER_TO_SERVER, null, TOKEN_ACCOUNTS, null));
        context.setAuthentication(authentication);
        when(context.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(context);

        jwtValidator.validate(COUNTRY_ZA, ACCOUNT_ID);
    }

    @Test
    public void testValidatePermissionOnTokenWhenIsEnabledOnlyB2BWithEmptyAppType() {
        final SecurityContext context = mock(SecurityContext.class);
        doReturn(true).when(jwtValidationTokenConfiguration).shouldValidateTokenForCountry(any(String.class));
        doReturn(true).when(jwtValidationTokenConfiguration).isEnabledOnlyB2B();

        final UsernamePasswordAuthenticationToken authentication = new UsernamePasswordAuthenticationToken(null, null, null);

        authentication.setDetails(new JwtUserDetails(JwtTypeEnum.USER_TO_SERVER, null, TOKEN_ACCOUNTS, ""));
        context.setAuthentication(authentication);
        when(context.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(context);

        jwtValidator.validate(COUNTRY_ZA, ACCOUNT_ID);
    }

    private void setUpContextHolder(final JwtTypeEnum type, final List<String> accounts) {
        final SecurityContext context = mock(SecurityContext.class);
        authentication.setDetails(new JwtUserDetails(type, USER_ID, accounts, null));
        context.setAuthentication(authentication);
        when(context.getAuthentication()).thenReturn(authentication);
        SecurityContextHolder.setContext(context);
    }
}