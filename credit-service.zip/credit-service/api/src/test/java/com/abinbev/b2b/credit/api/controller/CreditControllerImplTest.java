package com.abinbev.b2b.credit.api.controller;

import com.abinbev.b2b.credit.api.exception.JwtException;
import com.abinbev.b2b.credit.api.helper.JwtValidator;
import com.abinbev.b2b.credit.api.service.CreditServiceImpl;
import com.abinbev.b2b.credit.utilities.domain.Credit;
import com.abinbev.b2b.credit.utilities.exception.IssueEnum;
import com.abinbev.b2b.credit.utilities.exception.IssueHandler;
import com.abinbev.b2b.credit.utilities.exception.NotFoundException;
import com.abinbev.b2b.credit.utilities.vo.CreditConsumptionRequest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.util.Optional;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class CreditControllerImplTest {

    private static final String COUNTRY_BR = "BR";

    @Mock
    private CreditServiceImpl service;

    @Mock
    private JwtValidator validator;

    @InjectMocks
    private CreditControllerImpl controller;


    @Test
    public void testGetCreditByIdAndCountry() {
        final String id = "123456789";
        final Credit credit = new Credit();
        credit.setAvailable(BigDecimal.valueOf(100));
        credit.setBalance(BigDecimal.valueOf(2));
        credit.setTotal(BigDecimal.valueOf(10000));

        when(this.service.findById(COUNTRY_BR, id)).thenReturn(Optional.of(credit));

        final ResponseEntity<Credit> response = this.controller.get(COUNTRY_BR, id);
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody()).isEqualTo(credit);
    }

    @Test
    public void testGetCreditByIdAndCountryUnsuccessful() {
        final String id = "987654321";

        when(this.service.findById(COUNTRY_BR, id)).thenReturn(Optional.empty());

        final ResponseEntity<Credit> response = this.controller.get(COUNTRY_BR, id);
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(response.getBody()).isNull();
    }

    @Test(expected = JwtException.class)
    public void testGetCreditByIdAndCountryShouldReturnJwtException() {
        final String id = "123456789";
        final Credit credit = new Credit();
        credit.setAccountId(UUID.randomUUID().toString());
        credit.setAvailable(BigDecimal.valueOf(100));
        credit.setBalance(BigDecimal.valueOf(2));
        credit.setTotal(BigDecimal.valueOf(10000));

        when(this.service.findById(COUNTRY_BR, id)).thenReturn(Optional.of(credit));

        doThrow(new JwtException((IssueHandler.createIssue(IssueEnum.FORBIDDEN)))).when(validator).validate(COUNTRY_BR, credit.getAccountId());

        try{
            this.controller.get(COUNTRY_BR, id);
        }
        catch(JwtException e){
            assertThat(e.getIssues()).isNotNull();
            assertThat(e
                               .getIssues()
                               .size()).isOne();
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getCode()).isEqualTo(IssueEnum.FORBIDDEN.getCode());
            throw e;
        }
    }

    @Test
    public void testUpdateCreditConsumption() {
        final String accountId = UUID
                .randomUUID().toString();
        final CreditConsumptionRequest request = new CreditConsumptionRequest();
        request.setAccountId(accountId);
        request.setConsumption( BigDecimal.TEN);

        doNothing().when(service).updateCreditConsumption(COUNTRY_BR, false, request);

        final ResponseEntity<Void> response = this.controller.updateCreditConsumption(COUNTRY_BR, false, request);
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @Test(expected = JwtException.class)
    public void testUpdateCreditConsumptionShouldReturnJwtException() {
        final String accountId = UUID
                .randomUUID().toString();
        final CreditConsumptionRequest request = new CreditConsumptionRequest();
        request.setAccountId(accountId);
        request.setConsumption( BigDecimal.TEN);
        doThrow(new JwtException((IssueHandler.createIssue(IssueEnum.FORBIDDEN)))).when(validator).validate(COUNTRY_BR, accountId);

        try{
            this.controller.updateCreditConsumption(COUNTRY_BR, false, request);
        }
        catch(JwtException e){
            assertThat(e.getIssues()).isNotNull();
            assertThat(e
                               .getIssues()
                               .size()).isOne();
            assertThat(e
                               .getIssues()
                               .get(0)
                               .getCode()).isEqualTo(IssueEnum.FORBIDDEN.getCode());
            throw e;
        }
    }

    @Test(expected = NotFoundException.class)
    public void testUpdateCreditConsumptionUnsuccessful() {
        final String accountId = UUID
                .randomUUID().toString();
        final CreditConsumptionRequest request = new CreditConsumptionRequest();
        request.setAccountId(accountId);

        doThrow(NotFoundException.class).when(service).updateCreditConsumption(COUNTRY_BR, false, request);

        final ResponseEntity<Void> response = this.controller.updateCreditConsumption(COUNTRY_BR, false, request);
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(response.getBody()).isNull();
    }
}