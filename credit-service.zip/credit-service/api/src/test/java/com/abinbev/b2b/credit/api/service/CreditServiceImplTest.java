package com.abinbev.b2b.credit.api.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.web.client.HttpClientErrorException;

import com.abinbev.b2b.credit.api.config.CreditConsumptionFeatureProperties;
import com.abinbev.b2b.credit.api.remote.client.AccountClient;
import com.abinbev.b2b.credit.utilities.domain.Credit;
import com.abinbev.b2b.credit.utilities.exception.NotFoundException;
import com.abinbev.b2b.credit.utilities.exception.RemoteServiceErrorException;
import com.abinbev.b2b.credit.utilities.repository.CreditDao;
import com.abinbev.b2b.credit.utilities.vo.CreditConsumptionRequest;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;

@RunWith(MockitoJUnitRunner.class)
public class CreditServiceImplTest {

    private static final String COUNTRY_BR = "br";

    @Mock
    private CreditDao dao;

    @Mock
    private CreditConsumptionFeatureProperties consumptionProperties;

    @Mock
    private AccountClient accountClient;

    @InjectMocks
    private CreditServiceImpl service;

    @Test
    public void testGetById() {
        final String id = "123456789";
        final Credit credit = new Credit();
        credit.setTotal(BigDecimal.valueOf(1000));
        credit.setAvailable(BigDecimal.valueOf(23));


        when(dao.findById(COUNTRY_BR, id)).thenReturn(Optional.ofNullable(credit));

        final Optional<Credit> creditResponse = service.findById(COUNTRY_BR, id);
        assertThat(creditResponse).isPresent();
        assertThat(creditResponse.get()).isEqualTo(credit);
    }

    @Test
    public void testFindByIdWithExistentSharedCredit() {
        final String parentId = "9999999";
        final String childId = "123456789";
        final OffsetDateTime persistedUpdatedAt = OffsetDateTime.now();

        final Credit child = Credit
                .builder()
                .withAccountId(childId)
                .withParentId(parentId)
                .withUpdatedAt(persistedUpdatedAt)
                .build();

        final Credit parent = Credit
                .builder()
                .withAccountId(parentId)
                .withChildIds(ImmutableSet.of(childId))
                .withUpdatedAt(persistedUpdatedAt)
                .withBalance(BigDecimal.ONE)
                .withOverdue(BigDecimal.ZERO)
                .withAvailable(BigDecimal.TEN)
                .withTotal(new BigDecimal("20"))
                .withConsumption(new BigDecimal("5"))
                .withPaymentTerms("CREDIT")
                .build();

        when(dao.findById(COUNTRY_BR, childId)).thenReturn(Optional.of(child));
        when(dao.findById(COUNTRY_BR, parentId)).thenReturn(Optional.of(parent));

        final Optional<Credit> creditResponse = service.findById(COUNTRY_BR, childId);
        assertThat(creditResponse).isPresent();
        final Credit response = creditResponse.get();
        assertThat(response.getAccountId()).isEqualTo(childId);
        assertThat(response.getBalance()).isEqualTo(BigDecimal.ONE);
        assertThat(response.getOverdue()).isEqualTo(BigDecimal.ZERO);
        assertThat(response.getAvailable()).isEqualTo(BigDecimal.TEN);
        assertThat(response.getTotal()).isEqualTo(new BigDecimal("20"));
        assertThat(response.getConsumption()).isEqualTo(new BigDecimal("5"));
        assertThat(response.getPaymentTerms()).isEqualTo("CREDIT");
        assertThat(response.getUpdatedAt()).isEqualTo(parent.getUpdatedAt());
    }

    @Test
    public void testFindByIdWithSharedCreditForNonExistentParent() {
        final String parentId = "9999999";
        final String childId = "123456789";
        final OffsetDateTime persistedUpdatedAt = OffsetDateTime.now();

        final Credit child = Credit
                .builder()
                .withAccountId(childId)
                .withParentId(parentId)
                .withUpdatedAt(persistedUpdatedAt)
                .build();


        when(dao.findById(COUNTRY_BR, childId)).thenReturn(Optional.of(child));
        when(dao.findById(COUNTRY_BR, parentId)).thenReturn(Optional.empty());

        final Optional<Credit> creditResponse = service.findById(COUNTRY_BR, childId);
        assertThat(creditResponse).isNotPresent();;
    }

    @Test
    public void testFindByIdWithSharedCreditAndParentWithDifferentChildIds() {
        final String parentId = "9999999";
        final String childId = "123456789";
        final OffsetDateTime persistedUpdatedAt = OffsetDateTime.now();

        final Credit child = Credit
                .builder()
                .withAccountId(childId)
                .withParentId(parentId)
                .withUpdatedAt(persistedUpdatedAt)
                .build();

        final Credit parent = Credit
                .builder()
                .withAccountId(parentId)
                .withChildIds(ImmutableSet.of("foo", "bar"))
                .withUpdatedAt(persistedUpdatedAt)
                .withBalance(BigDecimal.ONE)
                .withOverdue(BigDecimal.ZERO)
                .withAvailable(BigDecimal.TEN)
                .withTotal(new BigDecimal("20"))
                .withConsumption(new BigDecimal("5"))
                .withPaymentTerms("CREDIT")
                .build();

        when(dao.findById(COUNTRY_BR, childId)).thenReturn(Optional.of(child));
        when(dao.findById(COUNTRY_BR, parentId)).thenReturn(Optional.of(parent));

        final Optional<Credit> creditResponse = service.findById(COUNTRY_BR, childId);
        assertThat(creditResponse).isNotPresent();
    }

    @Test
    public void testFindByIdWithSharedCreditAndParentWithNullChildIds() {
        final String parentId = "9999999";
        final String childId = "123456789";
        final OffsetDateTime persistedUpdatedAt = OffsetDateTime.now();

        final Credit child = Credit
                .builder()
                .withAccountId(childId)
                .withParentId(parentId)
                .withUpdatedAt(persistedUpdatedAt)
                .build();

        final Credit parent = Credit
                .builder()
                .withAccountId(parentId)
                .withChildIds(null)
                .withUpdatedAt(persistedUpdatedAt)
                .withBalance(BigDecimal.ONE)
                .withOverdue(BigDecimal.ZERO)
                .withAvailable(BigDecimal.TEN)
                .withTotal(new BigDecimal("20"))
                .withConsumption(new BigDecimal("5"))
                .withPaymentTerms("CREDIT")
                .build();

        when(dao.findById(COUNTRY_BR, childId)).thenReturn(Optional.of(child));
        when(dao.findById(COUNTRY_BR, parentId)).thenReturn(Optional.of(parent));

        final Optional<Credit> creditResponse = service.findById(COUNTRY_BR, childId);
        assertThat(creditResponse).isNotPresent();
    }

    @Test
    public void testGetByIdUnsuccessful() {
        final String id = "xxxx";

        when(dao.findById(COUNTRY_BR, id)).thenReturn(Optional.empty());

        final Optional<Credit> creditResponse = service.findById(COUNTRY_BR, id);
        assertThat(creditResponse).isNotPresent();
    }

    @Test
    public void testUpdateCreditConsumptionSuccessful() {
        final String accountId = UUID.randomUUID().toString();

        var persistedCredit = new Credit();
        persistedCredit.setAccountId(accountId);
        persistedCredit.setConsumption(BigDecimal.TEN);
        persistedCredit.setUpdatedAt(OffsetDateTime.now());

        final CreditConsumptionRequest request = new CreditConsumptionRequest();
        request.setAccountId(accountId);
        request.setConsumption(BigDecimal.TEN);

        when(dao.findById(COUNTRY_BR, accountId)).thenReturn(Optional.of(persistedCredit));

        service.updateCreditConsumption(COUNTRY_BR, false, request);

        verify(dao, times(1)).findById(COUNTRY_BR, accountId);
        verify(dao, times(1)).updateCreditConsumption(COUNTRY_BR, persistedCredit.getUpdatedAt(), accountId, new BigDecimal("20"));
        verify(accountClient, times(0)).creditConsumption(any(), any(), any());
    }

    @Test
    public void testUpdateCreditConsumptionAndDataReplicationSuccessful() {
        final String accountId = UUID.randomUUID().toString();

        var persistedCredit = new Credit();
        persistedCredit.setAccountId(accountId);
        persistedCredit.setConsumption(BigDecimal.TEN);
        persistedCredit.setUpdatedAt(OffsetDateTime.now());

        final CreditConsumptionRequest request = new CreditConsumptionRequest();
        request.setAccountId(accountId);
        request.setConsumption(BigDecimal.TEN);

        when(dao.findById(COUNTRY_BR, accountId)).thenReturn(Optional.of(persistedCredit));
        when(dao.updateCreditConsumption(COUNTRY_BR, persistedCredit.getUpdatedAt(), accountId, new BigDecimal("20"))).thenReturn(true);
        when(consumptionProperties.shouldReplicateToAccountService(COUNTRY_BR)).thenReturn(true);

        service.updateCreditConsumption(COUNTRY_BR, false, request);

        verify(dao, times(1)).findById(COUNTRY_BR, accountId);
        verify(dao, times(1)).updateCreditConsumption(COUNTRY_BR, persistedCredit.getUpdatedAt(), accountId, new BigDecimal("20"));
        verify(accountClient, times(1)).creditConsumption(COUNTRY_BR, accountId, BigDecimal.TEN);
        verify(dao, times(0)).updateCreditConsumption(COUNTRY_BR, persistedCredit.getUpdatedAt(), accountId, BigDecimal.TEN); // no rollback
    }

    @Test
    public void testUpdateCreditConsumptionAndDataReplicationSkipped() {
        final String accountId = UUID.randomUUID().toString();

        var persistedCredit = new Credit();
        persistedCredit.setAccountId(accountId);
        persistedCredit.setConsumption(BigDecimal.TEN);
        persistedCredit.setUpdatedAt(OffsetDateTime.now());

        final CreditConsumptionRequest request = new CreditConsumptionRequest();
        request.setAccountId(accountId);
        request.setConsumption(BigDecimal.TEN);

        when(dao.findById(COUNTRY_BR, accountId)).thenReturn(Optional.of(persistedCredit));
        when(dao.updateCreditConsumption(COUNTRY_BR, persistedCredit.getUpdatedAt(), accountId, new BigDecimal("20"))).thenReturn(false);
        lenient().when(consumptionProperties.shouldReplicateToAccountService(COUNTRY_BR)).thenReturn(true);

        service.updateCreditConsumption(COUNTRY_BR, false, request);

        verify(dao, times(1)).findById(COUNTRY_BR, accountId);
        verify(dao, times(1)).updateCreditConsumption(COUNTRY_BR, persistedCredit.getUpdatedAt(), accountId, new BigDecimal("20"));
        verify(accountClient, times(0)).creditConsumption(COUNTRY_BR, accountId, new BigDecimal("20"));
        verify(dao, times(0)).updateCreditConsumption(COUNTRY_BR, persistedCredit.getUpdatedAt(), accountId, BigDecimal.TEN); // no rollback
    }

    @Test(expected = NotFoundException.class)
    public void testUpdateCreditConsumptionAndDataReplicationUnsuccessfulForNonFound() {
        final String accountId = UUID.randomUUID().toString();

        var persistedCredit = new Credit();
        persistedCredit.setAccountId(accountId);
        persistedCredit.setConsumption(BigDecimal.TEN);
        persistedCredit.setUpdatedAt(OffsetDateTime.now());

        final CreditConsumptionRequest request = new CreditConsumptionRequest();
        request.setAccountId(accountId);
        request.setConsumption(BigDecimal.TEN);

        when(dao.findById(COUNTRY_BR, accountId)).thenReturn(Optional.of(persistedCredit));
        when(dao.updateCreditConsumption(COUNTRY_BR, persistedCredit.getUpdatedAt(), accountId, new BigDecimal("20"))).thenReturn(true);
        when(consumptionProperties.shouldReplicateToAccountService(COUNTRY_BR)).thenReturn(true);
        doThrow(new HttpClientErrorException(HttpStatus.NOT_FOUND)).when(accountClient).creditConsumption(COUNTRY_BR, accountId, BigDecimal.TEN);

        try {
            service.updateCreditConsumption(COUNTRY_BR, false, request);
        } catch (final NotFoundException e) {
            verify(dao, times(1)).findById(COUNTRY_BR, accountId);
            verify(dao, times(1)).updateCreditConsumption(COUNTRY_BR, persistedCredit.getUpdatedAt(), accountId, new BigDecimal("20"));
            verify(accountClient, times(1)).creditConsumption(COUNTRY_BR, accountId, BigDecimal.TEN);
            verify(dao, times(1)).updateCreditConsumption(COUNTRY_BR, persistedCredit.getUpdatedAt(), accountId, BigDecimal.TEN); // rollback
            throw e;
        }
    }

    @Test(expected = RemoteServiceErrorException.class)
    public void testUpdateCreditConsumptionAndDataReplicationUnsuccessfulForRemoteServiceError() {
        final String accountId = UUID.randomUUID().toString();

        var persistedCredit = new Credit();
        persistedCredit.setAccountId(accountId);
        persistedCredit.setConsumption(BigDecimal.TEN);
        persistedCredit.setUpdatedAt(OffsetDateTime.now());

        final CreditConsumptionRequest request = new CreditConsumptionRequest();
        request.setAccountId(accountId);
        request.setConsumption(BigDecimal.TEN);

        when(dao.findById(COUNTRY_BR, accountId)).thenReturn(Optional.of(persistedCredit));
        when(dao.updateCreditConsumption(COUNTRY_BR, persistedCredit.getUpdatedAt(), accountId, new BigDecimal("20"))).thenReturn(true);
        when(consumptionProperties.shouldReplicateToAccountService(COUNTRY_BR)).thenReturn(true);
        doThrow(new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR)).when(accountClient).creditConsumption(COUNTRY_BR, accountId, BigDecimal.TEN);

        try {
            service.updateCreditConsumption(COUNTRY_BR, false, request);
        } catch (final RemoteServiceErrorException e) {
            verify(dao, times(1)).findById(COUNTRY_BR, accountId);
            verify(dao, times(1)).updateCreditConsumption(COUNTRY_BR, persistedCredit.getUpdatedAt(), accountId, new BigDecimal("20"));
            verify(accountClient, times(1)).creditConsumption(COUNTRY_BR, accountId, BigDecimal.TEN);
            verify(dao, times(1)).updateCreditConsumption(COUNTRY_BR, persistedCredit.getUpdatedAt(), accountId, BigDecimal.TEN); // rollback
            throw e;
        }
    }

    @Test(expected = NotFoundException.class)
    public void testUpdateCreditConsumptionNotFound() {
        final String accountId = UUID.randomUUID().toString();
        final OffsetDateTime updatedAt = OffsetDateTime.now();

        final CreditConsumptionRequest request = new CreditConsumptionRequest();
        request.setAccountId(accountId);
        request.setConsumption(BigDecimal.TEN);

        when(dao.findById(COUNTRY_BR, accountId)).thenReturn(Optional.empty());

        try {
            service.updateCreditConsumption(COUNTRY_BR, false, request);
        } catch (final NotFoundException e){
            verify(dao, times(1)).findById(COUNTRY_BR, accountId);
            verify(dao, times(0)).updateCreditConsumption(any(), any(), any(), any());
            throw e;
        }
    }

    @Test
    public void testUpdateSharedCreditConsumptionSuccessful() {
        var parentId = "999";
        var childId = "111";

        var parentCredit = new Credit();
        parentCredit.setAccountId(parentId);
        parentCredit.setConsumption(BigDecimal.TEN);
        parentCredit.setUpdatedAt(OffsetDateTime.now());
        parentCredit.setChildIds(ImmutableSet.of(childId));

        var childCredit = new Credit();
        childCredit.setAccountId(childId);
        childCredit.setUpdatedAt(OffsetDateTime.now());
        childCredit.setParentId(parentId);

        final CreditConsumptionRequest request = new CreditConsumptionRequest();
        request.setAccountId(childId);
        request.setConsumption(BigDecimal.TEN);

        when(dao.findById(COUNTRY_BR, childId)).thenReturn(Optional.of(childCredit));
        when(dao.findById(COUNTRY_BR, parentId)).thenReturn(Optional.of(parentCredit));
        when(dao.updateCreditConsumption(COUNTRY_BR, parentCredit.getUpdatedAt(), parentId, new BigDecimal("20"))).thenReturn(true);
        lenient().when(consumptionProperties.shouldReplicateToAccountService(COUNTRY_BR)).thenReturn(true);

        service.updateCreditConsumption(COUNTRY_BR, false, request);

        verify(dao, times(1)).findById(COUNTRY_BR, childId);
        verify(dao, times(1)).findById(COUNTRY_BR, parentId);
        verify(dao, times(1)).updateCreditConsumption(COUNTRY_BR, parentCredit.getUpdatedAt(), parentId, new BigDecimal("20"));
        verify(accountClient, times(0)).creditConsumption(any(), any(), any()); // it must not work for shared credit even the toggle is enabled
    }

    @Test(expected = NotFoundException.class)
    public void testUpdateSharedCreditConsumptionNotFoundParent() {
        var parentId = "999";
        var childId = "111";

        var childCredit = new Credit();
        childCredit.setAccountId(childId);
        childCredit.setUpdatedAt(OffsetDateTime.now());
        childCredit.setParentId(parentId);

        final CreditConsumptionRequest request = new CreditConsumptionRequest();
        request.setAccountId(childId);
        request.setConsumption(BigDecimal.TEN);

        when(dao.findById(COUNTRY_BR, childId)).thenReturn(Optional.of(childCredit));
        when(dao.findById(COUNTRY_BR, parentId)).thenReturn(Optional.empty());

        try {
            service.updateCreditConsumption(COUNTRY_BR, false, request);
        } catch (final NotFoundException e){
            verify(dao, times(1)).findById(COUNTRY_BR, childId);
            verify(dao, times(1)).findById(COUNTRY_BR, parentId);
            verify(dao, times(0)).updateCreditConsumption(any(), any(), any(), any());
            verify(accountClient, times(0)).creditConsumption(any(), any(), any());
            throw e;
        }
    }

    @Test(expected = NotFoundException.class)
    public void testUpdateSharedCreditConsumptionWithParentChildIdsNull() {
        var parentId = "999";
        var childId = "111";

        var parentCredit = new Credit();
        parentCredit.setAccountId(parentId);
        parentCredit.setConsumption(BigDecimal.TEN);
        parentCredit.setUpdatedAt(OffsetDateTime.now());
        parentCredit.setChildIds(null);

        var childCredit = new Credit();
        childCredit.setAccountId(childId);
        childCredit.setUpdatedAt(OffsetDateTime.now());
        childCredit.setParentId(parentId);

        final CreditConsumptionRequest request = new CreditConsumptionRequest();
        request.setAccountId(childId);
        request.setConsumption(BigDecimal.TEN);

        when(dao.findById(COUNTRY_BR, childId)).thenReturn(Optional.of(childCredit));
        when(dao.findById(COUNTRY_BR, parentId)).thenReturn(Optional.of(parentCredit));

        try {
            service.updateCreditConsumption(COUNTRY_BR, false, request);
        } catch (final NotFoundException e){
            verify(dao, times(1)).findById(COUNTRY_BR, childId);
            verify(dao, times(1)).findById(COUNTRY_BR, parentId);
            verify(dao, times(0)).updateCreditConsumption(any(), any(), any(), any());
            verify(accountClient, times(0)).creditConsumption(any(), any(), any());
            throw e;
        }
    }

    @Test(expected = NotFoundException.class)
    public void testUpdateSharedCreditConsumptionWithDifferentParentChildIds() {
        var parentId = "999";
        var childId = "111";

        var parentCredit = new Credit();
        parentCredit.setAccountId(parentId);
        parentCredit.setConsumption(BigDecimal.TEN);
        parentCredit.setUpdatedAt(OffsetDateTime.now());
        parentCredit.setChildIds(ImmutableSet.of("333","444"));

        var childCredit = new Credit();
        childCredit.setAccountId(childId);
        childCredit.setUpdatedAt(OffsetDateTime.now());
        childCredit.setParentId(parentId);

        final CreditConsumptionRequest request = new CreditConsumptionRequest();
        request.setAccountId(childId);
        request.setConsumption(BigDecimal.TEN);

        when(dao.findById(COUNTRY_BR, childId)).thenReturn(Optional.of(childCredit));
        when(dao.findById(COUNTRY_BR, parentId)).thenReturn(Optional.of(parentCredit));

        try {
            service.updateCreditConsumption(COUNTRY_BR, false, request);
        } catch (final NotFoundException e){
            verify(dao, times(1)).findById(COUNTRY_BR, childId);
            verify(dao, times(1)).findById(COUNTRY_BR, parentId);
            verify(dao, times(0)).updateCreditConsumption(any(), any(), any(), any());
            verify(accountClient, times(0)).creditConsumption(any(), any(), any());
            throw e;
        }
    }

    @Test
    public void testGetByAccountIdsSuccess() {
        final String accountId1 = UUID.randomUUID().toString();
        final Credit credit1 = buildCredit(accountId1);

        final String accountId2 = UUID.randomUUID().toString();
        final Credit credit2 = buildCredit(accountId2);

        final String accountId3 = UUID.randomUUID().toString();
        final Credit credit3 = buildCredit(accountId3);

        final List<String> accountIds = ImmutableList.of(accountId1, accountId2, accountId3);
        final List<Credit> credits = ImmutableList.of(credit1, credit2, credit3);

        when(dao.findByAccountIds(COUNTRY_BR, accountIds)).thenReturn(credits);

        final List<Credit> returnedCredits = service.findByAccountIds(COUNTRY_BR, accountIds);

        assertThat(returnedCredits).isNotEmpty();
        assertThat(returnedCredits.get(0)).isEqualTo(credit1);
        assertThat(returnedCredits.get(1)).isEqualTo(credit2);
        assertThat(returnedCredits.get(2)).isEqualTo(credit3);
    }

    @Test
    public void testGetByAccountIdsWithEmptyList() {
        final String accountId1 = UUID.randomUUID().toString();
        final String accountId2 = UUID.randomUUID().toString();
        final String accountId3 = UUID.randomUUID().toString();

        final List<String> accountIds = ImmutableList.of(accountId1, accountId2, accountId3);
        final List<Credit> credits = Collections.emptyList();

        when(dao.findByAccountIds(COUNTRY_BR, accountIds)).thenReturn(credits);

        final List<Credit> returnedCredits = service.findByAccountIds(COUNTRY_BR, accountIds);

        assertThat(returnedCredits).isEmpty();
    }

    @Test
    public void testGetByAccountIds() {
        final String accountId1 = UUID.randomUUID().toString();
        final String accountId2 = UUID.randomUUID().toString();
        final String accountId3 = UUID.randomUUID().toString();

        final List<String> accountIds = ImmutableList.of(accountId1, accountId2, accountId3);
        final List<Credit> credits = Collections.emptyList();

        when(dao.findByAccountIds(COUNTRY_BR, accountIds)).thenReturn(credits);

        service.findByAccountIds(COUNTRY_BR, accountIds);

        verify(dao, times(1)).findByAccountIds(COUNTRY_BR, accountIds);
    }

    @Test
    public void testFindByAccountIdsWithShared() {
        final String singleAccountId = "ac-01";
        final String nonExistentSingleAccountId = "ac-02" ;

        final Credit singleCredit = Credit
                .builder()
                .withAccountId(singleAccountId)
                .withUpdatedAt(OffsetDateTime.now())
                .withBalance(BigDecimal.ONE)
                .withOverdue(BigDecimal.ZERO)
                .withAvailable(BigDecimal.TEN)
                .withTotal(new BigDecimal("20"))
                .withConsumption(new BigDecimal("5"))
                .withPaymentTerms("CREDIT")
                .build();

        final String parentId = "9999999";

        final String childIdA = "1111111";

        final OffsetDateTime persistedUpdatedAt = OffsetDateTime.now();

        final Credit childA = Credit
                .builder()
                .withAccountId(childIdA)
                .withParentId(parentId)
                .withUpdatedAt(persistedUpdatedAt)
                .build();

        final Credit parent = Credit
                .builder()
                .withAccountId(parentId)
                .withChildIds(ImmutableSet.of(childIdA))
                .withUpdatedAt(persistedUpdatedAt)
                .withBalance(BigDecimal.ONE)
                .withOverdue(BigDecimal.ZERO)
                .withAvailable(BigDecimal.TEN)
                .withTotal(new BigDecimal("20"))
                .withConsumption(new BigDecimal("5"))
                .withPaymentTerms("CREDIT")
                .build();

        final String childIdB = "222222";
        final Credit childB = Credit
                .builder()
                .withAccountId(childIdB)
                .withParentId(parentId) // it won't appear in the parent.childIds
                .withUpdatedAt(persistedUpdatedAt)
                .build();

        final String childIdC = "xpto";
        final String inexistentParentId = "bar";
        final Credit childC = Credit
                .builder()
                .withAccountId(childIdC)
                .withParentId(inexistentParentId) // it won't exist
                .withUpdatedAt(persistedUpdatedAt)
                .build();

        final List<String> input = ImmutableList.of(singleAccountId, nonExistentSingleAccountId, childIdA, childIdB, childIdC);

        when(dao.findByAccountIds(COUNTRY_BR, input)).thenReturn(ImmutableList.of(singleCredit, childA, childB, childC));
        when(dao.findByAccountIds(COUNTRY_BR, ImmutableSet.of(parentId, inexistentParentId))).thenReturn(ImmutableList.of(parent));

        final List<Credit> response = service.findByAccountIds(COUNTRY_BR, input);

        verify(dao, times(1)).findByAccountIds(COUNTRY_BR, input);
        verify(dao, times(1)).findByAccountIds(COUNTRY_BR, ImmutableSet.of(parentId, inexistentParentId));

        assertThat(response).isNotEmpty();
        assertThat(response.size()).isEqualTo(2);
        assertThat(response).contains(singleCredit);
        assertThat(response).contains(Credit
                                              .builder()
                                              .withAccountId(childA.getAccountId())
                                              .withConsumption(parent.getConsumption())
                                              .withTotal(parent.getTotal())
                                              .withAvailable(parent.getAvailable())
                                              .withOverdue(parent.getOverdue())
                                              .withBalance(parent.getBalance())
                                              .withPaymentTerms(parent.getPaymentTerms())
                                              .withUpdatedAt(parent.getUpdatedAt())
                                              .build());
    }

    @Test
    public void testFindByAccountIdsWithSharedAndNotFoundParents() {

        final String parentId = "9999999";

        final String childIdA = "1111111";

        final OffsetDateTime persistedUpdatedAt = OffsetDateTime.now();

        final Credit childA = Credit
                .builder()
                .withAccountId(childIdA)
                .withParentId(parentId)
                .withUpdatedAt(persistedUpdatedAt)
                .build();

        final String childIdB = "222222";
        final Credit childB = Credit
                .builder()
                .withAccountId(childIdB)
                .withParentId(parentId)
                .withUpdatedAt(persistedUpdatedAt)
                .build();

        final List<String> input = ImmutableList.of(childIdA, childIdB);

        when(dao.findByAccountIds(COUNTRY_BR, input)).thenReturn(ImmutableList.of(childA, childB));
        when(dao.findByAccountIds(COUNTRY_BR, ImmutableSet.of(parentId))).thenReturn(Collections.emptyList());

        final List<Credit> response = service.findByAccountIds(COUNTRY_BR, input);

        verify(dao, times(1)).findByAccountIds(COUNTRY_BR, input);
        verify(dao, times(1)).findByAccountIds(COUNTRY_BR, ImmutableSet.of(parentId));

        assertThat(response).isEmpty();
    }

    private Credit buildCredit(final String accountId) {
        final Credit credit = new Credit();
        credit.setAccountId(accountId);
        credit.setTotal(BigDecimal.valueOf(1000));
        credit.setAvailable(BigDecimal.valueOf(23));
        credit.setBalance(BigDecimal.valueOf(55));
        credit.setConsumption(BigDecimal.valueOf(33));
        credit.setOverdue(BigDecimal.valueOf(47));
        credit.setPaymentTerms("CASH");
        credit.setUpdatedAt(OffsetDateTime.now());

        return credit;
    }
}