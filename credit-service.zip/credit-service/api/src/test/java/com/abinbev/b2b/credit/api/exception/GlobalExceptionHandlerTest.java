package com.abinbev.b2b.credit.api.exception;


import com.abinbev.b2b.credit.utilities.exception.BadRequestException;
import com.abinbev.b2b.credit.utilities.exception.Issue;
import com.abinbev.b2b.credit.utilities.exception.IssueEnum;
import com.abinbev.b2b.credit.utilities.exception.IssueHandler;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.servlet.NoHandlerFoundException;

import java.nio.file.AccessDeniedException;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class GlobalExceptionHandlerTest {

    @InjectMocks
    private GlobalExceptionHandler handler;

    @Test
    public void testHandleException() {
        final ResponseEntity<Object> response = handler.handleException(new HttpMessageNotReadableException("Test exception"));
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody()).isInstanceOf(ErrorResponse.class);
        final ErrorResponse errorResponse = (ErrorResponse) response.getBody();
        assertThat(errorResponse.getMessage()).isEqualTo("Test exception");
        assertThat(errorResponse.getDetails()).isNotEmpty();
        assertThat(errorResponse
                           .getDetails()
                           .size()).isOne();
        final Issue issue = errorResponse
                .getDetails()
                .get(0);
        assertThat(issue.getCode()).isEqualTo(IssueEnum.GENERIC_EXCEPTION.getCode());
        assertThat(issue.getMessage()).isEqualTo("Test exception");
    }

    @Test
    public void testHandleRuntimeException() {
        final ResponseEntity<Object> response = handler.handleRuntimeException(new RuntimeException("Test runtime exception"));
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody()).isInstanceOf(ErrorResponse.class);
        final ErrorResponse errorResponse = (ErrorResponse) response.getBody();
        assertThat(errorResponse.getMessage()).isEqualTo("Test runtime exception");
        assertThat(errorResponse.getDetails()).isNotEmpty();
        assertThat(errorResponse
                           .getDetails()
                           .size()).isOne();
        final Issue issue = errorResponse
                .getDetails()
                .get(0);
        assertThat(issue.getCode()).isEqualTo(IssueEnum.GENERIC_EXCEPTION.getCode());
        assertThat(issue.getMessage()).isEqualTo("Test runtime exception");
    }

    @Test
    public void testHandleHttpRequestMethodNotSupportedException() {
        final ResponseEntity<Object> response = handler.handleHttpRequestMethodNotSupportedException(new HttpRequestMethodNotSupportedException("GET"));
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.METHOD_NOT_ALLOWED);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody()).isInstanceOf(ErrorResponse.class);
        final ErrorResponse errorResponse = (ErrorResponse) response.getBody();
        assertThat(errorResponse.getMessage()).isEqualTo("Request method 'GET' not supported");
        assertThat(errorResponse.getDetails()).isNotEmpty();
        assertThat(errorResponse
                           .getDetails()
                           .size()).isOne();
        final Issue issue = errorResponse
                .getDetails()
                .get(0);
        assertThat(issue.getCode()).isEqualTo(IssueEnum.GENERIC_EXCEPTION.getCode());
        assertThat(issue.getMessage()).isEqualTo("Request method 'GET' not supported");
    }

    @Test
    public void testHandleNotFoundException() {
        final ResponseEntity<Object> response = handler.handleNotFoundException(new NoHandlerFoundException("GET", "http://foo.bar", null));
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody()).isInstanceOf(ErrorResponse.class);
        final ErrorResponse errorResponse = (ErrorResponse) response.getBody();
        assertThat(errorResponse.getMessage()).isEqualTo("No handler found for GET http://foo.bar");
        assertThat(errorResponse.getDetails()).isNotEmpty();
        assertThat(errorResponse
                           .getDetails()
                           .size()).isOne();
        final Issue issue = errorResponse
                .getDetails()
                .get(0);
        assertThat(issue.getCode()).isEqualTo(IssueEnum.GENERIC_EXCEPTION.getCode());
        assertThat(issue.getMessage()).isEqualTo("No handler found for GET http://foo.bar");
    }

    @Test
    public void testHandleAccessDenied() {
        final ResponseEntity<Object> response = handler.handleAccessDenied(new AccessDeniedException("test access denied"));
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.FORBIDDEN);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody()).isInstanceOf(ErrorResponse.class);
        final ErrorResponse errorResponse = (ErrorResponse) response.getBody();
        assertThat(errorResponse.getMessage()).isEqualTo("test access denied");
        assertThat(errorResponse.getDetails()).isNotEmpty();
        assertThat(errorResponse
                           .getDetails()
                           .size()).isOne();
        final Issue issue = errorResponse
                .getDetails()
                .get(0);
        assertThat(issue.getCode()).isEqualTo(IssueEnum.GENERIC_EXCEPTION.getCode());
        assertThat(issue.getMessage()).isEqualTo("test access denied");
    }

    @Test
    public void testHandleBadRequestException() {
        final ResponseEntity<Object> response = handler.handleBadRequestException(new BadRequestException(IssueHandler.createIssue(IssueEnum.INVALID_COUNTRY, "XPTO")));
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);
        assertThat(response.getBody()).isNotNull();
        assertThat(response.getBody()).isInstanceOf(ErrorResponse.class);
        final ErrorResponse errorResponse = (ErrorResponse) response.getBody();
        assertThat(errorResponse.getMessage()).isEqualTo("The country 'XPTO' is not valid");
        assertThat(errorResponse.getDetails()).isNotEmpty();
        assertThat(errorResponse
                           .getDetails()
                           .size()).isOne();
        final Issue issue = errorResponse
                .getDetails()
                .get(0);
        assertThat(issue.getCode()).isEqualTo(IssueEnum.INVALID_COUNTRY.getCode());
        assertThat(issue.getMessage()).isEqualTo("The country 'XPTO' is not valid");
    }


}