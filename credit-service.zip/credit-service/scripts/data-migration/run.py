#!/usr/bin/python3
import simplejson as json
import sys
import os
import csv
import traceback
from datetime import datetime, timezone
import pika
import pika_pool
import logging as log
import pymongo
from decimal import *
import itertools
import concurrent.futures
from math import ceil

log.basicConfig(level=log.INFO, format="%(asctime)s [%(levelname)s] %(message)s [%(threadName)s]")

def load_config():
    file = open("config.json", "r")
    config = file.read()
    file.close()
    return json.loads(config)

config = load_config()
environments = config['environments']

try:
  env = sys.argv[1].lower()
  if env not in environments.keys():
    raise  ValueError
except Exception:
  raise Exception("Invalid environment argument. Allowed environments: %s" % (list(environments.keys())))

if not sys.argv[2:]:
    raise Exception("Missing country argument.")

country = sys.argv[2].strip().upper()
try:
  inputFileArg = sys.argv[3]
except IndexError: 
  inputFileArg = None

mongoExport = config['mongoExportApp']
batchSize = config['batchSize']
db = environments[env]['database']
dbUri = db['uri']
dbName = db['name']
dbCollection = db['collectionBase'] % (country)
inputFile = 'temp/%s-%s-db-dump.csv' % (env, country)
resultOutputFile = 'temp/%s-%s-credit-unsuccessful-%s.csv' % (env, country, datetime.now().isoformat())
accountIdsPostedSuccessful = []
initial_time = datetime.now()

rabbitConfig = environments[env]['rabbitmq']

url = "amqp://{user}:{password}@{host}:{port}/{vhost}".format(user=rabbitConfig['user'], password=rabbitConfig['password'], host=rabbitConfig['host'], port=rabbitConfig['port'], vhost=rabbitConfig['vhost'])
params = pika.URLParameters(url)

pool = pika_pool.QueuedPool(
    create=lambda: pika.BlockingConnection(parameters=params),
    max_size=batchSize,
    max_overflow=batchSize,
    timeout=60,
    recycle=3600,
    stale=45,
)

if inputFileArg == None and os.path.exists(inputFile):
  os.remove(inputFile)

if os.path.exists(resultOutputFile):
  os.remove(resultOutputFile)

poll_executor = concurrent.futures.ThreadPoolExecutor(max_workers=config['threadNumber'])
counter = itertools.count(1)

class Credit:
    country = None
    accountId = None
    available = None
    balance = None
    consumption = None
    overdue = None
    paymentTerms = None
    total = None
    updatedAt = None
    deleted = False

    def __init__(self, country, accountId, available, balance, consumption, overdue, paymentTerms, total, updatedAt, deleted):
        self.country = country
        self.accountId = accountId
        self.available = available
        self.balance = balance
        self.consumption = consumption
        self.overdue = overdue
        self.paymentTerms = paymentTerms
        self.total = total
        self.updatedAt = updatedAt
        self.deleted = deleted
    
    @staticmethod
    def serialize(self):
      return {
            "country": self.country,
            "accountId": self.accountId,
            "available": self.available,
            "balance": self.balance,
            "consumption": self.consumption,
            "overdue": self.overdue,
            "paymentTerms": self.paymentTerms,
            "total": self.total,
            "updatedAt": self.updatedAt,
            "deleted": self.deleted
        }

def build_properties(headers):
    return pika.spec.BasicProperties(content_type='application/json', headers=headers)

def chunk_list(seq, size):
    chunks = [
        seq[i * size:(i * size) + size]
        for i in range(ceil(len(seq) / size))
    ]
    return chunks

def export_database_account_Ids():
    ids = []
    global inputFile
    if inputFileArg == None:
        command = '%s --uri=\"%s\" -d %s -c %s -f _id --query \'{\"credit\":{\"$ne\":null}}\' --type=csv -o %s' % (mongoExport, dbUri, dbName, dbCollection, inputFile)
        os.system(command)
    else:
        inputFile = inputFileArg

    with open(inputFile) as csvfile:
        reader = csv.reader(csvfile) # change contents to floats
        reader.__next__()
        for row in reader:
          ids.append(row[0])   

    return ids

def find_accounts(accountIds):
    client = pymongo.MongoClient(dbUri)
    db = client[dbName]
    col = db[dbCollection]
    return list(col.find({"_id": {"$in": accountIds }}, {"credit": 1}))

def build_credit_batch(accounts):
    credits = []    

    for account in accounts:
        persistedCredit = account['credit']
        accountId = account['_id']
        available = Decimal(persistedCredit['available']) if ('available' in persistedCredit) else None
        balance = Decimal(persistedCredit['balance']) if ('balance' in persistedCredit) else None
        consumption = Decimal(persistedCredit['consumption']) if ('consumption' in persistedCredit) else None
        overdue = Decimal(persistedCredit['overdue']) if ('overdue' in persistedCredit) else None
        paymentTerms = persistedCredit['paymentTerms'] if ('paymentTerms' in persistedCredit) else None
        total = Decimal(persistedCredit['total']) if ('total' in persistedCredit) else None
        updatedAt = persistedCredit['updatedAt'].replace(tzinfo=timezone.utc).isoformat() if ('updatedAt' in persistedCredit) else None
        deleted = persistedCredit['deleted'] if ('deleted' in persistedCredit) else False
        credit = Credit(country, accountId, available, balance, consumption, overdue, paymentTerms, total, updatedAt, deleted)
        credits.append(credit)
    return credits

def send_to_rabbitmq(creditBatch, requestTraceId):
    headers = {'country':country, 'requestTraceId': requestTraceId}
    routing_key = "%s-batch" % (country.lower())

    payload = json.dumps(creditBatch, default=Credit.serialize, use_decimal=True)
    with pool.acquire() as cxn:
      cxn.channel.basic_publish(exchange=rabbitConfig['exchangeName'], routing_key=routing_key, body=payload, properties=build_properties(headers))

def find_and_send_to_rabbit(chunk):
    try:
        accounts = find_accounts(chunk)
        if accounts:
            payload = build_credit_batch(accounts)
            i = next(counter)
            request_trace_id = "%s-%s-%d-credit-data-republisher-%s" % (env, country, i, initial_time.strftime("%d-%b-%Y-%H:%M:%S"))
            send_to_rabbitmq(payload, request_trace_id)
            log.info('%d - Message was sent successful with %d credits' % (i, len(accounts)))
            accountIdsPostedSuccessful.extend(list(chunk))
        else:
          log.warn('%d - No accounts found for %d credits' % (next(counter), len(chunk)))
    except Exception as e:
        log.error("%d - '%s' when proccess credits for '%s'" % (next(counter), e.args, str(chunk)))
        return None

    return chunk

def write_result(accountIds, accountIdsPostedSuccessful):
    time_spent = datetime.now() - initial_time
    log.info('Total execution time %s' % time_spent)
    total = len(accountIds)
    totalMigrated = len(accountIdsPostedSuccessful)
    log.info('Result: \'%d\' from \'%d\' credits were republished successful' % (totalMigrated, total))

    difference = list(set(accountIds).difference(set(accountIdsPostedSuccessful)))        
    
    diffLen = len(difference)
    if diffLen > 0:
        log.info('Generating \'%s\' file with \'%d\' non republished credits', resultOutputFile, diffLen)
        with open(resultOutputFile, 'w', newline='') as myfile:
            wr = csv.writer(myfile, delimiter='\n')
            wr.writerow(['_id'])
            wr.writerow(difference)
    else:
        log.info('All credits were republished successful')

def process():
    accountIdLists = [] 
    accountIds = None

    try:
        accountIds = export_database_account_Ids()
        accountIdLists = chunk_list(accountIds, batchSize)
        futures = [] 
        for chunk in accountIdLists:
            futures.append(poll_executor.submit(find_and_send_to_rabbit, chunk))

        for future in concurrent.futures.as_completed(futures):
            try:
                future.result()
            except Exception as e:
                log.error("Future error '%s'" % (e.args))
    except KeyboardInterrupt:
        log.info('Interrupted')
        write_result(accountIds, accountIdsPostedSuccessful)
        try:
            sys.exit(0)
        except SystemExit:
            os._exit(0)
    except Exception:            
        log.error("Processing error. Detail: {0}".format(traceback.print_exc()))
    finally:     
        write_result(accountIds, accountIdsPostedSuccessful)

process()
