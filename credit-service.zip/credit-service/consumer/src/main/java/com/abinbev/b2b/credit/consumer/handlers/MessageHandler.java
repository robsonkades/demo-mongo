package com.abinbev.b2b.credit.consumer.handlers;

import com.newrelic.api.agent.Trace;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class MessageHandler {

    private static final Logger logger = LoggerFactory.getLogger(MessageHandler.class);

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @Trace
    public void send(final String exchange, final String routingKey, final Message message) {
        try {
            rabbitTemplate.send(exchange, routingKey, message);
        } catch (final AmqpException e) {
            logger.error(e.getMessage(),e);
            throw e;
        }
    }
}

