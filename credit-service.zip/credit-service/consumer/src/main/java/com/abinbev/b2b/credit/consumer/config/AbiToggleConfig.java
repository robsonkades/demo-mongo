package com.abinbev.b2b.credit.consumer.config;

public interface AbiToggleConfig {
    boolean isEnabledMultiVendorPerCountry(final String country);
}
