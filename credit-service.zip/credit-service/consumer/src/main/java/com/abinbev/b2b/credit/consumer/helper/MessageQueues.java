package com.abinbev.b2b.credit.consumer.helper;

import java.util.ArrayList;
import java.util.List;

public class MessageQueues {

    private List<String> creditQueues = new ArrayList<>();

    private List<String> creditBatchQueues = new ArrayList<>();

    private List<String> sharedCreditQueues = new ArrayList<>();

    private List<String> sharedCreditBatchQueues = new ArrayList<>();

    public List<String> getCreditQueues() {
        return creditQueues;
    }

    public void addCreditQueue(final String queue) {
        this.creditQueues.add(queue);
    }

    public List<String> getCreditBatchQueues() {
        return creditBatchQueues;
    }

    public void addCreditBatchQueue(final String queue) {
        this.creditBatchQueues.add(queue);
    }

    public List<String> getSharedCreditQueues() {
        return sharedCreditQueues;
    }

    public void addSharedCreditQueue(final String queue) {
        this.sharedCreditQueues.add(queue);
    }

    public List<String> getSharedCreditBatchQueues() {
        return sharedCreditBatchQueues;
    }

    public void addSharedCreditBatchQueue(final String queue) {
        this.sharedCreditBatchQueues.add(queue);
    }
}
