package com.abinbev.b2b.credit.consumer.listener;

import static com.newrelic.api.agent.NewRelic.addCustomParameter;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import com.abinbev.b2b.credit.consumer.handlers.MessageHandler;
import com.abinbev.b2b.credit.consumer.helper.RabbitHelper;
import com.abinbev.b2b.credit.consumer.helper.constants.Constants;
import com.abinbev.b2b.credit.consumer.vo.SharedCreditMessage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.newrelic.api.agent.Trace;

@Component
public class SharedCreditBatchListenerImpl implements SharedCreditBatchListener {

    private static final Logger logger = LoggerFactory.getLogger(SharedCreditBatchListenerImpl.class);

    private final MessageHandler messageHandler;

    private final ObjectMapper mapper;

    @Value("${message.exchanges.credits}")
    private String exchangeName;

    @Value("${message.routingKeys.sharedCredits}")
    private String sharedRoutingKey;

    @Autowired
    public SharedCreditBatchListenerImpl(final MessageHandler messageHandler, final ObjectMapper mapper) {
        this.messageHandler = messageHandler;
        this.mapper = mapper;
    }

    @Trace(dispatcher = true)
    @RabbitListener(queues = { "#{messageQueues.getSharedCreditBatchQueues()}" }, containerFactory = "simpleContainerFactoryCredit")
    public void receive(@Header String country, @Header String requestTraceId, @Payload final List<SharedCreditMessage> message) {
        addCustomParameter(Constants.COUNTRY_HEADER, country);
        addCustomParameter(Constants.REQUEST_TRACE_ID_HEADER, requestTraceId);
        logger.info("Shared credit batch message received size: {}", message.size());

        final String routingKey = RabbitHelper.buildRoutingKey(country, this.sharedRoutingKey);
        final MessageProperties prop = new MessageProperties();
        prop.setHeader(Constants.COUNTRY_HEADER, country);
        prop.setHeader(Constants.REQUEST_TRACE_ID_HEADER, requestTraceId);
        prop.setContentType(MediaType.APPLICATION_JSON_VALUE);
        message
                .parallelStream()
                .forEach(creditMessage -> {
                    try {
                        final Message m = MessageBuilder
                                .withBody(this.mapper.writeValueAsBytes(creditMessage))
                                .andProperties(prop)
                                .build();
                        messageHandler.send(this.exchangeName, routingKey, m);
                    } catch (final JsonProcessingException e) {
                        logger.error("Could not serialize message: {}", e.getMessage(), e);
                    }
                });
        logger.info("Shared credit batch message processed");
    }
}
