package com.abinbev.b2b.credit.consumer.helper;

import com.abinbev.b2b.credit.consumer.event.CreditEventData;
import com.abinbev.b2b.credit.consumer.vo.CreditMessage;
import com.abinbev.b2b.credit.consumer.vo.SharedCreditMessage;

public class CreditEventDataHelper {

    private CreditEventDataHelper() {
        super();
    }

    public static CreditEventData createCreditEventData(final CreditMessage credit) {
        final CreditEventData creditEventData = new CreditEventData();
        if (credit != null) {
            creditEventData.setAccountId(credit.getAccountId());
            creditEventData.setCountry(credit.getCountry());
            creditEventData.setBalance(credit.getBalance());
            creditEventData.setOverdue(credit.getOverdue());
            creditEventData.setAvailable(credit.getAvailable());
            creditEventData.setPaymentTerms(credit.getPaymentTerms());
            creditEventData.setTotal(credit.getTotal());
            creditEventData.setConsumption(credit.getConsumption());
        }
        return creditEventData;
    }

    public static CreditEventData createCreditEventData(final String accountId, final SharedCreditMessage credit) {
        final CreditEventData creditEventData = new CreditEventData();
        creditEventData.setCountry(credit.getCountry());
        creditEventData.setBalance(credit.getBalance());
        creditEventData.setOverdue(credit.getOverdue());
        creditEventData.setAvailable(credit.getAvailable());
        creditEventData.setPaymentTerms(credit.getPaymentTerms());
        creditEventData.setTotal(credit.getTotal());
        creditEventData.setConsumption(credit.getConsumption());
        creditEventData.setAccountId(accountId);
        return creditEventData;
    }
}