package com.abinbev.b2b.credit.consumer.config.property;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@Configuration
@ConfigurationProperties(prefix = "message")
public class MessageQueueProperties {

    private Set<String> countries = new HashSet<>();

    private Map<String, String> queues = new HashMap<>();

    private Map<String, String> exchanges = new HashMap<>();

    private Map<String, String> routingKeys = new HashMap<>();

    public Set<String> getCountries() {
        return countries;
    }

    public void setCountries(final Set<String> countries) {
        this.countries = countries;
    }

    public Map<String, String> getQueues() {
        return queues;
    }

    public void setQueues(final Map<String, String> queues) {
        this.queues = queues;
    }

    public Map<String, String> getExchanges() {
        return exchanges;
    }

    public void setExchanges(final Map<String, String> exchanges) {
        this.exchanges = exchanges;
    }

    public Map<String, String> getRoutingKeys() {
        return routingKeys;
    }

    public void setRoutingKeys(final Map<String, String> routingKeys) {
        this.routingKeys = routingKeys;
    }
}
