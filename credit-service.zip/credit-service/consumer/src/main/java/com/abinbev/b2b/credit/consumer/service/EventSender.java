package com.abinbev.b2b.credit.consumer.service;

import com.abinbev.b2b.credit.consumer.event.Event;

@FunctionalInterface
public interface EventSender {

    void sendEvent(final Object dataObjectToSend, final Event event, final String country);

}
