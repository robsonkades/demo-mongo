package com.abinbev.b2b.credit.consumer.config.property;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@ConfigurationProperties(prefix = "features")
public class FeatureProperties {

    private List<String> countriesSendCreditToEventHub;

    public List<String> getCountriesSendCreditToEventHub() {
        return countriesSendCreditToEventHub;
    }

    public void setCountriesSendCreditToEventHub(final List<String> countriesSendCreditToEventHub) {
        this.countriesSendCreditToEventHub = countriesSendCreditToEventHub;
    }

    public boolean shouldSendCreditToEventHub(final String country) {
        return country != null && countriesSendCreditToEventHub != null && countriesSendCreditToEventHub.contains(country);
    }

}
