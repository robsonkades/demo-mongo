package com.abinbev.b2b.credit.consumer.exception;

import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.retry.MessageRecoverer;
import org.springframework.amqp.rabbit.retry.RepublishMessageRecoverer;

import com.abinbev.b2b.credit.consumer.helper.RabbitHelper;

public class CustomMessageRecover implements MessageRecoverer {

    private RabbitTemplate rabbitTemplate;

    public CustomMessageRecover(final RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    @Override
    public void recover(final Message message, final Throwable cause) {

        final String routingKeyFormatted = RabbitHelper.buildDeadLetterRoutingKey(message.getMessageProperties().getReceivedRoutingKey());

        final RepublishMessageRecoverer republishMessageRecoverer = new RepublishMessageRecoverer(rabbitTemplate, message
                .getMessageProperties()
                .getReceivedExchange(), routingKeyFormatted);
        republishMessageRecoverer.recover(message, cause);
    }
}