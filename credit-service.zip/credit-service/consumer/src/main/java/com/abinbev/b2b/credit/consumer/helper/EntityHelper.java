package com.abinbev.b2b.credit.consumer.helper;

import java.util.Set;

import com.abinbev.b2b.credit.consumer.vo.CreditMessage;
import com.abinbev.b2b.credit.consumer.vo.SharedCreditMessage;
import com.abinbev.b2b.credit.utilities.domain.Credit;

public class EntityHelper {

    private EntityHelper() {
        super();
    }

    public static Credit convertFrom(final CreditMessage message) {
        return Credit
                .builder()
                .withAccountId(message.getAccountId())
                .withBalance(message.getBalance())
                .withOverdue(message.getOverdue())
                .withAvailable(message.getAvailable())
                .withPaymentTerms(message.getPaymentTerms())
                .withTotal(message.getTotal())
                .withConsumption(message.getConsumption())
                .withUpdatedAt(message.getUpdatedAt())
                .build();
    }

    public static Credit convertFrom(final String parentId, final SharedCreditMessage message, final Set<String> childIds) {
        return Credit
                .builder()
                .withAccountId(parentId)
                .withBalance(message.getBalance())
                .withOverdue(message.getOverdue())
                .withAvailable(message.getAvailable())
                .withPaymentTerms(message.getPaymentTerms())
                .withTotal(message.getTotal())
                .withConsumption(message.getConsumption())
                .withUpdatedAt(message.getUpdatedAt())
                .withChildIds(childIds)
                .build();

    }
}
