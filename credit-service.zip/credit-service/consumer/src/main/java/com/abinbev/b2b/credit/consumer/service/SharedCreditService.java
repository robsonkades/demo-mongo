package com.abinbev.b2b.credit.consumer.service;

import com.abinbev.b2b.credit.consumer.vo.SharedCreditMessage;

@FunctionalInterface
public interface SharedCreditService {
    void processMessage(final String country, final SharedCreditMessage message);
}
