package com.abinbev.b2b.credit.consumer.service;

import com.abinbev.b2b.credit.consumer.vo.CreditMessage;

@FunctionalInterface
public interface CreditService {
    void processMessage(final CreditMessage message);
}
