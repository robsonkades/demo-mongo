package com.abinbev.b2b.credit.consumer.service;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.abinbev.b2b.credit.consumer.config.AbiToggleConfig;
import com.abinbev.b2b.credit.consumer.config.property.FeatureProperties;
import com.abinbev.b2b.credit.consumer.event.CreditEvent;
import com.abinbev.b2b.credit.consumer.exception.AccountNotFoundException;
import com.abinbev.b2b.credit.consumer.exception.ListenerException;
import com.abinbev.b2b.credit.consumer.helper.CreditEventDataHelper;
import com.abinbev.b2b.credit.consumer.helper.EntityHelper;
import com.abinbev.b2b.credit.consumer.remote.client.AccountClient;
import com.abinbev.b2b.credit.consumer.vo.CreditMessage;
import com.abinbev.b2b.credit.utilities.domain.Credit;
import com.abinbev.b2b.credit.utilities.exception.IssueEnum;
import com.abinbev.b2b.credit.utilities.exception.IssueHandler;
import com.abinbev.b2b.credit.utilities.repository.CreditDao;
import com.newrelic.api.agent.Trace;

@Service
public class CreditServiceImpl implements CreditService {

    private static final Logger logger = LogManager.getLogger(CreditServiceImpl.class);

    private final CreditDao dao;

    private final EventSender eventSender;

    private final FeatureProperties featureProperties;

    private final AbiToggleConfig abiToggleConfig;

    private final AccountClient accountClient;

    @Autowired
    public CreditServiceImpl(final CreditDao dao, final EventSender eventSender, final FeatureProperties featureProperties, final AbiToggleConfig abiToggleConfig, final AccountClient accountClient) {
        this.dao = dao;
        this.eventSender = eventSender;
        this.featureProperties = featureProperties;
        this.abiToggleConfig = abiToggleConfig;
        this.accountClient = accountClient;
    }

    @Trace
    @Override
    public void processMessage(final CreditMessage message) {
        final String country = message.getCountry();

        try {
            if (abiToggleConfig.isEnabledMultiVendorPerCountry(country)) {
                final var accounts = accountClient.getAccountIdsByVendorAccountIdAndVendorId(country, Set.of(message.getAccountId()), message.getVendorId());
                if (!CollectionUtils.isEmpty(accounts)) {
                    final var account = accounts.get(0);
                    message.setAccountId(account.getAccountId());
                } else {
                    throw new AccountNotFoundException(IssueHandler.createIssue(IssueEnum.ACCOUNT_NOT_FOUND, message.getAccountId(), message.getVendorId()));
                }

            }

            final Optional<Credit> persistedCredit = dao.findById(country, message.getAccountId());

            if (persistedCredit.isPresent() && !message.getUpdatedAt().isAfter(persistedCredit.get().getUpdatedAt())){
                logger.info("Credit message discarded because it's outdated.");
                return;
            }

            if(message.isDeleted()){
                handleDeletion(message, persistedCredit);
            } else {
                handleUpsert(message, persistedCredit);
            }
        } catch (final Exception ex) {
            logger.error(ex.getMessage());
            throw ex;
        }
    }

    private void handleDeletion(final CreditMessage message, final Optional<Credit> persistedCredit) {
        final boolean isSharedCredit = persistedCredit.isPresent() && StringUtils.isNotBlank(persistedCredit.get().getParentId());
        if(isSharedCredit){
            // Unsupported feature for shared credits. See #BEESFI-7017
            throw new UnsupportedOperationException(String.format("Discarding a credit deletion message with accountId '%s' because shared credit deletion is not supported.", message.getAccountId()));
        }
        final boolean wasSuccessfull = this.dao.remove(message.getCountry(), message.getUpdatedAt(), message.getAccountId());
        if(wasSuccessfull) {
            notifyEventHubIfNecessary(message, CreditEvent.CREDITDELETED);
        }
    }

    private void handleUpsert(final CreditMessage message, final Optional<Credit> persistedCredit) {
        if (message.getConsumption() == null) {
            message.setConsumption(BigDecimal.ZERO);
        }

        final boolean succeeded = dao.upsert(message.getCountry(), EntityHelper.convertFrom(message));
        if (succeeded) {
            logger.info("The Credit with accountId '{}' was saved", message.getAccountId());
            normalizeSharedCreditIfNecessary(message.getCountry(), message.getUpdatedAt(), persistedCredit);
        } else {
            throw new ListenerException(String.format("Fail when trying to save Credit with accountId '%s' and updatedAt '%s'", message.getAccountId(), message.getUpdatedAt()));
        }

        final CreditEvent creditEvent;
        if (persistedCredit.isPresent()) {
            creditEvent = CreditEvent.CREDITUPDATED;
        } else {
            creditEvent = CreditEvent.CREDITCREATED;
        }

        notifyEventHubIfNecessary(message, creditEvent);
    }

    private void notifyEventHubIfNecessary(final CreditMessage message, final CreditEvent creditEvent) {
        if (featureProperties.shouldSendCreditToEventHub(message.getCountry())) {
            eventSender.sendEvent(CreditEventDataHelper.createCreditEventData(message), creditEvent, message.getCountry());
        } else {
            logger.info("Send credit to event hub is disabled for country: {}", message.getCountry());
        }
    }

    @Trace
    void normalizeSharedCreditIfNecessary(final String country, final OffsetDateTime timestamp, final Optional<Credit> databaseCredit) {
        if (databaseCredit.isPresent() && StringUtils.isNotBlank(databaseCredit.get().getParentId())) {
            try {
                final String accountId = databaseCredit.get().getAccountId();

                final String parentId = databaseCredit.get().getParentId();

                final Optional<Credit> parentCredit = this.dao.findById(country, parentId);
                if(parentCredit.isEmpty()){
                    logger.info("The parent credit '{}' was not found for '{}', no normalization required", parentId, accountId);
                    return;
                }
                if (!CollectionUtils.isEmpty(parentCredit.get().getChildIds())) {
                    final Credit credit = parentCredit.get();
                    final HashSet<String> childIds = new HashSet<>(parentCredit
                                                                          .get()
                                                                          .getChildIds());
                    childIds.remove(accountId);
                    parentCredit.get().setChildIds(childIds);
                    credit.setUpdatedAt(timestamp);
                    if(CollectionUtils.isEmpty(childIds)){
                        dao.remove(country, Collections.singletonList(parentId));
                        logger.info("Removing of the parent credit '{}' without children has been successful", parentId);
                    } else {
                        dao.upsert(country, credit);
                        logger.info("Removing of '{}' from the parent credit '{}' has been successful", accountId, parentId);
                    }
                }
            } catch (final Exception ex) {
                logger.error(ex.getMessage());
            }
        }
    }
}
