package com.abinbev.b2b.credit.consumer.vo;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.abinbev.b2b.credit.utilities.formatter.OffsetDateTimeDeserializer;
import com.abinbev.b2b.credit.utilities.formatter.OffsetDateTimeSerializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

public abstract class AbstractCreditMessage {

    private String country;

    private String vendorId;

    @Digits(integer = 30, fraction = 8)
    private BigDecimal balance;

    @Digits(integer = 30, fraction = 8)
    private BigDecimal overdue;

    @Digits(integer = 30, fraction = 8)
    private BigDecimal available;

    @Size(max = 255)
    private String paymentTerms;

    @Digits(integer = 30, fraction = 8)
    private BigDecimal total;

    @Digits(integer = 30, fraction = 8)
    @Min(0)
    private BigDecimal consumption;

    @JsonSerialize(using = OffsetDateTimeSerializer.class)
    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    private OffsetDateTime updatedAt;

    private boolean deleted;

    protected AbstractCreditMessage() {
        super();
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(final String country) {
        this.country = country;
    }

    public String getVendorId() {
        return vendorId;
    }

    public void setVendorId(final String vendorId) {
        this.vendorId = vendorId;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(final BigDecimal balance) {
        this.balance = balance;
    }

    public BigDecimal getOverdue() {
        return overdue;
    }

    public void setOverdue(final BigDecimal overdue) {
        this.overdue = overdue;
    }

    public BigDecimal getAvailable() {
        return available;
    }

    public void setAvailable(final BigDecimal available) {
        this.available = available;
    }

    public String getPaymentTerms() {
        return paymentTerms;
    }

    public void setPaymentTerms(final String paymentTerms) {
        this.paymentTerms = paymentTerms;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(final BigDecimal total) {
        this.total = total;
    }

    public BigDecimal getConsumption() {
        return consumption;
    }

    public void setConsumption(final BigDecimal consumption) {
        this.consumption = consumption;
    }

    public OffsetDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(final OffsetDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(final boolean deleted) {
        this.deleted = deleted;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}
