package com.abinbev.b2b.credit.consumer.service;

import com.abinbev.b2b.credit.consumer.config.property.RestEventProperties;
import com.abinbev.b2b.credit.consumer.event.CreditEventData;
import com.abinbev.b2b.credit.consumer.event.Event;
import com.abinbev.b2b.credit.consumer.helper.constants.Constants;
import com.abinbev.b2b.credit.utilities.remote.client.RemoteClient;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

@Component
@Profile("e2e")
public class RestEventService implements EventSender {

    private static final String EVENT_HEADER = "event";
    private static final String PORT_SEPARATOR = ":";
    private static final String CREDIT_EVENT_ENDPOINT = "/creditEvents";

    @Autowired
    private RestEventProperties restEventProperties;

    @Autowired
    private RemoteClient restClient;

    @Override
    public void sendEvent(final Object dataObjectToSend, final Event event, final String country) {
        final HttpHeaders headers = new HttpHeaders();
        headers.add(EVENT_HEADER, event.toString());
        headers.add(Constants.COUNTRY_HEADER, country);
        headers.add(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        headers.add(Constants.REQUEST_TRACE_ID_HEADER, MDC.get(Constants.REQUEST_TRACE_ID_HEADER));

        restClient
                .post(restEventProperties.getBaseUrl()
                        .concat(PORT_SEPARATOR)
                        .concat(restEventProperties.getPort())
                        .concat(CREDIT_EVENT_ENDPOINT), dataObjectToSend, headers, CreditEventData.class);
    }

}
