package com.abinbev.b2b.credit.consumer.event;

public enum CreditEvent implements Event {

    CREDITCREATED, CREDITUPDATED, CREDITDELETED

}
