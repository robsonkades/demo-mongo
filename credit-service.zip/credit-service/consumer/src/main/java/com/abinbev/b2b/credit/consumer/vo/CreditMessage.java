package com.abinbev.b2b.credit.consumer.vo;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

import javax.validation.constraints.NotBlank;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class CreditMessage extends AbstractCreditMessage {

    @NotBlank
    private String accountId;

    public CreditMessage() {
        super();
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(final String accountId) {
        this.accountId = accountId;
    }

    public static CreditMessageBuilder builder() {
        return new CreditMessageBuilder();
    }

    public static class CreditMessageBuilder {

        private CreditMessage instance = new CreditMessage();

        public CreditMessageBuilder withAccountId(final String accountId) {
            this.instance.accountId = accountId;
            return this;
        }

        public CreditMessageBuilder withVendorId(final String vendorId) {
            this.instance.setVendorId(vendorId);
            return this;
        }

        public CreditMessageBuilder withCountry(final String country) {
            this.instance.setCountry(country);
            return this;
        }

        public CreditMessageBuilder withBalance(final BigDecimal balance) {
            this.instance.setBalance(balance);
            return this;
        }

        public CreditMessageBuilder withOverdue(final BigDecimal overdue) {
            this.instance.setOverdue(overdue);
            return this;
        }

        public CreditMessageBuilder withAvailable(final BigDecimal available) {
            this.instance.setAvailable(available);
            return this;
        }

        public CreditMessageBuilder withPaymentTerms(final String paymentTerms){
            this.instance.setPaymentTerms(paymentTerms);
            return this;
        }

        public CreditMessageBuilder withTotal(final BigDecimal total){
            this.instance.setTotal(total);
            return this;
        }

        public CreditMessageBuilder withConsumption(final BigDecimal consumption){
            this.instance.setConsumption(consumption);
            return this;
        }

        public CreditMessageBuilder withUpdatedAt(final OffsetDateTime updatedAt){
            this.instance.setUpdatedAt(updatedAt);
            return this;
        }

        public CreditMessageBuilder withDeleted(final boolean deleted){
            this.instance.setDeleted(deleted);
            return this;
        }

        public CreditMessage build(){
            return this.instance;
        }
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}
