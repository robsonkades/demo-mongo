package com.abinbev.b2b.credit.consumer.listener;

import com.abinbev.b2b.credit.consumer.vo.SharedCreditMessage;

@FunctionalInterface
public interface SharedCreditListener {

    void receive(final String country, final String requestTraceId, final SharedCreditMessage message);
}
