package com.abinbev.b2b.credit.consumer.config;

import static com.abinbev.b2b.credit.consumer.helper.RabbitHelper.buildDeadLetterRoutingKey;
import static com.abinbev.b2b.credit.consumer.helper.RabbitHelper.buildQueueName;
import static com.abinbev.b2b.credit.consumer.helper.RabbitHelper.buildRoutingKey;

import java.net.URI;
import java.net.URISyntaxException;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.Declarable;
import org.springframework.amqp.core.Declarables;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.annotation.EnableRabbit;
import org.springframework.amqp.rabbit.config.RetryInterceptorBuilder;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.rabbit.listener.RabbitListenerEndpointRegistry;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConversionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.autoconfigure.amqp.RabbitProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.retry.interceptor.RetryOperationsInterceptor;
import org.springframework.retry.policy.SimpleRetryPolicy;

import com.abinbev.b2b.credit.consumer.config.property.MessageQueueProperties;
import com.abinbev.b2b.credit.consumer.exception.CustomMessageRecover;
import com.abinbev.b2b.credit.consumer.exception.ListenerExceptionHandler;
import com.abinbev.b2b.credit.consumer.interceptor.RequestHeaderListener;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.io.JsonEOFException;

@Configuration
@EnableRabbit
public class RabbitConfig {
    private static final Logger logger = LoggerFactory.getLogger(RabbitConfig.class);

    private static final String AMQPS_PROTOCOL = "amqps";

    private static final String AMQP_PROTOCOL = "amqp";

    private static final String RABBIT_URI_PATTERN = "%s://%s:%s@%s:%d/%s";

    @Value("${message.exchanges.credits}")
    private String creditExchangeName;

    private static final Map<Class<? extends Throwable>, Boolean> IRRECOVERABLE_EXCEPTIONS = Map.of(
            org.springframework.messaging.handler.annotation.support.MethodArgumentNotValidException.class, false,
            org.springframework.web.bind.MethodArgumentNotValidException.class, false,
            MessageConversionException.class, false,
            NullPointerException.class, false,
            JsonParseException.class, false,
            DateTimeParseException.class, false,
            JsonEOFException.class, false,
            ConstraintViolationException.class, false,
            UnsupportedOperationException.class, false);

    private final MessageQueueProperties messageQueueProperties;

    private RabbitProperties properties;

    private static final String DEAD_LETTER_SUFFIX = ".deadLetter";

    private static final Map<String, TopicExchange> EXCHANGE_MAP = new HashMap<>();

    @Autowired
    public RabbitConfig(final MessageQueueProperties messageQueueProperties, final RabbitProperties properties) {
        this.messageQueueProperties = messageQueueProperties;
        this.properties = properties;
    }

    @Bean
    public TopicExchange creditExchange() {
        final TopicExchange exchange = new TopicExchange(creditExchangeName, true, false);
        EXCHANGE_MAP.put(creditExchangeName, exchange);
        return exchange;
    }

    @Bean
    public RetryOperationsInterceptor retryInterceptor(final RabbitTemplate rabbitTemplate) {
        return RetryInterceptorBuilder
                .stateless()
                .recoverer(new CustomMessageRecover(rabbitTemplate))
                .retryPolicy(simpleRetryPolicy())
                .backOffOptions(properties.getListener().getSimple().getRetry().getInitialInterval().toMillis(),
                        properties.getListener().getSimple().getRetry().getMultiplier(),
                        properties.getListener().getSimple().getRetry().getMaxInterval().toMillis())
                .build();
    }

    @Bean
    public SimpleRetryPolicy simpleRetryPolicy() {
        return new SimpleRetryPolicy(properties.getListener().getSimple().getRetry().getMaxAttempts(), IRRECOVERABLE_EXCEPTIONS, true, true);
    }

    @Bean
    @Primary
    public ConnectionFactory connectionFactoryCredit(final RabbitProperties properties) throws URISyntaxException {
        final boolean isSslEnabled = properties.getSsl() != null && properties.getSsl().getEnabled() != null && properties.getSsl().getEnabled();
        final String protocol = isSslEnabled ? AMQPS_PROTOCOL : AMQP_PROTOCOL;
        return new CachingConnectionFactory(new URI(String.format(RABBIT_URI_PATTERN, protocol, properties.getUsername(), properties.getPassword(), properties.getHost(), properties.getPort(), properties.getVirtualHost())));
    }

    @Bean
    public ApplicationRunner runner(final RabbitListenerEndpointRegistry registry, final AmqpAdmin admin) {
        return args -> registry.start();
    }

    @Bean
    public Declarables declarablesBeans(final AmqpAdmin admin) {
        final List<Declarable> declarables = new ArrayList<>();
        logger.info("Creating queues to the rabbit");
        for (final String country : messageQueueProperties.getCountries()) {
            for (final String key : messageQueueProperties
                    .getQueues()
                    .keySet()) {

                // QueueName and routingKeyName
                final String queueName = messageQueueProperties
                        .getQueues()
                        .get(key);
                final String routingKey = buildRoutingKey(country, messageQueueProperties
                        .getRoutingKeys()
                        .getOrDefault(key, StringUtils.EMPTY));

                // Exchange and topicExchange
                final String exchangeName = messageQueueProperties
                        .getExchanges()
                        .get(key);
                final TopicExchange exchange = EXCHANGE_MAP.get(exchangeName);

                //Queues and Bindings
                final Queue queue = createQueue(exchange, buildQueueName(country, queueName), buildDeadLetterRoutingKey(routingKey), admin);
                final Binding queueBinding = createBinding(queue, exchange, routingKey, admin);
                final Queue deadLetterQueue = createQueueDeadLetter(buildQueueName(country, queueName), admin);
                final Binding deadLetterBinding = createBindingDeadLetter(deadLetterQueue, exchange, admin, routingKey);

                declarables.add(queue);
                declarables.add(queueBinding);
                declarables.add(deadLetterQueue);
                declarables.add(deadLetterBinding);
            }
        }
        return new Declarables(declarables);
    }

    @Bean
    public RequestHeaderListener requestTraceIdHeaderListener() {
        return new RequestHeaderListener();
    }

    @Bean
    public Jackson2JsonMessageConverter jackson2JsonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    @Bean
    public ListenerExceptionHandler listenerExceptionHandler() {
        return new ListenerExceptionHandler();
    }

    @Bean
    public SimpleRabbitListenerContainerFactory simpleContainerFactoryCredit(@Qualifier("connectionFactoryCredit") final ConnectionFactory connectionFactory, final RabbitTemplate rabbitTemplate) {
        final SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setConnectionFactory(connectionFactory);
        factory.setAdviceChain(retryInterceptor(rabbitTemplate), requestTraceIdHeaderListener());
        factory.setMessageConverter(jackson2JsonMessageConverter());
        factory.setErrorHandler(listenerExceptionHandler());
        factory.setConcurrentConsumers(properties.getListener().getSimple().getConcurrency());
        factory.setMaxConcurrentConsumers(properties.getListener().getSimple().getMaxConcurrency());
        factory.setAutoStartup(properties.getListener().getSimple().isAutoStartup());
        factory.setPrefetchCount(properties.getListener().getSimple().getPrefetch());
        return factory;
    }

    private static Queue createQueue(final TopicExchange exchange, final String queueName, final String deadLetterRoutingKey, final AmqpAdmin admin) {
        final Queue queue = QueueBuilder
                .durable(queueName)
                .withArgument("x-dead-letter-exchange", exchange.getName())
                .withArgument("x-dead-letter-routing-key", deadLetterRoutingKey)
                .build();
        admin.declareQueue(queue);
        return queue;
    }

    private static Binding createBinding(final Queue queue, final TopicExchange exchange, final String routingKey, final AmqpAdmin admin) {
        final Binding binding = BindingBuilder
                .bind(queue)
                .to(exchange)
                .with(routingKey);
        admin.declareBinding(binding);
        return binding;
    }

    private static Queue createQueueDeadLetter(final String queueName, final AmqpAdmin admin) {
        final Queue queue = QueueBuilder
                .durable(String.format("%s%s", queueName, DEAD_LETTER_SUFFIX))
                .build();
        admin.declareQueue(queue);
        return queue;
    }

    private static Binding createBindingDeadLetter(final Queue queue, final TopicExchange exchange, final AmqpAdmin admin, final String routingKey) {
        final Binding binding = BindingBuilder
                .bind(queue)
                .to(exchange)
                .with(buildDeadLetterRoutingKey(routingKey));
        admin.declareBinding(binding);
        return binding;
    }
}
