package com.abinbev.b2b.credit.consumer.remote.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AccountEntity {

    @JsonProperty
    private String accountId;

    @JsonProperty
    private String vendorAccountId;

    @JsonProperty
    private String vendorId;

    public AccountEntity() {
        super();
    }

    public AccountEntity(final String accountId, final String vendorAccountId, final String vendorId) {
        this.accountId = accountId;
        this.vendorAccountId = vendorAccountId;
        this.vendorId = vendorId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(final String accountId) {
        this.accountId = accountId;
    }

    public String getVendorAccountId() {
        return vendorAccountId;
    }

    public void setVendorAccountId(final String vendorAccountId) {
        this.vendorAccountId = vendorAccountId;
    }

    public String getVendorId() {
        return vendorId;
    }

    public void setVendorId(final String vendorId) {
        this.vendorId = vendorId;
    }

}