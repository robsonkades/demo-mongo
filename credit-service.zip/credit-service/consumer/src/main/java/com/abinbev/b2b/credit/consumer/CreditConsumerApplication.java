package com.abinbev.b2b.credit.consumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.abinbev.b2b.credit")
public class CreditConsumerApplication {
    public static void main(final String[] args) {
        SpringApplication.run(CreditConsumerApplication.class, args);
    }
}
