package com.abinbev.b2b.credit.consumer.exception;

public class ListenerException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public ListenerException(String msg) {
        super(msg);
    }
}
