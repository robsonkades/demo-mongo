package com.abinbev.b2b.credit.consumer.exception;

public class EventHubException extends RuntimeException {

    private static final long serialVersionUID = -743769793355366267L;

    public EventHubException(final String message) {
        super(message);
    }

    public static EventHubException missingProperty(final String property, final String eventName) {
        return new EventHubException(String.format("Missing property %s for %s", property, eventName));
    }

    public static EventHubException noEventHubClientDefined(final String event) {
        return new EventHubException(String.format("No Event Hub Client defined for event %s", event));
    }

}
