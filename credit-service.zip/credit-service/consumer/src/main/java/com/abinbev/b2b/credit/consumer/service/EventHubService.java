package com.abinbev.b2b.credit.consumer.service;

import com.abinbev.b2b.credit.consumer.event.Event;
import com.abinbev.b2b.credit.consumer.event.EventHubClientFactory;
import com.abinbev.b2b.credit.consumer.config.property.EventHubProperties;
import com.azure.messaging.eventhubs.EventData;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.newrelic.api.agent.Trace;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.Collections;

@Component
@Profile("!e2e")
public class EventHubService implements EventSender {

    @Autowired
    private EventHubProperties eventHubProperties;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private EventHubClientFactory eventHubClientFactory;

    private static final Logger LOGGER = LoggerFactory.getLogger(EventHubService.class);

    @Trace
    @Override
    public void sendEvent(final Object dataObjectToSend, final Event event, final String country) {

        LOGGER.info("Sending an event {} to Event Hub", event);
        final long methodStartTime = System.currentTimeMillis();

        try {

            final EventData data = new EventData(objectMapper.writeValueAsString(dataObjectToSend));
            data.getProperties().put("Content-Type", "application/json");
            data.getProperties().put("country", country);
            data.getProperties().put("requestTraceId", MDC.get("requestTraceId"));

            LOGGER.info("Sending event to Event Hub");
            final long commandStart = System.currentTimeMillis();
            eventHubClientFactory.getEventHubClientFor(event).send(Collections.singletonList(data));
            LOGGER.info("Took {} ms to send event {} to Event Hub", System.currentTimeMillis() - commandStart, event);

        } catch (final Exception ex) {
            LOGGER.error(ex.getMessage(), ex);
        } finally {
            LOGGER.info("Took {} ms to execute sendEvent method", System.currentTimeMillis() - methodStartTime);
            LOGGER.info("Finished trying to send events to Event Hub");
        }

    }

}
