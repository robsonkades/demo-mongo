package com.abinbev.b2b.credit.consumer.event;

public interface Event {
}
