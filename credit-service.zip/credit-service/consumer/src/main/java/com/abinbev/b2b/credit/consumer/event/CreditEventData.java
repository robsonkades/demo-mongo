package com.abinbev.b2b.credit.consumer.event;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.math.BigDecimal;

@JsonPropertyOrder(value = {"accountId", "country", "balance", "overdue", "available", "paymentTerms", "total", "consumption", "deleted"})
public class CreditEventData implements Serializable {

    private static final long serialVersionUID = 1L;

    private String accountId;

    private String country;

    private BigDecimal balance;

    private BigDecimal overdue;

    private BigDecimal available;

    private String paymentTerms;

    private BigDecimal total;

    private boolean deleted;

    private BigDecimal consumption;

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(final String accountId) {
        this.accountId = accountId;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(final String country) {
        this.country = country;
    }

    public String getPaymentTerms() {
        return paymentTerms;
    }

    public void setPaymentTerms(final String paymentTerms) {
        this.paymentTerms = paymentTerms;
    }

    public BigDecimal getOverdue() {
        return overdue;
    }

    public void setOverdue(final BigDecimal overdue) {
        this.overdue = overdue;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(final BigDecimal balance) {
        this.balance = balance;
    }

    public boolean getDeleted() {
        return deleted;
    }

    public void setDeleted(final boolean deleted) {
        this.deleted = deleted;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(final BigDecimal total) {
        this.total = total;
    }

    public BigDecimal getConsumption() {
        return consumption;
    }

    public void setConsumption(final BigDecimal consumption) {
        this.consumption = consumption;
    }

    public BigDecimal getAvailable() {
        return available;
    }

    public void setAvailable(final BigDecimal available) {
        this.available = available;
    }
}
