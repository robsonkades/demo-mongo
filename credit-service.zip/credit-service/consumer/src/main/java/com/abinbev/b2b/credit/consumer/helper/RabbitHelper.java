package com.abinbev.b2b.credit.consumer.helper;

import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

import com.abinbev.b2b.credit.consumer.config.property.MessageQueueProperties;

@Component
public class RabbitHelper {

    private static final Logger logger = LoggerFactory.getLogger(RabbitHelper.class);

    private static final String DEAD_LETTER = "dlq";

    private static final String TEXT_QUEUE_FORMAT = "%s-%s";

    private static final String CREDITS = "credits";
    private static final String CREDITS_BATCH = "creditsBatch";
    private static final String SHARED_CREDITS = "sharedCredits";
    private static final String SHARED_CREDITS_BATCH = "sharedCreditsBatch";

    @Autowired
    private MessageQueueProperties messageQueueProperties;

    private RabbitHelper() {
    }

    @Bean
    public MessageQueues messageQueues() {
        final MessageQueues messageQueues = new MessageQueues();
        final Set<String> queuesKeySet = messageQueueProperties.getQueues().keySet();
        final Set<String> countries = messageQueueProperties.getCountries();

        for (final String country : countries) {
            for (final String key : queuesKeySet) {
                switch (key){
                    case CREDITS:
                        messageQueues.addCreditQueue(buildQueueName(country, messageQueueProperties.getQueues().get(key)));
                        break;
                    case CREDITS_BATCH:
                        messageQueues.addCreditBatchQueue(buildQueueName(country, messageQueueProperties.getQueues().get(key)));
                        break;
                    case SHARED_CREDITS:
                        messageQueues.addSharedCreditQueue(buildQueueName(country, messageQueueProperties.getQueues().get(key)));
                        break;
                    case SHARED_CREDITS_BATCH:
                        messageQueues.addSharedCreditBatchQueue(buildQueueName(country, messageQueueProperties.getQueues().get(key)));
                        break;
                    default:
                        logger.warn("Unmaped queue type '{}'", key);
                }
            }
        }
        return messageQueues;
    }

    public static String buildQueueName(final String country, final String queueSuffixName) {
        return String.format(TEXT_QUEUE_FORMAT, country.toLowerCase(), queueSuffixName);
    }

    public static String buildRoutingKey(final String country) {
        return country.toLowerCase();
    }

    public static String buildRoutingKey(final String country, final String routingKeySuffixName) {
        if (StringUtils.isEmpty(routingKeySuffixName)) {
            return buildRoutingKey(country);
        }
        return String.format(TEXT_QUEUE_FORMAT, country.toLowerCase(), routingKeySuffixName);
    }

    public static String buildDeadLetterRoutingKey(final String routingKey) {
        return String.format(TEXT_QUEUE_FORMAT, routingKey.toLowerCase(), DEAD_LETTER);
    }

}
