package com.abinbev.b2b.credit.consumer.listener;

import java.util.List;

import com.abinbev.b2b.credit.consumer.vo.SharedCreditMessage;

@FunctionalInterface
public interface SharedCreditBatchListener {

    void receive(final String country, final String requestTraceId, final List<SharedCreditMessage> message);
}
