package com.abinbev.b2b.credit.consumer.config;

import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.abinbev.b2b.common.toggle.core.toggler.ABIToggler;
import com.abinbev.b2b.credit.consumer.helper.constants.Constants;

@Profile("!e2e")
@Component
public class AbiToggleConfigImpl implements AbiToggleConfig {

    private static final Logger logger = LoggerFactory.getLogger(AbiToggleConfigImpl.class);

    @Value("${abi.toggle.multiVendorEnabled}")
    private String multiVendorEnabled;

    @Autowired
    private ABIToggler toggler;

    @Override
    public boolean isEnabledMultiVendorPerCountry(final String country) {

        final Map<String, Object> attributes = Map.of(Constants.COUNTRY_HEADER, country);
        final var featureEnabled = toggler.isFeatureEnabled(multiVendorEnabled, UUID.randomUUID().toString(), attributes);

        logger.info("Feature toggle '{}' has value '{}' for country '{}' by Optimizely.", multiVendorEnabled, featureEnabled, country);
        return featureEnabled;
    }
}
