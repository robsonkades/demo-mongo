package com.abinbev.b2b.credit.consumer.vo;

import java.util.Set;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

public class SharedCreditMessage extends AbstractCreditMessage {

    @NotNull
    @Size(min = 1)
    private Set<String> accountId;

    public SharedCreditMessage(){
        super();
    }

    public Set<String> getAccountId() {
        return accountId;
    }

    public void setAccountId(final Set<String> accountId) {
        this.accountId = accountId;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}
