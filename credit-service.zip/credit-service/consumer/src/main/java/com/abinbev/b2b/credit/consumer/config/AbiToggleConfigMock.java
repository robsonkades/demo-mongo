package com.abinbev.b2b.credit.consumer.config;

import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import com.google.common.reflect.TypeToken;
import com.google.gson.Gson;

@Profile("e2e")
@Component
public class AbiToggleConfigMock implements AbiToggleConfig {

    final Type type = new TypeToken<Map<String, Boolean>>() {}.getType();

    @Value("#{environment.ENABLE_MULTI_VENDOR_PER_COUNTRY}")
    private String enabledMultiVendorPerCountryFromEnv;

    private Map<String, Boolean> enabledMultiVendorPerCountry = new HashMap<>();

    @Override
    public boolean isEnabledMultiVendorPerCountry(final String country) {
        if (StringUtils.isNotBlank(this.enabledMultiVendorPerCountryFromEnv)) {
            this.enabledMultiVendorPerCountry = new Gson().fromJson(enabledMultiVendorPerCountryFromEnv, type);
        }

        return enabledMultiVendorPerCountry.getOrDefault(StringUtils.lowerCase(country), false);
    }
}
