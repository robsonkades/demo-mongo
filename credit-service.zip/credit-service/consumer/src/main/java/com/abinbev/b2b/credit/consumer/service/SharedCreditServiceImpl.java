package com.abinbev.b2b.credit.consumer.service;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.CollectionUtils;

import com.abinbev.b2b.credit.consumer.config.AbiToggleConfig;
import com.abinbev.b2b.credit.consumer.config.property.FeatureProperties;
import com.abinbev.b2b.credit.consumer.event.CreditEvent;
import com.abinbev.b2b.credit.consumer.exception.AccountNotFoundException;
import com.abinbev.b2b.credit.consumer.helper.CreditEventDataHelper;
import com.abinbev.b2b.credit.consumer.helper.EntityHelper;
import com.abinbev.b2b.credit.consumer.remote.client.AccountClient;
import com.abinbev.b2b.credit.consumer.remote.entity.AccountEntity;
import com.abinbev.b2b.credit.consumer.vo.SharedCreditMessage;
import com.abinbev.b2b.credit.utilities.domain.Credit;
import com.abinbev.b2b.credit.utilities.exception.IssueEnum;
import com.abinbev.b2b.credit.utilities.exception.IssueHandler;
import com.abinbev.b2b.credit.utilities.repository.CreditDao;
import com.google.common.collect.ImmutableList;
import com.newrelic.api.agent.Trace;

@Service
public class SharedCreditServiceImpl implements SharedCreditService {

    private static final Logger logger = LogManager.getLogger(SharedCreditServiceImpl.class);

    private final CreditDao dao;

    private final EventSender eventSender;

    private final FeatureProperties featureProperties;

    private final AbiToggleConfig abiToggleConfig;

    private final AccountClient accountClient;

    @Autowired
    public SharedCreditServiceImpl(final CreditDao dao, final EventSender eventSender, final FeatureProperties featureProperties, final AbiToggleConfig abiToggleConfig, final AccountClient accountClient) {
        this.dao = dao;
        this.eventSender = eventSender;
        this.featureProperties = featureProperties;
        this.abiToggleConfig = abiToggleConfig;
        this.accountClient = accountClient;
    }

    @Trace
    @Transactional
    @Override
    public void processMessage(final String country, final SharedCreditMessage message) {
        try {
            if (message.isDeleted()) {
                // Unsupported feature for shared credits. See #BEESFI-7017
                throw new UnsupportedOperationException(String.format("Discarding a credit deletion message with accountIds '%s' because shared credit deletion is not supported.", message.getAccountId()));
            }

            if (abiToggleConfig.isEnabledMultiVendorPerCountry(country)) {
                final var accountsResponse = accountClient.getAccountIdsByVendorAccountIdAndVendorId(country, message.getAccountId(), message.getVendorId());

                final var accounts = Optional.ofNullable(accountsResponse).orElse(Collections.emptyList());
                final var vendorAccountIds = accounts.stream().map(AccountEntity::getVendorAccountId).collect(Collectors.toSet());

                if (vendorAccountIds.containsAll(message.getAccountId())) {
                    final var accountIds = accounts.stream().map(AccountEntity::getAccountId).collect(Collectors.toSet());
                    message.setAccountId(accountIds);
                } else {
                    throw new AccountNotFoundException(IssueHandler.createIssue(IssueEnum.ACCOUNT_NOT_FOUND, message.getAccountId(), message.getVendorId()));
                }

            }

            logger.info("Start creating shared persistedCredits for accountIds '{}'", message.getAccountId());
            final List<Credit> persistedCredits = dao.findByAccountIds(country, message.getAccountId());
            if (CollectionUtils.isEmpty(persistedCredits)) {
                createSharedCredits(country, message);
            } else {
                upsertSharedCredits(country, message, persistedCredits);
            }
        } catch (final Exception ex) {
            logger.error(ex.getMessage());
            throw ex;
        }
    }

    @Trace
    private void upsertSharedCredits(final String country, final SharedCreditMessage message, final List<Credit> persistedCredits) {
        final List<String> parentIds = findParentIds(persistedCredits);
        final List<Credit> parents = CollectionUtils.isEmpty(parentIds) ? Collections.emptyList() : this.dao.findByAccountIds(country, parentIds);
        boolean isSingle = parents.size() == 1;

        final String parentId = isSingle ?
                parents
                        .get(0)
                        .getAccountId() :
                UUID
                        .randomUUID()
                        .toString();

        logger.info("The '{}' parent credit ID will be used for '{}'", parentId, message.getAccountId());
        final Map<String, Credit> persistedCreditMap = persistedCredits
                .stream()
                .collect(Collectors.toMap(Credit::getAccountId, c -> c));

        final Set<String> outdatedCredits = message
                .getAccountId()
                .stream()
                .filter(accountId -> {
                    final Credit persistedCredit = persistedCreditMap.get(accountId);
                    return persistedCredit != null && (persistedCredit
                            .getUpdatedAt()
                            .isEqual(message.getUpdatedAt()) || persistedCredit
                            .getUpdatedAt()
                            .isAfter(message.getUpdatedAt()));
                })
                .collect(Collectors.toSet());

        for (final Credit persistedParent : parents) {
            handleSharedCreditConflicts(country, message, parentIds, isSingle, persistedParent, outdatedCredits);
        }

        if (CollectionUtils.isEmpty(outdatedCredits)) {
            logger.info("All persistedCredits are up to date");
        } else {
            logger.info("The following persistedCredits are outdated '{}'", outdatedCredits);
        }

        final Set<Credit> childs = message
                .getAccountId()
                .stream()
                .filter(accountId -> !outdatedCredits.contains(accountId))
                .map(accountId -> new Credit(accountId, parentId, message.getUpdatedAt()))
                .collect(Collectors.toSet());

        final Credit parent = EntityHelper.convertFrom(parentId, message, childs
                .stream()
                .map(Credit::getAccountId)
                .collect(Collectors.toSet()));

        if (CollectionUtils.isEmpty(parent.getChildIds())) {
            logger.info("Discarding shared credit persistence for '{}' because data is out of date", message.getAccountId());
            return;
        }

        this.dao.upsert(country, parent);
        this.dao.upsertChildCredits(country, childs);

        if (featureProperties.shouldSendCreditToEventHub(country)) {
            childs
                    .parallelStream()
                    .forEach(c -> {
                        final CreditEvent event = persistedCreditMap.get(c.getAccountId()) != null ? CreditEvent.CREDITUPDATED : CreditEvent.CREDITCREATED;
                        sendEventHubNotification(country, event, c, message);
                    });
        } else {
            logger.info("Send credit to event hub is disabled for country: {}", message.getCountry());
        }

        logger.info("Shared persistedCredits successfully saved to '{}'", message.getAccountId());
    }

    @Trace
    private void createSharedCredits(final String country, final SharedCreditMessage message) {
        final String parentId = UUID
                .randomUUID()
                .toString();

        final Credit parent = EntityHelper.convertFrom(parentId, message, message.getAccountId());

        final Set<Credit> childs = message
                .getAccountId()
                .stream()
                .map(accountId -> new Credit(accountId, parentId, message.getUpdatedAt()))
                .collect(Collectors.toSet());
        this.dao.upsert(country, parent);
        this.dao.upsertChildCredits(country, childs);
        if (featureProperties.shouldSendCreditToEventHub(country)) {
            childs
                    .parallelStream()
                    .forEach(c -> sendEventHubNotification(country, CreditEvent.CREDITCREATED, c, message));
        }
        logger.info("Shared credits for accountIds '{}' were created successful", message.getAccountId());
    }

    @Trace
    private void handleSharedCreditConflicts(final String country, final SharedCreditMessage message, final List<String> parentIds, final boolean isSingle, final Credit persistedParent,
                                             final Set<String> outdatedCredits) {
        final Set<String> accountIds = new HashSet<>(message.getAccountId());
        accountIds.removeAll(outdatedCredits);
        if (persistedParent.getChildIds() != null && !CollectionUtils.isEmpty(accountIds) && !persistedParent
                .getChildIds()
                .equals(accountIds)) {
            final Set<String> tmp = new HashSet<>(persistedParent.getChildIds());
            tmp.removeAll(accountIds);
            if (isSingle) {
                if (!CollectionUtils.isEmpty(tmp)) {
                    logger.info("Removing orphan credits for accountIds '{}'", tmp);
                    this.dao.removeChildCredits(country, persistedParent.getAccountId(), message.getUpdatedAt(), tmp);
                }
            } else {
                logger.info("Resolving shared credit conflicts for '{}' where the following parents were found '{}'", accountIds, parentIds);
                if (CollectionUtils.isEmpty(tmp)) {
                    logger.info("Removing unused parent credit '{}'", persistedParent.getAccountId());
                    this.dao.remove(country, Collections.singletonList(persistedParent.getAccountId()));
                } else if (!persistedParent
                        .getChildIds()
                        .equals(tmp)) {
                    logger.info("Updating children to '{}' in the '{}' parent credit", tmp, persistedParent.getAccountId());
                    persistedParent.setChildIds(tmp);
                    persistedParent.setUpdatedAt(message.getUpdatedAt());
                    this.dao.upsert(country, persistedParent);
                }
            }
        }
    }

    private List<String> findParentIds(final List<Credit> credits) {
        if (credits == null) {
            return Collections.emptyList();
        }
        final Set<String> tmp = credits
                .stream()
                .map(Credit::getParentId)
                .filter(StringUtils::isNotBlank)
                .collect(Collectors.toSet()); // toSet to avoid duplicated values
        return CollectionUtils.isEmpty(tmp) ? Collections.emptyList() : ImmutableList.copyOf(tmp);
    }

    @Trace
    private void sendEventHubNotification(final String country, final CreditEvent creditEvent, final Credit credit, final SharedCreditMessage message) {
        eventSender.sendEvent(CreditEventDataHelper.createCreditEventData(credit.getAccountId(), message), creditEvent, country);
    }
}
