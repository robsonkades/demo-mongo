package com.abinbev.b2b.credit.consumer.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.ErrorHandler;

public class ListenerExceptionHandler implements ErrorHandler {

    private static final Logger logger = LoggerFactory.getLogger(ListenerExceptionHandler.class);

    @Autowired
    private Jackson2JsonMessageConverter jackson2JsonMessageConverter;

    @Override
    public void handleError(final Throwable throwable) {
        logger.error(throwable.getMessage(), throwable);
        throw new AmqpRejectAndDontRequeueException(throwable);
    }
}
