package com.abinbev.b2b.credit.consumer.listener;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import com.abinbev.b2b.credit.consumer.service.SharedCreditService;
import com.abinbev.b2b.credit.consumer.vo.SharedCreditMessage;
import com.newrelic.api.agent.Trace;

@Component
public class SharedCreditListenerImpl implements SharedCreditListener {

    private static final Logger logger = LoggerFactory.getLogger(SharedCreditListenerImpl.class);

    private final SharedCreditService service;

    @Autowired
    public SharedCreditListenerImpl(final SharedCreditService service) {
        this.service = service;
    }

    @Trace(dispatcher = true)
    @RabbitListener(queues = { "#{messageQueues.getSharedCreditQueues()}" }, containerFactory = "simpleContainerFactoryCredit")
    public void receive(@Header String country, @Header String requestTraceId, @Valid @Payload final SharedCreditMessage message) {
        logger.info("Shared Credit listener '{}' '{}' === '{}'", country, requestTraceId, message);
        service.processMessage(country, message);
        logger.info("Shared credit was successful");
    }
}
