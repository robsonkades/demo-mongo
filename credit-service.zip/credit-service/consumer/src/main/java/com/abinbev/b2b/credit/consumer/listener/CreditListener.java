package com.abinbev.b2b.credit.consumer.listener;

import com.abinbev.b2b.credit.consumer.helper.constants.Constants;
import com.abinbev.b2b.credit.consumer.service.CreditService;
import com.abinbev.b2b.credit.consumer.vo.CreditMessage;
import com.newrelic.api.agent.Trace;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import javax.validation.Valid;

import static com.newrelic.api.agent.NewRelic.addCustomParameter;

@Component
public class CreditListener {

    private static final Logger logger = LogManager.getLogger(CreditListener.class);

    private final CreditService service;

    @Autowired
    public CreditListener(final CreditService service) {
        this.service = service;
    }

    @Trace(dispatcher = true)
    @RabbitListener(queues = { "#{messageQueues.getCreditQueues()}" }, containerFactory = "simpleContainerFactoryCredit")
    public void receive(@Header String country, @Header String requestTraceId, @Valid @Payload final CreditMessage creditMessage) {
        addCustomParameter(Constants.COUNTRY_HEADER, country);
        addCustomParameter(Constants.REQUEST_TRACE_ID_HEADER, requestTraceId);
        creditMessage.setCountry(country);
        logger.info("Credit message received for accountId: {} and updatedAt: {}", creditMessage.getAccountId(), creditMessage.getUpdatedAt());
        service.processMessage(creditMessage);
    }
}
