package com.abinbev.b2b.credit.consumer.interceptor;

import com.abinbev.b2b.credit.consumer.exception.ListenerException;
import com.abinbev.b2b.credit.utilities.helper.Constants;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.support.ListenerExecutionFailedException;

/**
 * Generic interceptor for all RabbitListener.
 */
public class RequestHeaderListener implements MethodInterceptor {

    @Override
    public Object invoke(final MethodInvocation invocation) throws Throwable {

        final Message message = (Message) invocation.getArguments()[1];

        try {
            final String requestTraceId = findRequestHeaders(Constants.REQUEST_TRACE_ID_HEADER, message);
            final String country = findRequestHeaders(Constants.COUNTRY_HEADER, message);
            MDC.put(Constants.REQUEST_TRACE_ID_HEADER, requestTraceId);
            MDC.put(Constants.COUNTRY_HEADER, country);

            return invocation.proceed();
        } finally {
            MDC.clear();
        }
    }

    private String findOptionalRequestReader(final String param, final Message message) {
        return (String) message
                .getMessageProperties()
                .getHeaders()
                .get(param);
    }

    private String findRequestHeaders(final String param, final Message message) {
        final String requestTraceId = findOptionalRequestReader(param, message);

        if (StringUtils.isEmpty(requestTraceId)) {
            throw new ListenerExecutionFailedException(String.format("Undefined %s header.", param),
                    new ListenerException(String.format("Missing %s header on message.", param)), message);
        }
        return requestTraceId;
    }
}
