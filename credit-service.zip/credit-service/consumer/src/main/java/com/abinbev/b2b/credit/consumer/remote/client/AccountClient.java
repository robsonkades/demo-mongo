package com.abinbev.b2b.credit.consumer.remote.client;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.util.UriComponentsBuilder;

import com.abinbev.b2b.credit.consumer.helper.constants.Constants;
import com.abinbev.b2b.credit.consumer.remote.entity.AccountEntity;
import com.abinbev.b2b.credit.utilities.remote.client.RemoteClient;

@Component
public class AccountClient {

	private static final Logger logger = LoggerFactory.getLogger(AccountClient.class);

	private static final String VENDOR_ACCOUNT_ID_PARAM = "vendorAccountId";

	private static final String VENDOR_ID_PARAM = "vendorId";

	@Value("${microservices.accountService.url}")
	private String url;

	private final RemoteClient remoteClient;

	@Autowired
	public AccountClient(final RemoteClient remoteClient) {
		this.remoteClient = remoteClient;
	}

	public List<AccountEntity> getAccountIdsByVendorAccountIdAndVendorId(final String country, final Set<String> vendorAccountIds, final String vendorId) {
		try {
			logger.info("Calling '{}' to get account for vendorAccountIds: '{}' and vendorId: '{}'", Constants.ACCOUNT_REMOTE_SERVICE, vendorAccountIds, vendorId);

			if (CollectionUtils.isEmpty(vendorAccountIds) || StringUtils.isBlank(vendorId) ) {
				return Collections.emptyList();
			}

			final String uri = UriComponentsBuilder
					.fromHttpUrl(this.url)
					.queryParam(VENDOR_ACCOUNT_ID_PARAM, vendorAccountIds)
					.queryParam(VENDOR_ID_PARAM, vendorId)
					.build()
					.toUriString();

			final var exchange = remoteClient.getForObject(uri, buildRequestHeader(country), AccountEntity[].class, Constants.ACCOUNT_REMOTE_SERVICE);
			logger.info("Request to '{}' using vendorAccountIds: '{}' and vendorId: '{}' was successful", Constants.ACCOUNT_REMOTE_SERVICE, vendorAccountIds, vendorId);

			final AccountEntity[] accounts = exchange.getBody();
			return accounts == null || accounts.length == 0 ? Collections.emptyList() : Arrays.asList(accounts);

		} catch (final HttpStatusCodeException ex) {
			logger.error(ex.getMessage(), ex);
			return Collections.emptyList();
		}
	}

	private HttpHeaders buildRequestHeader(final String country) {
		final HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
		headers.set(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
		headers.add(Constants.COUNTRY_HEADER, country);
		headers.add(Constants.REQUEST_TRACE_ID_HEADER, String.valueOf(MDC.get(Constants.REQUEST_TRACE_ID_HEADER)));
		return headers;
	}

}