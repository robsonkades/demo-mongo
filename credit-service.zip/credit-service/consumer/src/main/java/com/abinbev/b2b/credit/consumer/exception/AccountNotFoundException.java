package com.abinbev.b2b.credit.consumer.exception;

import org.springframework.http.HttpStatus;

import com.abinbev.b2b.credit.utilities.exception.GlobalException;
import com.abinbev.b2b.credit.utilities.exception.Issue;

public class AccountNotFoundException extends GlobalException {

    private static final long serialVersionUID = 1L;

    public AccountNotFoundException(final Issue issue) {
        super(issue, HttpStatus.NOT_FOUND);
    }
}
