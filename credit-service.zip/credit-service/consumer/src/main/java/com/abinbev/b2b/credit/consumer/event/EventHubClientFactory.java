package com.abinbev.b2b.credit.consumer.event;

import com.abinbev.b2b.credit.consumer.config.property.EventHubProperties;
import com.abinbev.b2b.credit.consumer.config.property.EventHubProperties.EventHubAmqpRetryOptions;
import com.abinbev.b2b.credit.consumer.exception.EventHubException;
import com.azure.core.amqp.AmqpRetryMode;
import com.azure.core.amqp.AmqpRetryOptions;
import com.azure.messaging.eventhubs.EventHubClientBuilder;
import com.azure.messaging.eventhubs.EventHubProducerClient;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.time.Duration;

@Component
@Scope("singleton")
public class EventHubClientFactory {

    private static final Logger logger = LoggerFactory.getLogger(EventHubClientFactory.class);

    private final AmqpRetryOptions retryOptions = new AmqpRetryOptions();

    private final EventHubProperties eventHubProperties;

    private EventHubProducerClient creditCreatedClient;

    private EventHubProducerClient creditUpdatedClient;

    private EventHubProducerClient creditDeletedClient;

    @Autowired
    public EventHubClientFactory(final EventHubProperties eventHubProperties) {
        this.eventHubProperties = eventHubProperties;
        this.init();
    }

    private void init() {
        EventHubAmqpRetryOptions eventHubAmqpRetryOptions = eventHubProperties.getRetryOptions();
        this.retryOptions.setMaxRetries(eventHubAmqpRetryOptions.getMaxRetries());
        this.retryOptions.setDelay(Duration.ofMillis(eventHubAmqpRetryOptions.getDelay()));
        this.retryOptions.setMaxDelay(Duration.ofMillis(eventHubAmqpRetryOptions.getMaxDelay()));
        this.retryOptions.setTryTimeout(Duration.ofMillis(eventHubAmqpRetryOptions.getTryTimeout()));
        this.retryOptions.setMode(AmqpRetryMode.EXPONENTIAL);
        logger.info("Initializing EventHub AMQP retry options with maxRetries: '{}' delay: '{}' maxDelay: '{}' tryTimeout: '{}'.",
                    this.retryOptions.getMaxRetries(), this.retryOptions.getDelay(), this.retryOptions.getMaxDelay(), this.retryOptions.getTryTimeout());
    }

    public EventHubProducerClient getCreditCreatedEventHubClient() {
        if (creditCreatedClient == null) {
            checkEventHubProperties(CreditEvent.CREDITCREATED);
            creditCreatedClient = new EventHubClientBuilder()
                    .connectionString(eventHubProperties.getEventHubConnectionStringByEvent(CreditEvent.CREDITCREATED),
                            eventHubProperties.getEventHubNameByEvent(CreditEvent.CREDITCREATED))
                    .retry(retryOptions)
                    .buildProducerClient();
        }
        return creditCreatedClient;
    }

    public EventHubProducerClient getCreditUpdatedEventHubClient() {
        if (creditUpdatedClient == null) {
            checkEventHubProperties(CreditEvent.CREDITUPDATED);
            creditUpdatedClient = new EventHubClientBuilder()
                    .connectionString(eventHubProperties.getEventHubConnectionStringByEvent(CreditEvent.CREDITUPDATED),
                            eventHubProperties.getEventHubNameByEvent(CreditEvent.CREDITUPDATED))
                    .retry(retryOptions)
                    .buildProducerClient();
        }
        return creditUpdatedClient;
    }

    public EventHubProducerClient getCreditDeletedEventHubClient() {
        if (creditDeletedClient == null) {
            checkEventHubProperties(CreditEvent.CREDITDELETED);
            creditDeletedClient = new EventHubClientBuilder()
                    .connectionString(eventHubProperties.getEventHubConnectionStringByEvent(CreditEvent.CREDITDELETED),
                            eventHubProperties.getEventHubNameByEvent(CreditEvent.CREDITDELETED))
                    .retry(retryOptions)
                    .buildProducerClient();
        }
        return creditDeletedClient;
    }

    private void checkEventHubProperties(final Event event) {
        if (StringUtils.isBlank(eventHubProperties.getEventHubConnectionStringByEvent(event))) {
            throw EventHubException.missingProperty("event-hub.connectionString", event.toString());
        }
        if (StringUtils.isBlank(eventHubProperties.getEventHubNameByEvent(event))) {
            throw EventHubException.missingProperty("event-hub.name", event.toString());
        }
    }

    public EventHubProducerClient getEventHubClientFor(final Event event) {
        switch (event.toString()) {
            case "CREDITCREATED":
                return getCreditCreatedEventHubClient();
            case "CREDITUPDATED":
                return getCreditUpdatedEventHubClient();
            case "CREDITDELETED":
                return getCreditDeletedEventHubClient();
            default:
                throw EventHubException.noEventHubClientDefined(event.toString());
        }
    }
}
