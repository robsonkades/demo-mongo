package com.abinbev.b2b.credit.consumer.listener;

import com.abinbev.b2b.credit.consumer.handlers.MessageHandler;
import com.abinbev.b2b.credit.consumer.helper.RabbitHelper;
import com.abinbev.b2b.credit.consumer.helper.constants.Constants;
import com.abinbev.b2b.credit.consumer.vo.CreditMessage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.newrelic.api.agent.Trace;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.messaging.handler.annotation.Header;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import javax.validation.Valid;
import java.util.List;

import static com.newrelic.api.agent.NewRelic.addCustomParameter;

@Component
public class CreditBatchListener {

    private static final Logger logger = LogManager.getLogger(CreditBatchListener.class);

    private final MessageHandler messageHandler;

    private final ObjectMapper mapper;

    @Value("${message.exchanges.credits}")
    private String exchangeName;

    @Autowired
    public CreditBatchListener(MessageHandler messageHandler, ObjectMapper mapper) {
        this.messageHandler = messageHandler;
        this.mapper = mapper;
    }

    @Trace(dispatcher = true)
    @RabbitListener(queues = { "#{messageQueues.getCreditBatchQueues()}" }, containerFactory = "simpleContainerFactoryCredit")
    public void receive(@Valid @Payload final List<CreditMessage> creditMessages, @Header String country, @Header String requestTraceId) {
        addCustomParameter(Constants.COUNTRY_HEADER, country);
        addCustomParameter(Constants.REQUEST_TRACE_ID_HEADER, requestTraceId);
        logger.info("Credit batch message received size: {}", creditMessages.size());
        creditMessages.parallelStream().forEach(creditMessage -> {
            try {

                final MessageProperties prop = new MessageProperties();
                prop.setHeader(Constants.COUNTRY_HEADER, country);
                prop.setHeader(Constants.REQUEST_TRACE_ID_HEADER, requestTraceId);
                prop.setContentType(MediaType.APPLICATION_JSON_VALUE);

                final Message message = MessageBuilder
                        .withBody(this.mapper.writeValueAsBytes(creditMessage))
                        .andProperties(prop)
                        .build();

                final String routingKey = RabbitHelper.buildRoutingKey(country);
                messageHandler.send(this.exchangeName, routingKey, message);
            } catch (final JsonProcessingException e) {
                logger.error("Could not serialize message: {}", e.getMessage(), e);
            }
        });
        logger.info("Credit batch message processed");
    }
}
