package com.abinbev.b2b.credit.consumer.config.property;

import com.abinbev.b2b.credit.consumer.event.Event;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
@ConfigurationProperties(prefix = "events")
public class EventHubProperties {

    private Map<String, Map<String, String>> eventHub;

    private EventHubAmqpRetryOptions retryOptions = new EventHubAmqpRetryOptions();

    public Map<String, Map<String, String>> getEventHub() {
        return eventHub;
    }

    public void setEventHub(final Map<String, Map<String, String>> eventHub) {
        this.eventHub = eventHub;
    }

    public String getEventHubNameByEvent(final Event event) {
        return getEventHub().get(event.toString()).get("name");
    }

    public String getEventHubConnectionStringByEvent(final Event event) {
        return getEventHub().get(event.toString()).get("connectionString");
    }

    public EventHubAmqpRetryOptions getRetryOptions() {
        return retryOptions;
    }

    public void setRetryOptions(final EventHubAmqpRetryOptions retryOptions) {
        this.retryOptions = retryOptions;
    }

    public static class EventHubAmqpRetryOptions {
        private int maxRetries = 0;
        private long delay = 50L;
        private long maxDelay = 500L;
        private long tryTimeout = 4000L;

        public int getMaxRetries() {
            return maxRetries;
        }

        public void setMaxRetries(final int maxRetries) {
            this.maxRetries = maxRetries;
        }

        public long getDelay() {
            return delay;
        }

        public void setDelay(final long delay) {
            this.delay = delay;
        }

        public long getMaxDelay() {
            return maxDelay;
        }

        public void setMaxDelay(final long maxDelay) {
            this.maxDelay = maxDelay;
        }

        public long getTryTimeout() {
            return tryTimeout;
        }

        public void setTryTimeout(final long tryTimeout) {
            this.tryTimeout = tryTimeout;
        }
    }
}
