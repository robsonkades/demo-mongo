package com.abinbev.b2b.credit.consumer.helper.constants;

public class Constants {

    public static final String REQUEST_TRACE_ID_HEADER = "requestTraceId";

    public static final String COUNTRY_HEADER = "country";

    public static final String ACCOUNT_REMOTE_SERVICE = "account-service";

    private Constants() {
        super();
    }
}

