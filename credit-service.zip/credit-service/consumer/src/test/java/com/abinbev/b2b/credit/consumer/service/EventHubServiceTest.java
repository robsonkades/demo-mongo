package com.abinbev.b2b.credit.consumer.service;

import com.abinbev.b2b.credit.consumer.event.CreditEventData;
import com.abinbev.b2b.credit.consumer.event.EventHubClientFactory;
import com.abinbev.b2b.credit.consumer.helper.CreditEventDataHelper;
import com.abinbev.b2b.credit.consumer.vo.CreditMessage;
import com.azure.messaging.eventhubs.EventHubProducerClient;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static com.abinbev.b2b.credit.consumer.event.CreditEvent.CREDITCREATED;
import static org.mockito.ArgumentMatchers.anyIterable;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class EventHubServiceTest {

    private static final String COUNTRY = "ZA";

    @InjectMocks
    private EventHubService service;

    @Mock
    private ObjectMapper objectMapper;

    @Mock
    private EventHubClientFactory eventHubClientFactory;

    @Mock
    private EventHubProducerClient eventHubProducerClient;

    @Test
    public void successfullySendEvent() throws JsonProcessingException {
        final CreditMessage creditMessage = new CreditMessage();
        final CreditEventData creditEventData = CreditEventDataHelper.createCreditEventData(creditMessage);
        when(objectMapper.writeValueAsString(creditEventData)).thenReturn("{accountId: \"accountId\"}");
        when(eventHubClientFactory.getEventHubClientFor(CREDITCREATED)).thenReturn(eventHubProducerClient);
        doNothing().when(eventHubProducerClient).send(anyIterable());
        service.sendEvent(creditEventData, CREDITCREATED, COUNTRY);
        verify(eventHubProducerClient).send(anyIterable());
    }

    @Test
    public void errorSendingEvent() {
        // it should not throw an exception
        service.sendEvent(null, CREDITCREATED, COUNTRY);
    }

}
