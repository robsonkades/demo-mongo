package com.abinbev.b2b.credit.consumer.service;

import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.abinbev.b2b.credit.consumer.config.AbiToggleConfigImpl;
import com.abinbev.b2b.credit.consumer.config.property.FeatureProperties;
import com.abinbev.b2b.credit.consumer.event.Event;
import com.abinbev.b2b.credit.consumer.exception.AccountNotFoundException;
import com.abinbev.b2b.credit.consumer.remote.client.AccountClient;
import com.abinbev.b2b.credit.consumer.remote.entity.AccountEntity;
import com.abinbev.b2b.credit.consumer.vo.SharedCreditMessage;
import com.abinbev.b2b.credit.utilities.domain.Credit;
import com.abinbev.b2b.credit.utilities.repository.CreditDao;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.mongodb.MongoException;

@RunWith(MockitoJUnitRunner.class)
public class SharedCreditServiceImplTest {

    private static final String COUNTRY_BR = "BR";

    @Mock
    private CreditDao dao;

    @Mock
    private EventSender eventSender;

    @Mock
    private FeatureProperties featureProperties;

    @InjectMocks
    private SharedCreditServiceImpl service;

    @Mock
    private AbiToggleConfigImpl abiToggleConfig;

    @Mock
    private AccountClient accountClient;

    @Captor
    private ArgumentCaptor<List<String>> idsCaptor;

    @Captor
    private ArgumentCaptor<Credit> parentCaptor;

    @Captor
    private ArgumentCaptor<Set<Credit>> childCaptor;

    @Test
    public void testProcessMessageForNonExistentCreditsAndWithoutEventHubNotification() {
        final ImmutableSet<String> accountIds = ImmutableSet.of("111", "222", "333");

        final SharedCreditMessage message = createMessage(accountIds);
        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_BR)).thenReturn(false);
        this.service.processMessage(COUNTRY_BR, message);
        verify(dao, times(1)).findByAccountIds(COUNTRY_BR, accountIds);
        verify(dao, times(1)).upsert(eq(COUNTRY_BR), parentCaptor.capture()); //
        verify(dao, times(1)).upsertChildCredits(eq(COUNTRY_BR), childCaptor.capture());
        verify(featureProperties, times(1)).shouldSendCreditToEventHub(COUNTRY_BR);
        verify(eventSender, times(0)).sendEvent(any(), any(), any());

        assertPersistedSharedCredits(accountIds, message);
    }

    @Test
    public void testProcessMessageForNonExistentCreditsAndWithEventHubNotification() {
        final ImmutableSet<String> accountIds = ImmutableSet.of("111", "222", "333", "444", "555");
        final SharedCreditMessage message = createMessage(accountIds);
        when(featureProperties.shouldSendCreditToEventHub(COUNTRY_BR)).thenReturn(true);
        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_BR)).thenReturn(false);

        this.service.processMessage(COUNTRY_BR, message);

        verify(dao, times(1)).findByAccountIds(COUNTRY_BR, accountIds);
        verify(dao, times(1)).upsert(eq(COUNTRY_BR), parentCaptor.capture()); //
        verify(dao, times(1)).upsertChildCredits(eq(COUNTRY_BR), childCaptor.capture());
        verify(featureProperties, times(1)).shouldSendCreditToEventHub(COUNTRY_BR);
        verify(eventSender, times(accountIds.size())).sendEvent(any(), any(), any());

        assertPersistedSharedCredits(accountIds, message);
    }

    @Test
    public void testProcessMessageForNonExistentCreditsMultiVendor() {
        final ImmutableSet<String> accountIds = ImmutableSet.of("111", "222", "333");
        final SharedCreditMessage message = createMessage(accountIds);
        message.setVendorId("vendor-id-1");
        when(featureProperties.shouldSendCreditToEventHub(COUNTRY_BR)).thenReturn(true);
        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_BR)).thenReturn(true);

        final AccountEntity account1 = new AccountEntity("account-id-1", "111", message.getVendorId());
        final AccountEntity account2 = new AccountEntity("account-id-2", "222", message.getVendorId());
        final AccountEntity account3 = new AccountEntity("account-id-3", "333", message.getVendorId());
        final List<AccountEntity> accountResponse = List.of(account1, account2, account3);
        when(accountClient.getAccountIdsByVendorAccountIdAndVendorId(COUNTRY_BR, message.getAccountId(), message.getVendorId())).thenReturn(accountResponse);

        this.service.processMessage(COUNTRY_BR, message);

        verify(dao, times(1)).findByAccountIds(COUNTRY_BR, ImmutableSet.of("account-id-1", "account-id-2", "account-id-3"));
        verify(dao, times(1)).upsert(eq(COUNTRY_BR), parentCaptor.capture());
        verify(dao, times(1)).upsertChildCredits(eq(COUNTRY_BR), childCaptor.capture());
        verify(featureProperties, times(1)).shouldSendCreditToEventHub(COUNTRY_BR);
        verify(eventSender, times(accountIds.size())).sendEvent(any(Object.class), any(Event.class), any(String.class));

        assertPersistedSharedCredits(ImmutableSet.of("account-id-1", "account-id-2", "account-id-3"), message);
    }

    @Test(expected = AccountNotFoundException.class)
    public void testProcessMessageForNonExistentCreditsMultiVendorAccountsNotFound() {
        final ImmutableSet<String> accountIds = ImmutableSet.of("111", "222", "333");
        final SharedCreditMessage message = createMessage(accountIds);
        message.setVendorId("vendor-id-1");
        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_BR)).thenReturn(true);

        final AccountEntity account1 = new AccountEntity("account-id-1", "111", message.getVendorId());
        final AccountEntity account2 = new AccountEntity("account-id-2", "222", message.getVendorId());
        final List<AccountEntity> accountResponse = List.of(account1, account2);
        when(accountClient.getAccountIdsByVendorAccountIdAndVendorId(COUNTRY_BR, message.getAccountId(), message.getVendorId())).thenReturn(accountResponse);

        this.service.processMessage(COUNTRY_BR, message);
    }

    @Test(expected = MongoException.class)
    public void testProcessMessageThrowingException() {
        final ImmutableSet<String> accountIds = ImmutableSet.of("111", "222", "333");

        final SharedCreditMessage message = createMessage(accountIds);

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_BR)).thenReturn(false);
        when(dao.upsert(eq(COUNTRY_BR), any())).thenThrow(new MongoException("error"));

        try {
            this.service.processMessage(COUNTRY_BR, message);
        } catch (final Exception e){
            verify(dao, times(1)).findByAccountIds(COUNTRY_BR, accountIds);
            verify(dao, times(1)).upsert(eq(COUNTRY_BR), any()); //
            verify(dao, times(0)).upsertChildCredits(eq(COUNTRY_BR), childCaptor.capture());
            verify(featureProperties, times(0)).shouldSendCreditToEventHub(COUNTRY_BR);
            verify(eventSender, times(0)).sendEvent(any(), any(), any());

            throw e;
        }
    }

    @Test(expected = UnsupportedOperationException.class)
    public void testProcessMessageForDeletedSharedCredits() {
        final ImmutableSet<String> accountIds = ImmutableSet.of("111", "222", "333");

        final SharedCreditMessage message = createMessage(accountIds);
        message.setDeleted(true);

        try {
            this.service.processMessage(COUNTRY_BR, message);
        } catch (final UnsupportedOperationException e) {
            verify(dao, times(0)).findByAccountIds(COUNTRY_BR, accountIds);
            verify(dao, times(0)).upsert(eq(COUNTRY_BR), parentCaptor.capture()); //
            verify(dao, times(0)).upsertChildCredits(eq(COUNTRY_BR), childCaptor.capture());
            verify(featureProperties, times(0)).shouldSendCreditToEventHub(COUNTRY_BR);
            verify(eventSender, times(0)).sendEvent(any(), any(), any());
            throw e;
        }
    }

    @Test
    public void testProcessMessageForExistentCreditsAndOutdatedMessage() {
        final ImmutableSet<String> accountIds = ImmutableSet.of("111", "222", "333");
        final SharedCreditMessage message = createMessage(accountIds);
        final String parentId = "xpto";

        final List<Credit> persistedChildCredits = createChildCredits(accountIds, parentId);
        when(this.dao.findByAccountIds(COUNTRY_BR, accountIds)).thenReturn(persistedChildCredits);
        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_BR)).thenReturn(false);

        final Credit parentCredit = createParentCredit(accountIds, parentId);
        when(this.dao.findByAccountIds(COUNTRY_BR, ImmutableList.of(parentId))).thenReturn(ImmutableList.of(parentCredit));

        this.service.processMessage(COUNTRY_BR, message);
        verify(dao, times(0)).removeChildCredits(any(), any(), any(), any());
        verify(dao, times(0)).remove(any(), any());
        verify(dao, times(1)).findByAccountIds(COUNTRY_BR, accountIds);
        verify(dao, times(0)).upsert(eq(COUNTRY_BR), parentCaptor.capture()); //
        verify(dao, times(0)).upsertChildCredits(eq(COUNTRY_BR), childCaptor.capture());
        verify(featureProperties, times(0)).shouldSendCreditToEventHub(COUNTRY_BR);
        verify(eventSender, times(0)).sendEvent(any(), any(), any());
    }

    @Test
    public void testProcessMessageForExistentCreditsAndUpToDateMessageWithoutEventHubNotification() {
        final ImmutableSet<String> accountIds = ImmutableSet.of("111", "222", "333");
        final SharedCreditMessage message = createMessage(accountIds);
        final String parentId = "xpto";

        final OffsetDateTime persistedUpdatedAt = OffsetDateTime.now().minusDays(30L);
        final List<Credit> persistedChildCredits = createChildCredits(accountIds, parentId, persistedUpdatedAt);
        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_BR)).thenReturn(false);
        when(this.dao.findByAccountIds(COUNTRY_BR, accountIds)).thenReturn(persistedChildCredits);

        final Credit parentCredit = createParentCredit(accountIds, parentId, persistedUpdatedAt);
        when(this.dao.findByAccountIds(COUNTRY_BR, ImmutableList.of(parentId))).thenReturn(ImmutableList.of(parentCredit));

        this.service.processMessage(COUNTRY_BR, message);
        verify(dao, times(0)).removeChildCredits(any(), any(), any(), any());
        verify(dao, times(0)).remove(any(), any());
        verify(dao, times(1)).findByAccountIds(COUNTRY_BR, accountIds);
        verify(dao, times(1)).upsert(eq(COUNTRY_BR), parentCaptor.capture()); //
        verify(dao, times(1)).upsertChildCredits(eq(COUNTRY_BR), childCaptor.capture());
        verify(featureProperties, times(1)).shouldSendCreditToEventHub(COUNTRY_BR);
        verify(eventSender, times(0)).sendEvent(any(), any(), any());

        assertPersistedSharedCredits(accountIds, message);
    }

    @Test
    public void testProcessMessageForExistentCreditsAndUpToDateMessageWithEventHubNotification() {
        final ImmutableSet<String> accountIds = ImmutableSet.of("111", "222", "333");
        final SharedCreditMessage message = createMessage(accountIds);
        final String parentId = "xpto";

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_BR)).thenReturn(false);
        final OffsetDateTime persistedUpdatedAt = OffsetDateTime.now().minusDays(30L);
        final List<Credit> persistedChildCredits = createChildCredits(accountIds, parentId, persistedUpdatedAt);
        when(this.dao.findByAccountIds(COUNTRY_BR, accountIds)).thenReturn(persistedChildCredits);

        final Credit parentCredit = createParentCredit(accountIds, parentId, persistedUpdatedAt);
        when(this.dao.findByAccountIds(COUNTRY_BR, ImmutableList.of(parentId))).thenReturn(ImmutableList.of(parentCredit));

        when(featureProperties.shouldSendCreditToEventHub(COUNTRY_BR)).thenReturn(true);

        this.service.processMessage(COUNTRY_BR, message);
        verify(dao, times(0)).removeChildCredits(any(), any(), any(), any());
        verify(dao, times(0)).remove(any(), any());
        verify(dao, times(1)).findByAccountIds(COUNTRY_BR, accountIds);
        verify(dao, times(1)).upsert(eq(COUNTRY_BR), parentCaptor.capture()); //
        verify(dao, times(1)).upsertChildCredits(eq(COUNTRY_BR), childCaptor.capture());
        verify(featureProperties, times(1)).shouldSendCreditToEventHub(COUNTRY_BR);
        verify(eventSender, times(accountIds.size())).sendEvent(any(), any(), any());

        assertPersistedSharedCredits(accountIds, message);
    }

    @Test
    public void testProcessMessageForExistentCreditsAndUpToDateMessageWithEventHubNotificationAndOrphanedChildren() {
        final ImmutableSet<String> accountIds = ImmutableSet.of("111", "222", "333");
        final SharedCreditMessage message = createMessage(accountIds);
        final String parentId = "xpto";

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_BR)).thenReturn(false);

        final OffsetDateTime persistedUpdatedAt = OffsetDateTime.now().minusDays(30L);
        final List<Credit> persistedChildCredits = createChildCredits(accountIds, parentId, persistedUpdatedAt);
        final Set<String> children = new HashSet<>();
        children.addAll(accountIds);
        children.add("777"); // orphaned
        children.add("888"); // orphaned
        children.add("999"); // orphaned
        final Credit parentCredit = createParentCredit(children, parentId, persistedUpdatedAt);

        when(this.dao.findByAccountIds(COUNTRY_BR, accountIds)).thenReturn(persistedChildCredits);

        when(this.dao.findByAccountIds(COUNTRY_BR, ImmutableList.of(parentId))).thenReturn(ImmutableList.of(parentCredit));

        when(featureProperties.shouldSendCreditToEventHub(COUNTRY_BR)).thenReturn(true);

        this.service.processMessage(COUNTRY_BR, message);
        verify(dao, times(1)).removeChildCredits(COUNTRY_BR, parentId, message.getUpdatedAt(), ImmutableSet.of("777","888","999"));
        verify(dao, times(0)).remove(any(), any());
        verify(dao, times(1)).findByAccountIds(COUNTRY_BR, accountIds);
        verify(dao, times(1)).upsert(eq(COUNTRY_BR), parentCaptor.capture()); //
        verify(dao, times(1)).upsertChildCredits(eq(COUNTRY_BR), childCaptor.capture());
        verify(featureProperties, times(1)).shouldSendCreditToEventHub(COUNTRY_BR);
        verify(eventSender, times(accountIds.size())).sendEvent(any(), any(), any());

        assertPersistedSharedCredits(accountIds, message);
    }

    @Test
    public void testProcessMessageForExistentCreditsAndUpToDateMessageWithEventHubNotificationAndParentConflicts() {
        final ImmutableSet<String> accountIdsA = ImmutableSet.of("111", "222", "333");
        final ImmutableSet<String> accountIdsB = ImmutableSet.of("444","555", "666");

        final String parentIdA = "parent-A";
        final OffsetDateTime persistedUpdatedAt = OffsetDateTime.now().minusDays(30L);
        final List<Credit> persistedChildCreditsA = createChildCredits(accountIdsA, parentIdA, persistedUpdatedAt);
        final Credit parentCreditA = createParentCredit(accountIdsA, parentIdA, persistedUpdatedAt);

        final String parentIdB = "parent-B";
        final List<Credit> persistedChildCreditsB = createChildCredits(accountIdsB, parentIdB, persistedUpdatedAt);
        final Credit parentCreditB = createParentCredit(accountIdsB, parentIdB, persistedUpdatedAt);

        final Set<String> allIds = new HashSet<>();
        allIds.addAll(accountIdsA);
        allIds.addAll(accountIdsB);

        final List<Credit> allChildCredits = new ArrayList<>();
        allChildCredits.addAll(persistedChildCreditsA);
        allChildCredits.addAll(persistedChildCreditsB);

        final List<Credit> allParentCredits = ImmutableList.of(parentCreditA, parentCreditB);

        final SharedCreditMessage message = createMessage(allIds);

        when(this.dao.findByAccountIds(COUNTRY_BR, allIds)).thenReturn(allChildCredits);
        when(this.dao.findByAccountIds(COUNTRY_BR, ImmutableList.of(parentIdB, parentIdA))).thenReturn(allParentCredits);

        when(featureProperties.shouldSendCreditToEventHub(COUNTRY_BR)).thenReturn(true);
        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_BR)).thenReturn(false);

        this.service.processMessage(COUNTRY_BR, message);
        verify(dao, times(0)).removeChildCredits(any(), any(), any(), any());
        verify(dao, times(2)).remove(any(), idsCaptor.capture());

        final List<List<String>> allValues = idsCaptor.getAllValues();
        assertThat(allValues).isNotEmpty();
        assertThat(allValues.size()).isEqualTo(allParentCredits.size());
        assertThat(Collections.singletonList(parentIdA)).isIn(allValues);
        assertThat(Collections.singletonList(parentIdB)).isIn(allValues);

        verify(dao, times(1)).findByAccountIds(COUNTRY_BR, allIds);
        verify(dao, times(1)).upsert(eq(COUNTRY_BR), parentCaptor.capture()); //
        verify(dao, times(1)).upsertChildCredits(eq(COUNTRY_BR), childCaptor.capture());
        verify(featureProperties, times(1)).shouldSendCreditToEventHub(COUNTRY_BR);
        verify(eventSender, times(allIds.size())).sendEvent(any(), any(), any());

        assertPersistedSharedCredits(allIds, message);
    }

    @Test
    public void testProcessMessageForExistentCreditsAndUpToDateMessageWithEventHubNotificationAndChildConflicts() {
        final ImmutableSet<String> accountIdsA = ImmutableSet.of("111", "222", "333");
        final ImmutableSet<String> accountIdsB = ImmutableSet.of("444","555", "666");

        final String parentIdA = "parent-A";
        final OffsetDateTime persistedUpdatedAt = OffsetDateTime.now().minusDays(30L);
        final List<Credit> persistedChildCreditsA = createChildCredits(ImmutableSet.of("111"), parentIdA, persistedUpdatedAt);
        final Credit parentCreditA = createParentCredit(accountIdsA, parentIdA, persistedUpdatedAt);

        final String parentIdB = "parent-B";
        final List<Credit> persistedChildCreditsB = createChildCredits(ImmutableSet.of("5555"), parentIdB, persistedUpdatedAt);
        final Credit parentCreditB = createParentCredit(accountIdsB, parentIdB, persistedUpdatedAt);

        final Set<String> allIds = ImmutableSet.of("111","555");

        final List<Credit> allChildCredits = new ArrayList<>();
        allChildCredits.addAll(persistedChildCreditsA);
        allChildCredits.addAll(persistedChildCreditsB);

        final List<Credit> allParentCredits = ImmutableList.of(parentCreditA, parentCreditB);

        final SharedCreditMessage message = createMessage(allIds);

        when(this.dao.findByAccountIds(COUNTRY_BR, allIds)).thenReturn(allChildCredits);
        when(this.dao.findByAccountIds(COUNTRY_BR, ImmutableList.of(parentIdB, parentIdA))).thenReturn(allParentCredits);

        when(featureProperties.shouldSendCreditToEventHub(COUNTRY_BR)).thenReturn(true);
        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_BR)).thenReturn(false);

        this.service.processMessage(COUNTRY_BR, message);
        verify(dao, times(0)).removeChildCredits(any(), any(), any(), any());
        verify(dao, times(0)).remove(any(), any());
        verify(dao, times(1)).findByAccountIds(COUNTRY_BR, allIds);
        verify(dao, times(3)).upsert(eq(COUNTRY_BR), parentCaptor.capture()); //
        verify(dao, times(1)).upsertChildCredits(eq(COUNTRY_BR), childCaptor.capture());
        verify(featureProperties, times(1)).shouldSendCreditToEventHub(COUNTRY_BR);
        verify(eventSender, times(allIds.size())).sendEvent(any(), any(), any());

        final List<Credit> allParentsCaptured = parentCaptor.getAllValues();
        assertThat(allParentsCaptured).isNotEmpty();
        assertThat(allParentsCaptured.size()).isEqualTo(3);
        final Credit parentA = allParentsCaptured.get(0);
        assertThat(parentA).isEqualToIgnoringGivenFields(parentCreditA, "childIds", "updatedAt");
        assertThat(parentA.getChildIds()).isEqualTo(ImmutableSet.of("222","333"));
        assertThat(parentA.getUpdatedAt()).isEqualTo(message.getUpdatedAt());
        final Credit parentB = allParentsCaptured.get(1);
        assertThat(parentB).isEqualToIgnoringGivenFields(parentCreditB, "childIds", "updatedAt");
        assertThat(parentB.getChildIds()).isEqualTo(ImmutableSet.of("444","666"));
        assertThat(parentB.getUpdatedAt()).isEqualTo(message.getUpdatedAt());

        assertPersistedSharedCredits(allIds, message);
    }

    @Test
    public void testProcessMessageForExistentCreditsAndUpToDateMessageWithEventHubNotificationAndChildConflictsAndParentWithoutChildren() {
        final ImmutableSet<String> accountIdsA = ImmutableSet.of("111", "222", "333");
        final ImmutableSet<String> accountIdsB = ImmutableSet.of("444","555", "666");
        final ImmutableSet<String> accountIdsC = ImmutableSet.of("777","888");

        final String parentIdA = "parent-A";
        final OffsetDateTime persistedUpdatedAt = OffsetDateTime.now().minusDays(30L);
        final List<Credit> persistedChildCreditsA = createChildCredits(ImmutableSet.of("111"), parentIdA, persistedUpdatedAt);
        final Credit parentCreditA = createParentCredit(accountIdsA, parentIdA, persistedUpdatedAt);

        final String parentIdB = "parent-B";
        final List<Credit> persistedChildCreditsB = createChildCredits(ImmutableSet.of("5555"), parentIdB, persistedUpdatedAt);
        final Credit parentCreditB = createParentCredit(accountIdsB, parentIdB, persistedUpdatedAt);

        final String parentIdC = "parent-C";
        final List<Credit> persistedChildCreditsC = createChildCredits(accountIdsC, parentIdC, persistedUpdatedAt);
        final Credit parentCreditC = createParentCredit(accountIdsC, parentIdC, persistedUpdatedAt);

        final List<Credit> allChildCredits = new ArrayList<>();
        allChildCredits.addAll(persistedChildCreditsA);
        allChildCredits.addAll(persistedChildCreditsB);
        allChildCredits.addAll(persistedChildCreditsC);

        final List<Credit> allParentCredits = ImmutableList.of(parentCreditA, parentCreditB, parentCreditC);

        final Set<String> allIds = ImmutableSet.of("111","555","777", "888");
        final SharedCreditMessage message = createMessage(allIds);

        when(this.dao.findByAccountIds(COUNTRY_BR, allIds)).thenReturn(allChildCredits);
        when(this.dao.findByAccountIds(COUNTRY_BR, ImmutableList.of(parentIdB, parentIdA, parentIdC))).thenReturn(allParentCredits);

        when(featureProperties.shouldSendCreditToEventHub(COUNTRY_BR)).thenReturn(true);
        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_BR)).thenReturn(false);

        this.service.processMessage(COUNTRY_BR, message);

        verify(dao, times(0)).removeChildCredits(any(), any(), any(), any());
        verify(dao, times(1)).remove(COUNTRY_BR, Collections.singletonList(parentIdC));
        verify(dao, times(1)).findByAccountIds(COUNTRY_BR, allIds);
        verify(dao, times(3)).upsert(eq(COUNTRY_BR), parentCaptor.capture()); //
        verify(dao, times(1)).upsertChildCredits(eq(COUNTRY_BR), childCaptor.capture());
        verify(featureProperties, times(1)).shouldSendCreditToEventHub(COUNTRY_BR);
        verify(eventSender, times(allIds.size())).sendEvent(any(), any(), any());

        final List<Credit> allParentsCaptured = parentCaptor.getAllValues();
        assertThat(allParentsCaptured).isNotEmpty();
        assertThat(allParentsCaptured.size()).isEqualTo(3);
        final Credit parentA = allParentsCaptured.get(0);
        assertThat(parentA).isEqualToIgnoringGivenFields(parentCreditA, "childIds", "updatedAt");
        assertThat(parentA.getChildIds()).isEqualTo(ImmutableSet.of("222","333"));
        assertThat(parentA.getUpdatedAt()).isEqualTo(message.getUpdatedAt());
        final Credit parentB = allParentsCaptured.get(1);
        assertThat(parentB).isEqualToIgnoringGivenFields(parentCreditB, "childIds", "updatedAt");
        assertThat(parentB.getChildIds()).isEqualTo(ImmutableSet.of("444","666"));
        assertThat(parentB.getUpdatedAt()).isEqualTo(message.getUpdatedAt());

        assertPersistedSharedCredits(allIds, message);
    }

    @Test
    public void testProcessMessageForExistentCreditsAndUpToDateMessageWithEventHubNotificationAndOutdatedChildren() {
        final ImmutableSet<String> accountIdsA = ImmutableSet.of("111", "222", "333");
        final ImmutableSet<String> accountIdsB = ImmutableSet.of("444","555", "666");

        final String parentIdA = "parent-A";
        final OffsetDateTime persistedUpdatedAt = OffsetDateTime.now().minusDays(30L);
        final List<Credit> persistedChildCreditsA = createChildCredits(ImmutableSet.of("111"), parentIdA, persistedUpdatedAt);
        final Credit parentCreditA = createParentCredit(accountIdsA, parentIdA, persistedUpdatedAt);

        final String parentIdB = "parent-B";
        final List<Credit> persistedChildCreditsB = createChildCredits(ImmutableSet.of("555"), parentIdB, OffsetDateTime.now().plusDays(3L));
        final Credit parentCreditB = createParentCredit(accountIdsB, parentIdB, persistedUpdatedAt);

        final Set<String> allIds = ImmutableSet.of("111","555");

        final List<Credit> allChildCredits = new ArrayList<>();
        allChildCredits.addAll(persistedChildCreditsA);
        allChildCredits.addAll(persistedChildCreditsB);

        final List<Credit> allParentCredits = ImmutableList.of(parentCreditA, parentCreditB);

        final SharedCreditMessage message = createMessage(allIds);

        when(this.dao.findByAccountIds(COUNTRY_BR, allIds)).thenReturn(allChildCredits);
        when(this.dao.findByAccountIds(COUNTRY_BR, ImmutableList.of(parentIdB, parentIdA))).thenReturn(allParentCredits);

        when(featureProperties.shouldSendCreditToEventHub(COUNTRY_BR)).thenReturn(true);
        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_BR)).thenReturn(false);

        this.service.processMessage(COUNTRY_BR, message);
        verify(dao, times(0)).removeChildCredits(any(), any(), any(), any());
        verify(dao, times(0)).remove(any(), any());
        verify(dao, times(1)).findByAccountIds(COUNTRY_BR, allIds);
        verify(dao, times(2)).upsert(eq(COUNTRY_BR), parentCaptor.capture()); //
        verify(dao, times(1)).upsertChildCredits(eq(COUNTRY_BR), childCaptor.capture());
        verify(featureProperties, times(1)).shouldSendCreditToEventHub(COUNTRY_BR);
        verify(eventSender, times(1)).sendEvent(any(), any(), any()); // just once, because 555 is outdated

        final List<Credit> allParentsCaptured = parentCaptor.getAllValues();
        assertThat(allParentsCaptured).isNotEmpty();
        assertThat(allParentsCaptured.size()).isEqualTo(2);
        final Credit parentA = allParentsCaptured.get(0);
        assertThat(parentA).isEqualToIgnoringGivenFields(parentCreditA, "childIds", "updatedAt");
        assertThat(parentA.getChildIds()).isEqualTo(ImmutableSet.of("222","333"));
        assertThat(parentA.getUpdatedAt()).isEqualTo(message.getUpdatedAt());

        assertPersistedSharedCredits(ImmutableSet.of("111"), message);
    }

    @Test
    public void testProcessMessageForExistentCreditsAndUpToDateMessageWithEventHubNotificationAndChildrenAndNonSharedOutdated() {
        final ImmutableSet<String> accountIdsA = ImmutableSet.of("111", "222", "333");
        final ImmutableSet<String> accountIdsB = ImmutableSet.of("444","555", "666");
        final ImmutableSet<String> accountIdsC = ImmutableSet.of("999","101010");
        final ImmutableSet<String> accountIdsD = ImmutableSet.of("foo","bar");

        final Credit nonSharedA = new Credit();
        nonSharedA.setAccountId("777");
        nonSharedA.setAvailable(BigDecimal.TEN);
        nonSharedA.setBalance(BigDecimal.ONE);
        nonSharedA.setConsumption(BigDecimal.ZERO);
        nonSharedA.setOverdue(new BigDecimal("2"));
        nonSharedA.setPaymentTerms("CREDIT");
        nonSharedA.setTotal(new BigDecimal("20"));
        nonSharedA.setUpdatedAt(OffsetDateTime.now().minusMinutes(5L));

        final Credit nonSharedB = new Credit();
        nonSharedB.setAccountId("888");
        nonSharedB.setAvailable(BigDecimal.TEN);
        nonSharedB.setBalance(BigDecimal.ONE);
        nonSharedB.setConsumption(BigDecimal.ZERO);
        nonSharedB.setOverdue(new BigDecimal("2"));
        nonSharedB.setPaymentTerms("CREDIT");
        nonSharedB.setTotal(new BigDecimal("20"));
        nonSharedB.setUpdatedAt(OffsetDateTime.now().plusDays(15L));

        final String parentIdA = "parent-A";
        final OffsetDateTime persistedUpdatedAt = OffsetDateTime.now().minusDays(30L);
        final List<Credit> persistedChildCreditsA = createChildCredits(ImmutableSet.of("111"), parentIdA, persistedUpdatedAt);
        final Credit parentCreditA = createParentCredit(accountIdsA, parentIdA, persistedUpdatedAt);

        final String parentIdB = "parent-B";
        final List<Credit> persistedChildCreditsB = createChildCredits(ImmutableSet.of("555"), parentIdB, OffsetDateTime.now().plusDays(3L));
        final Credit parentCreditB = createParentCredit(accountIdsB, parentIdB, persistedUpdatedAt);

        final String parentIdC = "parent-C";
        final List<Credit> persistedChildCreditsC = createChildCredits(accountIdsC, parentIdC, OffsetDateTime.now().plusDays(3L));
        final Credit parentCreditC = createParentCredit(accountIdsC, parentIdC, persistedUpdatedAt);

        final String parentIdD = "parent-D";
        final List<Credit> persistedChildCreditsD = createChildCredits(accountIdsD, parentIdD, OffsetDateTime.now().minusDays(3L));
        final Credit parentCreditD = createParentCredit(accountIdsD, parentIdD, persistedUpdatedAt);

        final Set<String> allIds = ImmutableSet.of("111","555","777","888","999","101010","111110", "foo", "bar");

        final List<Credit> allChildCredits = new ArrayList<>();
        allChildCredits.addAll(persistedChildCreditsA);
        allChildCredits.addAll(persistedChildCreditsB);
        allChildCredits.addAll(persistedChildCreditsC);
        allChildCredits.addAll(persistedChildCreditsD);
        allChildCredits.add(nonSharedA);
        allChildCredits.add(nonSharedB);

        final List<Credit> allParentCredits = ImmutableList.of(parentCreditA, parentCreditB, parentCreditC, parentCreditD);

        final SharedCreditMessage message = createMessage(allIds);

        when(this.dao.findByAccountIds(COUNTRY_BR, allIds)).thenReturn(allChildCredits);
        when(this.dao.findByAccountIds(COUNTRY_BR, ImmutableList.of(parentIdB, parentIdA, parentIdD, parentIdC))).thenReturn(allParentCredits);

        when(featureProperties.shouldSendCreditToEventHub(COUNTRY_BR)).thenReturn(true);
        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_BR)).thenReturn(false);

        this.service.processMessage(COUNTRY_BR, message);
        verify(dao, times(0)).removeChildCredits(any(), any(), any(), any());
        verify(dao, times(1)).remove(COUNTRY_BR, Collections.singletonList(parentIdD));
        verify(dao, times(1)).findByAccountIds(COUNTRY_BR, allIds);
        verify(dao, times(2)).upsert(eq(COUNTRY_BR), parentCaptor.capture()); //
        verify(dao, times(1)).upsertChildCredits(eq(COUNTRY_BR), childCaptor.capture());
        verify(featureProperties, times(1)).shouldSendCreditToEventHub(COUNTRY_BR);
        verify(eventSender, times(5)).sendEvent(any(), any(), any()); // Not for 555, 888, 999, 101010, because they are outdated

        final List<Credit> allParentsCaptured = parentCaptor.getAllValues();
        assertThat(allParentsCaptured).isNotEmpty();
        assertThat(allParentsCaptured.size()).isEqualTo(2);
        final Credit parentA = allParentsCaptured.get(0);
        assertThat(parentA).isEqualToIgnoringGivenFields(parentCreditA, "childIds", "updatedAt");
        assertThat(parentA.getChildIds()).isEqualTo(ImmutableSet.of("222","333"));
        assertThat(parentA.getUpdatedAt()).isEqualTo(message.getUpdatedAt());

        assertPersistedSharedCredits(ImmutableSet.of("111","777", "111110", "foo", "bar"), message);
    }

    private void assertPersistedSharedCredits(final Set<String> accountIds, final SharedCreditMessage message) {
        final Credit parent = parentCaptor.getValue();
        assertThat(parent.getAccountId()).isNotIn(accountIds);
        assertThat(parent.getAvailable()).isEqualTo(message.getAvailable());
        assertThat(parent.getBalance()).isEqualTo(message.getBalance());
        assertThat(parent.getConsumption()).isEqualTo(message.getConsumption());
        assertThat(parent.getOverdue()).isEqualTo(message.getOverdue());
        assertThat(parent.getPaymentTerms()).isEqualTo(message.getPaymentTerms());
        assertThat(parent.getTotal()).isEqualTo(message.getTotal());
        assertThat(parent.getUpdatedAt()).isEqualTo(message.getUpdatedAt());
        assertThat(parent.getChildIds()).isEqualTo(accountIds);
        assertThat(parent.getParentId()).isNull();

        final Set<Credit> children = childCaptor.getValue();
        assertThat(children).isNotEmpty();
        assertThat(children.size()).isEqualTo(accountIds.size());

        final List<Credit> childrenList = new ArrayList<>(children);
        for (int i = 0; i < accountIds.size(); i++) {
            assertThat(childrenList
                               .get(i)
                               .getAccountId()).isIn(accountIds);
            assertThat(childrenList
                               .get(i)
                               .getParentId()).isEqualTo(parent.getAccountId());
            assertThat(childrenList
                               .get(i)
                               .getUpdatedAt()).isEqualTo(parent.getUpdatedAt());

            assertThat(childrenList
                               .get(i)
                               .getAvailable()).isNull();
            assertThat(childrenList
                               .get(i)
                               .getBalance()).isNull();
            assertThat(childrenList
                               .get(i)
                               .getConsumption()).isNull();
            assertThat(childrenList
                               .get(i)
                               .getOverdue()).isNull();
            assertThat(childrenList
                               .get(i)
                               .getPaymentTerms()).isNull();
            assertThat(childrenList
                               .get(i)
                               .getTotal()).isNull();
            assertThat(childrenList
                               .get(i)
                               .getChildIds()).isNull();
        }
    }

    private SharedCreditMessage createMessage(final Set<String> accountIds) {
        final SharedCreditMessage credit = new SharedCreditMessage();
        credit.setAccountId(accountIds);
        credit.setAvailable(BigDecimal.TEN);
        credit.setBalance(BigDecimal.ONE);
        credit.setConsumption(BigDecimal.ZERO);
        credit.setOverdue(new BigDecimal("2"));
        credit.setPaymentTerms("CREDIT");
        credit.setTotal(new BigDecimal("20"));
        credit.setUpdatedAt(OffsetDateTime.now());
        return credit;
    }

    private Credit createParentCredit(final Set<String> accountIds, final String parentId) {
        return createParentCredit(accountIds, parentId, OffsetDateTime.now());
    }

    private Credit createParentCredit(final Set<String> accountIds, final String parentId, final OffsetDateTime updatedAt) {
        final Credit credit = new Credit();
        credit.setAccountId(parentId);
        credit.setAvailable(BigDecimal.TEN);
        credit.setBalance(BigDecimal.ONE);
        credit.setConsumption(BigDecimal.ZERO);
        credit.setOverdue(new BigDecimal("2"));
        credit.setPaymentTerms("CREDIT");
        credit.setTotal(new BigDecimal("20"));
        credit.setUpdatedAt(updatedAt);
        credit.setChildIds(accountIds);
        return credit;
    }

    private List<Credit> createChildCredits(final Set<String> accountIds, String parentId) {
        return createChildCredits(accountIds, parentId, OffsetDateTime.now());
    }

    private List<Credit> createChildCredits(final Set<String> accountIds, final String parentId, final OffsetDateTime updatedAt) {
        final List<Credit> credits = new ArrayList<>();
        for (final String accountId : accountIds) {
            final Credit credit = new Credit();
            credit.setAccountId(accountId);
            credit.setUpdatedAt(updatedAt);
            credit.setParentId(parentId);
            credits.add(credit);
        }
        return credits;
    }
}