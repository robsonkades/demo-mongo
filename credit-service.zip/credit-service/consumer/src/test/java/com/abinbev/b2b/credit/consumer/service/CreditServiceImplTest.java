package com.abinbev.b2b.credit.consumer.service;

import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.abinbev.b2b.credit.consumer.config.AbiToggleConfigImpl;
import com.abinbev.b2b.credit.consumer.config.property.FeatureProperties;
import com.abinbev.b2b.credit.consumer.event.CreditEvent;
import com.abinbev.b2b.credit.consumer.event.CreditEventData;
import com.abinbev.b2b.credit.consumer.exception.ListenerException;
import com.abinbev.b2b.credit.consumer.helper.EntityHelper;
import com.abinbev.b2b.credit.consumer.remote.client.AccountClient;
import com.abinbev.b2b.credit.consumer.remote.entity.AccountEntity;
import com.abinbev.b2b.credit.consumer.vo.CreditMessage;
import com.abinbev.b2b.credit.utilities.domain.Credit;
import com.abinbev.b2b.credit.utilities.repository.CreditDao;
import com.google.common.collect.ImmutableSet;

@RunWith(MockitoJUnitRunner.class)
public class CreditServiceImplTest {

    private static final String COUNTRY_ZA = "ZA";

    @InjectMocks
    private CreditServiceImpl service;

    @Mock
    private CreditDao dao;

    @Mock
    private EventSender eventSender;

    @Mock
    private FeatureProperties featureProperties;

    @Mock
    private AbiToggleConfigImpl abiToggleConfig;

    @Mock
    private AccountClient accountClient;

    @Captor
    private ArgumentCaptor<Credit> creditCaptor;

    @Captor
    private ArgumentCaptor<CreditEventData> creditEventCaptor;

    @Test
    public void removeCreditAndNotifyEventHubSuccessful() {
        final String accountId = UUID
                .randomUUID().toString();
        final CreditMessage message = creditMessage(COUNTRY_ZA, accountId);

        message.setDeleted(true);

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_ZA)).thenReturn(false);
        when(featureProperties.shouldSendCreditToEventHub(message.getCountry())).thenReturn(true);
        when(this.dao.remove(message.getCountry(), message.getUpdatedAt(), message.getAccountId())).thenReturn(true);

        service.processMessage(message);

        verify(dao, times(1)).findById(message.getCountry(), message.getAccountId());
        verify(dao, times(1)).remove(message.getCountry(), message.getUpdatedAt(), message.getAccountId());
        verify(dao, times(0)).upsert(any(), any());

        final ArgumentCaptor<CreditEventData> captor = ArgumentCaptor.forClass(CreditEventData.class);
        verify(eventSender, times(1)).sendEvent(captor.capture(), eq(CreditEvent.CREDITDELETED), eq(message.getCountry()));

        assertThat(captor.getValue()).isNotNull().isInstanceOf(CreditEventData.class);
        final CreditEventData event = captor.getValue();
        assertThat(event.getAccountId()).isEqualTo(message.getAccountId());
        assertThat(event.getCountry()).isEqualTo(message.getCountry());
        assertThat(event.getBalance()).isEqualTo(message.getBalance());
        assertThat(event.getOverdue()).isEqualTo(message.getOverdue());
        assertThat(event.getAvailable()).isEqualTo(message.getAvailable());
        assertThat(event.getPaymentTerms()).isEqualTo(message.getPaymentTerms());
        assertThat(event.getTotal()).isEqualTo(message.getTotal());
        assertThat(event.getConsumption()).isEqualTo(message.getConsumption());
    }

    @Test
    public void removeCreditAndNotifyEventHubSuccessfulMultiVendor() {
        final CreditMessage message = creditMessage(COUNTRY_ZA, "vendor-account-id-1");
        message.setVendorId("vendor-id-1");
        message.setDeleted(true);

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_ZA)).thenReturn(true);
        when(featureProperties.shouldSendCreditToEventHub(message.getCountry())).thenReturn(true);
        final List<AccountEntity> accountResponse = List.of(new AccountEntity("account-id-1", message.getAccountId(), message.getVendorId()));
        when(accountClient.getAccountIdsByVendorAccountIdAndVendorId(COUNTRY_ZA, Set.of(message.getAccountId()), message.getVendorId())).thenReturn(accountResponse);
        when(this.dao.remove(message.getCountry(), message.getUpdatedAt(), "account-id-1")).thenReturn(true);

        service.processMessage(message);

        verify(dao, times(1)).findById(COUNTRY_ZA, "account-id-1");
        verify(dao, times(1)).remove(COUNTRY_ZA, message.getUpdatedAt(), "account-id-1");
        verify(dao, times(0)).upsert(any(), any());

        final ArgumentCaptor<CreditEventData> captor = ArgumentCaptor.forClass(CreditEventData.class);
        verify(eventSender, times(1)).sendEvent(captor.capture(), eq(CreditEvent.CREDITDELETED), eq(COUNTRY_ZA));

        assertThat(captor.getValue()).isNotNull().isInstanceOf(CreditEventData.class);
        final CreditEventData event = captor.getValue();
        assertThat(event.getAccountId()).isEqualTo("account-id-1");
        assertThat(event.getCountry()).isEqualTo(COUNTRY_ZA);
        assertThat(event.getBalance()).isEqualTo(message.getBalance());
        assertThat(event.getOverdue()).isEqualTo(message.getOverdue());
        assertThat(event.getAvailable()).isEqualTo(message.getAvailable());
        assertThat(event.getPaymentTerms()).isEqualTo(message.getPaymentTerms());
        assertThat(event.getTotal()).isEqualTo(message.getTotal());
        assertThat(event.getConsumption()).isEqualTo(message.getConsumption());
    }

    @Test
    public void removeCreditSuccessfulAndDoesNotNotifyEventHub() {
        final String accountId = UUID.randomUUID().toString();
        final CreditMessage message = creditMessage(COUNTRY_ZA, accountId);

        message.setDeleted(true);

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_ZA)).thenReturn(false);
        lenient().when(featureProperties.shouldSendCreditToEventHub(message.getCountry())).thenReturn(false);
        when(this.dao.remove(message.getCountry(), message.getUpdatedAt(), message.getAccountId())).thenReturn(true);

        service.processMessage(message);

        verify(dao, times(1)).findById(message.getCountry(), message.getAccountId());
        verify(dao, times(1)).remove(message.getCountry(), message.getUpdatedAt(), message.getAccountId());
        verify(dao, times(0)).upsert(any(), any());
        verify(eventSender, times(0)).sendEvent(any(), any(), any());
    }

    @Test
    public void removeCreditUnsuccessfulAndAvoidNotifyEventHub() {
        final String accountId = UUID.randomUUID().toString();
        final CreditMessage message = creditMessage(COUNTRY_ZA, accountId);
        message.setDeleted(true);

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_ZA)).thenReturn(false);
        lenient().when(featureProperties.shouldSendCreditToEventHub(message.getCountry())).thenReturn(true);
        lenient().when(this.dao.remove(message.getCountry(), message.getUpdatedAt(), message.getAccountId())).thenReturn(false);

        service.processMessage(message);

        verify(dao, times(1)).findById(message.getCountry(), message.getAccountId());
        verify(dao, times(1)).remove(message.getCountry(), message.getUpdatedAt(), message.getAccountId());
        verify(dao, times(0)).upsert(any(), any());
        verify(eventSender, times(0)).sendEvent(any(), any(), any());
    }

    @Test
    public void removeCreditUnsuccessfulAndAvoidNotifyEventHubForOutdatedMessage() {
        final String accountId = UUID.randomUUID().toString();
        final CreditMessage message = creditMessage(COUNTRY_ZA, accountId);
        message.setDeleted(true);

        final Credit persistedCredit = Credit
                .builder()
                .withAccountId(accountId)
                .withUpdatedAt(OffsetDateTime.now().plusDays(1L))
                .build();

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_ZA)).thenReturn(false);
        when(dao.findById(COUNTRY_ZA, accountId)).thenReturn(Optional.of(persistedCredit));
        lenient().when(featureProperties.shouldSendCreditToEventHub(message.getCountry())).thenReturn(true);
        lenient().when(this.dao.remove(message.getCountry(), message.getUpdatedAt(), message.getAccountId())).thenReturn(true);

        service.processMessage(message);

        verify(dao, times(1)).findById(message.getCountry(), message.getAccountId());
        verify(dao, times(0)).remove(message.getCountry(), message.getUpdatedAt(), message.getAccountId());
        verify(dao, times(0)).upsert(any(), any());
        verify(eventSender, times(0)).sendEvent(any(), any(), any());
    }

    @Test(expected = UnsupportedOperationException.class)
    public void removeSharedCreditUnsuccessfulAndAvoidNotifyEventHub() {
        final String accountId = UUID.randomUUID().toString();
        final CreditMessage message = creditMessage(COUNTRY_ZA, accountId);
        message.setDeleted(true);

        final Credit persistedCredit = Credit
                .builder()
                .withAccountId(accountId)
                .withParentId("parent-1")
                .withUpdatedAt(OffsetDateTime.now().minusDays(1L))
                .build();

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_ZA)).thenReturn(false);
        when(dao.findById(COUNTRY_ZA, accountId)).thenReturn(Optional.of(persistedCredit));
        lenient().when(featureProperties.shouldSendCreditToEventHub(message.getCountry())).thenReturn(true);

        try {
            service.processMessage(message);
        } catch (final UnsupportedOperationException e) {
            verify(dao, times(1)).findById(message.getCountry(), message.getAccountId());
            verify(dao, times(0)).remove(message.getCountry(), message.getUpdatedAt(), message.getAccountId());
            verify(dao, times(0)).upsert(any(), any());
            verify(eventSender, times(0)).sendEvent(any(), any(), any());
            throw e;
        }
    }

    @Test
    public void processMessageSuccessfulWithoutEventHubNotification() {
        final CreditMessage message = creditMessage(COUNTRY_ZA, "111");

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_ZA)).thenReturn(false);
        when(dao.upsert(COUNTRY_ZA, EntityHelper.convertFrom(message))).thenReturn(true);

        this.service.processMessage(message);

        verify(this.dao, times(1)).findById(COUNTRY_ZA, "111");
        verify(this.dao, times(1)).upsert(eq(COUNTRY_ZA), creditCaptor.capture());
        verify(this.featureProperties, times(1)).shouldSendCreditToEventHub(COUNTRY_ZA);
        verify(this.eventSender, times(0)).sendEvent(any(), any(), any());
        verify(this.dao, times(0)).remove(any(), any());
    }

    @Test(expected = ListenerException.class)
    public void processMessageUnsuccessful() {
        final CreditMessage message = creditMessage(COUNTRY_ZA, "111");

        try {
            this.service.processMessage(message);
        } catch (final Exception e) {
            verify(this.dao, times(1)).findById(COUNTRY_ZA, "111");
            verify(this.dao, times(1)).upsert(eq(COUNTRY_ZA), creditCaptor.capture());
            verify(this.featureProperties, times(0)).shouldSendCreditToEventHub(COUNTRY_ZA);
            verify(this.eventSender, times(0)).sendEvent(any(), any(), any());
            verify(this.dao, times(0)).remove(any(), any());
            throw e;
        }
    }

    @Test
    public void processMessageSuccessfulAndEventHubNotification() {
        final CreditMessage message = creditMessage(COUNTRY_ZA, "111");

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_ZA)).thenReturn(false);
        when(dao.upsert(COUNTRY_ZA, EntityHelper.convertFrom(message))).thenReturn(true);
        when(featureProperties.shouldSendCreditToEventHub(COUNTRY_ZA)).thenReturn(true);

        this.service.processMessage(message);

        verify(this.dao, times(1)).findById(COUNTRY_ZA, "111");
        verify(this.dao, times(1)).upsert(eq(COUNTRY_ZA), creditCaptor.capture());
        verify(this.featureProperties, times(1)).shouldSendCreditToEventHub(COUNTRY_ZA);
        verify(this.eventSender, times(1)).sendEvent(creditEventCaptor.capture(), eq(CreditEvent.CREDITCREATED), eq(COUNTRY_ZA));
        verify(this.dao, times(0)).remove(any(), any());

        final Credit persisted = creditCaptor.getValue();
        assertThat(persisted).isNotNull();
        assertThat(persisted).isEqualToIgnoringGivenFields(message, "country", "parentId", "childIds");

        final CreditEventData eventData = creditEventCaptor.getValue();
        assertThat(eventData).isNotNull();
        assertThat(eventData).isEqualToIgnoringGivenFields(message, "country", "parentId", "childIds");
    }

    @Test
    public void processMessageWithOutdatedPersistedDataAndEventHubNotification() {
        final CreditMessage message = creditMessage(COUNTRY_ZA, "111");
        final Credit persistedCredit = createCredit("111", OffsetDateTime
                .now()
                .minusDays(2L));

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_ZA)).thenReturn(false);
        when(dao.findById(COUNTRY_ZA, "111")).thenReturn(Optional.of(persistedCredit));
        when(dao.upsert(COUNTRY_ZA, EntityHelper.convertFrom(message))).thenReturn(true);
        when(featureProperties.shouldSendCreditToEventHub(COUNTRY_ZA)).thenReturn(true);

        this.service.processMessage(message);

        verify(this.dao, times(1)).findById(COUNTRY_ZA, "111");
        verify(this.dao, times(1)).upsert(eq(COUNTRY_ZA), creditCaptor.capture());
        verify(this.featureProperties, times(1)).shouldSendCreditToEventHub(COUNTRY_ZA);
        verify(this.eventSender, times(1)).sendEvent(creditEventCaptor.capture(), eq(CreditEvent.CREDITUPDATED), eq(COUNTRY_ZA));
        verify(this.dao, times(0)).remove(any(), any());

        final Credit persisted = creditCaptor.getValue();
        assertThat(persisted).isNotNull();
        assertThat(persisted).isEqualToIgnoringGivenFields(message, "country", "parentId", "childIds");

        final CreditEventData eventData = creditEventCaptor.getValue();
        assertThat(eventData).isNotNull();
        assertThat(eventData).isEqualToIgnoringGivenFields(message, "country", "parentId", "childIds");
    }

    @Test
    public void processMessageWithOutdatedMessage() {
        final CreditMessage message = creditMessage(COUNTRY_ZA, "111");
        final Credit persistedCredit = createCredit("111", OffsetDateTime
                .now()
                .plusDays(2L));

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_ZA)).thenReturn(false);
        when(dao.findById(COUNTRY_ZA, "111")).thenReturn(Optional.of(persistedCredit));

        this.service.processMessage(message);

        verify(this.dao, times(1)).findById(COUNTRY_ZA, "111");
        verify(this.dao, times(0)).upsert(eq(COUNTRY_ZA), any());
        verify(this.featureProperties, times(0)).shouldSendCreditToEventHub(COUNTRY_ZA);
        verify(this.eventSender, times(0)).sendEvent(any(), eq(CreditEvent.CREDITUPDATED), eq(COUNTRY_ZA));
        verify(this.dao, times(0)).remove(any(), any());
    }

    @Test
    public void processMessageWithPersistedSharedCreditAndMultiChild() {
        final CreditMessage message = creditMessage(COUNTRY_ZA, "111");

        final OffsetDateTime persistedUpdatedAt = OffsetDateTime.now().minusDays(2);
        final Credit persistedParent = createCredit("parent-1", persistedUpdatedAt);
        persistedParent.setChildIds(ImmutableSet.of("111","222","333"));
        final Credit persistedCredit = Credit
                .builder()
                .withAccountId("111")
                .withParentId("parent-1")
                .withUpdatedAt(persistedUpdatedAt)
                .build();

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_ZA)).thenReturn(false);
        when(dao.findById(COUNTRY_ZA, "111")).thenReturn(Optional.of(persistedCredit));
        when(dao.findById(COUNTRY_ZA, "parent-1")).thenReturn(Optional.of(persistedParent));
        when(dao.upsert(COUNTRY_ZA, EntityHelper.convertFrom(message))).thenReturn(true);

        this.service.processMessage(message);

        verify(this.dao, times(1)).findById(COUNTRY_ZA, "111");
        verify(this.dao, times(2)).upsert(eq(COUNTRY_ZA), creditCaptor.capture());
        verify(this.featureProperties, times(1)).shouldSendCreditToEventHub(COUNTRY_ZA);
        verify(this.eventSender, times(0)).sendEvent(any(), eq(CreditEvent.CREDITUPDATED), eq(COUNTRY_ZA));
        verify(this.dao, times(0)).remove(any(), any());

        final List<Credit> allValues = creditCaptor.getAllValues();
        assertThat(allValues).isNotEmpty();
        assertThat(allValues.size()).isEqualTo(2);
        assertThat(allValues.get(0)).isEqualToIgnoringGivenFields(message, "country", "parentId", "childIds");
        assertThat(allValues.get(1)).isEqualToIgnoringGivenFields(persistedParent, "childIds");
        assertThat(allValues.get(1).getChildIds()).isEqualTo(ImmutableSet.of("222","333"));
    }

    @Test
    public void processMessageWithPersistedSharedCreditAndAllChildrenRemoved() {
        final CreditMessage message = creditMessage(COUNTRY_ZA, "111");

        final OffsetDateTime persistedUpdatedAt = OffsetDateTime.now().minusDays(2);
        final Credit persistedParent = createCredit("parent-1", persistedUpdatedAt);
        persistedParent.setChildIds(ImmutableSet.of("111"));
        final Credit persistedCredit = Credit
                .builder()
                .withAccountId("111")
                .withParentId("parent-1")
                .withUpdatedAt(persistedUpdatedAt)
                .build();

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY_ZA)).thenReturn(false);
        when(dao.findById(COUNTRY_ZA, "111")).thenReturn(Optional.of(persistedCredit));
        when(dao.findById(COUNTRY_ZA, "parent-1")).thenReturn(Optional.of(persistedParent));
        when(dao.upsert(COUNTRY_ZA, EntityHelper.convertFrom(message))).thenReturn(true);

        this.service.processMessage(message);

        verify(this.dao, times(1)).findById(COUNTRY_ZA, "111");
        verify(this.dao, times(1)).upsert(eq(COUNTRY_ZA), creditCaptor.capture());
        verify(this.featureProperties, times(1)).shouldSendCreditToEventHub(COUNTRY_ZA);
        verify(this.eventSender, times(0)).sendEvent(any(), eq(CreditEvent.CREDITUPDATED), eq(COUNTRY_ZA));
        verify(this.dao, times(1)).remove(COUNTRY_ZA, Collections.singletonList("parent-1"));

        final List<Credit> allValues = creditCaptor.getAllValues();
        assertThat(allValues).isNotEmpty();
        assertThat(allValues.size()).isEqualTo(1);
        assertThat(allValues.get(0)).isEqualToIgnoringGivenFields(message, "country", "parentId", "childIds");
    }

    @Test
    public void normalizeSharedCreditIfNecessaryWithoutPersistedCredit() {
        this.service.normalizeSharedCreditIfNecessary(COUNTRY_ZA, OffsetDateTime.now(), Optional.empty());
        verify(this.dao, times(0)).findById(any(), any());
        verify(this.dao, times(0)).upsert(any(), any());
        verify(this.dao, times(0)).remove(any(), any());
    }

    @Test
    public void normalizeSharedCreditIfNecessaryWithPersistedCreditWithoutParentId() {
        final Credit credit = new Credit();
        credit.setParentId(null);
        this.service.normalizeSharedCreditIfNecessary(COUNTRY_ZA, OffsetDateTime.now(), Optional.of(credit));
        verify(this.dao, times(0)).findById(any(), any());
        verify(this.dao, times(0)).upsert(any(), any());
        verify(this.dao, times(0)).remove(any(), any());
    }

    @Test
    public void normalizeSharedCreditIfNecessaryWithError() {
        final Credit credit = new Credit();
        credit.setParentId("123");
        when(dao.findById(COUNTRY_ZA, "123")).thenThrow(new RuntimeException("error"));
        this.service.normalizeSharedCreditIfNecessary(COUNTRY_ZA, OffsetDateTime.now(), Optional.of(credit));
        verify(this.dao, times(1)).findById(COUNTRY_ZA, "123");
        verify(this.dao, times(0)).upsert(any(), any());
        verify(this.dao, times(0)).remove(any(), any());
    }

    @Test
    public void normalizeSharedCreditForNonExistentParent() {
        final Credit credit = new Credit();
        credit.setParentId("123");
        when(dao.findById(COUNTRY_ZA, "123")).thenReturn(Optional.empty());
        this.service.normalizeSharedCreditIfNecessary(COUNTRY_ZA, OffsetDateTime.now(), Optional.of(credit));
        verify(this.dao, times(1)).findById(COUNTRY_ZA, "123");
        verify(this.dao, times(0)).upsert(any(), any());
        verify(this.dao, times(0)).remove(any(), any());
    }

    private CreditMessage creditMessage(final String country, final String accountId){
        return CreditMessage
                .builder()
                .withAccountId(accountId)
                .withCountry(country)
                .withBalance(BigDecimal.ONE)
                .withOverdue(BigDecimal.ONE)
                .withAvailable(BigDecimal.TEN)
                .withPaymentTerms("CREDIT")
                .withTotal(BigDecimal.TEN)
                .withConsumption(BigDecimal.ZERO)
                .withUpdatedAt(OffsetDateTime.now())
                .build();
    }

    private Credit createCredit(final String accountId, final OffsetDateTime updatedAt){
        return Credit
                .builder()
                .withAccountId(accountId)
                .withBalance(BigDecimal.TEN)
                .withOverdue(BigDecimal.TEN)
                .withAvailable(BigDecimal.TEN)
                .withPaymentTerms("CREDIT")
                .withTotal(BigDecimal.TEN)
                .withConsumption(BigDecimal.ZERO)
                .withUpdatedAt(updatedAt)
                .build();
    }
}