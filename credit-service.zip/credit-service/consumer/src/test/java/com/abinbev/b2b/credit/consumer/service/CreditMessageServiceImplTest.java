package com.abinbev.b2b.credit.consumer.service;

import static com.abinbev.b2b.credit.consumer.event.CreditEvent.CREDITCREATED;
import static com.abinbev.b2b.credit.consumer.event.CreditEvent.CREDITUPDATED;
import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.abinbev.b2b.credit.consumer.config.AbiToggleConfigImpl;
import com.abinbev.b2b.credit.consumer.config.property.FeatureProperties;
import com.abinbev.b2b.credit.consumer.event.CreditEvent;
import com.abinbev.b2b.credit.consumer.exception.AccountNotFoundException;
import com.abinbev.b2b.credit.consumer.exception.ListenerException;
import com.abinbev.b2b.credit.consumer.remote.client.AccountClient;
import com.abinbev.b2b.credit.consumer.remote.entity.AccountEntity;
import com.abinbev.b2b.credit.consumer.vo.CreditMessage;
import com.abinbev.b2b.credit.utilities.domain.Credit;
import com.abinbev.b2b.credit.utilities.repository.CreditDao;

@RunWith(MockitoJUnitRunner.class)
public class CreditMessageServiceImplTest {

    private static final String COUNTRY = "ZA";
    private static final Set<String> VENDOR_ACCOUNT_IDS = Set.of("12345");
    private static final String VENDOR_ACCOUNT_ID = "12345";
    private static final String VENDOR_ID = "54321";
    public static final BigDecimal BALANCE = BigDecimal.ONE;
    public static final BigDecimal OVERDUE = BigDecimal.ONE;
    public static final BigDecimal AVAILABLE = BigDecimal.ONE;
    public static final String PAYMENT_TERMS = "paymentTerms";
    public static final BigDecimal TOTAL = BigDecimal.ONE;
    public static final BigDecimal CONSUMPTION = BigDecimal.ONE;

    @InjectMocks
    private CreditServiceImpl service;

    @Mock
    private CreditDao dao;

    @Mock
    private EventHubService eventHubService;

    @Mock
    private FeatureProperties featureProperties;

    @Mock
    private AbiToggleConfigImpl abiToggleConfig;

    @Mock
    private AccountClient accountClient;


    @Test
    public void createCreditSuccess() {
        final String accountId = UUID.randomUUID().toString();
        final OffsetDateTime updatedAtRequest = OffsetDateTime.now();
        final CreditMessage message = CreditMessage
                .builder()
                .withAccountId(accountId)
                .withCountry(COUNTRY)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(updatedAtRequest)
                .build();

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY)).thenReturn(false);
        when(dao.findById(message.getCountry(), message.getAccountId())).thenReturn(Optional.empty());
        when(dao.upsert(eq(message.getCountry()), any(Credit.class))).thenReturn(true);
        when(featureProperties.shouldSendCreditToEventHub(message.getCountry())).thenReturn(true);
        service.processMessage(message);

        final ArgumentCaptor<CreditEvent> creditEventArgumentCaptor = ArgumentCaptor.forClass(CreditEvent.class);
        verify(eventHubService).sendEvent(any(), creditEventArgumentCaptor.capture(), any());
        final CreditEvent creditEvent = creditEventArgumentCaptor.getValue();
        assertEquals(CREDITCREATED, creditEvent);

        final ArgumentCaptor<Credit> captor = ArgumentCaptor.forClass(Credit.class);
        verify(dao, times(1)).upsert(any(), captor.capture());
        final Credit persistedValue = captor.getValue();

        assertCreditEventDataIsEqual(persistedValue, message);
    }

    @Test
    public void updateCreditSuccess() {
        final String accountId = UUID.randomUUID().toString();
        final OffsetDateTime updatedAtRequest = OffsetDateTime.now();
        final OffsetDateTime databaseUpdatedAt = OffsetDateTime.of(LocalDateTime.of(2018, 11, 13, 19, 10), ZoneOffset.UTC);

        final CreditMessage message = CreditMessage
                .builder()
                .withAccountId(accountId)
                .withCountry(COUNTRY)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(updatedAtRequest)
                .build();

        final Credit databaseCredit = Credit
                .builder()
                .withAccountId(accountId)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(databaseUpdatedAt)
                .build();

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY)).thenReturn(false);
        when(dao.findById(message.getCountry(), message.getAccountId())).thenReturn(Optional.of(databaseCredit));
        when(dao.upsert(eq(message.getCountry()), any(Credit.class))).thenReturn(true);
        when(featureProperties.shouldSendCreditToEventHub(message.getCountry())).thenReturn(true);
        service.processMessage(message);

        final ArgumentCaptor<CreditEvent> creditEventArgumentCaptor = ArgumentCaptor.forClass(CreditEvent.class);
        verify(eventHubService).sendEvent(any(), creditEventArgumentCaptor.capture(), any());
        final CreditEvent creditEvent = creditEventArgumentCaptor.getValue();
        assertEquals(CREDITUPDATED, creditEvent);

        final ArgumentCaptor<Credit> captor = ArgumentCaptor.forClass(Credit.class);
        verify(dao, times(1)).upsert(any(), captor.capture());
        final Credit persistedValue = captor.getValue();

        assertCreditEventDataIsEqual(persistedValue, message);
    }

    @Test
    public void createCreditWithNullConsumptionShouldSaveZero() {
        final String accountId = UUID.randomUUID().toString();
        final OffsetDateTime updatedAtRequest = OffsetDateTime.now();
        final CreditMessage message = CreditMessage
                .builder()
                .withAccountId(accountId)
                .withCountry(COUNTRY)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(null)
                .withUpdatedAt(updatedAtRequest)
                .build();

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY)).thenReturn(false);
        when(dao.findById(message.getCountry(), message.getAccountId())).thenReturn(Optional.empty());
        when(dao.upsert(eq(message.getCountry()), any(Credit.class))).thenReturn(true);
        when(featureProperties.shouldSendCreditToEventHub(message.getCountry())).thenReturn(true);
        service.processMessage(message);

        final ArgumentCaptor<CreditEvent> creditEventArgumentCaptor = ArgumentCaptor.forClass(CreditEvent.class);
        verify(eventHubService).sendEvent(any(), creditEventArgumentCaptor.capture(), any());
        final CreditEvent creditEvent = creditEventArgumentCaptor.getValue();
        assertEquals(CREDITCREATED, creditEvent);

        final ArgumentCaptor<Credit> captor = ArgumentCaptor.forClass(Credit.class);
        verify(dao, times(1)).upsert(any(), captor.capture());
        final Credit persistedValue = captor.getValue();

        assertEquals(message.getAccountId(), persistedValue.getAccountId());
        assertEquals(message.getBalance(), persistedValue.getBalance());
        assertEquals(message.getOverdue(), persistedValue.getOverdue());
        assertEquals(message.getAvailable(), persistedValue.getAvailable());
        assertEquals(message.getPaymentTerms(), persistedValue.getPaymentTerms());
        assertEquals(message.getTotal(), persistedValue.getTotal());
        assertEquals(BigDecimal.ZERO, persistedValue.getConsumption());
    }


    @Test
    public void shouldNotUpdateCreditWithSameTimestamp() {
        final String accountId = UUID.randomUUID().toString();
        final OffsetDateTime databaseUpdatedAt = OffsetDateTime.of(LocalDateTime.of(2018, 11, 13, 19, 10), ZoneOffset.UTC);

        final CreditMessage message = CreditMessage
                .builder()
                .withAccountId(accountId)
                .withCountry(COUNTRY)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(databaseUpdatedAt)
                .build();

        final Credit databaseCredit = Credit
                .builder()
                .withAccountId(accountId)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(databaseUpdatedAt)
                .build();

        when(dao.findById(message.getCountry(), message.getAccountId())).thenReturn(Optional.of(databaseCredit));
        service.processMessage(message);

        verify(dao, times(0)).upsert(eq(COUNTRY), any(Credit.class));
        verify(eventHubService, times(0)).sendEvent(any(), any(), eq(COUNTRY));
    }

    @Test
    public void shouldNotUpdateCreditWhenMessageIsOutdated() {
        final String accountId = UUID.randomUUID().toString();
        final OffsetDateTime updatedAtRequest = OffsetDateTime.of(LocalDateTime.of(2018, 10, 13, 19, 10), ZoneOffset.UTC);
        final OffsetDateTime databaseUpdatedAt = OffsetDateTime.of(LocalDateTime.of(2018, 11, 13, 19, 10), ZoneOffset.UTC);

        final CreditMessage message = CreditMessage
                .builder()
                .withAccountId(accountId)
                .withCountry(COUNTRY)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(updatedAtRequest)
                .build();

        final Credit databaseCredit = Credit
                .builder()
                .withAccountId(accountId)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(databaseUpdatedAt)
                .build();

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY)).thenReturn(false);
        when(dao.findById(message.getCountry(), message.getAccountId())).thenReturn(Optional.of(databaseCredit));
        service.processMessage(message);

        verify(dao, times(0)).upsert(eq(COUNTRY), any(Credit.class));
        verify(eventHubService, times(0)).sendEvent(any(), any(), eq(COUNTRY));
    }

    @Test(expected = ListenerException.class)
    public void updateCreditFailure() {
        final String accountId = UUID.randomUUID().toString();
        final OffsetDateTime updatedAtRequest = OffsetDateTime.now();
        final OffsetDateTime databaseUpdatedAt = OffsetDateTime.of(LocalDateTime.of(2018, 11, 13, 19, 10), ZoneOffset.UTC);

        final CreditMessage message = CreditMessage
                .builder()
                .withAccountId(accountId)
                .withCountry(COUNTRY)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(updatedAtRequest)
                .build();

        final Credit databaseCredit = Credit
                .builder()
                .withAccountId(accountId)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(databaseUpdatedAt)
                .build();

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY)).thenReturn(false);
        when(dao.findById(message.getCountry(), message.getAccountId())).thenReturn(Optional.of(databaseCredit));
        service.processMessage(message);
    }

    @Test
    public void createMultiVendorCreditSuccess() {
        final String accountId = UUID.randomUUID().toString();
        final OffsetDateTime updatedAtRequest = OffsetDateTime.now();
        final CreditMessage message = CreditMessage
                .builder()
                .withAccountId(VENDOR_ACCOUNT_ID)
                .withVendorId(VENDOR_ID)
                .withCountry(COUNTRY)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(updatedAtRequest)
                .build();
        final List<AccountEntity> accountResponse = List.of(new AccountEntity(accountId, VENDOR_ACCOUNT_ID, VENDOR_ID));

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY)).thenReturn(true);
        when(accountClient.getAccountIdsByVendorAccountIdAndVendorId(COUNTRY, VENDOR_ACCOUNT_IDS, VENDOR_ID)).thenReturn(accountResponse);
        when(dao.findById(message.getCountry(), accountId)).thenReturn(Optional.empty());
        when(dao.upsert(eq(message.getCountry()), any(Credit.class))).thenReturn(true);
        when(featureProperties.shouldSendCreditToEventHub(message.getCountry())).thenReturn(true);
        service.processMessage(message);

        final ArgumentCaptor<CreditEvent> creditEventArgumentCaptor = ArgumentCaptor.forClass(CreditEvent.class);
        verify(eventHubService).sendEvent(any(Object.class), creditEventArgumentCaptor.capture(), any(String.class));
        final CreditEvent creditEvent = creditEventArgumentCaptor.getValue();
        assertEquals(CREDITCREATED, creditEvent);

        final ArgumentCaptor<Credit> captor = ArgumentCaptor.forClass(Credit.class);
        verify(dao, times(1)).upsert(any(String.class), captor.capture());
        final Credit persistedValue = captor.getValue();

        assertCreditEventDataIsEqual(persistedValue, message);
    }


    @Test
    public void updateMultiVendorCreditSuccess() {
        final String accountId = UUID.randomUUID().toString();
        final OffsetDateTime updatedAtRequest = OffsetDateTime.now();
        final OffsetDateTime databaseUpdatedAt = OffsetDateTime.of(LocalDateTime.of(2018, 11, 13, 19, 10), ZoneOffset.UTC);

        final CreditMessage message = CreditMessage
                .builder()
                .withAccountId(VENDOR_ACCOUNT_ID)
                .withVendorId(VENDOR_ID)
                .withCountry(COUNTRY)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(updatedAtRequest)
                .build();

        final Credit databaseCredit = Credit
                .builder()
                .withAccountId(accountId)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(databaseUpdatedAt)
                .build();

        final AccountEntity account = new AccountEntity();
        account.setAccountId(accountId);
        account.setVendorAccountId(VENDOR_ACCOUNT_ID);
        account.setVendorId(VENDOR_ID);

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY)).thenReturn(true);
        when(accountClient.getAccountIdsByVendorAccountIdAndVendorId(COUNTRY, VENDOR_ACCOUNT_IDS, VENDOR_ID)).thenReturn(List.of(account));
        when(dao.findById(message.getCountry(), accountId)).thenReturn(Optional.of(databaseCredit));
        when(dao.upsert(eq(message.getCountry()), any(Credit.class))).thenReturn(true);
        when(featureProperties.shouldSendCreditToEventHub(message.getCountry())).thenReturn(true);
        service.processMessage(message);

        final ArgumentCaptor<CreditEvent> creditEventArgumentCaptor = ArgumentCaptor.forClass(CreditEvent.class);
        verify(eventHubService).sendEvent(any(), creditEventArgumentCaptor.capture(), any());
        final CreditEvent creditEvent = creditEventArgumentCaptor.getValue();
        assertEquals(CREDITUPDATED, creditEvent);

        final ArgumentCaptor<Credit> captor = ArgumentCaptor.forClass(Credit.class);
        verify(dao, times(1)).upsert(any(), captor.capture());
        final Credit persistedValue = captor.getValue();

        assertCreditEventDataIsEqual(persistedValue, message);
    }

    @Test(expected = AccountNotFoundException.class)
    public void createMultiVendorCreditAccountsNull() {
        final OffsetDateTime updatedAtRequest = OffsetDateTime.now();
        final CreditMessage message = CreditMessage
                .builder()
                .withAccountId(VENDOR_ACCOUNT_ID)
                .withVendorId(VENDOR_ID)
                .withCountry(COUNTRY)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(updatedAtRequest)
                .build();

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY)).thenReturn(true);
        when(accountClient.getAccountIdsByVendorAccountIdAndVendorId(COUNTRY, VENDOR_ACCOUNT_IDS, VENDOR_ID)).thenReturn(null);
        service.processMessage(message);
    }

    @Test(expected = AccountNotFoundException.class)
    public void createMultiVendorCreditAccountsEmpty() {
        final OffsetDateTime updatedAtRequest = OffsetDateTime.now();
        final CreditMessage message = CreditMessage
                .builder()
                .withAccountId(VENDOR_ACCOUNT_ID)
                .withVendorId(VENDOR_ID)
                .withCountry(COUNTRY)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(updatedAtRequest)
                .build();

        when(abiToggleConfig.isEnabledMultiVendorPerCountry(COUNTRY)).thenReturn(true);
        when(accountClient.getAccountIdsByVendorAccountIdAndVendorId(COUNTRY, VENDOR_ACCOUNT_IDS, VENDOR_ID)).thenReturn(Collections.emptyList());
        service.processMessage(message);
    }

    private void assertCreditEventDataIsEqual(final Credit credit, final CreditMessage creditMessage) {
        assertEquals(credit.getAccountId(), creditMessage.getAccountId());
        assertEquals(credit.getBalance(), creditMessage.getBalance());
        assertEquals(credit.getOverdue(), creditMessage.getOverdue());
        assertEquals(credit.getAvailable(), creditMessage.getAvailable());
        assertEquals(credit.getPaymentTerms(), creditMessage.getPaymentTerms());
        assertEquals(credit.getTotal(), creditMessage.getTotal());
        assertEquals(credit.getConsumption(), creditMessage.getConsumption());
    }
}