package com.abinbev.b2b.credit.consumer.helper;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import com.abinbev.b2b.credit.consumer.event.CreditEventData;
import com.abinbev.b2b.credit.consumer.vo.CreditMessage;

@RunWith(MockitoJUnitRunner.class)
public class CreditEventDataHelperTest {

    public static final String ACCOUNT_ID = "accountId";
    public static final String COUNTRY = "BR";
    public static final BigDecimal BALANCE = BigDecimal.ONE;
    public static final BigDecimal OVERDUE = BigDecimal.ONE;
    public static final BigDecimal AVAILABLE = BigDecimal.ONE;
    public static final String PAYMENT_TERMS = "paymentTerms";
    public static final BigDecimal TOTAL = BigDecimal.ONE;
    public static final BigDecimal CONSUMPTION = BigDecimal.ONE;

    @Test
    public void shouldCreateFullCreditEventData() {
        final CreditMessage creditMessage = CreditMessage
                .builder()
                .withAccountId(ACCOUNT_ID)
                .withCountry(COUNTRY)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(OffsetDateTime.now())
                .build();

        final CreditEventData creditEventData = CreditEventDataHelper.createCreditEventData(creditMessage);
        assertCreditEventDataIsEqual(creditEventData, creditMessage);
    }

    @Test
    public void shouldCreateCreditEventDataWithoutBalance() {
        final CreditMessage creditMessage = CreditMessage
                .builder()
                .withAccountId(ACCOUNT_ID)
                .withCountry(COUNTRY)
                .withBalance(null)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(OffsetDateTime.now())
                .build();
        final CreditEventData creditEventData = CreditEventDataHelper.createCreditEventData(creditMessage);
        assertCreditEventDataIsEqual(creditEventData, creditMessage);
    }

    @Test
    public void shouldCreateCreditEventDataWithoutAvailable() {
        final CreditMessage creditMessage = CreditMessage
                .builder()
                .withAccountId(ACCOUNT_ID)
                .withCountry(COUNTRY)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(null)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(OffsetDateTime.now())
                .build();
        final CreditEventData creditEventData = CreditEventDataHelper.createCreditEventData(creditMessage);
        assertCreditEventDataIsEqual(creditEventData, creditMessage);
    }

    @Test
    public void shouldCreateCreditEventDataWithoutConsumption() {
        final CreditMessage creditMessage = CreditMessage
                .builder()
                .withAccountId(ACCOUNT_ID)
                .withCountry(COUNTRY)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(null)
                .withUpdatedAt(OffsetDateTime.now())
                .build();
        final CreditEventData creditEventData = CreditEventDataHelper.createCreditEventData(creditMessage);
        assertCreditEventDataIsEqual(creditEventData, creditMessage);
    }

    @Test
    public void shouldCreateCreditEventDataWithoutOverdue() {
        final CreditMessage creditMessage = CreditMessage
                .builder()
                .withAccountId(ACCOUNT_ID)
                .withCountry(COUNTRY)
                .withBalance(BALANCE)
                .withOverdue(null)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(OffsetDateTime.now())
                .build();
        final CreditEventData creditEventData = CreditEventDataHelper.createCreditEventData(creditMessage);
        assertCreditEventDataIsEqual(creditEventData, creditMessage);
    }

    @Test
    public void shouldCreateCreditEventDataWithoutPaymentTerms() {
        final CreditMessage creditMessage = CreditMessage
                .builder()
                .withAccountId(ACCOUNT_ID)
                .withCountry(COUNTRY)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(null)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(OffsetDateTime.now())
                .build();
        final CreditEventData creditEventData = CreditEventDataHelper.createCreditEventData(creditMessage);
        assertCreditEventDataIsEqual(creditEventData, creditMessage);
    }

    @Test
    public void shouldCreateCreditEventDataWithoutTotal() {
        final CreditMessage creditMessage = CreditMessage
                .builder()
                .withAccountId(ACCOUNT_ID)
                .withCountry(COUNTRY)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(null)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(OffsetDateTime.now())
                .build();
        final CreditEventData creditEventData = CreditEventDataHelper.createCreditEventData(creditMessage);
        assertCreditEventDataIsEqual(creditEventData, creditMessage);
    }

    private void assertCreditEventDataIsEqual(final CreditEventData creditEventData, final CreditMessage creditMessage) {
        assertEquals(creditEventData.getAccountId(), creditMessage.getAccountId());
        assertEquals(creditEventData.getCountry(), creditMessage.getCountry());
        assertEquals(creditEventData.getBalance(), creditMessage.getBalance());
        assertEquals(creditEventData.getOverdue(), creditMessage.getOverdue());
        assertEquals(creditEventData.getAvailable(), creditMessage.getAvailable());
        assertEquals(creditEventData.getPaymentTerms(), creditMessage.getPaymentTerms());
        assertEquals(creditEventData.getTotal(), creditMessage.getTotal());
        assertEquals(creditEventData.getConsumption(), creditMessage.getConsumption());
    }

}
