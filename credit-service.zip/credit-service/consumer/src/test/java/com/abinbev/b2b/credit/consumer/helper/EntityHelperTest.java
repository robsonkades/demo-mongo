package com.abinbev.b2b.credit.consumer.helper;

import com.abinbev.b2b.credit.consumer.vo.CreditMessage;
import com.abinbev.b2b.credit.utilities.domain.Credit;
import org.junit.Test;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

import static org.junit.Assert.assertEquals;

public class EntityHelperTest {

    private static final String ACCOUNT_ID = "accountId";
    private static final String COUNTRY = "BR";
    private static final BigDecimal BALANCE = BigDecimal.ONE;
    private static final BigDecimal OVERDUE = BigDecimal.ONE;
    private static final BigDecimal AVAILABLE = BigDecimal.ONE;
    private static final String PAYMENT_TERMS = "paymentTerms";
    private static final BigDecimal TOTAL = BigDecimal.ONE;
    private static final BigDecimal CONSUMPTION = BigDecimal.ONE;

    @Test
    public void convertFrom() {
        final CreditMessage creditMessage = CreditMessage
                .builder()
                .withAccountId(ACCOUNT_ID)
                .withCountry(COUNTRY)
                .withBalance(BALANCE)
                .withOverdue(OVERDUE)
                .withAvailable(AVAILABLE)
                .withPaymentTerms(PAYMENT_TERMS)
                .withTotal(TOTAL)
                .withConsumption(CONSUMPTION)
                .withUpdatedAt(OffsetDateTime.now())
                .build();

        final Credit actual = EntityHelper.convertFrom(creditMessage);

        assertEquals(actual.getAccountId(), creditMessage.getAccountId());
        assertEquals(actual.getBalance(), creditMessage.getBalance());
        assertEquals(actual.getOverdue(), creditMessage.getOverdue());
        assertEquals(actual.getAvailable(), creditMessage.getAvailable());
        assertEquals(actual.getPaymentTerms(), creditMessage.getPaymentTerms());
        assertEquals(actual.getTotal(), creditMessage.getTotal());
        assertEquals(actual.getConsumption(), creditMessage.getConsumption());
    }
}