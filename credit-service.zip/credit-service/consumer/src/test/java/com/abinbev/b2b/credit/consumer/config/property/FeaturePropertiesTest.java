package com.abinbev.b2b.credit.consumer.config.property;

import org.apache.commons.lang3.StringUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

@RunWith(MockitoJUnitRunner.class)
public class FeaturePropertiesTest {

    private static final String UNMAPPED_COUNTRY = "bla";

    private static final String COUNTRY_ZA = "za";

    private static final String COUNTRY_BR = "br";

    private static final String COUNTRY_CO = "co";

    @InjectMocks
    private FeatureProperties featureProperties;

    @Before
    public void setUp() {
        final List<String> countriesSendCreditToEventHub = List.of(COUNTRY_ZA, COUNTRY_CO);
        ReflectionTestUtils.setField(featureProperties, "countriesSendCreditToEventHub", countriesSendCreditToEventHub);
    }

    @Test
    public void shouldSendCreditToEventHubForCountryValid() {
        assertTrue(featureProperties.shouldSendCreditToEventHub(COUNTRY_ZA));
        assertTrue(featureProperties.shouldSendCreditToEventHub(COUNTRY_CO));
        assertFalse(featureProperties.shouldSendCreditToEventHub(COUNTRY_BR));
    }

    @Test
    public void shouldSendCreditToEventHubForCountryInvalid() {
        assertFalse(featureProperties.shouldSendCreditToEventHub(null));
        assertFalse(featureProperties.shouldSendCreditToEventHub(StringUtils.EMPTY));
        assertFalse(featureProperties.shouldSendCreditToEventHub(StringUtils.SPACE));
        assertFalse(featureProperties.shouldSendCreditToEventHub(UNMAPPED_COUNTRY));
    }

}