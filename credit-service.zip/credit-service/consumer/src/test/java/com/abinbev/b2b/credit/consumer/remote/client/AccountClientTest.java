package com.abinbev.b2b.credit.consumer.remote.client;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.client.HttpStatusCodeException;

import com.abinbev.b2b.credit.consumer.helper.constants.Constants;
import com.abinbev.b2b.credit.consumer.remote.entity.AccountEntity;
import com.abinbev.b2b.credit.utilities.remote.client.RemoteClient;

@RunWith(MockitoJUnitRunner.class)
public class AccountClientTest {

    private static final String COUNTRY_BR = "BR";

    @InjectMocks
    private AccountClient client;

    @Mock
    private RemoteClient remoteClient;

    @Before
    public void setUp(){
        ReflectionTestUtils.setField(client, "url", "http://localhost:1080/accounts");
    }

    @Test
    public void testGetAccountSuccessfully() {
        final var account = new AccountEntity("12345", "vendor-account-test-1", "vendor-test-2");
        final var uri = "http://localhost:1080/accounts?vendorAccountId=vendor-account-test-1&vendorId=vendor-test-2";

        final var mockedAccounts = List.of(account).toArray(AccountEntity[]::new);
        when(this.remoteClient.getForObject(eq(uri), any(HttpHeaders.class), eq(AccountEntity[].class), eq(Constants.ACCOUNT_REMOTE_SERVICE))).thenReturn(ResponseEntity.ok(mockedAccounts));

        final var accountsResponse = this.client.getAccountIdsByVendorAccountIdAndVendorId(COUNTRY_BR, Set.of(account.getVendorAccountId()), account.getVendorId());
        assertThat(accountsResponse).isNotNull().isEqualTo(List.of(account));
    }

    @Test
    public void testGetAccountSuccessfullyMoreThanOne() {
        final var account1 = new AccountEntity("12345", "vendor-account-test-1", "vendor-test-2");
        final var account2 = new AccountEntity("12346", "vendor-account-test-2", "vendor-test-2");
        final var account3 = new AccountEntity("12347", "vendor-account-test-3", "vendor-test-2");
        final var uri = "http://localhost:1080/accounts?vendorAccountId=vendor-account-test-1&vendorAccountId=vendor-account-test-2&vendorAccountId=vendor-account-test-3&vendorId=vendor-test-2";

        final var mockedAccounts = List.of(account1, account2, account3).toArray(AccountEntity[]::new);
        when(this.remoteClient.getForObject(eq(uri), any(HttpHeaders.class), eq(AccountEntity[].class), eq(Constants.ACCOUNT_REMOTE_SERVICE))).thenReturn(ResponseEntity.ok(mockedAccounts));

        final var vendorAccountIds = new LinkedHashSet<>(List.of(account1.getVendorAccountId(), account2.getVendorAccountId(), account3.getVendorAccountId()));
        final var accountsResponse = this.client.getAccountIdsByVendorAccountIdAndVendorId(COUNTRY_BR, vendorAccountIds, account1.getVendorId());
        assertThat(accountsResponse).isNotNull().isEqualTo(List.of(account1, account2, account3));
    }

    @Test
    public void testGetAccountAccountsNull() {
        final var account = new AccountEntity("12345", "vendor-account-test-1", "vendor-test-2");
        final var uri = "http://localhost:1080/accounts?vendorAccountId=vendor-account-test-1&vendorId=vendor-test-2";

        when(this.remoteClient.getForObject(eq(uri), any(HttpHeaders.class), eq(AccountEntity[].class), eq(Constants.ACCOUNT_REMOTE_SERVICE))).thenReturn(ResponseEntity.ok().build());

        final var accounts = this.client.getAccountIdsByVendorAccountIdAndVendorId(COUNTRY_BR, Set.of(account.getVendorAccountId()), account.getVendorId());
        assertThat(accounts).isNotNull().isEqualTo(Collections.emptyList());
    }

    @Test
    public void testGetAccountAccountsEmpty() {
        final var account = new AccountEntity("12345", "vendor-account-test-1", "vendor-test-2");
        final var uri = "http://localhost:1080/accounts?vendorAccountId=vendor-account-test-1&vendorId=vendor-test-2";

        final var mockedAccounts = new ArrayList<AccountEntity>().toArray(AccountEntity[]::new);
        when(this.remoteClient.getForObject(eq(uri), any(HttpHeaders.class), eq(AccountEntity[].class), eq(Constants.ACCOUNT_REMOTE_SERVICE))).thenReturn(ResponseEntity.ok(mockedAccounts));

        final var accounts = this.client.getAccountIdsByVendorAccountIdAndVendorId(COUNTRY_BR, Set.of(account.getVendorAccountId()), account.getVendorId());
        assertThat(accounts).isNotNull().isEqualTo(Collections.emptyList());
    }

    @Test
    public void testGetAccountException() throws HttpStatusCodeException {
        final var account = new AccountEntity("12345", "vendor-account-test-1", "vendor-test-2");
        final var uri = "http://localhost:1080/accounts?vendorAccountId=vendor-account-test-1&vendorId=vendor-test-2";

        when(this.remoteClient.getForObject(eq(uri), any(HttpHeaders.class), eq(AccountEntity[].class), eq(Constants.ACCOUNT_REMOTE_SERVICE)))
                .thenThrow(new HttpStatusCodeException(HttpStatus.BAD_REQUEST){});

        final var accounts = this.client.getAccountIdsByVendorAccountIdAndVendorId(COUNTRY_BR, Set.of(account.getVendorAccountId()), account.getVendorId());
        assertThat(accounts).isNotNull().isEqualTo(Collections.emptyList());
    }

    @Test
    public void testGetAccountVendorAccountIdNull() {
        final var accounts = this.client.getAccountIdsByVendorAccountIdAndVendorId(COUNTRY_BR, null, "vendor-test-2");
        assertThat(accounts).isNotNull().isEqualTo(Collections.emptyList());
    }

    @Test
    public void testGetAccountVendorIdNull() {
        final var accounts = this.client.getAccountIdsByVendorAccountIdAndVendorId(COUNTRY_BR, Set.of("vendor-account-test-1"), null);
        assertThat(accounts).isNotNull().isEqualTo(Collections.emptyList());
    }

}