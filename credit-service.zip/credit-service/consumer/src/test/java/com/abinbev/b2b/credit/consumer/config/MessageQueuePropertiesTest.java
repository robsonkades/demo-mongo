package com.abinbev.b2b.credit.consumer.config;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

import java.util.Set;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import com.abinbev.b2b.credit.consumer.config.property.MessageQueueProperties;

@SpringBootTest(classes = MessageQueuePropertiesTest.TestConfiguration.class)
@ActiveProfiles("test")
class MessageQueuePropertiesTest {

    @Test
    void shouldLoadMessageQueueCountries(@Autowired MessageQueueProperties properties) {
        final Set<String> countries = properties.getCountries();
        assertThat(countries).contains("br").contains("do").contains("co");
    }

    @Test
    void shouldLoadQueuesNames(@Autowired final MessageQueueProperties properties) {
        assertEquals("credits", properties.getQueues().get("credits"));
        assertEquals("credits-batch", properties.getQueues().get("creditsBatch"));
    }

    @Test
    void shouldLoadExchangeNames(@Autowired final MessageQueueProperties properties) {
        assertEquals("credits.exchange", properties.getExchanges().get("credits"));
        assertEquals("credits.exchange", properties.getExchanges().get("creditsBatch"));
    }

    @Test
    void shouldLoadRoutingKeys(@Autowired final MessageQueueProperties properties) {
        assertEquals("batch", properties.getRoutingKeys().get("creditsBatch"));
    }

    @EnableConfigurationProperties(MessageQueueProperties.class)
    public static class TestConfiguration {
        //nothing
    }

}