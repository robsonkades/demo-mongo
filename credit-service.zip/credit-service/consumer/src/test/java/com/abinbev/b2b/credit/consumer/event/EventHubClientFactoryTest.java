package com.abinbev.b2b.credit.consumer.event;

import com.abinbev.b2b.credit.consumer.exception.EventHubException;
import com.abinbev.b2b.credit.consumer.config.property.EventHubProperties;
import com.abinbev.b2b.credit.consumer.config.property.EventHubProperties.EventHubAmqpRetryOptions;
import com.azure.core.amqp.AmqpRetryMode;
import com.azure.core.amqp.AmqpRetryOptions;
import com.azure.messaging.eventhubs.EventHubProducerAsyncClient;
import com.azure.messaging.eventhubs.EventHubProducerClient;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Duration;
import static com.abinbev.b2b.credit.consumer.event.CreditEvent.CREDITCREATED;
import static com.abinbev.b2b.credit.consumer.event.CreditEvent.CREDITDELETED;
import static com.abinbev.b2b.credit.consumer.event.CreditEvent.CREDITUPDATED;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class EventHubClientFactoryTest {

    public static final String CONNECTION_STRING = "Endpoint=sb://localhost/;SharedAccessKeyName=event-sender;" + "SharedAccessKey=accessKey;EntityPath=";

    @Mock
    private EventHubProperties eventHubProperties;

    @Test
    public void getEventHubClientCreditRetryEnabled() {
        final EventHubAmqpRetryOptions eventHubAmqpRetryOptions = new EventHubProperties().getRetryOptions();
        eventHubAmqpRetryOptions.setMaxRetries(3);
        eventHubAmqpRetryOptions.setDelay(100L);
        eventHubAmqpRetryOptions.setMaxDelay(400L);
        eventHubAmqpRetryOptions.setTryTimeout(2000L);
        when(eventHubProperties.getRetryOptions()).thenReturn(eventHubAmqpRetryOptions);
        final EventHubClientFactory eventHubClientFactory = new EventHubClientFactory(eventHubProperties);
        when(eventHubProperties.getEventHubNameByEvent(CREDITCREATED)).thenReturn(CREDITCREATED.toString());
        when(eventHubProperties.getEventHubConnectionStringByEvent(CREDITCREATED)).thenReturn(CONNECTION_STRING + CREDITCREATED);
        final EventHubProducerClient client = eventHubClientFactory.getEventHubClientFor(CREDITCREATED);

        assertEquals(CREDITCREATED.toString(), client.getEventHubName());
        verify(eventHubProperties, times(1)).getRetryOptions();

        final AmqpRetryOptions amqpOptions = (AmqpRetryOptions) ReflectionTestUtils.getField(eventHubClientFactory, "retryOptions");

        assertEquals(3, amqpOptions.getMaxRetries());
        assertEquals(Duration.ofMillis(100L), amqpOptions.getDelay());
        assertEquals(Duration.ofMillis(400L), amqpOptions.getMaxDelay());
        assertEquals(Duration.ofMillis(2000L), amqpOptions.getTryTimeout());
        assertEquals(AmqpRetryMode.EXPONENTIAL, amqpOptions.getMode());

        final EventHubProducerAsyncClient producer = (EventHubProducerAsyncClient) ReflectionTestUtils.getField(client, "producer");
        final AmqpRetryOptions amqpOptionsFromClient = (AmqpRetryOptions) ReflectionTestUtils.getField(producer, "retryOptions");
        assertEquals(amqpOptionsFromClient, amqpOptions);

    }

    @Test
    public void getEventHubClientCreditCreatedRetryDisabled() {
        final EventHubProperties.EventHubAmqpRetryOptions eventHubAmqpRetryOptions = new EventHubProperties().getRetryOptions();
        eventHubAmqpRetryOptions.setMaxRetries(0);
        eventHubAmqpRetryOptions.setDelay(10L);
        eventHubAmqpRetryOptions.setMaxDelay(40L);
        eventHubAmqpRetryOptions.setTryTimeout(1000L);
        when(eventHubProperties.getRetryOptions()).thenReturn(eventHubAmqpRetryOptions);
        final EventHubClientFactory eventHubClientFactory = new EventHubClientFactory(eventHubProperties);
        when(eventHubProperties.getEventHubNameByEvent(CREDITCREATED)).thenReturn(CREDITCREATED.toString());
        when(eventHubProperties.getEventHubConnectionStringByEvent(CREDITCREATED)).thenReturn(CONNECTION_STRING + CREDITCREATED);
        final EventHubProducerClient client = eventHubClientFactory.getEventHubClientFor(CREDITCREATED);

        assertEquals(CREDITCREATED.toString(), client.getEventHubName());
        verify(eventHubProperties, times(1)).getRetryOptions();

        final AmqpRetryOptions amqpOptions = (AmqpRetryOptions) ReflectionTestUtils.getField(eventHubClientFactory, "retryOptions");
        assertEquals(Duration.ofMillis(10L), amqpOptions.getDelay());
        assertEquals(Duration.ofMillis(40L), amqpOptions.getMaxDelay());
        assertEquals(Duration.ofMillis(1000L), amqpOptions.getTryTimeout());
        assertEquals(AmqpRetryMode.EXPONENTIAL, amqpOptions.getMode());

        final EventHubProducerAsyncClient producer = (EventHubProducerAsyncClient) ReflectionTestUtils.getField(client, "producer");
        final AmqpRetryOptions amqpOptionsFromClient = (AmqpRetryOptions) ReflectionTestUtils.getField(producer, "retryOptions");
        assertEquals(amqpOptionsFromClient, amqpOptions);

        eventHubClientFactory.getEventHubClientFor(CREDITCREATED);
    }

    @Test
    public void getEventHubClientCreditUpdatedRetryEnabled() {
        final EventHubAmqpRetryOptions eventHubAmqpRetryOptions = new EventHubProperties().getRetryOptions();
        eventHubAmqpRetryOptions.setMaxRetries(5);
        eventHubAmqpRetryOptions.setDelay(1000L);
        eventHubAmqpRetryOptions.setMaxDelay(2000L);
        eventHubAmqpRetryOptions.setTryTimeout(5000L);
        when(eventHubProperties.getRetryOptions()).thenReturn(eventHubAmqpRetryOptions);
        final EventHubClientFactory eventHubClientFactory = new EventHubClientFactory(eventHubProperties);
        when(eventHubProperties.getEventHubNameByEvent(CREDITUPDATED)).thenReturn(CREDITUPDATED.toString());
        when(eventHubProperties.getEventHubConnectionStringByEvent(CREDITUPDATED)).thenReturn(CONNECTION_STRING + CREDITUPDATED);
        final EventHubProducerClient client = eventHubClientFactory.getEventHubClientFor(CREDITUPDATED);

        assertEquals(CREDITUPDATED.toString(), client.getEventHubName());
        verify(eventHubProperties, times(1)).getRetryOptions();

        final AmqpRetryOptions amqpOptions = (AmqpRetryOptions) ReflectionTestUtils.getField(eventHubClientFactory, "retryOptions");
        assertEquals(5, amqpOptions.getMaxRetries());
        assertEquals(Duration.ofMillis(1000L), amqpOptions.getDelay());
        assertEquals(Duration.ofMillis(2000L), amqpOptions.getMaxDelay());
        assertEquals(Duration.ofMillis(5000L), amqpOptions.getTryTimeout());
        assertEquals(AmqpRetryMode.EXPONENTIAL, amqpOptions.getMode());

        final EventHubProducerAsyncClient producer = (EventHubProducerAsyncClient) ReflectionTestUtils.getField(client, "producer");
        final AmqpRetryOptions amqpOptionsFromClient = (AmqpRetryOptions) ReflectionTestUtils.getField(producer, "retryOptions");
        assertEquals(amqpOptionsFromClient, amqpOptions);
    }

    @Test
    public void getEventHubClientCreditUpdatedRetryDisabled() {
        final EventHubAmqpRetryOptions eventHubAmqpRetryOptions = new EventHubProperties().getRetryOptions();
        eventHubAmqpRetryOptions.setMaxRetries(0);
        eventHubAmqpRetryOptions.setDelay(100L);
        eventHubAmqpRetryOptions.setMaxDelay(200L);
        eventHubAmqpRetryOptions.setTryTimeout(500L);
        when(eventHubProperties.getRetryOptions()).thenReturn(eventHubAmqpRetryOptions);
        final EventHubClientFactory eventHubClientFactory = new EventHubClientFactory(eventHubProperties);
        when(eventHubProperties.getEventHubNameByEvent(CREDITUPDATED)).thenReturn(CREDITUPDATED.toString());
        when(eventHubProperties.getEventHubConnectionStringByEvent(CREDITUPDATED)).thenReturn(CONNECTION_STRING + CREDITUPDATED);
        final EventHubProducerClient client = eventHubClientFactory.getEventHubClientFor(CREDITUPDATED);

        assertEquals(CREDITUPDATED.toString(), client.getEventHubName());
        verify(eventHubProperties, times(1)).getRetryOptions();

        final AmqpRetryOptions amqpOptions = (AmqpRetryOptions) ReflectionTestUtils.getField(eventHubClientFactory, "retryOptions");
        assertEquals(0, amqpOptions.getMaxRetries());
        assertEquals(Duration.ofMillis(100L), amqpOptions.getDelay());
        assertEquals(Duration.ofMillis(200L), amqpOptions.getMaxDelay());
        assertEquals(Duration.ofMillis(500L), amqpOptions.getTryTimeout());
        assertEquals(AmqpRetryMode.EXPONENTIAL, amqpOptions.getMode());

        final EventHubProducerAsyncClient producer = (EventHubProducerAsyncClient) ReflectionTestUtils.getField(client, "producer");
        final AmqpRetryOptions amqpOptionsFromClient = (AmqpRetryOptions) ReflectionTestUtils.getField(producer, "retryOptions");
        assertEquals(amqpOptionsFromClient, amqpOptions);

        eventHubClientFactory.getEventHubClientFor(CREDITUPDATED);
    }

    @Test
    public void getEventHubClientCreditDeletedRetryEnabled() {
        final EventHubAmqpRetryOptions eventHubAmqpRetryOptions = new EventHubProperties().getRetryOptions();
        eventHubAmqpRetryOptions.setMaxRetries(10);
        eventHubAmqpRetryOptions.setDelay(100L);
        eventHubAmqpRetryOptions.setMaxDelay(200L);
        eventHubAmqpRetryOptions.setTryTimeout(500L);
        when(eventHubProperties.getRetryOptions()).thenReturn(eventHubAmqpRetryOptions);
        final EventHubClientFactory eventHubClientFactory = new EventHubClientFactory(eventHubProperties);
        when(eventHubProperties.getEventHubNameByEvent(CREDITDELETED)).thenReturn(CREDITDELETED.toString());
        when(eventHubProperties.getEventHubConnectionStringByEvent(CREDITDELETED)).thenReturn(CONNECTION_STRING + CREDITDELETED);
        final EventHubProducerClient client = eventHubClientFactory.getEventHubClientFor(CREDITDELETED);

        assertEquals(CREDITDELETED.toString(), client.getEventHubName());
        verify(eventHubProperties, times(1)).getRetryOptions();

        final AmqpRetryOptions amqpOptions = (AmqpRetryOptions) ReflectionTestUtils.getField(eventHubClientFactory, "retryOptions");
        assertEquals(10, amqpOptions.getMaxRetries());
        assertEquals(Duration.ofMillis(100L), amqpOptions.getDelay());
        assertEquals(Duration.ofMillis(200L), amqpOptions.getMaxDelay());
        assertEquals(Duration.ofMillis(500L), amqpOptions.getTryTimeout());
        assertEquals(AmqpRetryMode.EXPONENTIAL, amqpOptions.getMode());

        final EventHubProducerAsyncClient producer = (EventHubProducerAsyncClient) ReflectionTestUtils.getField(client, "producer");
        final AmqpRetryOptions amqpOptionsFromClient = (AmqpRetryOptions) ReflectionTestUtils.getField(producer, "retryOptions");
        assertEquals(amqpOptionsFromClient, amqpOptions);
    }

    @Test
    public void getEventHubClientCreditDeletedRetryDisabled() {
        final EventHubAmqpRetryOptions eventHubAmqpRetryOptions = new EventHubProperties().getRetryOptions();
        eventHubAmqpRetryOptions.setMaxRetries(0);
        eventHubAmqpRetryOptions.setDelay(1L);
        eventHubAmqpRetryOptions.setMaxDelay(2L);
        eventHubAmqpRetryOptions.setTryTimeout(5L);
        when(eventHubProperties.getRetryOptions()).thenReturn(eventHubAmqpRetryOptions);
        final EventHubClientFactory eventHubClientFactory = new EventHubClientFactory(eventHubProperties);
        when(eventHubProperties.getEventHubNameByEvent(CREDITDELETED)).thenReturn(CREDITDELETED.toString());
        when(eventHubProperties.getEventHubConnectionStringByEvent(CREDITDELETED)).thenReturn(CONNECTION_STRING + CREDITDELETED);
        final EventHubProducerClient client = eventHubClientFactory.getEventHubClientFor(CREDITDELETED);

        assertEquals(CREDITDELETED.toString(), client.getEventHubName());
        verify(eventHubProperties, times(1)).getRetryOptions();

        final AmqpRetryOptions amqpOptions = (AmqpRetryOptions) ReflectionTestUtils.getField(eventHubClientFactory, "retryOptions");
        assertEquals(0, amqpOptions.getMaxRetries());
        assertEquals(Duration.ofMillis(1L), amqpOptions.getDelay());
        assertEquals(Duration.ofMillis(2L), amqpOptions.getMaxDelay());
        assertEquals(Duration.ofMillis(5L), amqpOptions.getTryTimeout());
        assertEquals(AmqpRetryMode.EXPONENTIAL, amqpOptions.getMode());

        final EventHubProducerAsyncClient producer = (EventHubProducerAsyncClient) ReflectionTestUtils.getField(client, "producer");
        final AmqpRetryOptions amqpOptionsFromClient = (AmqpRetryOptions) ReflectionTestUtils.getField(producer, "retryOptions");
        assertEquals(amqpOptionsFromClient, amqpOptions);

        eventHubClientFactory.getEventHubClientFor(CREDITDELETED);
    }

    @Test(expected = EventHubException.class)
    public void tryGetNonExistingEventHubClient() {
        when(eventHubProperties.getRetryOptions()).thenReturn(new EventHubProperties().getRetryOptions());
        final EventHubClientFactory eventHubClientFactory = new EventHubClientFactory(eventHubProperties);
        eventHubClientFactory.getEventHubClientFor(UnknownEvent.UNKNOWNEVENT);
    }

    @Test(expected = EventHubException.class)
    public void identifyMissingEventHubName() {
        when(eventHubProperties.getRetryOptions()).thenReturn(new EventHubProperties().getRetryOptions());
        final EventHubClientFactory eventHubClientFactory = new EventHubClientFactory(eventHubProperties);
        when(eventHubProperties.getEventHubConnectionStringByEvent(CREDITCREATED)).thenReturn(CONNECTION_STRING + CREDITCREATED);
        when(eventHubProperties.getEventHubNameByEvent(CREDITCREATED)).thenReturn(null);
        eventHubClientFactory.getEventHubClientFor(CREDITCREATED);
    }

    @Test(expected = EventHubException.class)
    public void identifyMissingEventHubConnectionString() {
        when(eventHubProperties.getRetryOptions()).thenReturn(new EventHubProperties().getRetryOptions());
        final EventHubClientFactory eventHubClientFactory = new EventHubClientFactory(eventHubProperties);
        when(eventHubProperties.getEventHubConnectionStringByEvent(CREDITCREATED)).thenReturn(null);
        eventHubClientFactory.getEventHubClientFor(CREDITCREATED);
    }

    enum UnknownEvent implements Event {
        UNKNOWNEVENT;
    }
}
