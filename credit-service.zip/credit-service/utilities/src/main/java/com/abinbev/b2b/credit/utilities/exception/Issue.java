package com.abinbev.b2b.credit.utilities.exception;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;

@JsonInclude(Include.NON_NULL)
public class Issue implements Serializable {
    private static final long serialVersionUID = 1L;

    @ApiModelProperty(notes = "${resources.errorResponse.issue.code}", dataType = "java.lang.String", example = "credit-service.required-field")
    @JsonProperty
    private final String code;

    @ApiModelProperty(position = 1, notes = "${resources.errorResponse.issue.message}", dataType = "java.lang.String", example = "The field value is required")
    @JsonProperty
    private final String message;

    public Issue(final String code, final String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this, ToStringStyle.JSON_STYLE)
                .append("code", code)
                .append("message", message)
                .toString();
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }

        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        final Issue issue = (Issue) o;

        return new EqualsBuilder()
                .append(code, issue.code)
                .append(message, issue.message)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder()
                .append(code)
                .append(message)
                .toHashCode();
    }
}
