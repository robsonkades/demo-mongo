package com.abinbev.b2b.credit.utilities.config;

import com.abinbev.b2b.credit.utilities.domain.Credit;
import com.abinbev.b2b.credit.utilities.helper.Constants;
import com.google.common.collect.ImmutableList;
import com.mongodb.lang.NonNull;

import org.bson.types.Decimal128;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.mongo.MongoAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.core.convert.converter.Converter;
import org.springframework.data.convert.ReadingConverter;
import org.springframework.data.convert.WritingConverter;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.MongoTransactionManager;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.convert.DbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultMongoTypeMapper;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.convert.MongoCustomConversions;
import org.springframework.data.mongodb.core.index.IndexOperations;
import org.springframework.data.mongodb.core.index.IndexResolver;
import org.springframework.data.mongodb.core.index.MongoPersistentEntityIndexResolver;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Date;
import java.util.Map;
import java.util.Set;

@Configuration
@Import(value = MongoAutoConfiguration.class)
public class MongoConfiguration {

    private static final Logger logger = LoggerFactory.getLogger(MongoConfiguration.class);

    @Autowired
    private MongoDatabaseFactory mongoDbFactory;

    @Autowired
    private MongoMappingContext mongoMappingContext;

    @Autowired
    private DatabaseCollectionsConfiguration collectionProperties;

    @Bean
    public MongoTransactionManager mongoTransactionManager() {
        return new MongoTransactionManager(this.mongoDbFactory);
    }

    @Bean
    public MongoTemplate mongoTemplate(final MappingMongoConverter converter) {
        final MongoTemplate mongoTemplate = new MongoTemplate(this.mongoDbFactory, converter);
        createCollectionsAndIndexesIfNecessary(mongoTemplate);
        return mongoTemplate;
    }

    public void createCollectionsAndIndexesIfNecessary(final MongoTemplate mongoTemplate) {
        try {
            final IndexResolver resolver = new MongoPersistentEntityIndexResolver(this.mongoMappingContext);
            final Set<Map.Entry<String, String>> ticketMap = collectionProperties
                    .getCredits()
                    .entrySet();
            for (final Map.Entry<String, String> entry : ticketMap) {
                final String country = entry.getKey();
                final String collection = entry.getValue();
                MDC.put(Constants.COUNTRY_HEADER, country);
                if (!mongoTemplate.collectionExists(collection)) {
                    logger.info("Creating collection '{}' for country '{}'", collection, country);
                    mongoTemplate.createCollection(collection);
                }
                final IndexOperations creditIndexOperation = mongoTemplate.indexOps(Credit.class);
                resolver.resolveIndexFor(Credit.class).forEach(creditIndexOperation::ensureIndex);
            }
        } finally {
            MDC.clear();
        }
    }

    @Bean
    public MappingMongoConverter mappingMongoConverter(@Qualifier("customConversions") MongoCustomConversions customConversions) {
        final DbRefResolver dbRefResolver = new DefaultDbRefResolver(mongoDbFactory);
        final MappingMongoConverter converter = new MappingMongoConverter(dbRefResolver, mongoMappingContext);
        converter.setTypeMapper(new DefaultMongoTypeMapper(null));
        converter.setCustomConversions(customConversions);
        return converter;
    }

    @Bean
    public MongoCustomConversions customConversions() {
        return new MongoCustomConversions(ImmutableList.of(DateToOffsetDateTimeConverter.INSTANCE, OffsetDateTimeToDateConverter.INSTANCE, BigDecimalDecimal128Converter.INSTANCE, Decimal128BigDecimalConverter.INSTANCE));
    }

    @ReadingConverter
    private static final class DateToOffsetDateTimeConverter implements Converter<Date, OffsetDateTime> {

        public static final DateToOffsetDateTimeConverter INSTANCE = new DateToOffsetDateTimeConverter();

        private DateToOffsetDateTimeConverter() {
        }

        @Override
        public OffsetDateTime convert(final Date source) {
            return source != null ? OffsetDateTime.ofInstant(source.toInstant(), ZoneOffset.UTC) : null;
        }
    }

    @WritingConverter
    private static final class OffsetDateTimeToDateConverter implements Converter<OffsetDateTime, Date> {

        public static final OffsetDateTimeToDateConverter INSTANCE = new OffsetDateTimeToDateConverter();

        private OffsetDateTimeToDateConverter() {
        }

        @Override
        public Date convert(final OffsetDateTime source) {
            if (source == null) {
                return null;
            }
            return Date.from(source.toInstant());
        }
    }

    @WritingConverter
    private static class BigDecimalDecimal128Converter implements Converter<BigDecimal, Decimal128> {

        public static final BigDecimalDecimal128Converter INSTANCE = new BigDecimalDecimal128Converter();

        private BigDecimalDecimal128Converter() {
            super();
        }

        @Override
        public Decimal128 convert(@NonNull BigDecimal source) {
            return new Decimal128(source);
        }
    }

    @ReadingConverter
    private static class Decimal128BigDecimalConverter implements Converter<Decimal128, BigDecimal> {

        public static final Decimal128BigDecimalConverter INSTANCE = new Decimal128BigDecimalConverter();

        private Decimal128BigDecimalConverter() {
            super();
        }

        @Override
        public BigDecimal convert(@NonNull Decimal128 source) {
            return source.bigDecimalValue();
        }
    }
}
