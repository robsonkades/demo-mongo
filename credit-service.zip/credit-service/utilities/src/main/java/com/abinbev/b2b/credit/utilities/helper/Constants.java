package com.abinbev.b2b.credit.utilities.helper;

public abstract class Constants {

    public static final String REQUEST_TRACE_ID_HEADER = "requestTraceId";

	public static final String COUNTRY_HEADER = "country";

    private Constants() {
		// com.abinbev.b2b.credit.utilities.helper class, only constants variables here
	}
}
