package com.abinbev.b2b.credit.utilities.remote.client;


import com.abinbev.b2b.credit.utilities.exception.ExternalServiceException;
import com.abinbev.b2b.credit.utilities.exception.IssueEnum;
import com.abinbev.b2b.credit.utilities.exception.IssueHandler;
import com.abinbev.b2b.credit.utilities.exception.RemoteServiceErrorException;
import com.abinbev.b2b.credit.utilities.exception.ServiceUnavailableException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.retry.RetryCallback;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

@Component
public class RemoteClient {

    private static final Logger logger = LoggerFactory.getLogger(RemoteClient.class);

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private RetryTemplate retryTemplate;

    public <T> ResponseEntity<T> getForObject(final String url, final HttpHeaders headers, final Class<T> expectedResponseType, final String remoteServiceName, final Object... uriVariables) {
        return doRequest(url, HttpMethod.GET, headers, null, expectedResponseType, remoteServiceName, uriVariables);
    }

    public <T> ResponseEntity<T> postForObject(final String url, final HttpHeaders headers, final Object payload, final Class<T> expectedResponseType, final String remoteServiceName, final Object... uriVariables) {
        return doRequest(url, HttpMethod.POST, headers, payload, expectedResponseType, remoteServiceName, uriVariables);
    }

    public <T> T post(final String url, final Object payload,
                      final MultiValueMap<String, String> headers, final Class<T> expectedResponseType) {
        final MultiValueMap<String, String> requestHeaders = headers == null ? new LinkedMultiValueMap<>() : headers;
        try {
            return retryTemplate.execute((RetryCallback<T, RestClientException>) context ->
                    exchange(url, HttpMethod.POST, new HttpEntity<>(payload, requestHeaders), expectedResponseType));
        } catch (final RestClientException ex) {
            return handleRetryException(url, ex, HttpMethod.POST);
        }
    }

    private <T> ResponseEntity<T> doRequest(final String url, final HttpMethod method, final HttpHeaders headers, final Object payload, final Class<T> expectedResponseType, final String remoteServiceName, final Object... uriVariables) {
        try {
            return restTemplate.exchange(url, method, new HttpEntity<>(payload, headers), expectedResponseType, uriVariables);
        } catch (final HttpStatusCodeException e) {
            logger.error(e.getMessage(), e);
            if(HttpStatus.SERVICE_UNAVAILABLE.equals(e.getStatusCode())) {
                throw new ServiceUnavailableException(IssueHandler.createIssue(IssueEnum.REMOTE_SERVICE_UNAVAILABLE, remoteServiceName));
            }

            if(!e.getStatusCode().is4xxClientError()) {
                throw new RemoteServiceErrorException(IssueHandler.createIssue(IssueEnum.REMOTE_SERVICE_ERROR, remoteServiceName));
            }

            throw e;
        } catch (final Exception e) {
            logger.error(e.getMessage(), e);
            throw new ServiceUnavailableException(IssueHandler.createIssue(IssueEnum.REMOTE_SERVICE_UNAVAILABLE, remoteServiceName));
        }
    }

    private <T> T handleRetryException(final String url, final RestClientException ex, final HttpMethod httpMethod) {
        logger.error("Error calling {} {}", httpMethod, url, ex);
        throw ExternalServiceException.errorCallingExternalService(ex);
    }

    private <T> T exchange(final String url, final HttpMethod httpMethod,
                           final HttpEntity httpEntity, final Class<T> expectedResponseType) {
        logger.info("Calling {} {}", httpMethod, url);
        return restTemplate.exchange(url, httpMethod, httpEntity, expectedResponseType).getBody();
    }
}
