package com.abinbev.b2b.credit.utilities.vo;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.annotations.ApiModelProperty;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import javax.validation.constraints.Digits;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;

public class CreditConsumptionRequest {

    @NotBlank
    @ApiModelProperty(value = "The credit accountId unique identifier", required = true)
    private String accountId;

    @JsonProperty
    @Digits(integer = 30, fraction = 8, message = "consumption: numeric value out of bounds (<30 digits>.<8 digits> expected)")
    @Min(value = 0, message = "consumption: must be greater than or equal to 0")
    @NotNull(message = "consumption: must not be null")
    @ApiModelProperty(value = "Credit consumed on B2B Platform before last credit update.", required = true)
    private BigDecimal consumption;

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(final String accountId) {
        this.accountId = accountId;
    }

    public BigDecimal getConsumption() {
        return consumption;
    }

    public void setConsumption(final BigDecimal consumption) {
        this.consumption = consumption;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this, ToStringStyle.JSON_STYLE);
    }
}
