package com.abinbev.b2b.credit.utilities.config;

import com.abinbev.b2b.credit.utilities.exception.BadRequestException;
import com.abinbev.b2b.credit.utilities.exception.IssueEnum;
import com.abinbev.b2b.credit.utilities.exception.IssueHandler;
import com.abinbev.b2b.credit.utilities.helper.Constants;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.lang.reflect.Type;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Configuration("dbCollections")
@ConfigurationProperties(prefix = "database.collections")
public class DatabaseCollectionsConfiguration {

    private static final Logger logger = LoggerFactory.getLogger(DatabaseCollectionsConfiguration.class);

    private static final Type TYPE = new TypeToken<Map<String, String>>(){}.getType();

    @Value("#{environment.DATABASE_COLLECTIONS_CREDITS}")
    private String creditCollectionsFromEnv;

    private Map<String, String> credits;

    public Map<String, String> getCredits() {
        return credits;
    }

    public void setCredits(final Map<String, String> credits) {
        if (StringUtils.isNotBlank(this.creditCollectionsFromEnv)) {
            try {
                this.credits = new Gson().fromJson(creditCollectionsFromEnv, TYPE);
            } catch (final Exception e) {
                logger.error(e.getMessage(), e);
                this.credits = null;
            }
        } else {
            this.credits = credits;
        }
    }

    public String findCreditCollectionByCountry(final String country) {
        if (credits != null && StringUtils.isNotBlank(country)) {
            final String countryParam = country.toLowerCase();
            final String collectionName = credits.get(countryParam);
            if (StringUtils.isNotBlank(collectionName)) {
                return collectionName;
            }
        }
        throw new BadRequestException(IssueHandler.createIssue(IssueEnum.UNSUPPORTED_COUNTRY, country, credits != null ?
                credits
                        .keySet()
                        .stream()
                        .map(String::toUpperCase)
                        .collect(Collectors.toList()) :
                null));
    }

    public String findCreditCollectionByCountry() {
        final String country = MDC.get(Constants.COUNTRY_HEADER);
        return findCreditCollectionByCountry(country);
    }

    public Set<String> getSupportedCountries() {
        if (this.credits == null) {
            return Collections.emptySet();
        }
        return this.credits.keySet();
    }
}
