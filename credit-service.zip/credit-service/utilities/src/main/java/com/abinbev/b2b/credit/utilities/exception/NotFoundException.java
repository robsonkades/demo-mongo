package com.abinbev.b2b.credit.utilities.exception;

import org.springframework.http.HttpStatus;

public class NotFoundException extends GlobalException {

	private static final long serialVersionUID = 1L;

	public NotFoundException(final Issue issue) {
		super(issue, HttpStatus.NOT_FOUND);
	}
}
