package com.abinbev.b2b.credit.utilities.domain;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Set;

public class CreditBuilder {
    private Credit instance = new Credit();

    public CreditBuilder withAccountId(final String accountId) {
        this.instance.setAccountId(accountId);
        return this;
    }

    public CreditBuilder withBalance(final BigDecimal balance) {
        this.instance.setBalance(balance);
        return this;
    }

    public CreditBuilder withOverdue(final BigDecimal overdue) {
        this.instance.setOverdue(overdue);
        return this;
    }

    public CreditBuilder withAvailable(final BigDecimal available) {
        this.instance.setAvailable(available);
        return this;
    }

    public CreditBuilder withPaymentTerms(final String paymentTerms){
        this.instance.setPaymentTerms(paymentTerms);
        return this;
    }

    public CreditBuilder withTotal(final BigDecimal total){
        this.instance.setTotal(total);
        return this;
    }

    public CreditBuilder withConsumption(final BigDecimal consumption){
        this.instance.setConsumption(consumption);
        return this;
    }

    public CreditBuilder withUpdatedAt(final OffsetDateTime updatedAt){
        this.instance.setUpdatedAt(updatedAt);
        return this;
    }

    public CreditBuilder withChildIds(final Set<String> childIds){
        this.instance.setChildIds(childIds);
        return this;
    }

    public CreditBuilder withParentId(final String parentId){
        this.instance.setParentId(parentId);
        return this;
    }

    public Credit build() {
        return this.instance;
    }
}
