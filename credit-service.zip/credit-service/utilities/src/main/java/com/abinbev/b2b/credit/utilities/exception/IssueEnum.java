package com.abinbev.b2b.credit.utilities.exception;

import java.util.IllegalFormatException;
import java.util.ResourceBundle;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public enum IssueEnum {
    // Note: the comments are placed just to prevent auto formatting add
    // the constants to the same line.
    //
    REQUEST_TRACE_ID_NOT_VALID("credit-service.request-trace-id-not-valid", "The header requestTraceId '%s' is not valid"),

    INVALID_COUNTRY("credit-service.invalid-country", "The country '%s' is not valid"),

    UNSUPPORTED_COUNTRY("credit-service.unsupported-country", "The country '%s' is not supported. The supported countries are %s"),
    // Others.

    FORBIDDEN("credit-service.forbidden", "Access Denied"),

    GENERIC_EXCEPTION("credit-service.generic-exception"),

    ACCOUNT_ID_NOT_FOUND("credit-service.account-id-not-found", "Credit with accountId '%s' was not found in database"),

    ACCOUNT_NOT_FOUND("credit-service.account-not-found", "Account(s) not found for vendorAccountId(s): '%s' and vendorId: '%s'"),

    REMOTE_SERVICE_UNAVAILABLE("credit-service.remote-service-unavailable", "Remote service '%s' is unavailable"),

    REMOTE_SERVICE_ERROR("credit-service.remote-service-error");

    private final String code;

    private String message;

    private ResourceBundle bundle;

    // not static because ENUMS are initialized before static fields by JVM
    private static final Logger logger = LoggerFactory.getLogger(IssueEnum.class);

    IssueEnum(final String code) {
        this(code, null);
    }

    IssueEnum(final String code, final String message) {
        this.code = code;
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public String getFormattedMessage(final Object... args) {
        if (message == null) {
            return message;
        }

        try {
            return String.format(message, args);
        } catch (final IllegalFormatException e) {
            logger.warn(e.getMessage(), e);
            return message.replace("%s", "");
        }
    }
}
