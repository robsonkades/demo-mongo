package com.abinbev.b2b.credit.utilities.repository;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import com.abinbev.b2b.credit.utilities.domain.Credit;

public interface CreditDao {

    Optional<Credit> findById(final String country, final String id);

    boolean upsert(final String country, final Credit entity);

    boolean updateCreditConsumption(final String country, final OffsetDateTime updatedAt, final String accountId, final BigDecimal newConsumption);

    List<Credit> findByAccountIds(final String country, final Collection<String> accountIds);

    void upsertChildCredits(final String country, final Collection<Credit> credits);

    void remove(final String country, final Collection<String> accountIds);

    boolean remove(final String country, final OffsetDateTime updatedAt, final String id);

    void removeChildCredits(final String country, final String parentId, final OffsetDateTime timestamp, final Collection<String> accountIds);
}
