package com.abinbev.b2b.credit.utilities.exception;

import org.springframework.http.HttpStatus;

import java.util.List;

public class BadRequestException extends GlobalException {

    public BadRequestException(final Issue issue) {
        super(issue, HttpStatus.BAD_REQUEST);
    }

    public BadRequestException(final String message, final List<Issue> issues) {
        super(message, issues, HttpStatus.BAD_REQUEST);
    }

}
