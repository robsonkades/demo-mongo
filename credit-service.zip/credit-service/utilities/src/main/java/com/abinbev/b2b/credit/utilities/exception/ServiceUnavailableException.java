package com.abinbev.b2b.credit.utilities.exception;

import org.springframework.http.HttpStatus;

public class ServiceUnavailableException extends GlobalException {

    public ServiceUnavailableException(final Issue issue) {
        super(issue, HttpStatus.SERVICE_UNAVAILABLE);
    }
}
