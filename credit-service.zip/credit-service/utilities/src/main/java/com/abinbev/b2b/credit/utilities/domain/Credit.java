package com.abinbev.b2b.credit.utilities.domain;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.Set;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.abinbev.b2b.credit.utilities.formatter.OffsetDateTimeDeserializer;
import com.abinbev.b2b.credit.utilities.formatter.OffsetDateTimeSerializer;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import io.swagger.annotations.ApiModelProperty;
import io.swagger.v3.oas.annotations.Hidden;

@JsonIgnoreProperties(value = {"childIds", "parentId"})
@Document(collection = "#{@dbCollections.findCreditCollectionByCountry()}")
public class Credit {

    @Id
    @ApiModelProperty(notes = "${resources.credit.accountId}", example = "123456")
    private String accountId;

    @ApiModelProperty(notes = "${resources.credit.balance}", example = "1000.00")
    private BigDecimal balance;

    @ApiModelProperty(notes = "${resources.credit.overdue}", example = "500.00")
    private BigDecimal overdue;

    @ApiModelProperty(notes = "${resources.credit.available}", example = "500.00")
    private BigDecimal available;

    @ApiModelProperty(notes = "${resources.credit.paymentTerms}", example = "30 DAY CHARGE")
    private String paymentTerms;

    @ApiModelProperty(notes = "${resources.credit.total}", example = "1000.00")
    private BigDecimal total;

    @ApiModelProperty(notes = "${resources.credit.consumption}", example = "0.00")
    private BigDecimal consumption;

    @ApiModelProperty(example = "2021-02-05T14:50:20.257Z")
    @JsonSerialize(using = OffsetDateTimeSerializer.class)
    @JsonDeserialize(using = OffsetDateTimeDeserializer.class)
    private OffsetDateTime updatedAt;

    @Hidden
    private String parentId;

    @Hidden
    private Set<String> childIds;

    public Credit() {
        //Default constructor
    }

    public Credit(final String accountId, final String parentId, final OffsetDateTime updatedAt) {
        this.accountId = accountId;
        this.parentId = parentId;
        this.updatedAt = updatedAt;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(final String accountId) {
        this.accountId = accountId;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    public void setBalance(final BigDecimal balance) {
        this.balance = balance;
    }

    public BigDecimal getOverdue() {
        return overdue;
    }

    public void setOverdue(final BigDecimal overdue) {
        this.overdue = overdue;
    }

    public BigDecimal getAvailable() {
        return available;
    }

    public void setAvailable(final BigDecimal available) {
        this.available = available;
    }

    public String getPaymentTerms() {
        return paymentTerms;
    }

    public void setPaymentTerms(final String paymentTerms) {
        this.paymentTerms = paymentTerms;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(final BigDecimal total) {
        this.total = total;
    }

    public OffsetDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(final OffsetDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    public BigDecimal getConsumption() {
        return consumption;
    }

    public void setConsumption(final BigDecimal consumption) {
        this.consumption = consumption;
    }

    @JsonIgnore
    public String getParentId() {
        return parentId;
    }

    public void setParentId(final String parentId) {
        this.parentId = parentId;
    }

    @JsonIgnore
    public Set<String> getChildIds() {
        return childIds;
    }

    public void setChildIds(final Set<String> childIds) {
        this.childIds = childIds;
    }

    public static CreditBuilder builder() {
        return new CreditBuilder();
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o)
            return true;

        if (o == null || getClass() != o.getClass())
            return false;

        final Credit credit = (Credit) o;

        return new EqualsBuilder()
                .append(accountId, credit.accountId)
                .append(balance, credit.balance)
                .append(overdue, credit.overdue)
                .append(available, credit.available)
                .append(paymentTerms, credit.paymentTerms)
                .append(total, credit.total)
                .append(consumption, credit.consumption)
                .append(updatedAt, credit.updatedAt)
                .append(parentId, credit.parentId)
                .append(childIds, credit.childIds)
                .isEquals();
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder(17, 37)
                .append(accountId)
                .append(balance)
                .append(overdue)
                .append(available)
                .append(paymentTerms)
                .append(total)
                .append(consumption)
                .append(updatedAt)
                .append(parentId)
                .append(childIds)
                .toHashCode();
    }
}
