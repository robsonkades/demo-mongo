package com.abinbev.b2b.credit.utilities.vo;

import java.util.List;

public class CreditRequest {

    private String country;

    private List<String> accountIds;

    public CreditRequest() {
        super();
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(final String country) {
        this.country = country;
    }

    public List<String> getAccountIds() {
        return accountIds;
    }

    public void setAccountIds(final List<String> accountIds) {
        this.accountIds = accountIds;
    }

    public static CreditRequestBuilder builder(){
        return new CreditRequestBuilder();
    }

    public static class CreditRequestBuilder {
        private CreditRequest request = new CreditRequest();

        public CreditRequestBuilder withCountry(final String country) {
            this.request.country = country;
            return this;
        }

        public CreditRequestBuilder withAccountIds(final List<String> accountIds) {
            this.request.accountIds = accountIds;
            return this;
        }

        public CreditRequest build () {
            return this.request;
        }
    }
}
