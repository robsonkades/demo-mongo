package com.abinbev.b2b.credit.utilities.exception;

import org.springframework.http.HttpStatus;

import java.util.Arrays;
import java.util.List;

public class GlobalException extends RuntimeException {

    private final HttpStatus httpStatus;

    private final List<Issue> issues;

    protected GlobalException(final Issue issue, final HttpStatus httpStatus) {
        super(issue.getMessage());
        this.issues = Arrays.asList(issue);
        this.httpStatus = httpStatus;
    }

    protected GlobalException(final String message, final List<Issue> issues, final HttpStatus httpStatus) {
        super(message);
        this.issues = issues;
        this.httpStatus = httpStatus;
    }

    protected GlobalException(final String message, final HttpStatus httpStatus, final Throwable e) {
        super(message,e);
        this.issues = null;
        this.httpStatus = httpStatus;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public List<Issue> getIssues() {
        return issues;
    }
}
