package com.abinbev.b2b.credit.utilities.config;

import com.abinbev.b2b.credit.utilities.config.property.RestProperties;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.retry.RetryPolicy;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.retry.backoff.ExponentialBackOffPolicy;
import org.springframework.retry.policy.ExceptionClassifierRetryPolicy;
import org.springframework.retry.policy.SimpleRetryPolicy;
import org.springframework.retry.support.RetryTemplate;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Component
@EnableRetry
public class RemoteConfig {

    @Autowired
    private RestProperties restProperties;

    @Bean
    public RestTemplate restTemplate() {
        final HttpClient httpClient = HttpClientBuilder.create()
                                                       .setMaxConnTotal(restProperties.getMaxConnTotal())
                                                       .setMaxConnPerRoute(restProperties.getMaxConnPerRoute())
                                                       .build();

        final HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
        requestFactory.setReadTimeout(restProperties.getReadTimeout());
        requestFactory.setConnectTimeout(restProperties.getConnectTimeout());

        return new RestTemplate(requestFactory);
    }

    @Bean
    public RetryTemplate retryTemplate() {
        final RestProperties.RetryableProperties retryableProperties = restProperties.getRetryable();

        final Map<Class<? extends Throwable>, RetryPolicy> policyMap = new HashMap<>();
        policyMap.put(RestClientException.class, new SimpleRetryPolicy(retryableProperties.getMaxAttempts()));

        final ExceptionClassifierRetryPolicy exceptionClassifierRetryPolicy = new ExceptionClassifierRetryPolicy();
        exceptionClassifierRetryPolicy.setPolicyMap(policyMap);

        final ExponentialBackOffPolicy backOffPolicy = new ExponentialBackOffPolicy();
        backOffPolicy.setInitialInterval(retryableProperties.getInitialInterval());
        backOffPolicy.setMaxInterval(retryableProperties.getMaxInterval());
        backOffPolicy.setMultiplier(retryableProperties.getMultiplier());

        final RetryTemplate template = new RetryTemplate();
        template.setRetryPolicy(exceptionClassifierRetryPolicy);
        template.setBackOffPolicy(backOffPolicy);
        return template;
    }

}
