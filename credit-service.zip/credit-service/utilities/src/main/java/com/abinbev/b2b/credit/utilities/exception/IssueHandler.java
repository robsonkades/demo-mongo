package com.abinbev.b2b.credit.utilities.exception;

public class IssueHandler {

    private IssueHandler() {
        super();
    }

    public static Issue createIssue(final IssueEnum issueEnum, final Object... args) {
        return new Issue(issueEnum.getCode(), issueEnum.getFormattedMessage(args));
    }

    public static Issue createIssue(final Throwable ex) {
        return new Issue(IssueEnum.GENERIC_EXCEPTION.getCode(), ex.getLocalizedMessage());
    }

    public static Issue createIssue(final String message) {
        return new Issue(IssueEnum.GENERIC_EXCEPTION.getCode(), message);
    }
}
