package com.abinbev.b2b.credit.utilities.exception;

public class ExternalServiceException extends RuntimeException {

    private static final long serialVersionUID = 6008413325140047190L;

    public ExternalServiceException(final String message, final Exception ex) {
        super(message, ex);
    }

    public static ExternalServiceException errorCallingExternalService(final Exception ex) {
        return new ExternalServiceException("Unable to process the request. We are having problems in our ecosystem. Please, try again later.", ex);
    }

}
