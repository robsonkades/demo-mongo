package com.abinbev.b2b.credit.utilities.repository;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.BulkOperations.BulkMode;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.util.Pair;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.abinbev.b2b.credit.utilities.config.DatabaseCollectionsConfiguration;
import com.abinbev.b2b.credit.utilities.domain.Credit;
import com.google.common.collect.ImmutableSet;
import com.mongodb.BasicDBList;
import com.mongodb.MongoBulkWriteException;
import com.mongodb.bulk.BulkWriteResult;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;
import com.newrelic.api.agent.Trace;

@Repository
public class CreditDaoImpl implements CreditDao {

    private static final Logger logger = LoggerFactory.getLogger(CreditDaoImpl.class);

    static final String CONSUMPTION_KEY = "consumption";

    static final String ID_KEY = "_id";

    static final String BALANCE_KEY = "balance";

    static final String OVERDUE_KEY = "overdue";

    static final String AVAILABLE_KEY = "available";

    static final String PAYMENT_TERMS_KEY = "paymentTerms";

    static final String TOTAL_KEY = "total";

    static final String UPDATED_AT = "updatedAt";

    static final String CHILD_IDS_KEY = "childIds";

    static final String PARENT_ID_KEY = "parentId";

    private final DatabaseCollectionsConfiguration properties;

    private final MongoTemplate template;

    @Autowired
    public CreditDaoImpl(final DatabaseCollectionsConfiguration properties, final MongoTemplate template) {
        this.properties = properties;
        this.template = template;
    }

    @Override
    public Optional<Credit> findById(final String country, final String id) {
        final String collection = this.properties.findCreditCollectionByCountry(country);
        return Optional.ofNullable(this.template.findById(id, Credit.class, collection));
    }

    @Trace
    @Override
    public boolean upsert(final String country, final Credit entity) {
        logger.info("Starting upsert for the credit '{}'", entity.getAccountId());
        final String collection = this.properties.findCreditCollectionByCountry(country);
        final Document doc = createDocument(entity);


        final Query query = Query.query(where(ID_KEY)
                .is(entity.getAccountId())
                .and(UPDATED_AT)
                .lt(entity.getUpdatedAt()));

        final UpdateResult result = this.template.upsert(query, buildUpdate(doc, ID_KEY), collection);
        final boolean wasSuccessful = result.getUpsertedId() != null || result.getModifiedCount() > 0;
        if(wasSuccessful){
            logger.info("Ending the credit '{}' upsert successfully", entity.getAccountId());
            return true;
        }

        logger.info("Ending the credit '{}' upsert unsuccessfully", entity.getAccountId());
        return false;
    }

    @Override
    public boolean updateCreditConsumption(final String country, final OffsetDateTime updatedAt, final String accountId, final BigDecimal newConsumption) {
        logger.info("Starting the credit consumption update for accountId '{}'", accountId);
        final String collectionName = properties.findCreditCollectionByCountry(country);
        final UpdateResult result = this.template.updateFirst(query(Criteria
                                                                                  .where(ID_KEY)
                                                                                  .is(accountId)
                                                                                  .and(UPDATED_AT)
                                                                                  .is(updatedAt)), Update.update(CONSUMPTION_KEY, newConsumption), collectionName);
        final boolean wasSuccessful = result.getModifiedCount() > 0;
        if(wasSuccessful) {
            logger.info("The credit consumption update was successful for accountId '{}'", accountId);
            return true;
        }
        logger.warn("The credit consumption update was unsuccessful for accountId '{}', there is probably already a new version for this credit", accountId);
        return false;
    }

    @Trace
    @Override
    public List<Credit> findByAccountIds(final String country, final Collection<String> accountIds) {
        if (CollectionUtils.isEmpty(accountIds)) {
            logger.info("Discarding find because accountIds argument is empty");
            return Collections.emptyList();
        }
        var collection = this.properties.findCreditCollectionByCountry(country);
        final Query query = buildQueryByFilters(accountIds);
        return findCredits(query, collection);
    }

    @Trace
    @Override
    public void upsertChildCredits(final String country, final Collection<Credit> credits){
        if (CollectionUtils.isEmpty(credits)) {
            logger.info("Discarding upsert because credits are empty");
            return;
        }
        final var collectionName = this.properties.findCreditCollectionByCountry(country);
        logger.info("Start upserting '{}' credits", credits.size());

        final List<Pair<Query, Update>> updates = new ArrayList<>();

        for(final Credit credit : credits){
            final Document doc = createDocument(credit);
            final Query query = Query.query(where(ID_KEY)
                                                    .is(credit.getAccountId())
                                                    .and(UPDATED_AT)
                                                    .lt(credit.getUpdatedAt())
            );
            updates.add(Pair.of(query, buildUpdate(doc, ID_KEY)));
        }


        if (!CollectionUtils.isEmpty(updates)) {
            BulkWriteResult result = null;
            try {
                result = this.template
                        .bulkOps(BulkMode.UNORDERED, collectionName)
                        .upsert(updates)
                        .execute();
            } catch (final MongoBulkWriteException e) {
                result = e.getWriteResult();
                logger.error(e.getMessage(), e);
                throw e;
            } finally {
                logger.info("It has been created '{}' from '{}' credits", result != null && result.getUpserts() != null ? result.getUpserts().size() : 0, credits.size());
                logger.info("It has been updated '{}' from '{}' credits", result != null ? result.getModifiedCount() : 0, credits.size());
            }
        }
    }

    @Trace
    @Override
    public void remove(final String country, final Collection<String> accountIds) {
        if (CollectionUtils.isEmpty(accountIds)) {
            logger.info("Discarding credit deletion because accountIds are empty");
            return;
        }
        logger.info("Start removing '{}' credits", accountIds);
        final var collectionName = this.properties.findCreditCollectionByCountry(country);
        final Query query = new Query().addCriteria(Criteria
                                                            .where(ID_KEY)
                                                            .in(accountIds));

        final DeleteResult result = this.template.remove(query, collectionName);
        logger.info("Total of '{}' credits were removed", result.getDeletedCount());

    }

    @Trace
    @Override
    public boolean remove(final String country, final OffsetDateTime updatedAt, final String id) {
        logger.info("Start removing the credit '{}' with updatedAt '{}'", id, updatedAt);
        final var collectionName = this.properties.findCreditCollectionByCountry(country);
        final Query query = new Query().addCriteria(Criteria
                                                            .where(ID_KEY)
                                                            .is(id)
                                                            .and(UPDATED_AT)
                                                            .lte(updatedAt)
                                                            .and(PARENT_ID_KEY)
                                                            .exists(false) // avoid shared credit removal
        );

        final DeleteResult result = this.template.remove(query, collectionName);
        if (result != null && result.getDeletedCount() > 0) {
            logger.info("The credit '{}' with updatedAt '{}' was removed successful", id, updatedAt);
            return true;
        }
        logger.warn("The credit '{}' with updatedAt '{}' has not been removed", id, updatedAt);
        return false;
    }

    @Trace
    @Override
    public void removeChildCredits(final String country, final String parentId, final OffsetDateTime timestamp, final Collection<String> accountIds) {
        if (CollectionUtils.isEmpty(accountIds)) {
            logger.info("Discarding shared credits removal because list is empty");
            return;
        }
        logger.info("Start removing '{}' shared credits", accountIds.size());
        final var collectionName = this.properties.findCreditCollectionByCountry(country);
        final List<Query> updates = new ArrayList<>();
        for (final String accountId : accountIds) {
            updates.add(Query.query(where(ID_KEY)
                                            .is(accountId)
                                            .and(PARENT_ID_KEY)
                                            .is(parentId)
                                            .and(UPDATED_AT)
                                            .lt(timestamp)));
        }

        if (!CollectionUtils.isEmpty(updates)) {
            BulkWriteResult result = null;
            try {
                result = this.template
                        .bulkOps(BulkMode.UNORDERED, collectionName)
                        .remove(updates)
                        .execute();
            } catch (final MongoBulkWriteException e) {
                result = e.getWriteResult();
                logger.error(e.getMessage(), e);
                throw e;
            } finally {
                logger.info("It has been removed '{}' from '{}' credits", result != null ? result.getDeletedCount() : 0, accountIds.size());
            }
        }
    }

    Document createDocument(final Credit credit) {
        final Document document = new Document();
        document.put(ID_KEY, credit.getAccountId());
        document.put(PARENT_ID_KEY, credit.getParentId());
        document.put(UPDATED_AT, credit.getUpdatedAt());
        document.put(CONSUMPTION_KEY, credit.getConsumption());
        document.put(BALANCE_KEY, credit.getBalance());
        document.put(OVERDUE_KEY, credit.getOverdue());
        document.put(AVAILABLE_KEY, credit.getAvailable());
        document.put(PAYMENT_TERMS_KEY, credit.getPaymentTerms());
        document.put(TOTAL_KEY, credit.getTotal());
        document.put(CHILD_IDS_KEY, credit.getChildIds());
        return document;
    }

    private Query buildQueryByFilters(final Collection<String> accountIds) {
        final Query query = new Query();

        if (!CollectionUtils.isEmpty(accountIds)) {
            query.addCriteria(Criteria
                    .where(ID_KEY)
                    .in(accountIds));
        }

        return query;
    }

    private List<Credit> findCredits(final Query query, final String collectionName) {
        return template.find(query, Credit.class, collectionName);
    }

    Update buildUpdate(final Document object, final String... ignoredFields) {
        final Set<String> ignoredFieldsSet = ImmutableSet.copyOf(ignoredFields);
        final Update update = new Update();
        for (Map.Entry<String, Object> entry : object.entrySet()) {
            if (ignoredFieldsSet.contains(entry.getKey())) {
                continue;
            }
            final Object value = entry.getValue();
            final boolean isNotEmpty = value instanceof BasicDBList ? !((BasicDBList) value).isEmpty() : value != null;
            if (isNotEmpty) {
                update.set(entry.getKey(), value);
            } else {
                update.unset(entry.getKey());
            }
        }
        return update;
    }

}
