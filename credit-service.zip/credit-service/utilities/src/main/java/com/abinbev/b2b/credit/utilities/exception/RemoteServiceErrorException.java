package com.abinbev.b2b.credit.utilities.exception;

import org.springframework.http.HttpStatus;

public class RemoteServiceErrorException extends GlobalException {

    public RemoteServiceErrorException(final Issue issue) {
        super(issue, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
