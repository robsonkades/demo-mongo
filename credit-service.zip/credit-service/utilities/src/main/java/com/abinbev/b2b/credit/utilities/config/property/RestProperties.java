package com.abinbev.b2b.credit.utilities.config.property;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties("rest")
public class RestProperties {

    private int readTimeout;

    private int connectTimeout;

    private int maxConnTotal;

    private int maxConnPerRoute;

    private RetryableProperties retryable = new RetryableProperties();

    public int getReadTimeout() {
        return readTimeout;
    }

    public void setReadTimeout(final int readTimeout) {
        this.readTimeout = readTimeout;
    }

    public int getConnectTimeout() {
        return connectTimeout;
    }

    public void setConnectTimeout(final int connectTimeout) {
        this.connectTimeout = connectTimeout;
    }

    public int getMaxConnTotal() {
        return maxConnTotal;
    }

    public void setMaxConnTotal(final int maxConnTotal) {
        this.maxConnTotal = maxConnTotal;
    }

    public int getMaxConnPerRoute() {
        return maxConnPerRoute;
    }

    public void setMaxConnPerRoute(final int maxConnPerRoute) {
        this.maxConnPerRoute = maxConnPerRoute;
    }

    public RetryableProperties getRetryable() {
        return retryable;
    }

    public void setRetryable(final RetryableProperties retryable) {
        this.retryable = retryable;
    }

    public static class RetryableProperties {

        private int maxAttempts;

        private long initialInterval;

        private long maxInterval;

        private double multiplier;

        public int getMaxAttempts() {
            return maxAttempts;
        }

        public void setMaxAttempts(final int maxAttempts) {
            this.maxAttempts = maxAttempts;
        }

        public long getInitialInterval() {
            return initialInterval;
        }

        public void setInitialInterval(final long initialInterval) {
            this.initialInterval = initialInterval;
        }

        public long getMaxInterval() {
            return maxInterval;
        }

        public void setMaxInterval(final long maxInterval) {
            this.maxInterval = maxInterval;
        }

        public double getMultiplier() {
            return multiplier;
        }

        public void setMultiplier(final double multiplier) {
            this.multiplier = multiplier;
        }

    }

}
