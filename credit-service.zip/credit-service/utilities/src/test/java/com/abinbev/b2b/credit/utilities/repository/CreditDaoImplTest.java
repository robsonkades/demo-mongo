package com.abinbev.b2b.credit.utilities.repository;

import static com.abinbev.b2b.credit.utilities.repository.CreditDaoImpl.AVAILABLE_KEY;
import static com.abinbev.b2b.credit.utilities.repository.CreditDaoImpl.BALANCE_KEY;
import static com.abinbev.b2b.credit.utilities.repository.CreditDaoImpl.CHILD_IDS_KEY;
import static com.abinbev.b2b.credit.utilities.repository.CreditDaoImpl.CONSUMPTION_KEY;
import static com.abinbev.b2b.credit.utilities.repository.CreditDaoImpl.ID_KEY;
import static com.abinbev.b2b.credit.utilities.repository.CreditDaoImpl.OVERDUE_KEY;
import static com.abinbev.b2b.credit.utilities.repository.CreditDaoImpl.PARENT_ID_KEY;
import static com.abinbev.b2b.credit.utilities.repository.CreditDaoImpl.PAYMENT_TERMS_KEY;
import static com.abinbev.b2b.credit.utilities.repository.CreditDaoImpl.TOTAL_KEY;
import static com.abinbev.b2b.credit.utilities.repository.CreditDaoImpl.UPDATED_AT;
import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.RETURNS_SELF;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

import org.bson.BsonDocument;
import org.bson.BsonString;
import org.bson.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.data.mongodb.core.BulkOperations;
import org.springframework.data.mongodb.core.BulkOperations.BulkMode;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.util.Pair;

import com.abinbev.b2b.credit.utilities.config.DatabaseCollectionsConfiguration;
import com.abinbev.b2b.credit.utilities.domain.Credit;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.mongodb.MongoBulkWriteException;
import com.mongodb.ServerAddress;
import com.mongodb.bulk.BulkWriteError;
import com.mongodb.bulk.BulkWriteResult;
import com.mongodb.bulk.BulkWriteUpsert;
import com.mongodb.client.result.DeleteResult;
import com.mongodb.client.result.UpdateResult;

@RunWith(MockitoJUnitRunner.class)
public class CreditDaoImplTest {

    private static final String COUNTRY_BR = "BR";
    private static final String CREDIT_COLLECTION_BR = "BR-Credits";

    @InjectMocks
    private CreditDaoImpl dao;

    @Mock
    private MongoTemplate template;

    @Mock
    private DatabaseCollectionsConfiguration databaseCollectionsConfiguration;

    @Before
    public void setup() {
        when(databaseCollectionsConfiguration.findCreditCollectionByCountry(COUNTRY_BR)).thenReturn(CREDIT_COLLECTION_BR);
    }

    @Test
    public void testFindById() {
        final String creditId1 = UUID.randomUUID().toString();

        dao.findById(COUNTRY_BR , creditId1);
        verify(template, Mockito.times(1)).findById(eq(creditId1), eq(Credit.class) , eq(CREDIT_COLLECTION_BR));
    }

    @Test
    public void testUpdateConsumptionSuccessful() {
        final String accountId = UUID.randomUUID().toString();
        final OffsetDateTime updatedAt = OffsetDateTime.now();

        when(template.updateFirst(query(Criteria
                                                .where(ID_KEY)
                                                .is(accountId)
                                                .and(UPDATED_AT)
                                                .is(updatedAt)), Update.update(CONSUMPTION_KEY, BigDecimal.TEN), CREDIT_COLLECTION_BR)).thenReturn(UpdateResult.acknowledged(1L,1L,null));

        dao.updateCreditConsumption(COUNTRY_BR, updatedAt, accountId, BigDecimal.TEN);

        verify(template, times(1)).updateFirst(
                eq(Query.query(Criteria.where(ID_KEY).is(accountId).and(UPDATED_AT).is(updatedAt))),
                eq(Update.update(CONSUMPTION_KEY, BigDecimal.TEN)),
                eq(CREDIT_COLLECTION_BR));
    }

    @Test
    public void testUpdateConsumptionUnsuccessful() {
        final String accountId = UUID.randomUUID().toString();
        final OffsetDateTime updatedAt = OffsetDateTime.now();

        when(template.updateFirst(query(Criteria
                                                .where(ID_KEY)
                                                .is(accountId)
                                                .and(UPDATED_AT)
                                                .is(updatedAt)), Update.update(CONSUMPTION_KEY, BigDecimal.TEN), CREDIT_COLLECTION_BR)).thenReturn(UpdateResult.acknowledged(0L,0L,null));

        dao.updateCreditConsumption(COUNTRY_BR, updatedAt, accountId, BigDecimal.TEN);

        verify(template, times(1)).updateFirst(
                eq(Query.query(Criteria.where(ID_KEY).is(accountId).and(UPDATED_AT).is(updatedAt))),
                eq(Update.update(CONSUMPTION_KEY, BigDecimal.TEN)),
                eq(CREDIT_COLLECTION_BR));
    }

    @Test
    public void testFindByAccountIds() {
        final String accountId1 = UUID.randomUUID().toString();
        final String accountId2 = UUID.randomUUID().toString();
        final String accountId3 = UUID.randomUUID().toString();

        final List<String> accountIds = ImmutableList.of(accountId1, accountId2, accountId3);

        dao.findByAccountIds(COUNTRY_BR , accountIds);
        verify(template, Mockito.times(1)).find(any(Query.class), eq(Credit.class) , eq(CREDIT_COLLECTION_BR));
    }

    @Test
    public void testFindByAccountIdsWithEmptyArgument() {
        dao.findByAccountIds(COUNTRY_BR , Collections.emptyList());
        verify(template, Mockito.times(0)).find(any(Query.class), eq(Credit.class) , eq(CREDIT_COLLECTION_BR));
    }

    @Test
    public void testRemove() {
        final String accountId1 = UUID.randomUUID().toString();
        final String accountId2 = UUID.randomUUID().toString();
        final String accountId3 = UUID.randomUUID().toString();

        final List<String> accountIds = ImmutableList.of(accountId1, accountId2, accountId3);

        final Query query = new Query().addCriteria(Criteria
                                                            .where(ID_KEY)
                                                            .in(accountIds));

        when(this.template.remove(query, CREDIT_COLLECTION_BR)).thenReturn(DeleteResult.acknowledged(3));

        dao.remove(COUNTRY_BR, accountIds);
        verify(template, Mockito.times(1)).remove(query, CREDIT_COLLECTION_BR);
    }

    @Test
    public void testRemoveWithEmptyArgument() {
        dao.remove(COUNTRY_BR, Collections.emptyList());
        verify(template, Mockito.times(0)).remove(any(), eq(CREDIT_COLLECTION_BR));
    }

    @Test
    public void testRemoveChildCredits() {
        final String accountId1 = UUID
                .randomUUID()
                .toString();
        final String accountId2 = UUID
                .randomUUID()
                .toString();
        final String accountId3 = UUID
                .randomUUID()
                .toString();
        final String parentId = "xpto";

        final List<String> accountIds = ImmutableList.of(accountId1, accountId2, accountId3);
        final OffsetDateTime timestamp = OffsetDateTime.now();

        final List<Query> queries = ImmutableList.of(Query.query(where(ID_KEY)
                                                                       .is(accountId1)
                                                                       .and(PARENT_ID_KEY)
                                                                       .is(parentId)
                                                                       .and(UPDATED_AT)
                                                                       .lt(timestamp)), Query.query(where(ID_KEY)
                                                                                                            .is(accountId2)
                                                                                                            .and(PARENT_ID_KEY)
                                                                                                            .is(parentId)
                                                                                                            .and(UPDATED_AT)
                                                                                                            .lt(timestamp)), Query.query(where(ID_KEY)
                                                                                                                                                 .is(accountId3)
                                                                                                                                                 .and(PARENT_ID_KEY)
                                                                                                                                                 .is(parentId)
                                                                                                                                                 .and(UPDATED_AT)
                                                                                                                                                 .lt(timestamp)));

        BulkOperations bulkOperations = mock(BulkOperations.class, RETURNS_SELF);
        final BulkWriteResult acknowledged = BulkWriteResult.acknowledged(0, 0, 3, 0, Collections.emptyList());
        when(this.template.bulkOps(BulkMode.UNORDERED, CREDIT_COLLECTION_BR)).thenReturn(bulkOperations);
        when(bulkOperations.remove(eq(queries))).thenReturn(bulkOperations);
        when(bulkOperations.remove(eq(queries)).execute()).thenReturn(acknowledged);

        dao.removeChildCredits(COUNTRY_BR, "xpto", timestamp, accountIds);

        verify(bulkOperations, times(1)).remove(eq(queries));
        verify(bulkOperations, times(1)).execute();
    }

    @Test(expected = MongoBulkWriteException.class)
    public void testRemoveChildCreditsThrowingException() {
        final String accountId1 = UUID
                .randomUUID()
                .toString();
        final String accountId2 = UUID
                .randomUUID()
                .toString();
        final String accountId3 = UUID
                .randomUUID()
                .toString();
        final String parentId = "xpto";

        final List<String> accountIds = ImmutableList.of(accountId1, accountId2, accountId3);
        final OffsetDateTime timestamp = OffsetDateTime.now();

        final List<Query> queries = ImmutableList.of(Query.query(where(ID_KEY)
                                                                         .is(accountId1)
                                                                         .and(PARENT_ID_KEY)
                                                                         .is(parentId)
                                                                         .and(UPDATED_AT)
                                                                         .lt(timestamp)), Query.query(where(ID_KEY)
                                                                                                              .is(accountId2)
                                                                                                              .and(PARENT_ID_KEY)
                                                                                                              .is(parentId)
                                                                                                              .and(UPDATED_AT)
                                                                                                              .lt(timestamp)), Query.query(where(ID_KEY)
                                                                                                                                                   .is(accountId3)
                                                                                                                                                   .and(PARENT_ID_KEY)
                                                                                                                                                   .is(parentId)
                                                                                                                                                   .and(UPDATED_AT)
                                                                                                                                                   .lt(timestamp)));

        BulkOperations bulkOperations = mock(BulkOperations.class, RETURNS_SELF);
        final BulkWriteResult acknowledged = BulkWriteResult.acknowledged(0, 0, 0, 0, Collections.emptyList());
        final List<BulkWriteError> updateFailure = List.of(
                new BulkWriteError(11000, "E11000 duplicate key error", new BsonDocument(), 1)
        );
        when(this.template.bulkOps(BulkMode.UNORDERED, CREDIT_COLLECTION_BR)).thenReturn(bulkOperations);
        when(bulkOperations.remove(eq(queries))).thenReturn(bulkOperations);
        when(bulkOperations.remove(eq(queries)).execute()).thenThrow(new MongoBulkWriteException(acknowledged, updateFailure, null, new ServerAddress()));
        try {
            dao.removeChildCredits(COUNTRY_BR, parentId, timestamp, accountIds);
        } catch (final Exception e){
            verify(bulkOperations, times(1)).remove(eq(queries));
            verify(bulkOperations, times(1)).execute();
            throw e;
        }
    }

    @Test
    public void testRemoveChildCreditsWithEmptyList() {
        final BulkOperations bulkOperations = mock(BulkOperations.class, RETURNS_SELF);
        dao.removeChildCredits(COUNTRY_BR, "xpto", OffsetDateTime.now(), Collections.emptyList());
        verify(bulkOperations, times(0)).execute();
    }

    @Test
    public void testUpsertChildCredits() {
        final String parentId = "xpto";

        final String ac1 = UUID.randomUUID().toString();
        final String ac2 = UUID.randomUUID().toString();
        final String ac3 = UUID.randomUUID().toString();

        final OffsetDateTime timestamp = OffsetDateTime.now();
        final List<Credit> credits = ImmutableList.of(
                new Credit(ac1, parentId, timestamp),
                new Credit(ac2, parentId, timestamp),
                new Credit(ac3, parentId, timestamp)
        );

        final List<Pair<Query, Update>> updates = new ArrayList<>();

        for(final Credit credit : credits){
            final Document doc = this.dao.createDocument(credit);
            final Query query = Query.query(where(ID_KEY)
                                                    .is(credit.getAccountId())
                                                    .and(UPDATED_AT)
                                                    .lt(credit.getUpdatedAt())
            );
            updates.add(Pair.of(query, this.dao.buildUpdate(doc, ID_KEY)));
        }

        BulkOperations bulkOperations = mock(BulkOperations.class, RETURNS_SELF);
        final BulkWriteResult acknowledged = BulkWriteResult.acknowledged(1, 0, 0, 2, List.of(new BulkWriteUpsert(0, new BsonString("1234"))));
        when(this.template.bulkOps(BulkMode.UNORDERED, CREDIT_COLLECTION_BR)).thenReturn(bulkOperations);
        when(bulkOperations.upsert(eq(updates))).thenReturn(bulkOperations);
        when(bulkOperations.upsert(eq(updates)).execute()).thenReturn(acknowledged);

        dao.upsertChildCredits(COUNTRY_BR, credits);

        verify(bulkOperations, times(1)).upsert(eq(updates));
        verify(bulkOperations, times(1)).execute();
    }

    @Test(expected = MongoBulkWriteException.class)
    public void testUpsertChildCreditsThrowingException() {
        final String parentId = "xpto";

        final String ac1 = UUID.randomUUID().toString();
        final String ac2 = UUID.randomUUID().toString();
        final String ac3 = UUID.randomUUID().toString();

        final OffsetDateTime timestamp = OffsetDateTime.now();
        final List<Credit> credits = ImmutableList.of(
                new Credit(ac1, parentId, timestamp),
                new Credit(ac2, parentId, timestamp),
                new Credit(ac3, parentId, timestamp)
        );

        final List<Pair<Query, Update>> updates = new ArrayList<>();

        for(final Credit credit : credits){
            final Document doc = this.dao.createDocument(credit);
            final Query query = Query.query(where(ID_KEY)
                                                    .is(credit.getAccountId())
                                                    .and(UPDATED_AT)
                                                    .lt(credit.getUpdatedAt())
            );
            updates.add(Pair.of(query, this.dao.buildUpdate(doc, ID_KEY)));
        }

        BulkOperations bulkOperations = mock(BulkOperations.class, RETURNS_SELF);
        final BulkWriteResult acknowledged = BulkWriteResult.acknowledged(0, 0, 0, 0, Collections.emptyList());
        final List<BulkWriteError> updateFailure = List.of(
                new BulkWriteError(11000, "E11000 duplicate key error", new BsonDocument(), 1)
        );
        when(this.template.bulkOps(BulkMode.UNORDERED, CREDIT_COLLECTION_BR)).thenReturn(bulkOperations);
        when(bulkOperations.upsert(eq(updates))).thenReturn(bulkOperations);
        when(bulkOperations.upsert(eq(updates)).execute()).thenThrow(new MongoBulkWriteException(acknowledged, updateFailure, null, new ServerAddress()));

        try {
            dao.upsertChildCredits(COUNTRY_BR, credits);
        } catch (final Exception e){
            verify(bulkOperations, times(1)).upsert(eq(updates));
            verify(bulkOperations, times(1)).execute();
            throw e;
        }
    }

    @Test
    public void testUpsertChildCreditsWithEmptyList() {
        final BulkOperations bulkOperations = mock(BulkOperations.class, RETURNS_SELF);
        dao.upsertChildCredits(COUNTRY_BR, Collections.emptyList());
        verify(bulkOperations, times(0)).execute();
    }

    @Test
    public void testRemoveCreditSuccessful() {
        final OffsetDateTime updatedAt = OffsetDateTime.now();
        final String accountId = UUID.randomUUID().toString();

        final Query expectedQuery = new Query().addCriteria(Criteria
                                                            .where(ID_KEY)
                                                            .is(accountId)
                                                            .and(UPDATED_AT)
                                                            .lte(updatedAt)
                                                            .and(PARENT_ID_KEY)
                                                            .exists(false) // avoid shared credit removal
        );

        when(this.template.remove(expectedQuery, CREDIT_COLLECTION_BR)).thenReturn(DeleteResult.acknowledged(1L));

        final boolean wasSuccessful = dao.remove(COUNTRY_BR, updatedAt, accountId);

        assertThat(wasSuccessful).isTrue();
        verify(template, times(1)).remove(expectedQuery, CREDIT_COLLECTION_BR);
    }

    @Test
    public void testRemoveCreditUnsuccessful() {
        final OffsetDateTime updatedAt = OffsetDateTime.now();
        final String accountId = UUID.randomUUID().toString();

        final Query expectedQuery = new Query().addCriteria(Criteria
                                                                    .where(ID_KEY)
                                                                    .is(accountId)
                                                                    .and(UPDATED_AT)
                                                                    .lte(updatedAt)
                                                                    .and(PARENT_ID_KEY)
                                                                    .exists(false) // avoid shared credit removal
        );

        when(this.template.remove(expectedQuery, CREDIT_COLLECTION_BR)).thenReturn(DeleteResult.acknowledged(0L));

        final boolean wasSuccessful = dao.remove(COUNTRY_BR, updatedAt, accountId);

        assertThat(wasSuccessful).isFalse();
        verify(template, times(1)).remove(expectedQuery, CREDIT_COLLECTION_BR);
    }

    @Test
    public void testRemoveCreditUnsuccessfulForANullResult() {
        final OffsetDateTime updatedAt = OffsetDateTime.now();
        final String accountId = UUID.randomUUID().toString();

        final Query expectedQuery = new Query().addCriteria(Criteria
                                                                    .where(ID_KEY)
                                                                    .is(accountId)
                                                                    .and(UPDATED_AT)
                                                                    .lte(updatedAt)
                                                                    .and(PARENT_ID_KEY)
                                                                    .exists(false) // avoid shared credit removal
        );

        lenient().when(this.template.remove(expectedQuery, CREDIT_COLLECTION_BR)).thenReturn(null);

        final boolean wasSuccessful = dao.remove(COUNTRY_BR, updatedAt, accountId);

        assertThat(wasSuccessful).isFalse();
        verify(template, times(1)).remove(expectedQuery, CREDIT_COLLECTION_BR);
    }


    @Test
    public void testCreateDocument(){
        final Credit credit = new Credit();
        credit.setAccountId("111111");
        credit.setParentId("99999");
        credit.setUpdatedAt(OffsetDateTime.now());
        credit.setAvailable(BigDecimal.TEN);
        credit.setBalance(BigDecimal.ONE);
        credit.setConsumption(BigDecimal.ZERO);
        credit.setOverdue(new BigDecimal("7"));
        credit.setPaymentTerms("xpto");
        credit.setTotal(new BigDecimal("20"));
        credit.setParentId("parent");
        credit.setChildIds(ImmutableSet.of("1","2"));

        final Document document = dao.createDocument(credit);

        assertThat(document).containsKeys(ID_KEY, UPDATED_AT, AVAILABLE_KEY, BALANCE_KEY, CONSUMPTION_KEY, OVERDUE_KEY, PAYMENT_TERMS_KEY, TOTAL_KEY, PARENT_ID_KEY, CHILD_IDS_KEY);
        assertThat(document.get(ID_KEY)).isEqualTo(credit.getAccountId());
        assertThat(document.get(UPDATED_AT)).isEqualTo(credit.getUpdatedAt());
        assertThat(document.get(AVAILABLE_KEY)).isEqualTo(credit.getAvailable());
        assertThat(document.get(BALANCE_KEY)).isEqualTo(credit.getBalance());
        assertThat(document.get(CONSUMPTION_KEY)).isEqualTo(credit.getConsumption());
        assertThat(document.get(OVERDUE_KEY)).isEqualTo(credit.getOverdue());
        assertThat(document.get(PAYMENT_TERMS_KEY)).isEqualTo(credit.getPaymentTerms());
        assertThat(document.get(TOTAL_KEY)).isEqualTo(credit.getTotal());
        assertThat(document.get(PARENT_ID_KEY)).isEqualTo(credit.getParentId());
        assertThat(document.get(CHILD_IDS_KEY)).isEqualTo(credit.getChildIds());

    }
}
