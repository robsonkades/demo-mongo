package com.abinbev.b2b.credit.utilities.config;

import com.abinbev.b2b.credit.utilities.exception.BadRequestException;
import com.abinbev.b2b.credit.utilities.exception.Issue;
import com.abinbev.b2b.credit.utilities.exception.IssueEnum;
import com.google.common.collect.ImmutableMap;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.Map;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class DatabaseCollectionsConfigurationTest {

    private static final String COUNTRY_DO = "do";

    private static final String COLLECTION_CREDITS_DO = "DO-Credits";

    private static final String COUNTRY_BR = "br";

    private static final String COLLECTION_CREDITS_BR = "BR-Credits";

    @InjectMocks
    private DatabaseCollectionsConfiguration databaseCollectionProperties;

    @Before
    public void setUp() {
        final Map<String, String> collections = ImmutableMap.of(COUNTRY_BR, COLLECTION_CREDITS_BR, COUNTRY_DO, COLLECTION_CREDITS_DO);
        ReflectionTestUtils.setField(databaseCollectionProperties, "credits", collections);
    }

    @Test
    public void testGetCreditsCollectionByCountry() {
        assertThat(databaseCollectionProperties.findCreditCollectionByCountry(COUNTRY_BR.toLowerCase())).isNotNull();
        assertThat(databaseCollectionProperties.findCreditCollectionByCountry(COUNTRY_BR.toUpperCase())).isEqualTo(COLLECTION_CREDITS_BR);
    }

    @Test(expected = BadRequestException.class)
    public void testGetCreditsCollectionByCountryWithInvalidCountry() {
        databaseCollectionProperties.findCreditCollectionByCountry("XPTO");
    }

    @Test
    public void testGetCredits() {
        assertThat(databaseCollectionProperties.getCredits()).isNotNull();
    }

    @Test
    public void testSetCreditsByJsonEnv() {
        final Map<String, String> creditCollection = ImmutableMap.of(COUNTRY_BR, COLLECTION_CREDITS_BR);
        final String toJson = "{\"ar\":\"AR-Credits\"}";
        ReflectionTestUtils.setField(databaseCollectionProperties, "creditCollectionsFromEnv", toJson);
        databaseCollectionProperties.setCredits(creditCollection);
        assertThat(databaseCollectionProperties.getCredits()).doesNotContainEntry(COUNTRY_BR, COLLECTION_CREDITS_BR);
        assertThat(databaseCollectionProperties.getCredits()).containsEntry("ar", "AR-Credits");
    }

    @Test
    public void testSetTickets() {
        final Map<String, String> creditCollections = ImmutableMap.of(COUNTRY_DO, COLLECTION_CREDITS_DO);
        databaseCollectionProperties.setCredits(creditCollections);
        assertThat(databaseCollectionProperties.getCredits()).isNotEmpty();
        assertThat(databaseCollectionProperties.getCredits()).containsEntry(COUNTRY_DO, COLLECTION_CREDITS_DO);
    }


    @Test(expected = BadRequestException.class)
    public void testFindCreditsCollectionByCountryWithNullEntries() {
        databaseCollectionProperties.setCredits(null);
        try {
            databaseCollectionProperties.findCreditCollectionByCountry(COUNTRY_DO);
        } catch (final BadRequestException e){
            final List<Issue> issues = e.getIssues();
            assertThat(issues).isNotEmpty();
            assertThat(issues.size()).isOne();
            assertThat(issues.get(0).getCode()).isEqualTo(IssueEnum.UNSUPPORTED_COUNTRY.getCode());
            assertThat(issues.get(0).getMessage()).isEqualTo(IssueEnum.UNSUPPORTED_COUNTRY.getFormattedMessage(COUNTRY_DO.toLowerCase(), null));
            throw e;
        }
    }

    @Test
    public void testGetSupportedCountriesWithNullEntries() {
        databaseCollectionProperties.setCredits(null);

        final Set<String> supportedCountries = databaseCollectionProperties.getSupportedCountries();
        assertThat(supportedCountries).isEmpty();
    }

    @Test
    public void testGetSupportedCountries() {
        final Map<String, String> creditCollections = ImmutableMap.of(COUNTRY_DO, COLLECTION_CREDITS_DO);
        databaseCollectionProperties.setCredits(creditCollections);

        final Set<String> supportedCountries = databaseCollectionProperties.getSupportedCountries();
        assertThat(supportedCountries).isEqualTo(creditCollections.keySet());
    }

    @Test
    public void testSetCreditsCollectionsWithWrongJson() {
        final Map<String, String> creditCollections = ImmutableMap.of(COUNTRY_DO, COLLECTION_CREDITS_DO);
        final String toJsonError = "br\"::\"DO-Credits\"}}}}";
        ReflectionTestUtils.setField(databaseCollectionProperties, "creditCollectionsFromEnv", toJsonError);
        databaseCollectionProperties.setCredits(creditCollections);
        assertThat(databaseCollectionProperties.getCredits()).isNull();
    }
}
