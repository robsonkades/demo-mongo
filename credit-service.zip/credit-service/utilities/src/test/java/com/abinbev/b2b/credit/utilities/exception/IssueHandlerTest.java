package com.abinbev.b2b.credit.utilities.exception;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import static org.assertj.core.api.Assertions.assertThat;

@RunWith(MockitoJUnitRunner.class)
public class IssueHandlerTest {

    @Test
    public void testCreateIssue() {
        final Issue expectedIssue = new Issue(IssueEnum.INVALID_COUNTRY.getCode(), "The country 'XPTO' is not valid");

        final Issue issueCreated = IssueHandler.createIssue(IssueEnum.INVALID_COUNTRY, "XPTO");

        assertThat(issueCreated).isNotNull();
        assertThat(issueCreated).isEqualTo(expectedIssue);
    }

    @Test
    public void testCreateIssueForException() {
        final Issue expectedIssue = new Issue(IssueEnum.GENERIC_EXCEPTION.getCode(), "error");

        final RuntimeException exception = new RuntimeException("error");
        final Issue issueCreated = IssueHandler.createIssue(exception);

        assertThat(issueCreated).isNotNull();
        assertThat(issueCreated).isEqualTo(expectedIssue);
    }
}